---
id: RED-L3-029
locale: fr-FR
source_locale: en-US
track: RED
level: 3
lesson: 29
title: "Pourquoi les clauses restrictives d'un prêt peuvent limiter ce que vous faites de votre bien"
source_title: "Why Loan Covenants Can Restrict What You Do With a Property"
description: "Découvrez pourquoi certains prêts contiennent des conditions permanentes que l'emprunteur doit respecter, et pourquoi les enfreindre peut entraîner des conséquences au-delà d'un simple retard de paiement."
slug: red-l3-029-loan-covenants
seo_title: "Pourquoi les clauses restrictives d'un prêt peuvent limiter ce que vous faites de votre bien | Edunancial"
meta_description: "Découvrez pourquoi certains prêts contiennent des conditions permanentes que l'emprunteur doit respecter, et pourquoi les enfreindre peut entraîner des conséquences au-delà d'un simple retard de paiement."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-029: Pourquoi les clauses restrictives d'un prêt peuvent limiter ce que vous faites de votre bien

## Objectifs d'apprentissage
À la fin de cette leçon, vous serez capable de :
- Expliquer ce qu'est une clause restrictive (covenant) de prêt
- Donner un exemple de clause courante dans le financement immobilier
- Expliquer pourquoi enfreindre une clause peut avoir des conséquences même sans retard de paiement

## Contenu principal

Une **clause restrictive de prêt** (loan covenant) est une condition permanente, écrite dans le contrat de prêt, que l'emprunteur doit respecter pendant toute la durée du prêt, en plus de simplement payer à temps. Ces clauses sont plus courantes dans les prêts commerciaux (leçon 16) que dans les prêts immobiliers résidentiels classiques.

Un exemple courant est une clause de DSCR minimum (ratio de couverture du service de la dette, en lien avec la leçon 20) : le contrat de prêt peut exiger que le bien garde un DSCR supérieur à un certain niveau pendant toute la durée du prêt, et pas seulement au moment de l'accord. D'autres clauses peuvent limiter les emprunts supplémentaires sur le bien, exiger l'accord du prêteur avant de gros travaux de rénovation ou exiger des rapports financiers réguliers sur les performances du bien.

Voici le « pourquoi » : enfreindre une clause s'appelle être « en défaut », même si chaque paiement a été fait à temps. [VERIFIED FACT] Selon le contrat de prêt, une infraction à une clause peut donner au prêteur le droit d'exiger le remboursement immédiat du prêt, de modifier les conditions ou de prendre d'autres mesures prévues ; les conséquences exactes dépendent entièrement des termes précis du contrat de ce prêt.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un prêt commercial sur un immeuble d'appartements comprend une clause qui exige que le bien garde un DSCR d'au moins 1.15 pendant toute la durée du prêt. L'investisseur a fait chaque paiement à temps, mais une hausse temporaire de la vacance locative fait baisser le DSCR réel du bien à 1.05 pendant une période de déclaration. [ASSUMPTION] Même si aucun paiement n'a été manqué, cela pourrait déclencher un défaut au titre de la clause du contrat de prêt et donner potentiellement au prêteur les droits prévus dans ce contrat, une conséquence totalement indépendante de l'historique de paiement de l'investisseur.

## Quiz d'entraînement

1. Qu'est-ce qu'une clause restrictive de prêt ?
2. Donnez un exemple de clause restrictive courante dans un prêt immobilier.
3. Pourquoi une infraction à une clause peut-elle être considérée comme un défaut même si les paiements sont à jour ?

## Corrigé

1. Une condition permanente écrite dans un contrat de prêt, que l'emprunteur doit respecter pendant toute la durée du prêt, en plus de faire ses paiements.
2. Une exigence de DSCR minimum est un exemple courant (d'autres exemples : des limites aux emprunts supplémentaires ou l'obligation d'obtenir l'accord du prêteur avant de gros changements sur le bien).
3. Parce que le contrat de prêt définit le défaut par le respect de conditions précises, et pas seulement par l'historique de paiement ; enfreindre n'importe quelle clause définie peut déclencher un défaut, quel que soit l'état des paiements.

## Réponses et explications

1. C'est la définition de base nécessaire pour le reste de la leçon.
2. Cette réponse relie la notion abstraite à un exemple concret déjà présenté dans la leçon 20.
3. C'est le point central, facile à négliger : le défaut ne concerne pas seulement les paiements manqués.

## Points clés
- Les clauses restrictives de prêt sont des conditions permanentes que l'emprunteur doit respecter pendant toute la durée d'un prêt ; elles sont courantes dans le financement commercial.
- Un exemple courant est une exigence de DSCR minimum, qui doit être maintenue et pas seulement atteinte à la signature.
- Enfreindre une clause peut déclencher un défaut même si chaque paiement a été fait à temps, avec des conséquences définies par le contrat de prêt concerné.

---

*Cette leçon est fournie uniquement à des fins d'éducation financière générale et ne constitue pas un conseil financier, d'investissement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations illustratives, et non des garanties. Consultez un professionnel agréé avant de prendre des décisions financières.*
