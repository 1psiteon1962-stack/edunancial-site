---
id: RED-L3-030
locale: fr-FR
source_locale: en-US
track: RED
level: 3
lesson: 30
title: "Pourquoi la dette mezzanine se situe entre les capitaux propres et le prêt immobilier"
source_title: "Why Mezzanine Debt Sits Between Equity and a Mortgage"
description: "Découvrez ce qu'est la dette mezzanine, pourquoi elle est plus risquée et plus chère qu'un prêt immobilier de premier rang, et dans quels cas on l'utilise habituellement."
slug: red-l3-030-mezzanine-debt
seo_title: "Pourquoi la dette mezzanine se situe entre les capitaux propres et le prêt immobilier | Edunancial"
meta_description: "Découvrez ce qu'est la dette mezzanine, pourquoi elle est plus risquée et plus chère qu'un prêt immobilier de premier rang, et dans quels cas on l'utilise habituellement."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-030: Pourquoi la dette mezzanine se situe entre les capitaux propres et le prêt immobilier

## Objectifs d'apprentissage
À la fin de cette leçon, vous serez capable de :
- Expliquer où se situe la dette mezzanine dans la structure de financement d'un bien
- Expliquer pourquoi les prêteurs mezzanine demandent des taux plus élevés que les prêteurs de premier rang
- Identifier un cas typique d'utilisation du financement mezzanine

## Contenu principal

La « structure de financement » (capital stack) d'un bien décrit les couches d'argent utilisées pour le financer, classées selon leur priorité de remboursement si quelque chose tourne mal. Un prêt immobilier de premier rang se trouve généralement en haut de cet ordre de priorité : il est payé en premier avec l'argent obtenu si le bien est vendu ou saisi. Les capitaux propres (l'argent de l'investisseur lui-même) se trouvent généralement en bas : ils sont payés en dernier, s'il reste quelque chose.

La **dette mezzanine** se situe entre les deux : c'est une couche secondaire de financement, subordonnée au prêt immobilier de premier rang mais prioritaire sur les investisseurs en capitaux propres. Voici le « pourquoi » de son coût : comme les prêteurs mezzanine ne sont remboursés qu'une fois le prêt de premier rang réglé, ils prennent plus de risques qu'un prêteur de premier rang, et ils font payer ce risque avec un taux d'intérêt nettement plus élevé, souvent plus proche de ce qu'attendrait un investisseur en capitaux propres que de ce que demanderait un prêteur immobilier.

La dette mezzanine est généralement utilisée pour de grandes opérations commerciales, quand le prêt de premier rang seul ne couvre pas tout le montant nécessaire et que le promoteur (sponsor) veut combler l'écart avec de la dette plutôt que de faire entrer plus d'investisseurs en capitaux propres et de diluer encore la propriété.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] L'achat d'un bien commercial nécessite 10 millions $ de capitaux au total. Un prêt de premier rang couvre 6.5 millions $ à un taux relativement bas, qui reflète sa position prioritaire de remboursement. Au lieu de lever les 3.5 millions $ restants uniquement auprès d'investisseurs en capitaux propres, le promoteur utilise 1.5 million $ de dette mezzanine, à un taux sensiblement plus élevé qui reflète sa position subordonnée, et lève les 2 millions $ restants en capitaux propres. Cette structure en couches comble le besoin de financement tout en cédant moins de propriété que si tout le montant restant avait été levé en capitaux propres.

## Quiz d'entraînement

1. Où se situe la dette mezzanine dans la structure de financement d'un bien, par rapport au prêt de premier rang et aux capitaux propres ?
2. Pourquoi les prêteurs mezzanine demandent-ils des taux plus élevés que les prêteurs de premier rang ?
3. Pourquoi un promoteur pourrait-il utiliser de la dette mezzanine plutôt que de lever plus de capitaux propres ?

## Corrigé

1. Entre le prêt de premier rang (prioritaire) et les capitaux propres (subordonnés) : subordonnée au prêt, mais prioritaire sur les investisseurs en capitaux propres.
2. Parce qu'ils ne sont remboursés qu'une fois le prêt de premier rang réglé, ce qui rend leur position plus risquée, et ce risque se traduit par un taux plus élevé.
3. Pour combler un besoin de financement sans diluer davantage la propriété entre les investisseurs en capitaux propres, puisque la dette n'oblige pas à céder une part de propriété.

## Réponses et explications

1. Cette réponse établit la position structurelle qui explique tout le reste sur la dette mezzanine.
2. C'est la logique centrale de la leçon sur le prix du risque.
3. Cette réponse explique la raison commerciale concrète pour laquelle les promoteurs choisissent cette couche de financement.

## Points clés
- La dette mezzanine se situe entre le prêt de premier rang et les capitaux propres dans la structure de financement d'un bien.
- Sa position de remboursement subordonnée signifie plus de risque pour le prêteur, ce qui se traduit par un taux d'intérêt plus élevé.
- Elle est souvent utilisée pour de grandes opérations afin de combler un besoin de financement sans diluer la propriété autant qu'une levée de capitaux propres supplémentaire.

---

*Cette leçon est fournie uniquement à des fins d'éducation financière générale et ne constitue pas un conseil financier, d'investissement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations illustratives, et non des garanties. Consultez un professionnel agréé avant de prendre des décisions financières.*
