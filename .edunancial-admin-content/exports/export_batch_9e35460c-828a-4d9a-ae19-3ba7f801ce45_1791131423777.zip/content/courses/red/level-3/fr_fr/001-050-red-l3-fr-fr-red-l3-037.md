---
id: RED-L3-037
locale: fr-FR
source_locale: en-US
track: RED
level: 3
lesson: 37
title: "Pourquoi le rang des sûretés détermine qui est payé en premier"
source_title: "Why Lien Priority Determines Who Gets Paid First"
description: "Découvrez comment les sûretés sur un bien sont classées, pourquoi ce classement compte si le bien est vendu ou saisi, et quel est le lien avec la garantie croisée."
slug: red-l3-037-lien-priority
seo_title: "Pourquoi le rang des sûretés détermine qui est payé en premier | Edunancial"
meta_description: "Découvrez comment les sûretés sur un bien sont classées, pourquoi ce classement compte si le bien est vendu ou saisi, et quel est le lien avec la garantie croisée."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-037: Pourquoi le rang des sûretés détermine qui est payé en premier

## Objectifs d'apprentissage
À la fin de cette leçon, vous serez capable de :
- Expliquer ce qu'est une sûreté (lien) et comment son rang est généralement déterminé
- Expliquer pourquoi le rang des sûretés compte si un bien est vendu ou saisi
- Relier cette notion à la garantie croisée (cross-collateralization) vue dans la leçon 19

## Contenu principal

Une **sûreté** (lien) est un droit légal sur un bien, qui garantit généralement une dette. Un prêt immobilier en est un exemple courant, mais une sûreté peut aussi naître de travaux d'entrepreneur impayés, d'impôts impayés ou d'autres réclamations légales. Quand plusieurs sûretés pèsent sur le même bien, le **rang des sûretés** (lien priority) détermine l'ordre dans lequel chacune est payée si le bien est vendu ou saisi.

Voici le « pourquoi » général de ce classement : [VERIFIED FACT] le rang des sûretés est souvent, mais pas toujours, déterminé par l'ordre dans lequel elles ont été enregistrées. Un prêt immobilier de « premier rang » a généralement priorité sur un prêt de « second rang » ou sur une HELOC (ligne de crédit garantie par la valeur nette du bien, leçon 21) enregistrés plus tard : le créancier de premier rang est donc payé en totalité avant que quoi que ce soit ne revienne aux sûretés de rang inférieur. Certaines sûretés, comme celles liées à la taxe foncière, peuvent avoir priorité selon des règles précises, quelle que soit leur date d'enregistrement ; les règles exactes varient selon la juridiction et le type de sûreté.

Cela compte directement pour le risque réel : si un bien est vendu pour moins que le total des dettes qui pèsent sur lui, les créanciers de rang inférieur peuvent ne recevoir que peu de chose, voire rien, même si leur créance est tout à fait légitime. C'est aussi pour cela que la garantie croisée (leçon 19) peut être particulièrement risquée : un prêteur qui a des droits sur plusieurs biens peut avoir un rang différent sur chacun d'eux, ce qui ajoute de la complexité à un risque déjà très interconnecté.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un bien porte un prêt immobilier de premier rang de 150 000 $ et une HELOC (sûreté de second rang) de 30 000 $. Si le bien est saisi et vendu 160 000 $ après frais, le prêteur de premier rang est payé en premier, pour la totalité de ses 150 000 $, ce qui ne laisse que 10 000 $ pour le prêteur de la HELOC. Celui-ci est créancier de 30 000 $, mais ne récupère qu'une partie de cette somme à cause de son rang inférieur.

## Quiz d'entraînement

1. Qu'est-ce qu'une sûreté ?
2. D'après cette leçon, comment le rang des sûretés est-il généralement déterminé ?
3. Dans l'exemple pratique, pourquoi le prêteur de la HELOC ne récupère-t-il pas la totalité de ce qui lui est dû ?

## Corrigé

1. Un droit légal sur un bien, qui garantit généralement une dette.
2. En général, par l'ordre dans lequel les sûretés ont été enregistrées, même si certains types de sûretés (comme certaines sûretés liées à la taxe foncière) peuvent avoir priorité quel que soit l'ordre d'enregistrement, et les règles varient selon la juridiction.
3. Parce que le prêt de premier rang a priorité et est payé en totalité en premier ; seul le reste du produit de la vente revient à la HELOC de rang inférieur, et ce reste est inférieur au montant total dû.

## Réponses et explications

1. C'est la définition de base nécessaire pour la leçon.
2. Cette question pose la règle générale, avec les nuances qui s'imposent vu les différences entre juridictions.
3. Cette question montre, chiffres à l'appui, la conséquence de l'ordre de priorité dans un scénario réel.

## Points clés
- Une sûreté est un droit légal sur un bien, qui garantit souvent une dette comme un prêt immobilier.
- Le rang des sûretés, généralement fondé sur l'ordre d'enregistrement (avec quelques exceptions), détermine qui est payé en premier si un bien est vendu ou saisi.
- Les créanciers de rang inférieur peuvent récupérer peu, voire rien, si le produit de la vente ne couvre pas toutes les dettes, ce qui ajoute un vrai risque à tout financement secondaire.

---

*Cette leçon est fournie uniquement à des fins d'éducation financière générale et ne constitue pas un conseil financier, d'investissement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations illustratives, et non des garanties. Consultez un professionnel agréé avant de prendre des décisions financières.*
