---
id: RED-L3-039
locale: fr-FR
source_locale: en-US
track: RED
level: 3
lesson: 39
title: "Pourquoi la dation en paiement et la vente à découvert sont des voies de sortie différentes"
source_title: "Why Deed-in-Lieu and Short Sales Are Different Exit Paths"
description: "Découvrez deux alternatives à la saisie immobilière — la dation en paiement et la vente à découvert — et pourquoi chacune peut être moins dommageable que de laisser une saisie aller jusqu'au bout."
slug: red-l3-039-deed-in-lieu-and-short-sales
seo_title: "Pourquoi la dation en paiement et la vente à découvert sont des voies de sortie différentes | Edunancial"
meta_description: "Découvrez deux alternatives à la saisie immobilière — la dation en paiement et la vente à découvert — et pourquoi chacune peut être moins dommageable que de laisser une saisie aller jusqu'au bout."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-039: Pourquoi la dation en paiement et la vente à découvert sont des voies de sortie différentes

## Objectifs d'apprentissage
À la fin de cette leçon, vous serez capable de :
- Expliquer ce qu'est une dation en paiement (deed-in-lieu of foreclosure)
- Expliquer ce qu'est une vente à découvert (short sale) et dans quels cas on peut y recourir
- Expliquer pourquoi ces deux solutions sont généralement considérées comme moins dommageables qu'une saisie immobilière menée à son terme

## Contenu principal

Quand un emprunteur est en grande difficulté financière et qu'un défaut de paiement semble probable ou a déjà eu lieu, la saisie immobilière (leçon 38) n'est pas la seule issue possible. Deux alternatives courantes sont la dation en paiement et la vente à découvert.

Une **dation en paiement** (deed-in-lieu of foreclosure) est un accord par lequel l'emprunteur transfère volontairement le titre de propriété du bien au prêteur, en échange de quoi le prêteur le libère du reste de son obligation de remboursement, ce qui évite une procédure officielle de saisie.

Une **vente à découvert** (short sale) a lieu quand le bien est vendu pour moins que le solde restant du prêt, avec l'accord du prêteur pour accepter le produit de la vente comme règlement (total ou partiel) de la dette, plutôt que d'exiger la totalité du solde.

Voici pourquoi ces deux alternatives existent : [VERIFIED FACT] la saisie immobilière coûte généralement cher et prend du temps pour les prêteurs, et une dation en paiement comme une vente à découvert peuvent permettre de régler la situation plus vite et à moindre coût pour les deux parties, par rapport à une procédure de saisie complète. Cependant, les résultats, l'effet sur le dossier de crédit et toute responsabilité restante pour l'emprunteur peuvent varier beaucoup selon la situation, le prêteur et la juridiction.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse possède un bien « sous l'eau » (qui vaut moins que le solde du prêt) et ne peut plus assumer les mensualités ; elle contacte son prêteur avant de cesser complètement de payer. Plutôt que d'avancer vers une saisie, ils négocient une vente à découvert : le bien est vendu pour moins que le solde du prêt, et le prêteur accepte que le produit de la vente règle la dette selon les conditions négociées. [ASSUMPTION] Cette voie, même si elle reste une issue difficile, est généralement considérée comme moins dommageable pour la situation financière globale de l'investisseuse que de laisser la situation aller jusqu'à une saisie immobilière menée à son terme.

## Quiz d'entraînement

1. Qu'est-ce qu'une dation en paiement ?
2. Qu'est-ce qu'une vente à découvert ?
3. Pourquoi un prêteur pourrait-il accepter l'une de ces alternatives plutôt que de poursuivre la saisie immobilière ?

## Corrigé

1. Un transfert volontaire du titre de propriété du bien au prêteur, en échange de la libération du reste de l'obligation de remboursement, ce qui évite une saisie officielle.
2. La vente du bien pour moins que le solde restant du prêt, avec l'accord du prêteur pour accepter le produit de la vente comme règlement (total ou partiel) de la dette.
3. Parce que la saisie immobilière coûte généralement cher et prend du temps, et que ces alternatives peuvent permettre de régler la situation plus vite et à moindre coût pour le prêteur comme pour l'emprunteur.

## Réponses et explications

1. C'est la définition de base de la première alternative présentée.
2. C'est la définition de base de la seconde alternative.
3. Cette question souligne l'intérêt propre du prêteur à envisager ces alternatives, en lien avec la discussion sur le coût de la saisie dans la leçon 38.

## Points clés
- Une dation en paiement transfère volontairement le titre de propriété au prêteur en échange de la libération du reste de la dette.
- Une vente à découvert consiste à vendre le bien pour moins que ce qui est dû, le prêteur acceptant d'imputer le produit de la vente sur la dette.
- Ces deux solutions sont généralement considérées comme potentiellement moins dommageables qu'une saisie immobilière menée à son terme, même si les résultats précis varient selon la situation.

---

*Cette leçon a uniquement une vocation d'éducation financière générale et ne constitue pas un conseil personnalisé en matière financière, d'investissement, fiscale ou juridique. Les résultats varient beaucoup selon la situation et la juridiction ; consultez un avocat agréé ou un professionnel de la finance pour toute situation particulière.*
