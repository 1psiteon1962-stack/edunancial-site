---
id: RED-L3-042
locale: fr-FR
source_locale: en-US
track: RED
level: 3
lesson: 42
title: "Pourquoi les plafonds d'un prêt à taux variable comptent plus que le taux d'appel"
source_title: "Why Adjustable-Rate Caps Matter More Than the Teaser Rate"
description: "Découvrez pourquoi les plafonds de taux d'un prêt immobilier à taux variable comptent davantage pour le risque à long terme que le taux de départ attractif."
slug: red-l3-042-arm-rate-caps
seo_title: "Pourquoi les plafonds d'un prêt à taux variable comptent plus que le taux d'appel | Edunancial"
meta_description: "Découvrez pourquoi les plafonds de taux d'un prêt immobilier à taux variable comptent davantage pour le risque à long terme que le taux de départ attractif."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-042: Pourquoi les plafonds d'un prêt à taux variable comptent plus que le taux d'appel

## Objectifs d'apprentissage
À la fin de cette leçon, vous serez capable de :
- Expliquer ce que limitent les plafonds de taux (rate caps) d'un prêt immobilier à taux variable
- Expliquer pourquoi le taux d'appel (« teaser rate ») de départ est une mauvaise base pour évaluer le risque à long terme
- Comprendre pourquoi connaître le pire scénario permis par le plafond compte plus que le meilleur taux de départ

## Contenu principal

La leçon 6 a présenté le risque général des prêts à taux variable à mesure qu'un portefeuille grandit. Cette leçon porte sur un mécanisme de protection précis intégré à beaucoup d'ARM (adjustable-rate mortgage, prêt immobilier à taux variable) : les **plafonds de taux** (rate caps). En général, ils limitent de combien le taux peut augmenter à chaque période de révision, et de combien il peut augmenter au total sur toute la durée du prêt.

Voici pourquoi les plafonds comptent plus que le taux de départ : le taux de départ d'un ARM — parfois appelé taux d'appel — est souvent plus bas qu'un taux fixe comparable, justement pour attirer les emprunteurs, mais il ne dit rien du pire scénario du prêt. Ce sont les plafonds qui le disent. [VERIFIED FACT] La structure des plafonds varie selon le prêt, mais comprend souvent un plafond par révision (qui limite de combien le taux peut monter à chaque réajustement) et un plafond sur toute la durée (qui limite la hausse totale possible sur toute la durée du prêt) ; il faut comprendre les deux pour connaître la vraie mensualité maximale que le prêt pourrait un jour exiger.

Un investisseur qui évalue un ARM doit analyser l'opération en fonction de la mensualité du pire scénario permis par le plafond sur toute la durée, et non en fonction du taux de départ attractif. C'est l'application directe au risque de taux du principe du test de résistance de la leçon 40.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un ARM démarre à un taux nettement inférieur aux taux fixes actuels, avec une structure qui permet une hausse de 2 % maximum par révision et un plafond sur toute la durée de 5 % au-dessus du taux de départ. Un investisseur qui ne regarde que le taux de départ attractif risque de sous-estimer le vrai risque du prêt. [ASSUMPTION] Analyser correctement l'opération signifie calculer la mensualité au plafond maximal de 5 % sur toute la durée et vérifier que les revenus prévus du bien pourraient encore couvrir cette mensualité du pire scénario, et pas seulement la mensualité de départ séduisante.

## Quiz d'entraînement

1. Que limitent généralement les plafonds de taux d'un ARM ?
2. Pourquoi le taux d'appel de départ est-il une mauvaise base pour évaluer le vrai risque d'un ARM ?
3. D'après cette leçon, en fonction de quoi un investisseur doit-il analyser l'opération ?

## Corrigé

1. De combien le taux d'intérêt peut augmenter à chaque période de révision, et de combien il peut augmenter au total sur toute la durée du prêt.
2. Parce qu'il est souvent fixé artificiellement bas pour attirer les emprunteurs et ne dit rien de la mensualité dans le pire scénario du prêt.
3. En fonction de la mensualité du pire scénario, calculée au plafond sur toute la durée du prêt, et non du taux de départ attractif.

## Réponses et explications

1. C'est la définition de base sur laquelle repose la leçon.
2. C'est la mise en garde centrale : ne laissez pas un chiffre de départ attractif remplacer l'analyse du pire scénario.
3. Cette question applique directement au risque de taux le principe du test de résistance de la leçon 40.

## Points clés
- Les plafonds de taux limitent de combien le taux d'un ARM peut monter à chaque révision et sur toute sa durée.
- Le taux d'appel de départ est souvent fixé bas pour attirer les emprunteurs et ne reflète pas le vrai risque du prêt dans le pire scénario.
- Une opération doit être analysée en fonction de la mensualité du pire scénario au plafond sur toute la durée, et non du taux de départ séduisant.

---

*Cette leçon est fournie uniquement à des fins d'éducation financière générale et ne constitue pas un conseil financier, d'investissement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations illustratives, et non des garanties. Consultez un professionnel agréé avant de prendre des décisions financières.*
