---
id: RED-L3-001
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 1
title: "Por qué la deuda no siempre es mala: deuda estratégica vs. deuda de consumo"
source_title: "Why Debt Isn't Always Bad: Strategic vs. Consumer Debt"
description: "Aprende por qué no toda deuda es igual, y por qué la deuda detrás de una propiedad de alquiler puede crear riqueza mientras la deuda de una tarjeta de crédito la destruye."
slug: red-l3-001-strategic-vs-consumer-debt
seo_title: "Por qué la deuda no siempre es mala: deuda estratégica vs. deuda de consumo | Edunancial"
meta_description: "Aprende por qué no toda deuda es igual, y por qué la deuda detrás de una propiedad de alquiler puede crear riqueza mientras la deuda de una tarjeta de crédito la destruye."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-001: Por qué la deuda no siempre es mala: deuda estratégica vs. deuda de consumo

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar la diferencia entre la deuda estratégica y la deuda de consumo
- Identificar a qué categoría pertenece un préstamo y por qué eso importa
- Explicar por qué la misma palabra, "deuda", puede describir dos situaciones financieras opuestas

## Contenido principal

A la mayoría de la gente le enseñan una sola lección sobre la deuda: evítala. Ese consejo tiene sentido para un tipo de deuda y es un consejo peligroso para otro tipo.

La **deuda de consumo** paga cosas que pierden valor en el momento en que las compras: balances de tarjetas de crédito por cosas que ya consumiste, un préstamo de carro por un vehículo que se deprecia cada año, un préstamo para unas vacaciones. El activo (o el no-activo) no genera ingresos. Estás pagando intereses sobre dinero ya gastado, sin nada que trabaje para pagar esos intereses por ti.

La **deuda estratégica**, a veces llamada deuda productiva, es distinta en un punto específico: está respaldada por un activo que genera ingresos o que se valoriza, y ese ingreso (o el plan de vender el activo) es lo que paga el préstamo. Una hipoteca sobre una propiedad de alquiler es el ejemplo más claro. Se supone que la renta del inquilino, no tu cheque de pago, es la que cubre el pago de la hipoteca.

Este es el "por qué" que importa en este nivel: no es el tamaño de la deuda, ni siquiera la tasa de interés, lo que hace que una deuda sea buena o mala. Es si la deuda está atada a algo que se paga solo. [ILLUSTRATIVE EXAMPLE] Una hipoteca de $300,000 sobre una propiedad de alquiler que deja $500 al mes de flujo de efectivo después de todos los gastos es deuda que trabaja. Una hipoteca de $300,000 sobre una casa que no puedes pagar, y que te obliga a sacar de tus ahorros cada mes para cubrirla, es un pasivo disfrazado de activo: mismo tamaño, misma tasa, un riesgo completamente distinto.

[VERIFIED FACT] Ambos tipos de deuda te obligan legalmente a pagar, y ambos afectan tu crédito y tu capacidad de tomar prestado. Esa parte no cambia. Lo que cambia es quién, o qué, está haciendo realmente el pago: tú, con tus propios ingresos, o el activo, con el ingreso que genera.

Esta distinción es la base de todo lo demás en esta ruta. Cada lección de aquí en adelante asume que sabes distinguir estos dos tipos antes de mirar los números.

## Ejemplo práctico

María está decidiendo entre dos préstamos:

- **Préstamo A**: $25,000 para un carro nuevo. Pago: $450 al mes. El carro pierde valor cada año que ella lo tiene.
- **Préstamo B**: hipoteca de $180,000 sobre un dúplex. Pago: $1,100 al mes. [ESTIMATE] La renta combinada de ambas unidades, después de apartar dinero para desocupación y reparaciones, se proyecta en $1,450 al mes.

El Préstamo A es deuda de consumo: se paga completamente con el salario de María, y el activo que lo respalda pierde valor todo el tiempo.

El Préstamo B es deuda estratégica: se proyecta que la renta de los inquilinos cubra el pago y deje $350 al mes, y el activo (el dúplex) tiene el potencial de valorizarse. No es María quien paga este préstamo, sino la propiedad, siempre que [ASSUMPTION] las proyecciones de renta se cumplan y las unidades se mantengan razonablemente ocupadas.

## Prueba de práctica

1. ¿Cuál es el único factor que determina si una deuda es "estratégica" o "de consumo", sin importar el monto del préstamo ni la tasa de interés?
2. Cierto o falso: Un préstamo de carro nunca puede considerarse deuda estratégica.
3. En el ejemplo práctico, ¿por qué el Préstamo B se considera deuda estratégica aunque sea mucho más grande que el Préstamo A?
4. ¿Qué riesgo real podría convertir la deuda "estratégica" del dúplex de María en algo que se comporte como deuda de consumo?

## Clave de respuestas

1. Si la deuda está respaldada por un activo que genera ingresos (o que se valoriza de forma confiable) suficientes para cubrir el pago.
2. Falso: si el carro se usa para generar ingresos (por ejemplo, un vehículo de entregas cuyo ingreso cubre claramente el préstamo), podría funcionar como deuda estratégica. El contexto importa más que la etiqueta de la categoría.
3. Porque se espera que la deuda se pague con el ingreso de alquiler de la propiedad, no con el cheque personal de María.
4. Si las unidades se quedan vacías, las rentas bajan o reparaciones grandes se comen el flujo de efectivo, María podría tener que cubrir la hipoteca con su propio ingreso; en ese punto se comporta como deuda de consumo aunque esté garantizada por bienes raíces.

## Respuestas y explicaciones

1. El tamaño del préstamo y la tasa de interés importan para los términos del negocio, pero no determinan la *categoría* de la deuda. La categoría depende de la relación entre la deuda y el ingreso al que está atada.
2. Esta es una pregunta de "por qué", no de "qué": evalúa si entiendes el principio de fondo en lugar de memorizar "carros = deuda mala". El principio se aplica en otros casos: cualquier deuda respaldada por un uso que genera ingresos puede ser estratégica.
3. El tamaño no tiene nada que ver con la clasificación. Lo que importa es la relación con el ingreso: el Préstamo B está diseñado para pagarse solo.
4. Este es el riesgo central del apalancamiento en bienes raíces, y por eso lecciones posteriores de esta ruta cubren en detalle las reservas para desocupación y los colchones de flujo de efectivo. La deuda estratégica puede degradarse a deuda de consumo si el lado del ingreso en la ecuación falla.

## Puntos clave
- La deuda no es buena ni mala por sí misma: su clasificación depende de qué la está pagando.
- La deuda estratégica está respaldada por activos que generan ingresos o se valorizan; la deuda de consumo solo está respaldada por tu salario futuro.
- Un préstamo del mismo tamaño, a la misma tasa, puede tener un riesgo radicalmente distinto según este único factor.
- La deuda estratégica también puede fallar: el "por qué" de la falla suele ser que el supuesto de ingreso se rompe, no la deuda en sí.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
