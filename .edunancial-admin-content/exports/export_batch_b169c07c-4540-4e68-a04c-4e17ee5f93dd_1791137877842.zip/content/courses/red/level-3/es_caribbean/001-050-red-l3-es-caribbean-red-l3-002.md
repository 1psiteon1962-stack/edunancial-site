---
id: RED-L3-002
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 2
title: "Por qué la moneda fiduciaria cambia las cuentas de la deuda a tasa fija"
source_title: "Why Fiat Currency Changes the Math on Fixed-Rate Debt"
description: "Entiende por qué pagar una hipoteca de tasa fija en moneda fiduciaria puede, poco a poco, favorecer al prestatario con el tiempo, y por qué eso solo se cumple bajo ciertas condiciones."
slug: red-l3-002-fiat-currency-fixed-rate-debt
seo_title: "Por qué la moneda fiduciaria cambia las cuentas de la deuda a tasa fija | Edunancial"
meta_description: "Entiende por qué pagar una hipoteca de tasa fija en moneda fiduciaria puede, poco a poco, favorecer al prestatario con el tiempo, y por qué eso solo se cumple bajo ciertas condiciones."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-002: Por qué la moneda fiduciaria cambia las cuentas de la deuda a tasa fija

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar qué es la moneda fiduciaria y por qué su valor no es fijo en el tiempo
- Explicar por qué un préstamo de tasa fija puede volverse "más barato" en términos reales con el paso del tiempo
- Identificar las condiciones en que esta dinámica ayuda, o no ayuda, a un prestatario

## Contenido principal

La moneda fiduciaria es dinero que tiene valor porque un gobierno lo declara así y la gente acepta usarlo, no porque esté respaldado por una cantidad fija de oro u otra mercancía física. [VERIFIED FACT] La mayoría de las monedas principales del mundo hoy, incluido el dólar estadounidense, son monedas fiduciarias.

Por eso importa para una hipoteca: el poder de compra de la moneda fiduciaria tiende a reducirse con el tiempo. Un dólar hoy generalmente compra menos que un dólar hace diez años. A esto normalmente se le llama inflación.

Ahora aplícalo a una hipoteca de tasa fija. Si hace diez años fijaste un pago de $1,500 al mes, esa obligación de $1,500 nunca cambia, pero los dólares con que la pagas valen menos cada año que los dólares que tomaste prestados al principio. Mientras tanto, [ASSUMPTION] si los salarios y las rentas tienden a subir con la inflación con el tiempo, el ingreso de alquiler que usas para cubrir ese pago fijo probablemente crece, mientras el pago se queda igual.

Por eso los inversionistas de bienes raíces a menudo describen la deuda a tasa fija como un activo en sí misma, no solo como un pasivo: te permiten pagar una deuda, durante décadas, con una moneda que vale menos cada año, mientras, en muchos casos, el ingreso que respalda esa deuda sube con la inflación.

Esto solo funciona bajo condiciones específicas, y es importante nombrarlas con honestidad:
- El préstamo tiene que ser de **tasa fija**. Un préstamo de tasa variable también puede subir con la inflación y borrar esta ventaja.
- El ingreso de alquiler tiene que mantenerse al ritmo de la inflación en tu mercado específico; esto no está garantizado en todas partes ni todos los años.
- Tienes que poder mantener la propiedad a través de los ciclos económicos, incluidos los períodos en que esta dinámica no está trabajando a tu favor.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Hace diez años, David sacó una hipoteca de tasa fija de $200,000 con un pago de $1,200 al mes, respaldada por una unidad de alquiler que en ese momento se rentaba en $1,400 al mes.

Hoy, ese mismo pago de $1,200 al mes no ha cambiado: es fijo. Pero [ESTIMATE] si las rentas en su mercado han subido con la inflación, esa unidad podría rentarse ahora en algo cercano a $1,900 al mes. El pago de David no cambió; su ingreso de alquiler creció. La diferencia entre los dos, su flujo de efectivo mensual, se ha ampliado, no porque él haya hecho algo distinto, sino porque su deuda es fija mientras su ingreso no lo es.

Compáralo con una versión hipotética de tasa variable del mismo préstamo: si la tasa hubiera subido junto con la inflación, el pago de David podría haberse acercado a su ingreso de alquiler, o superarlo, y borrar la ventaja por completo.

## Prueba de práctica

1. ¿Por qué la inflación, por sí sola, no ayuda automáticamente a un prestatario?
2. ¿Qué característica estructural específica necesita un préstamo para beneficiarse de esta dinámica?
3. En el ejemplo de David, ¿qué dos cosas cambiaron y no cambiaron, y por qué importa esa diferencia?
4. Menciona una condición bajo la cual esta "ventaja fiduciaria" no ayudaría a un prestatario.

## Clave de respuestas

1. La inflación solo ayuda si el pago del préstamo es fijo y no sube junto con los precios; en un préstamo de tasa variable, el pago también puede subir con la inflación.
2. Una tasa de interés fija.
3. Su pago de hipoteca se mantuvo fijo; su ingreso de alquiler (que se asume sigue a la inflación) subió. La diferencia cada vez mayor es su creciente ventaja de flujo de efectivo.
4. Si el ingreso de alquiler de la propiedad no sigue el ritmo de la inflación en ese mercado específico (por ejemplo, una economía local en declive), o si el préstamo es de tasa variable.

## Respuestas y explicaciones

1. Esto evalúa si entiendes que la inflación sola no es el mecanismo: lo que crea la ventaja es que el *pago* es fijo frente a un entorno de costos que sube.
2. Sin una tasa fija, el préstamo puede moverse con las mismas presiones inflacionarias que ayudan al lado del ingreso, y eso cancela el beneficio.
3. Este es el mecanismo central de la lección: la ventaja vive en la diferencia creciente entre una obligación plana y un ingreso que sube.
4. Esta pregunta comprueba que entiendes que el supuesto es condicional, no automático: rentas estancadas en un mercado específico o una tasa variable lo romperían.

## Puntos clave
- El valor de la moneda fiduciaria puede reducirse con el tiempo; a esto normalmente se le llama inflación.
- Una hipoteca de tasa fija congela tu pago mientras tu ingreso (la renta) puede subir, y así el flujo de efectivo se amplía con el tiempo.
- Esta ventaja requiere una tasa fija, un ingreso que suba con la inflación y la capacidad de aguantar a través de los ciclos.
- Es un patrón real, observado históricamente en muchos mercados, pero no está garantizado y no aplica a la deuda de tasa variable.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
