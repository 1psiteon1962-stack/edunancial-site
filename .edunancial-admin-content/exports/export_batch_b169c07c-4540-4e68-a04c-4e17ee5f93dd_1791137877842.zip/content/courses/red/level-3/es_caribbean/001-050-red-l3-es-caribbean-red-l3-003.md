---
id: RED-L3-003
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 3
title: "Por qué el apalancamiento multiplica tanto las ganancias como las pérdidas"
source_title: "Why Leverage Multiplies Both Gains and Losses"
description: "Aprende por qué usar dinero prestado para comprar bienes raíces puede aumentar mucho tus rendimientos, y aumentar tu riesgo en la misma medida."
slug: red-l3-003-leverage-multiplies-gains-and-losses
seo_title: "Por qué el apalancamiento multiplica tanto las ganancias como las pérdidas | Edunancial"
meta_description: "Aprende por qué usar dinero prestado para comprar bienes raíces puede aumentar mucho tus rendimientos, y aumentar tu riesgo en la misma medida."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-003: Por qué el apalancamiento multiplica tanto las ganancias como las pérdidas

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar qué significa el apalancamiento en el contexto de bienes raíces
- Calcular cómo el apalancamiento cambia el rendimiento porcentual de una propiedad comparado con una compra en efectivo
- Explicar por qué el apalancamiento corta en ambas direcciones y aumenta tanto las posibles ganancias como las posibles pérdidas

## Contenido principal

Apalancamiento significa usar dinero prestado para controlar un activo más grande que el efectivo que pusiste. En bienes raíces, esto normalmente aparece como el pago inicial: podrías poner el 20% del precio de una propiedad y tomar prestado el otro 80%.

Este es el "por qué" que hace poderoso al apalancamiento: tu rendimiento se calcula sobre el dinero que *tú* pusiste, no sobre el precio total de la propiedad. Si el valor de la propiedad sube, esa ganancia se aplica a *toda* la propiedad, pero solo tuviste que poner una fracción del precio de compra para capturarla.

[ILLUSTRATIVE EXAMPLE] Una propiedad de $200,000 que se valoriza 5% en un año gana $10,000 en valor. Si pagaste todo en efectivo ($200,000), tu rendimiento es 5%. Si pusiste $40,000 (20%) y financiaste el resto, esa misma ganancia de $10,000 ahora es un rendimiento de 25% sobre tus $40,000, porque la ganancia se mide contra una cantidad mucho más pequeña de tu propio dinero.

Precisamente por eso el apalancamiento corta en ambas direcciones. [ILLUSTRATIVE EXAMPLE] Si esa misma propiedad perdiera 5% de su valor, el comprador en efectivo pierde 5%. El comprador apalancado pierde 25% de su capital invertido: el mismo efecto multiplicador, funcionando al revés. La deuda no se achica solo porque bajó el valor de la propiedad.

Por eso las lecciones de este nivel insisten en la palabra "apalancamiento" en lugar de solo "financiamiento": el apalancamiento describe un multiplicador matemático, y los multiplicadores se aplican a las pérdidas igual de fácil que a las ganancias.

## Ejemplo práctico

Dos inversionistas evalúan el mismo dúplex de $250,000.

- **Inversionista A** paga todo en efectivo: $250,000 de su bolsillo.
- **Inversionista B** pone 20% de pago inicial ($50,000) y financia el resto.

[ASSUMPTION] Supón que la propiedad se valoriza 8% en tres años y luego, en un escenario de caída, imagina que en cambio hubiera bajado 8%.

Escenario de valorización: la propiedad gana $20,000 en valor.
- Rendimiento del Inversionista A: $20,000 / $250,000 = 8%
- Rendimiento del Inversionista B: $20,000 / $50,000 = 40%

Escenario de desvalorización: la propiedad pierde $20,000 en valor.
- Pérdida del Inversionista A: 8% del capital invertido
- Pérdida del Inversionista B: 40% del capital invertido, y el Inversionista B todavía debe el balance completo del préstamo, sin importar cuánto valga ahora la propiedad.

## Prueba de práctica

1. ¿Cuál es la razón matemática por la que el apalancamiento aumenta el rendimiento porcentual de las ganancias?
2. ¿Por qué la deuda de un comprador apalancado no se reduce cuando la propiedad pierde valor?
3. Si el Inversionista B del ejemplo hubiera puesto 10% de pago inicial en lugar de 20%, ¿sus cambios porcentuales (hacia arriba o hacia abajo) serían más grandes o más pequeños? ¿Por qué?
4. Explica con tus propias palabras por qué "apalancamiento" es una palabra más precisa que "financiamiento" para lo que ocurre en esta lección.

## Clave de respuestas

1. Porque el rendimiento se mide contra el efectivo que invirtió el inversionista, no contra el precio completo de la propiedad; un denominador más pequeño convierte la misma ganancia en dólares en un porcentaje mayor.
2. El préstamo es una obligación fija, independiente del valor de mercado de la propiedad; solo el capital propio (valor de la propiedad menos balance del préstamo) se mueve con el mercado.
3. Cambios más grandes, porque un pago inicial menor significa un denominador todavía más pequeño, así que la misma ganancia o pérdida en dólares produce un cambio porcentual aún mayor.
4. "Financiamiento" solo describe tomar dinero prestado; "apalancamiento" describe el efecto multiplicador que ese préstamo tiene sobre tus rendimientos porcentuales, hacia arriba y hacia abajo. La palabra refleja el mecanismo, no solo la transacción.

## Respuestas y explicaciones

1. Este es el centro matemático de toda la lección: menos capital invertido, misma ganancia en dólares, porcentaje mayor.
2. Este es el "por qué" del riesgo a la baja del apalancamiento: la deuda es fija y el capital propio es variable, así que toda la volatilidad se concentra en la parte del capital propio, que ya es más pequeña desde el principio.
3. Esto comprueba que puedes extender el principio a un escenario nuevo en lugar de solo recordar los números dados.
4. Esto evalúa la comprensión del concepto, no el vocabulario: la meta es reconocer el apalancamiento como un efecto multiplicador, que es la idea sobre la que se construye el resto de esta ruta.

## Puntos clave
- Apalancamiento significa controlar un activo grande con una cantidad pequeña de tu propio dinero.
- Las ganancias porcentuales se calculan contra tu efectivo invertido, así que el apalancamiento amplifica los rendimientos cuando el valor sube.
- El apalancamiento amplifica las pérdidas con el mismo multiplicador: la deuda no se achica cuando baja el valor del activo.
- Un pago inicial más pequeño significa cambios porcentuales más grandes en ambas direcciones.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
