---
id: RED-L3-004
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 4
title: "Por qué a los prestamistas les importan las razones DTI y LTV"
source_title: "Why Lenders Care About DTI and LTV Ratios"
description: "Aprende por qué los prestamistas se apoyan en dos razones, deuda-ingreso y préstamo-valor, para decidir cuánto prestar y qué tan riesgoso es un negocio."
slug: red-l3-004-dti-and-ltv-ratios
seo_title: "Por qué a los prestamistas les importan las razones DTI y LTV | Edunancial"
meta_description: "Aprende por qué los prestamistas se apoyan en dos razones, deuda-ingreso y préstamo-valor, para decidir cuánto prestar y qué tan riesgoso es un negocio."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-004: Por qué a los prestamistas les importan las razones DTI y LTV

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Definir las razones de deuda-ingreso (DTI) y préstamo-valor (LTV)
- Explicar por qué los prestamistas usan ambas razones en lugar de una sola
- Explicar por qué estas razones protegen más al prestamista que al prestatario

## Contenido principal

Cuando un prestamista decide si aprueba un préstamo, en realidad se está haciendo una sola pregunta: si algo sale mal, ¿cuánto podemos perder? Dos razones ayudan a contestarla.

La **razón deuda-ingreso (DTI, por sus siglas en inglés)** compara el total de tus pagos mensuales de deudas con tu ingreso bruto mensual. [ILLUSTRATIVE EXAMPLE] Si ganas $6,000 al mes y pagas $2,000 al mes entre todas tus deudas, tu DTI es 33%. Esta razón le dice al prestamista qué parte de tu ingreso ya está comprometida: mientras más baja, más espacio tienes para absorber un pago nuevo.

La **razón préstamo-valor (LTV, por sus siglas en inglés)** compara el monto del préstamo con el valor tasado de la propiedad. [ILLUSTRATIVE EXAMPLE] Un préstamo de $160,000 sobre una propiedad de $200,000 es un LTV de 80%. Esta razón le dice al prestamista cuánto colchón existe si tuviera que reposeer y revender la propiedad: mientras más bajo el LTV, más capital propio protege al prestamista si el mercado baja.

Este es el "por qué" que las conecta: el DTI mide tu capacidad de seguir pagando; el LTV mide el colchón del prestamista si dejas de pagar. Un prestatario puede tener un DTI bajo (bastante ingreso), pero un prestamista aún podría dudar ante un negocio con LTV alto, porque una caída del mercado podría dejar el préstamo más grande que el valor de la propiedad. Al revés, un negocio con LTV bajo y un prestatario con DTI alto sigue siendo riesgoso, porque ese prestatario tiene poco espacio para absorber un gasto inesperado.

[VERIFIED FACT] Los prestamistas normalmente fijan límites máximos para ambas razones, y los requisitos pueden ser distintos para propiedades de inversión que para residencias principales: los préstamos de inversión suelen tener límites más estrictos porque el prestamista los ve como de mayor riesgo.

## Ejemplo práctico

Priya quiere comprar una propiedad de alquiler de $250,000 con un pago inicial de $50,000 (un préstamo de $200,000). Su ingreso bruto mensual es $7,500, y ya paga $1,200 al mes en otras deudas. Si se suma el pago proyectado de hipoteca de $1,400 al mes:

- LTV: $200,000 / $250,000 = 80%
- DTI: ($1,200 + $1,400) / $7,500 = 34.7%

[ASSUMPTION] Si las guías del prestamista para propiedades de inversión limitan el DTI a 45% y el LTV a 80%, el negocio de Priya cabe dentro de ambos límites, pero apenas en el LTV, lo que significa que un pago inicial más pequeño podría sacar el negocio completamente de la zona de comodidad del prestamista.

## Prueba de práctica

1. ¿Qué pregunta está tratando de contestar realmente un prestamista cuando calcula el DTI y el LTV?
2. ¿Por qué un prestamista podría dudar ante un negocio con DTI bajo pero LTV alto?
3. En el ejemplo de Priya, ¿qué le pasaría a su LTV si pusiera solo $25,000 de pago inicial en lugar de $50,000?
4. ¿Por qué los préstamos para propiedades de inversión suelen tener requisitos de DTI/LTV más estrictos que los préstamos para residencia principal?

## Clave de respuestas

1. Cuánto puede perder el prestamista si el prestatario no puede seguir pagando.
2. Porque incluso un prestatario con capacidad financiera podría devolver en una caída del mercado una propiedad que vale menos que el balance del préstamo, y el prestamista tendría una pérdida sin importar el ingreso del prestatario.
3. Su LTV subiría a 90% ($225,000 / $250,000), lo que probablemente sacaría el negocio de los límites típicos de un prestamista.
4. Porque el prestatario no vive en la propiedad, los prestamistas ven los préstamos de inversión como de mayor riesgo de que el prestatario abandone el pago si el negocio deja de ser rentable.

## Respuestas y explicaciones

1. Este es el "por qué" que une ambas razones: existen para medir el riesgo del prestamista desde dos ángulos distintos.
2. Esto comprueba que entiendes que el DTI y el LTV miden tipos distintos de riesgo y no se sustituyen uno al otro.
3. Esto evalúa si puedes recalcular el LTV con un dato cambiado, y refuerza que un pago inicial menor aumenta directamente el riesgo del prestamista.
4. Esto conecta la lección con un patrón real de evaluación de préstamos: si el dueño vive o no en la propiedad cambia la evaluación de riesgo del prestamista.

## Puntos clave
- El DTI mide la capacidad del prestatario de seguir pagando; el LTV mide el colchón del prestamista si no puede.
- Ambas razones protegen primero al prestamista: un número fuerte en una no compensa un número débil en la otra.
- Los préstamos para propiedades de inversión normalmente tienen estándares más estrictos que los de residencia principal.
- El tamaño del pago inicial determina directamente el LTV, y por eso un pago inicial más grande a menudo consigue mejores términos de préstamo.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
