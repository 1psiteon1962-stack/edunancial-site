---
id: RED-L3-005
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 5
title: "Por qué el flujo de efectivo, no la valorización, debe guiar la decisión"
source_title: "Why Cash Flow, Not Appreciation, Should Drive the Decision"
description: "Aprende por qué depender de que una propiedad suba de valor es una estrategia más débil que depender del flujo de efectivo mensual, y por qué no son la misma apuesta."
slug: red-l3-005-cash-flow-vs-appreciation
seo_title: "Por qué el flujo de efectivo, no la valorización, debe guiar la decisión | Edunancial"
meta_description: "Aprende por qué depender de que una propiedad suba de valor es una estrategia más débil que depender del flujo de efectivo mensual, y por qué no son la misma apuesta."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-005: Por qué el flujo de efectivo, no la valorización, debe guiar la decisión

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Distinguir entre el flujo de efectivo y la valorización como fuentes de rendimiento en bienes raíces
- Explicar por qué la valorización es más difícil de controlar o predecir que el flujo de efectivo
- Explicar por qué una propiedad con flujo de efectivo negativo es más riesgosa aunque se esté valorizando

## Contenido principal

Una propiedad de alquiler puede darte dinero de dos formas: el flujo de efectivo mensual (renta menos todos los gastos, incluida la hipoteca) y la valorización (que la propiedad valga más con el tiempo). Las dos son reales. No son igual de confiables.

El flujo de efectivo se puede medir hoy. Puedes calcular, con números reales, cuánto te deja una propiedad cada mes. La valorización es una proyección sobre el futuro: depende del mercado local, de la economía en general y de un momento que tú no controlas. [VERIFIED FACT] Históricamente, los mercados de bienes raíces han tenido tanto períodos largos de valorización como períodos de caída o estancamiento, y el desempeño pasado en un mercado o período no garantiza resultados futuros en otro.

Este es el "por qué" que importa en este nivel: una propiedad con buen flujo de efectivo mensual te sigue pagando, se mueva o no el mercado. Una propiedad que solo "funciona" porque estás apostando a la valorización es una apuesta a una variable fuera de tu control, y si el mercado se estanca o baja mientras tienes una propiedad con flujo de efectivo negativo, estás pagando de tu bolsillo cada mes sin forma de detener la pérdida excepto vender, muchas veces con pérdida.

Esto no significa que la valorización no importe: a menudo es una parte importante del rendimiento de los bienes raíces a largo plazo. Significa que la valorización debe verse como un extra encima de un negocio que ya funciona por su flujo de efectivo, no como la razón por la que el negocio funciona.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Dos inversionistas compran propiedades de $300,000 el mismo año.

- **Propiedad A**: Se renta en $2,200 al mes; todos los gastos (hipoteca, contribuciones, seguro, reserva de mantenimiento) suman $2,000 al mes. Flujo de efectivo: +$200 al mes.
- **Propiedad B**: Se renta en $1,800 al mes; todos los gastos suman $2,300 al mes. Flujo de efectivo: -$500 al mes. El comprador lo aceptó porque el vecindario "claramente se iba a valorizar".

[ASSUMPTION] Si el mercado local se estanca por tres años (precios planos, sin valorización), el dueño de la Propiedad A ha cobrado $7,200 de flujo de efectivo en ese período. El dueño de la Propiedad B ha pagado $18,000 de su bolsillo en el mismo período, sin ninguna ganancia por valorización que lo compense. La apuesta a la valorización no se materializó en el plazo de ese dueño, y no había un colchón de flujo de efectivo en que apoyarse.

## Prueba de práctica

1. ¿Cuál es la diferencia clave entre el flujo de efectivo y la valorización como fuentes de rendimiento?
2. ¿Por qué una propiedad con flujo de efectivo negativo se considera más riesgosa, incluso en un mercado con tendencias históricas de valorización?
3. En el ejemplo práctico, ¿qué fue exactamente lo que salió mal para el dueño de la Propiedad B?
4. ¿Esta lección argumenta que la valorización no importa? ¿Por qué sí o por qué no?

## Clave de respuestas

1. El flujo de efectivo es un rendimiento actual y medible; la valorización es una proyección sobre el futuro que depende de factores fuera del control del inversionista.
2. Porque si la valorización no ocurre en el plazo esperado, el dueño no tiene colchón y paga de su bolsillo cada mes sin ninguna ganancia que lo compense.
3. Dependía de la valorización para que el negocio funcionara, pero el mercado se estancó, y le quedaron años de pérdidas de su bolsillo sin ninguna ganancia que las compensara.
4. No: la lección argumenta que la valorización debe ser un extra encima de un negocio con flujo de efectivo positivo, no la razón para aceptar un negocio.

## Respuestas y explicaciones

1. Esta es la distinción central de la lección: control y posibilidad de medir, frente a proyección y dependencia del mercado.
2. Esto evalúa el "por qué" del riesgo: no es que la valorización nunca ocurra, es que apostar todo el negocio a ella elimina tu margen de seguridad.
3. Esto comprueba que puedes conectar la falla específica descrita en el ejemplo con el principio de fondo.
4. Esta pregunta evita una conclusión demasiado simple: la lección no está en contra de la valorización, se trata del orden en que dependes de cada rendimiento.

## Puntos clave
- El flujo de efectivo se puede medir hoy; la valorización es una proyección sobre mañana.
- Una propiedad con flujo de efectivo positivo puede aguantar un mercado plano o en caída; una con flujo negativo que apuesta a la valorización no puede.
- La valorización debe verse como un extra en un negocio que ya funciona, no como la razón para aceptarlo.
- Los mercados se mueven en ciclos: un negocio que solo funciona si el mercado coopera es más débil que uno que funciona de todas formas.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
