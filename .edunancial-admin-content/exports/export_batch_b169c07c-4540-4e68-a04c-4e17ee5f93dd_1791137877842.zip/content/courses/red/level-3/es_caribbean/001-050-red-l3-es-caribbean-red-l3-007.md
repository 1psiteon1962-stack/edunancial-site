---
id: RED-L3-007
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 7
title: "Por qué las tablas de amortización revelan el costo real de un préstamo"
source_title: "Why Amortization Schedules Reveal the Real Cost of a Loan"
description: "Aprende por qué los primeros años de una hipoteca pagan mayormente intereses y no principal, y por qué ese momento importa para planificar tu salida."
slug: red-l3-007-amortization-schedules
seo_title: "Por qué las tablas de amortización revelan el costo real de un préstamo | Edunancial"
meta_description: "Aprende por qué los primeros años de una hipoteca pagan mayormente intereses y no principal, y por qué ese momento importa para planificar tu salida."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-007: Por qué las tablas de amortización revelan el costo real de un préstamo

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar qué muestra una tabla de amortización
- Explicar por qué los primeros pagos son mayormente intereses y los últimos son mayormente principal
- Explicar por qué este patrón importa para el tiempo que planeas mantener una propiedad

## Contenido principal

Una tabla de amortización divide un préstamo en su serie completa de pagos y muestra cuánto de cada pago va a intereses y cuánto a principal (la cantidad que realmente tomaste prestada). En una hipoteca estándar de tasa fija, esa división no es pareja durante la vida del préstamo.

Este es el "por qué": el interés se calcula sobre el balance que queda del préstamo. Al principio, el balance está en su punto más alto, así que la parte de intereses de cada pago es la más grande, y la parte de principal, lo que sobra, es la más pequeña. A medida que el balance baja año tras año, más de cada pago va al principal y menos a intereses. [VERIFIED FACT] Esta estructura significa que en los primeros años de una hipoteca fija típica a 30 años, la mayor parte de cada pago es interés, no principal, aunque el monto total del pago se mantiene igual todo el tiempo.

Esto importa directamente para la estrategia en bienes raíces. [ILLUSTRATIVE EXAMPLE] Si vendes o refinancias una propiedad después de solo 3 o 4 años, casi no has creado capital propio pagando principal: la mayor parte de lo que pagaste se fue al prestamista como interés, no a tu parte de la propiedad. Si tu plan depende de crear capital propio rápido solo con los pagos (aparte de la valorización), un período corto de tenencia trabaja en tu contra.

Por eso la planificación del tiempo de tenencia y la amortización se tienen que considerar juntas: un préstamo que se ve bien en papel puede debilitar sin que lo notes una estrategia de corto plazo si no tomas en cuenta lo poco que se paga de principal al principio.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] En una hipoteca fija de $200,000 a 30 años con cierta tasa, los pagos del primer año podrían aplicar más o menos 80% a intereses y solo 20% a principal. Para el año 20, esa proporción podría estar más cerca de 30% intereses y 70% principal.

[ASSUMPTION] Un inversionista que planea mantener una propiedad solo 3 años, esperando que los pagos aumenten de forma importante su capital propio, puede sorprenderse al ver que ha pagado apenas una fracción pequeña del balance original del préstamo: la mayoría de sus pagos fueron a intereses, y el crecimiento de su capital propio vino principalmente de la valorización, si la hubo, no de los pagos.

## Prueba de práctica

1. ¿Por qué una parte mayor de los primeros pagos de una hipoteca es interés y no principal?
2. ¿Qué le pasa a la división entre intereses y principal a medida que el préstamo madura?
3. ¿Por qué un período corto de tenencia reduciría el beneficio en capital propio de "ir pagando el préstamo"?
4. ¿En qué debería apoyarse un inversionista que planea una tenencia corta, en lugar del pago de principal, para hacer crecer su capital propio?

## Clave de respuestas

1. Porque el interés se calcula sobre el balance que queda, que es más alto al principio del préstamo.
2. A medida que el balance baja, la parte de intereses disminuye y la parte de principal aumenta con cada pago.
3. Porque en los primeros años la mayor parte de cada pago va a intereses, así que el balance del préstamo casi no baja; el capital propio creado solo con pagos es mínimo en un período corto.
4. En la valorización, u otra fuente de crecimiento del capital propio (como mejoras que añaden valor), porque el pago de principal por sí solo no aportará mucho capital propio en una tenencia corta.

## Respuestas y explicaciones

1. Esta es la base mecánica de la amortización: el interés se calcula sobre el balance.
2. Esto confirma que entiendes cómo cambia la proporción durante la vida del préstamo.
3. Esto conecta el mecanismo directamente con una consecuencia estratégica, que es el propósito de la lección.
4. Esto comprueba que el inversionista entiende en qué otra palanca tendría que apoyarse si el pago de principal todavía no está haciendo mucho trabajo.

## Puntos clave
- Las tablas de amortización muestran cómo cada pago se divide entre intereses y principal con el tiempo.
- Los primeros pagos son mayormente intereses; los últimos son mayormente principal.
- Una tenencia corta significa una ganancia mínima de capital propio solo con los pagos: la valorización o el valor añadido tienen que cargar más peso.
- La planificación del tiempo de tenencia y la amortización deben considerarse juntas antes de escoger una estrategia.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
