---
id: RED-L3-010
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 10
title: "Por qué la desocupación y las reservas cambian tu riesgo real de apalancamiento"
source_title: "Why Vacancy and Reserves Change Your Real Leverage Risk"
description: "Aprende por qué la renta que una propiedad \"debería\" cobrar y la renta que realmente cobra son dos números distintos, y por qué las reservas te protegen de esa diferencia."
slug: red-l3-010-vacancy-and-reserves
seo_title: "Por qué la desocupación y las reservas cambian tu riesgo real de apalancamiento | Edunancial"
meta_description: "Aprende por qué la renta que una propiedad \"debería\" cobrar y la renta que realmente cobra son dos números distintos, y por qué las reservas te protegen de esa diferencia."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-010: Por qué la desocupación y las reservas cambian tu riesgo real de apalancamiento

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar por qué la renta proyectada y la renta cobrada no son el mismo número
- Explicar por qué las reservas de efectivo son una forma de manejar el riesgo del apalancamiento
- Calcular un estimado sencillo de flujo de efectivo ajustado por desocupación

## Contenido principal

Cada proyección de flujo de efectivo de las lecciones anteriores asumía que la renta se paga a tiempo, todos los meses. En la realidad, las unidades se quedan vacías entre un inquilino y otro, a veces los inquilinos pagan tarde y surgen reparaciones inesperadas. ¿Por qué importa tanto esto aquí? Porque tu pago de hipoteca no se detiene por nada de eso: el prestamista espera el pago esté ocupada o no la unidad.

Por eso los inversionistas con experiencia incluyen desde el principio una **tasa de desocupación** y una **reserva de mantenimiento** en sus proyecciones, en lugar de tratarlas como algo de último momento. [ILLUSTRATIVE EXAMPLE] Presupuestar entre 5% y 8% de desocupación significa apartar ese porcentaje de la renta esperada, incluso en los meses en que la unidad está ocupada, para que el dinero esté ahí cuando por fin llegue una desocupación, porque tarde o temprano va a llegar.

Las reservas funcionan como el colchón entre la obligación fija de una propiedad apalancada (la hipoteca) y su realidad variable (el ingreso que realmente se cobra). Sin reservas, un inversionista está a un mal mes de tener que cubrir la hipoteca de su bolsillo, lo que convierte la deuda estratégica en deuda de consumo, como se vio antes en esta ruta.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Una propiedad se renta en $1,800 al mes. Las cuentas ingenuas de flujo de efectivo asumen que llegan $1,800 todos los meses. [ASSUMPTION] Presupuestar una reserva de desocupación de 7% significa apartar $126 al mes, lo que deja $1,674 al mes como el ingreso "real" con que se prueba si la hipoteca y los gastos están cubiertos, un número más honesto que la renta anunciada.

## Prueba de práctica

1. ¿Por qué la renta anunciada no es igual a un ingreso mensual confiable?
2. ¿Cuál es el propósito de una reserva de desocupación?
3. ¿Qué le pasa a un inversionista sin reservas cuando una unidad se queda vacía?

## Clave de respuestas

1. Porque la desocupación, los pagos tardíos y el tiempo entre un inquilino y otro reducen el ingreso que realmente se cobra por debajo de la renta anunciada.
2. Aparta una parte del ingreso durante los meses ocupados para que haya fondos disponibles en los meses vacíos, que son inevitables.
3. Podría tener que cubrir la hipoteca de su bolsillo, lo que puede convertir una deuda estratégica en un pasivo que se paga de tu propio dinero.

## Respuestas y explicaciones

1. Esto distingue un número de mercadeo de un número de evaluación financiera, que es el punto central de la lección.
2. Esto confirma que entiendes las reservas como un colchón preventivo, no como una reacción a una crisis.
3. Esto conecta la lección con la distinción entre deuda estratégica y deuda de consumo de la Lección 1.

## Puntos clave
- La renta anunciada y el ingreso que se cobra de forma confiable no son el mismo número.
- Las reservas de desocupación deben incluirse en las proyecciones desde el principio, no tratarse como algo de último momento.
- Las reservas son lo que mantiene a una propiedad apalancada funcionando como deuda estratégica durante un mes difícil.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
