---
id: RED-L3-011
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 11
title: "Por qué los prestamistas de cartera piensan distinto a los bancos tradicionales"
source_title: "Why Portfolio Lenders Think Differently Than Retail Banks"
description: "Aprende por qué los prestamistas que se quedan con los préstamos en sus propios libros evalúan los negocios de forma distinta a los bancos que venden sus préstamos en el mercado secundario."
slug: red-l3-011-portfolio-lenders
seo_title: "Por qué los prestamistas de cartera piensan distinto a los bancos tradicionales | Edunancial"
meta_description: "Aprende por qué los prestamistas que se quedan con los préstamos en sus propios libros evalúan los negocios de forma distinta a los bancos que venden sus préstamos en el mercado secundario."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-011: Por qué los prestamistas de cartera piensan distinto a los bancos tradicionales

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar la diferencia entre un prestamista de cartera y un prestamista que vende sus préstamos
- Explicar por qué esa diferencia cambia lo que un prestamista está dispuesto a aprobar
- Identificar por qué los prestamistas de cartera pueden ser más flexibles con negocios poco convencionales

## Contenido principal

La mayoría de las hipotecas convencionales no se quedan con el banco que las otorgó: se venden en el mercado secundario a inversionistas, muchas veces agrupadas en valores respaldados por hipotecas. Como esos préstamos se van a vender, el prestamista que los origina tiene que seguir guías estrictas y estandarizadas para que el préstamo califique para esa reventa.

Un **prestamista de cartera** (portfolio lender) hace algo distinto: se queda con el préstamo en sus propios libros en lugar de venderlo. Este es el "por qué" que importa: como el prestamista carga el riesgo él mismo, puede fijar sus propias reglas de evaluación en lugar de seguir los estándares del mercado secundario. Eso a menudo significa más flexibilidad: evaluar un negocio según el potencial de ingreso de la propiedad, el portafolio completo del inversionista o tipos de propiedad poco convencionales que no calificarían bajo guías estandarizadas.

[VERIFIED FACT] Esta flexibilidad no es generosidad automática: los prestamistas de cartera asumen un riesgo más directo al quedarse con el préstamo, así que a menudo cobran tasas más altas o piden pagos iniciales más grandes para compensar.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Un inversionista quiere financiar una propiedad de uso mixto (comercio en el primer piso, apartamentos arriba), un tipo de propiedad que no encaja bien en las guías convencionales estándar. Un banco tradicional que sigue las reglas del mercado secundario podría negar el préstamo de entrada. Un prestamista de cartera, que evalúa el negocio según el ingreso total de la propiedad y el historial del inversionista, podría aprobarlo, con una tasa más alta que la de un préstamo convencional, reflejando el riesgo adicional que asume directamente.

## Prueba de práctica

1. ¿Qué pasa con la mayoría de los préstamos hipotecarios convencionales después de que se otorgan?
2. ¿Por qué un prestamista de cartera tiene más flexibilidad al evaluar préstamos?
3. ¿Cuál es el intercambio típico a cambio de esa flexibilidad adicional?

## Clave de respuestas

1. Normalmente se venden en el mercado secundario, muchas veces agrupados en valores respaldados por hipotecas.
2. Porque se queda con el préstamo en sus propios libros y carga el riesgo directamente, así que no está atado a las reglas estandarizadas que se exigen a los préstamos destinados a la reventa.
3. Tasas de interés más altas o pagos iniciales más grandes, porque el prestamista asume un riesgo más directo.

## Respuestas y explicaciones

1. Esto establece el punto de partida (el mercado secundario) con el que contrasta el préstamo de cartera.
2. Este es el mecanismo central de la lección: quien carga el riesgo es quien pone las reglas.
3. Esto refuerza que la flexibilidad no es gratis; está incluida en el precio del negocio.

## Puntos clave
- La mayoría de los préstamos convencionales se venden al mercado secundario y tienen que cumplir guías estandarizadas.
- Los prestamistas de cartera se quedan con los préstamos en sus propios libros y pueden fijar sus propias reglas de evaluación.
- Esa flexibilidad a menudo viene con tasas más altas o requisitos de pago inicial más estrictos.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
