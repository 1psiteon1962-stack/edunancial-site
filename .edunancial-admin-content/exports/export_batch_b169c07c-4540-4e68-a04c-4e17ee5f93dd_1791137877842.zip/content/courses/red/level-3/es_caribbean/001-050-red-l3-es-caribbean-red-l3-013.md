---
id: RED-L3-013
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 13
title: "Por qué el sobreapalancamiento destruye inversiones que de otra forma serían buenas"
source_title: "Why Over-Leveraging Kills Otherwise Good Investments"
description: "Aprende por qué una propiedad fundamentalmente sólida todavía puede fracasar como inversión si se le pone demasiada deuda encima."
slug: red-l3-013-over-leveraging-risk
seo_title: "Por qué el sobreapalancamiento destruye inversiones que de otra forma serían buenas | Edunancial"
meta_description: "Aprende por qué una propiedad fundamentalmente sólida todavía puede fracasar como inversión si se le pone demasiada deuda encima."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-013: Por qué el sobreapalancamiento destruye inversiones que de otra forma serían buenas

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar qué significa el sobreapalancamiento en el contexto de bienes raíces
- Explicar por qué una buena propiedad todavía puede convertirse en una mala inversión por exceso de deuda
- Identificar señales de alerta de sobreapalancamiento en un negocio

## Contenido principal

Cada lección hasta ahora ha mostrado el apalancamiento como una herramienta que puede trabajar a favor del inversionista. Esta lección cubre a propósito el otro lado: al apalancamiento no le importa si una propiedad es "buena"; solo multiplica lo que pase, bueno o malo, como se vio en la Lección 3.

El **sobreapalancamiento** ocurre cuando la cantidad de deuda acumulada sobre una propiedad (o un portafolio) deja poco o ningún margen para los baches normales que toda propiedad vive: desocupación, reparaciones, cambios de tasa. La propiedad en sí podría ser un activo realmente sólido, en una buena ubicación y con demanda de alquiler real. Es el tamaño de la deuda comparado con la capacidad de la propiedad para pagarla lo que convierte un buen activo en una inversión frágil.

[ILLUSTRATIVE EXAMPLE] Acumular una primera hipoteca, una línea de crédito sobre el valor de la misma propiedad (HELOC) y un préstamo personal usado para el pago inicial pueden ser, cada uno por separado, deudas que parecen razonables, pero que juntas le dejan al inversionista casi ningún colchón si algo sale mal. Por eso las lecciones anteriores sobre DTI, LTV, reservas para desocupación y flujo de efectivo importan todas juntas: el sobreapalancamiento es lo que pasa cuando esas barreras de protección se ignoran o se estiran demasiado, una a una.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Un inversionista compra una propiedad con una primera hipoteca al 90% de LTV, luego saca un préstamo personal para cubrir los costos de renovación en lugar de pagar en efectivo, y no aparta reservas para desocupación para ahorrar en el pago inicial. [ASSUMPTION] Si un solo inquilino se va de repente, la propiedad ahora tiene que cubrir al mismo tiempo la primera hipoteca, el pago del préstamo personal y la renta perdida, sin ninguna reserva. Una propiedad que habría manejado cómodamente una desocupación normal con menos deuda ahora amenaza toda la posición de efectivo del inversionista.

## Prueba de práctica

1. ¿El sobreapalancamiento significa que la propiedad es un mal activo? ¿Por qué sí o por qué no?
2. ¿Cuál es el hilo común que conecta el sobreapalancamiento con las lecciones anteriores sobre DTI, LTV y reservas?
3. En el ejemplo práctico, ¿qué decisiones específicas se combinaron para crear la situación frágil?

## Clave de respuestas

1. No: la propiedad en sí puede ser sólida; el sobreapalancamiento se trata de la estructura de deuda que se le pone encima y que no deja margen para los contratiempos normales.
2. El sobreapalancamiento es lo que pasa cuando esas barreras individuales (límites de DTI, límites de LTV, reservas) se estiran o se saltan una a una, eliminando el colchón que cada una debe dar.
3. Una primera hipoteca con LTV alto, un préstamo personal adicional para las renovaciones y ninguna reserva para desocupación: cada una parece razonable sola, pero combinadas eliminaron todo el margen de error.

## Respuestas y explicaciones

1. Esto distingue la calidad del activo de la estructura de financiamiento que lo rodea, que es el punto central de la lección.
2. Esto conecta la lección con toda la ruta y muestra el sobreapalancamiento como una falla acumulada de principios anteriores, no como un concepto nuevo y aislado.
3. Esto comprueba que el lector puede conectar un resultado frágil con decisiones específicas que se fueron sumando.

## Puntos clave
- El sobreapalancamiento es un problema de estructura de deuda, no necesariamente de calidad del activo.
- Acumular varios préstamos sobre la misma propiedad puede parecer razonable préstamo por préstamo y aun así sumar una fragilidad real.
- Las barreras de protección de las lecciones anteriores (DTI, LTV, reservas) existen precisamente para evitar este resultado.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
