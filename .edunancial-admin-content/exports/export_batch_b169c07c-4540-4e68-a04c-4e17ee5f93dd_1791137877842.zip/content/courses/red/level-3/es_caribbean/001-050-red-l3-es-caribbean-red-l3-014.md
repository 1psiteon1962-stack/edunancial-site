---
id: RED-L3-014
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 14
title: "Por qué los choques de tasas ponen a prueba cada supuesto de un negocio"
source_title: "Why Rate Shocks Test Every Assumption in a Deal"
description: "Recorre un escenario económico realista y mira cómo un aumento repentino de las tasas de interés expone cada supuesto débil de un negocio de bienes raíces apalancado."
slug: red-l3-014-rate-shocks-test-assumptions
seo_title: "Por qué los choques de tasas ponen a prueba cada supuesto de un negocio | Edunancial"
meta_description: "Recorre un escenario económico realista y mira cómo un aumento repentino de las tasas de interés expone cada supuesto débil de un negocio de bienes raíces apalancado."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-014: Por qué los choques de tasas ponen a prueba cada supuesto de un negocio

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Seguir cómo un solo evento económico afecta varias decisiones financieras a la vez
- Aplicar los conceptos de DTI, LTV, flujo de efectivo y reservas de esta ruta a un escenario de estrés
- Explicar por qué "¿y si suben las tasas?" se debe probar antes de cerrar un negocio, no después

## Contenido principal

[HYPOTHETICAL SCENARIO — ASSUMPTION, NOT VERIFIED FACT] Imagina que un banco central, respondiendo a una inflación creciente, sube bruscamente las tasas de interés de referencia en un período corto. Este tipo de escenario es una prueba de estrés útil, no una predicción sobre ningún evento real específico.

En este escenario hipotético, las tasas de las hipotecas nuevas para propiedades de inversión suben de forma importante en cuestión de meses. Los préstamos de tasa ajustable que ya existen empiezan a reajustarse más altos en su próxima fecha de ajuste. Refinanciar se vuelve más caro, lo que frena el paso de "repetir" de las estrategias tipo BRRRR vistas en la Lección 9. Los valores de las propiedades se ablandan en algunos mercados, porque las tasas más altas reducen lo que los compradores pueden pagar, y eso afecta los cálculos de LTV de cualquier refinanciamiento planificado.

Este solo evento hipotético toca casi todo lo que se ha cubierto en esta ruta a la vez: los cálculos de DTI cambian porque la deuda nueva cuesta más en relación con el ingreso; los márgenes de flujo de efectivo se reducen en cualquier propiedad de tasa ajustable; las reservas se ponen a prueba porque los inquilinos, que enfrentan sus propios costos más altos, podrían atrasarse más; y las estrategias de salida planificadas alrededor de un refinanciamiento podrían tener que cambiar hacia mantener la propiedad más tiempo o venderla.

El "por qué" de esta lección: un choque de tasas no es realmente un solo riesgo; es una prueba de estrés que revela si cada supuesto anterior de un negocio (crecimiento del ingreso, valorización, momento del refinanciamiento, tamaño de las reservas) era realista u optimista. Los negocios con un margen real de flujo de efectivo y reservas razonables tienden a sobrevivir este tipo de escenario. Los negocios que solo funcionaban gracias a tasas favorables y precios en alza son los más expuestos.

## Ejemplo práctico

[HYPOTHETICAL — ILLUSTRATIVE, NOT A PREDICTION] Un inversionista con tres propiedades financiadas con préstamos de tasa ajustable planeaba refinanciar cada una en dos años para sacar efectivo y hacer más compras. En este escenario, las tasas suben bruscamente antes de cualquier refinanciamiento. Los tres pagos ajustables aumentan en su próximo reajuste. Los refinanciamientos con retiro de efectivo ya no tienen sentido con las tasas nuevas y más altas, y los valores tasados se han ablandado un poco, lo que reduce el capital propio disponible para sacar aunque el inversionista siguiera adelante de todas formas. El plan original del inversionista (refinanciar, sacar capital, repetir) queda en pausa, y los márgenes de flujo de efectivo de las propiedades (si existían) son lo que determina si el portafolio puede simplemente aguantar hasta que cambien las condiciones.

## Prueba de práctica

1. ¿Por qué este escenario se describe como hipotético y no como un evento histórico específico?
2. Menciona tres conceptos distintos de esta ruta que un escenario de choque de tasas toca al mismo tiempo.
3. ¿Qué distingue a un negocio que "sobrevive" este tipo de escenario de uno que no?
4. ¿Por qué un inversionista debería probar un negocio contra un choque de tasas antes de cerrar, y no después?

## Clave de respuestas

1. Porque está diseñado como un ejercicio general de prueba de estrés para razonar sobre el riesgo, no como una afirmación sobre ningún evento o fecha real en particular.
2. Tres cualesquiera de: DTI, LTV/valor tasado, reajustes de tasa ajustable, momento del refinanciamiento (BRRRR), margen de flujo de efectivo, reservas para desocupación, estrategia de salida.
3. El margen de flujo de efectivo y el tamaño de las reservas: los negocios con margen real pueden absorber el choque; los que dependen de tasas favorables y precios en alza son los más expuestos.
4. Porque una vez que el negocio está cerrado y apalancado, el inversionista tiene mucha menos flexibilidad para cambiar de rumbo; probar los supuestos por adelantado revela la fragilidad escondida mientras todavía se puede escoger no hacer el negocio o reestructurarlo.

## Respuestas y explicaciones

1. Esto distingue la educación por escenarios de la predicción, que es el uso que se busca con el formato de esta lección.
2. Esto comprueba que el lector puede integrar conceptos de toda la ruta en lugar de ver cada lección por separado.
3. Esto refuerza el hilo de toda la ruta RED Nivel 3: el margen y las reservas son lo que separa a los negocios resistentes de los frágiles.
4. Esta es la conclusión práctica: la prueba de estrés es una herramienta para antes de decidir, no un análisis de lo que salió mal.

## Puntos clave
- Un solo evento económico hipotético puede tocar el DTI, el LTV, el momento del refinanciamiento, el flujo de efectivo y las reservas a la vez.
- Por eso esta ruta trata estos conceptos como conectados, no como temas separados.
- Los negocios con un margen real de flujo de efectivo y reservas adecuadas tienen más probabilidad de sobrevivir un choque de tasas que los que dependen de que las condiciones favorables sigan para siempre.
- Probar un negocio contra un escenario de choque de tasas antes de cerrar revela la fragilidad mientras todavía hay tiempo de actuar.

---

*Esta lección usa un escenario hipotético solo con fines educativos y no describe ni predice ningún evento real específico. No constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
