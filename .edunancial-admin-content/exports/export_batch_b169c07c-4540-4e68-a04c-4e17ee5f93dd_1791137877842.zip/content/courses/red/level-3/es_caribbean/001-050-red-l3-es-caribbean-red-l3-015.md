---
id: RED-L3-015
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 15
title: "Por qué la estrategia de salida se debe decidir antes de comprar"
source_title: "Why Exit Strategy Should Be Decided Before You Buy"
description: "Aprende por qué planificar cómo vas a vender, refinanciar o mantener una propiedad cambia las decisiones que tomas desde el primer día como dueño."
slug: red-l3-015-exit-strategy-before-you-buy
seo_title: "Por qué la estrategia de salida se debe decidir antes de comprar | Edunancial"
meta_description: "Aprende por qué planificar cómo vas a vender, refinanciar o mantener una propiedad cambia las decisiones que tomas desde el primer día como dueño."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-015: Por qué la estrategia de salida se debe decidir antes de comprar

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar por qué una estrategia de salida afecta las decisiones de financiamiento que se toman al comprar
- Comparar al menos dos estrategias de salida distintas y lo que implican para el financiamiento
- Explicar el riesgo de comprar una propiedad sin un plan de salida claro

## Contenido principal

Cada lección de esta ruta (amortización, refinanciamiento, tipo de tasa, intercambios 1031) depende de algo que es fácil saltarse: saber, más o menos, cuánto tiempo planeas mantener la propiedad y cómo planeas salir de la inversión algún día. Sin ese plan, es difícil siquiera escoger la estructura de deuda correcta.

Piensa en algunas estrategias de salida comunes: mantener la propiedad indefinidamente por su flujo de efectivo y dejarla eventualmente en herencia; mantenerla un número fijo de años y luego venderla por una suma global; o mantenerla a corto plazo con un refinanciamiento planificado para volver a usar el capital (el enfoque BRRRR). Cada una apunta a una decisión de financiamiento distinta. Una tenencia a largo plazo favorece un préstamo de tasa fija, porque la amortización de la Lección 7 muestra que el capital propio crece despacio pero de forma constante durante décadas. Una tenencia corta planificada alrededor de un refinanciamiento tiene que tomar en cuenta el riesgo de tasación visto en la Lección 9. Una venta planificada tiene que tomar en cuenta las penalidades por pago anticipado (una lección posterior) y el tratamiento tributario de la venta.

El "por qué" aquí es el orden: la estrategia de salida no es una decisión para cuando estés listo para vender. Las lecciones anteriores de esta ruta muestran que las decisiones de financiamiento que se toman al comprar apoyan o debilitan un plan de salida. Escoger la estrategia de salida primero, aunque sea de forma general, te permite escoger un financiamiento hecho de verdad para ella, en lugar de descubrir años después que no encajan.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Dos inversionistas compran dúplex parecidos. Uno planea mantenerlo más de 20 años como propiedad de ingreso para su retiro y escoge un préstamo de tasa fija a 30 años, dando prioridad a la estabilidad del pago sobre la tasa. La otra planea renovar y refinanciar en 18 meses para volver a usar el capital en otro negocio, así que escoge una estructura de préstamo a plazo más corto, diseñada para refinanciarse sin una penalidad grande por pago anticipado, aunque tenga una tasa un poco más alta. Cada decisión encaja con su propio plan de salida, pero si los dos inversionistas intercambiaran estrategias sin intercambiar el financiamiento, probablemente ambos tendrían fricciones: el que mantiene a largo plazo enfrentaría costos de refinanciamiento anticipado sin necesidad, y la inversionista a corto plazo quedaría con décadas de una estructura de préstamo que nunca pensó mantener.

## Prueba de práctica

1. ¿Por qué la estrategia de salida afecta la decisión de financiamiento que se toma al comprar, en lugar de importar solo al momento de vender?
2. Según lecciones anteriores de esta ruta, ¿qué característica del financiamiento le importaría más a un inversionista que planea una tenencia a largo plazo?
3. ¿Qué característica del financiamiento le importaría más a un inversionista que planea una tenencia corta con un refinanciamiento planificado?
4. ¿Qué riesgo asume un inversionista que compra una propiedad sin ninguna estrategia de salida en mente?

## Clave de respuestas

1. Porque distintas estrategias de salida dependen de distintas estructuras de préstamo para funcionar bien; escoger el financiamiento primero, sin un plan de salida, arriesga un desajuste que se descubre demasiado tarde.
2. La estabilidad del pago que da una tasa fija, porque una tenencia larga se beneficia de una amortización previsible con el tiempo (Lecciones 6 y 7).
3. Penalidades por pago anticipado bajas o ninguna, y términos que apoyen un refinanciamiento temprano (Lecciones 8 y 9).
4. Arriesga terminar con un financiamiento que no encaja con cómo querrá usar la propiedad más adelante, lo que crea costos o fricciones innecesarias cuando decida vender, refinanciar o mantenerla.

## Respuestas y explicaciones

1. Este es el "por qué" central de la lección: ajustar el financiamiento al plan, no al revés.
2. Esto conecta directamente con las lecciones de amortización y tipo de tasa.
3. Esto conecta directamente con las lecciones de refinanciamiento y BRRRR.
4. Esto cierra el hilo de la ruta: cada concepto, desde la clasificación de la deuda hasta el riesgo del apalancamiento, asume un plan de tiempo como dueño que el inversionista debe decidir a propósito, no por omisión.

## Puntos clave
- Decidir más o menos cómo planeas salir de una propiedad debe ocurrir antes de escoger cómo financiarla, no después.
- Distintas estrategias de salida favorecen distintas estructuras de préstamo: las tenencias largas favorecen la estabilidad de la tasa fija; los planes de corto plazo favorecen términos flexibles para refinanciar.
- Un financiamiento escogido sin plan de salida arriesga un desajuste costoso que solo se descubre cuando llega el momento de vender, refinanciar o mantener.
- Esta lección cierra el arco básico de RED Nivel 3: cada concepto anterior asume un plan de tiempo como dueño decidido a propósito.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
