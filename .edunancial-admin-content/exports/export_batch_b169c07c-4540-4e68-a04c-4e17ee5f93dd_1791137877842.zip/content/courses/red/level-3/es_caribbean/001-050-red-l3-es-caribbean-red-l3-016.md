---
id: RED-L3-016
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 16
title: "Por qué las reglas de préstamos comerciales son distintas a las residenciales"
source_title: "Why Commercial Lending Rules Differ from Residential"
description: "Aprende por qué financiar un edificio de apartamentos pequeño o una propiedad comercial sigue reglas distintas a las de financiar una propiedad de alquiler unifamiliar."
slug: red-l3-016-commercial-vs-residential-lending
seo_title: "Por qué las reglas de préstamos comerciales son distintas a las residenciales | Edunancial"
meta_description: "Aprende por qué financiar un edificio de apartamentos pequeño o una propiedad comercial sigue reglas distintas a las de financiar una propiedad de alquiler unifamiliar."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-016: Por qué las reglas de préstamos comerciales son distintas a las residenciales

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar el límite general de tamaño que separa los préstamos residenciales de los comerciales
- Explicar por qué los préstamos comerciales se evalúan principalmente según el ingreso de la propiedad
- Identificar por qué los términos de los préstamos comerciales a menudo se ven distintos a los residenciales

## Contenido principal

Las reglas de préstamos residenciales, incluida la mayor parte de lo que se cubrió antes en esta ruta, generalmente aplican a propiedades de 1 a 4 unidades. [VERIFIED FACT] Las propiedades con 5 o más unidades residenciales, junto con la mayoría de los tipos de propiedad no residencial, normalmente caen bajo las reglas de préstamos comerciales, que siguen un marco distinto.

Este es el "por qué": los préstamos residenciales normalmente se evalúan en gran parte según el ingreso personal y el crédito del prestatario (el DTI, como se vio en la Lección 4). Los préstamos comerciales mueven el énfasis hacia la capacidad propia de la propiedad para generar ingreso, parecido en espíritu a los préstamos DSCR que se ven en una lección posterior, pero con una evaluación adicional propia de lo comercial. Como los préstamos comerciales se evalúan más según el activo, sus términos suelen ser distintos en su estructura: plazos más cortos (a veces de 5 a 10 años) con pagos calculados como si el préstamo se repartiera en un período más largo, que terminan en un pago global (balloon, que se ve en una lección posterior) en lugar de saldarse completamente en 30 años.

Este cambio en la forma de evaluar existe porque las propiedades comerciales y sus ingresos varían mucho más que las casas unifamiliares estándar, así que los prestamistas incluyen flexibilidad, y protección contra el riesgo, en la forma en que estructuran el préstamo, no solo en cómo califican al prestatario.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Un inversionista que compra un edificio de cuatro unidades pasa por la evaluación residencial estándar, parecida a la compra de una casa unifamiliar, con el DTI como factor central. Si ese mismo inversionista compra en cambio un edificio de apartamentos de 12 unidades, pasa por una evaluación comercial, donde el prestamista se enfoca mucho en el ingreso operativo neto del edificio y en la cobertura del servicio de la deuda, y ofrece un préstamo a 10 años con pagos basados en una tabla de amortización a 25 años, lo que significa que al final del año 10 se debe un pago global por el balance restante.

## Prueba de práctica

1. ¿Qué límite de tamaño separa generalmente los préstamos residenciales de los comerciales?
2. ¿Qué enfatiza la evaluación comercial en lugar del DTI personal del prestatario?
3. ¿Por qué los préstamos comerciales a menudo incluyen una estructura de pago global?

## Clave de respuestas

1. Generalmente 5 o más unidades residenciales (o la mayoría de los tipos de propiedad comercial no residencial).
2. La capacidad propia de la propiedad para generar ingreso y la cobertura del servicio de la deuda.
3. Porque los plazos de los préstamos comerciales suelen ser más cortos que el período de amortización con que se calculan los pagos, así que queda un balance que se debe al final del plazo.

## Respuestas y explicaciones

1. Este es un límite concreto que vale la pena conocer antes de comparar tipos de préstamo.
2. Este es el cambio central en la filosofía de evaluación que explica la lección.
3. Esto conecta la estructura de pago global (que se detalla en una lección posterior) con el plazo más corto de los préstamos comerciales.

## Puntos clave
- Los préstamos residenciales generalmente aplican a propiedades de 1 a 4 unidades; las de 5 o más unidades y la mayoría de las propiedades comerciales caen bajo préstamos comerciales.
- La evaluación comercial enfatiza el ingreso de la propiedad, no solo las finanzas personales del prestatario.
- Los préstamos comerciales a menudo tienen plazos más cortos con pagos globales, lo que refleja el enfoque de riesgo distinto del prestamista ante propiedades más grandes y variables.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
