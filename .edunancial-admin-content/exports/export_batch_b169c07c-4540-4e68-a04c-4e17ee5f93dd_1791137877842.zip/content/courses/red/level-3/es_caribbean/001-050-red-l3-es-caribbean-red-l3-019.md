---
id: RED-L3-019
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 19
title: "Por qué la garantía cruzada es un arma de doble filo"
source_title: "Why Cross-Collateralization Is a Double-Edged Sword"
description: "Aprende por qué usar una propiedad como garantía de un préstamo sobre otra puede abrir la puerta al financiamiento, y por qué también pone ambas propiedades en riesgo juntas."
slug: red-l3-019-cross-collateralization
seo_title: "Por qué la garantía cruzada es un arma de doble filo | Edunancial"
meta_description: "Aprende por qué usar una propiedad como garantía de un préstamo sobre otra puede abrir la puerta al financiamiento, y por qué también pone ambas propiedades en riesgo juntas."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-019: Por qué la garantía cruzada es un arma de doble filo

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar qué significa la garantía cruzada
- Explicar por qué un prestamista podría exigirla
- Explicar el riesgo específico que introduce entre varias propiedades

## Contenido principal

La **garantía cruzada** (cross-collateralization) ocurre cuando más de una propiedad se usa como garantía de un solo préstamo (a veces llamado préstamo general o blanket loan), o cuando el capital propio de una propiedad se ofrece para garantizar el financiamiento de otra. En lugar de que cada propiedad sea la garantía de su propia deuda por separado, las propiedades quedan vinculadas.

¿Por qué lo haría un inversionista o un prestamista? Del lado del prestamista, puede reducir su riesgo al repartir la garantía entre varios activos, lo que a veces lo lleva a aprobar un préstamo que no aprobaría contra una sola propiedad. Del lado del inversionista, puede abrir la puerta al financiamiento; por ejemplo, usar el capital propio de una propiedad que ya tiene y que ha pagado en buena parte para calificar a un préstamo sobre una compra nueva.

Este es el "por qué" de que corte en ambas direcciones: si las propiedades tienen garantía cruzada y el inversionista incumple el préstamo atado a una propiedad, el prestamista podría tener derechos también sobre la otra, porque también está ofrecida como garantía. Un problema limitado a una propiedad ahora puede amenazar una propiedad que de otra forma estaba funcionando bien.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Un inversionista con una propiedad de alquiler completamente saldada la usa como garantía adicional para conseguir el financiamiento de una compra nueva, en lugar de poner un pago inicial más grande en efectivo. Si la propiedad nueva rinde menos de lo esperado y el inversionista se atrasa en ese préstamo, el acuerdo de garantía cruzada podría permitirle al prestamista ir también tras la propiedad saldada, aunque el desempeño de esa propiedad nunca fue un problema.

## Prueba de práctica

1. ¿Qué significa la garantía cruzada?
2. ¿Por qué un prestamista podría preferir un préstamo con garantía cruzada?
3. ¿Cuál es el riesgo específico que esta estructura introduce para el inversionista?

## Clave de respuestas

1. Más de una propiedad se ofrece como garantía de un solo préstamo, o el capital propio de una propiedad garantiza un financiamiento atado a otra.
2. Reparte la garantía del prestamista entre varios activos, lo que puede reducir su riesgo y hacer más probable la aprobación.
3. Un incumplimiento atado a una propiedad puede poner en riesgo otra propiedad distinta que funciona bien, porque también está ofrecida como garantía.

## Respuestas y explicaciones

1. Esta es la definición estructural necesaria para entender el resto de la lección.
2. Esto explica el incentivo del prestamista para exigir u ofrecer esta estructura.
3. Este es el riesgo central sobre el que se construye la lección: el vínculo entre activos que de otra forma estarían separados.

## Puntos clave
- La garantía cruzada ofrece más de una propiedad para garantizar un solo préstamo.
- Puede ayudar a los inversionistas a calificar para financiamiento que de otra forma no conseguirían, y reducir el riesgo del prestamista.
- El precio es que un problema con una propiedad puede poner en riesgo otra propiedad distinta que no tiene nada que ver.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
