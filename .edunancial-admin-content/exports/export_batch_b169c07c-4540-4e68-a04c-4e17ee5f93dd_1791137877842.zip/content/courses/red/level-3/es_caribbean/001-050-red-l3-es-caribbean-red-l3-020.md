---
id: RED-L3-020
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 20
title: "Por qué los préstamos DSCR juzgan la propiedad, no al prestatario"
source_title: "Why DSCR Loans Judge the Property, Not the Borrower"
description: "Aprende por qué los préstamos por razón de cobertura del servicio de la deuda permiten a los inversionistas de bienes raíces calificar según el ingreso de una propiedad en lugar de sus talonarios de pago personales."
slug: red-l3-020-dscr-loans
seo_title: "Por qué los préstamos DSCR juzgan la propiedad, no al prestatario | Edunancial"
meta_description: "Aprende por qué los préstamos por razón de cobertura del servicio de la deuda permiten a los inversionistas de bienes raíces calificar según el ingreso de una propiedad en lugar de sus talonarios de pago personales."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-020: Por qué los préstamos DSCR juzgan la propiedad, no al prestatario

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Definir la razón de cobertura del servicio de la deuda (DSCR) y cómo se calcula
- Explicar por qué los préstamos DSCR alejan la calificación del ingreso personal
- Explicar a quién tiende a beneficiar más este tipo de préstamo

## Contenido principal

La **razón de cobertura del servicio de la deuda (DSCR, por sus siglas en inglés)** compara el ingreso operativo neto de una propiedad con el total de sus pagos de deuda. [ILLUSTRATIVE EXAMPLE] Una propiedad que genera $2,400 al mes de ingreso neto contra un pago de hipoteca de $2,000 al mes tiene un DSCR de 1.2, lo que significa que genera 20% más ingreso del que necesita para cubrir la deuda.

Un **préstamo DSCR** califica al prestatario principalmente según esta razón, en lugar del cálculo de DTI personal visto en la Lección 4. Este es el "por qué" que importa: muchos inversionistas de bienes raíces, sobre todo los que trabajan por cuenta propia o tienen varias propiedades, pueden mostrar en papel un ingreso personal tributable relativamente bajo (muchas veces por deducciones legítimas de depreciación) aunque sus propiedades rindan bien. Un préstamo convencional basado en el DTI puede subestimar la verdadera posición financiera de estos inversionistas; un préstamo DSCR hace en cambio una pregunta más directa: ¿esta propiedad específica genera suficiente ingreso para cubrir su propia deuda?

[VERIFIED FACT] Los préstamos DSCR normalmente exigen un DSCR igual o mayor que un mínimo fijado por el prestamista (a menudo alrededor de 1.0 a 1.25) y muchas veces tienen tasas algo más altas que los préstamos convencionales para vivienda propia, lo que refleja una evaluación enfocada en inversionistas y menos dependiente del ingreso personal.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Dos inversionistas, Sam y Lena, quieren comprar una propiedad de alquiler con un ingreso operativo neto proyectado de $1,800 al mes y un pago de hipoteca proyectado de $1,600 al mes (DSCR de 1.125). Sam tiene un buen salario de empleado (W-2) y califica fácilmente bajo las reglas convencionales de DTI. Lena trabaja por cuenta propia, tiene varias propiedades y muestra un ingreso tributable más bajo por deducciones legítimas de depreciación, lo que le hace más difícil calificar por DTI convencional aunque sus propiedades rinden bien. Un préstamo DSCR, que evalúa la propiedad en sí en lugar de la planilla de impuestos personal de Lena, podría permitirle calificar para el mismo negocio que un préstamo basado en el DTI le haría difícil.

## Prueba de práctica

1. ¿Qué mide el DSCR?
2. ¿Por qué un préstamo DSCR podría ayudar a un inversionista que muestra un ingreso tributable bajo aunque tenga propiedades rentables?
3. ¿Cuál es un intercambio típico de usar un préstamo DSCR en lugar de un financiamiento convencional?

## Clave de respuestas

1. El ingreso operativo neto de una propiedad en relación con el total de sus pagos de deuda.
2. Porque califica el préstamo según el desempeño del ingreso de la propiedad en lugar de la planilla de impuestos personal del prestatario, que puede subestimar su verdadera fortaleza financiera por deducciones legítimas como la depreciación.
3. Los préstamos DSCR a menudo tienen tasas de interés algo más altas que los préstamos convencionales, lo que refleja el enfoque distinto de evaluación.

## Respuestas y explicaciones

1. Esta es la definición básica necesaria para el resto de la lección.
2. Este es el "por qué" central: los préstamos DSCR resuelven un desajuste específico entre el ingreso tributable y el rendimiento real de la inversión.
3. Esto refuerza el patrón que se repite: depender menos de las finanzas personales muchas veces viene con un costo a cambio.

## Puntos clave
- El DSCR compara el ingreso neto de una propiedad con sus pagos de deuda, en lugar de depender del ingreso personal.
- Los préstamos DSCR pueden ayudar a inversionistas cuyas planillas de impuestos subestiman su verdadera posición financiera por deducciones legítimas.
- Esta flexibilidad normalmente viene con tasas de interés algo más altas que las de los préstamos convencionales para vivienda propia.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
