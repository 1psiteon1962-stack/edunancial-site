---
id: RED-L3-022
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 22
title: "Por qué los pagos globales crean una fecha límite escondida"
source_title: "Why Balloon Payments Create a Hidden Deadline"
description: "Aprende por qué algunos préstamos exigen un pago grande de una sola vez al final de un plazo corto, y por qué esa fecha límite se tiene que planificar con años de anticipación."
slug: red-l3-022-balloon-payments
seo_title: "Por qué los pagos globales crean una fecha límite escondida | Edunancial"
meta_description: "Aprende por qué algunos préstamos exigen un pago grande de una sola vez al final de un plazo corto, y por qué esa fecha límite se tiene que planificar con años de anticipación."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-022: Por qué los pagos globales crean una fecha límite escondida

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar qué es un pago global
- Explicar por qué las estructuras de pago global son comunes en los préstamos comerciales
- Explicar el riesgo de no planificar con tiempo una fecha de pago global

## Contenido principal

Un **pago global** (balloon payment) es un pago grande de una sola vez que se debe al final del plazo de un préstamo, y que cubre el balance que no se saldó con los pagos mensuales regulares. Como se presentó en la Lección 16, esta estructura es común en los préstamos comerciales: un préstamo se puede amortizar como si fuera a 25 o 30 años (lo que mantiene manejables los pagos mensuales), pero en realidad vence, es decir, se debe todo el balance restante, después de solo 5 o 10 años.

Este es el "por qué" de que cree una fecha límite escondida: como los pagos mensuales se calculan con una tabla de amortización más larga que el plazo real del préstamo, para la fecha de vencimiento solo se ha pagado una parte pequeña del principal, como se mostró en la discusión sobre amortización de la Lección 7. Al inversionista le queda un balance grande que se debe de una sola vez, y que casi siempre hay que resolver con un refinanciamiento o una venta, no pagarlo de su bolsillo.

Por eso los préstamos con pago global exigen planificar la estrategia de salida (Lección 15) con años de anticipación: si las condiciones del mercado, el valor de la propiedad o la capacidad de calificar del inversionista cambian para mal cuando se acerca la fecha del pago global, refinanciar puede volverse difícil o caro justo cuando más se necesita.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Un inversionista saca un préstamo comercial sobre un edificio de 8 unidades: los pagos se calculan con una tabla de amortización a 25 años, pero el préstamo vence en 7 años, y en ese momento se debe el balance restante completo. [ASSUMPTION] Si, cuando se acerca la marca de los 7 años, las tasas de interés han subido y el ingreso de la propiedad se ha ablandado, conseguir un préstamo nuevo para cubrir el pago global podría ser más difícil, o venir con términos menos favorables, que si el inversionista hubiera planificado con tiempo e incluido reservas o una opción de refinanciamiento más temprana en su estrategia.

## Prueba de práctica

1. ¿Qué es un pago global?
2. ¿Por qué una estructura de pago global deja un balance grande al vencimiento?
3. ¿Qué riesgo crea esperar a que se acerque la fecha del pago global para planificarlo?

## Clave de respuestas

1. Un pago grande de una sola vez que se debe al final del plazo de un préstamo, y que cubre el balance que no se saldó con los pagos regulares.
2. Porque los pagos se calculan con una tabla de amortización más larga que el plazo real del préstamo, así que se paga relativamente poco principal para cuando el préstamo vence.
3. Si las condiciones del mercado o la posición financiera del inversionista han cambiado para mal para la fecha del pago global, refinanciar para cubrirlo puede ser difícil o costoso justo cuando más se necesita.

## Respuestas y explicaciones

1. Esta es la base de definición de la lección.
2. Esto conecta directamente con la mecánica de amortización de la Lección 7.
3. Este es el riesgo central y refuerza el tema de la planificación de la estrategia de salida de la Lección 15.

## Puntos clave
- Un pago global es una suma que se debe de una sola vez al vencimiento del préstamo, común en las estructuras de préstamos comerciales.
- Como los pagos se calculan con una tabla más larga que el plazo real del préstamo, queda un balance grande al vencimiento.
- Las fechas de pago global se deben planificar con años de anticipación, porque cambios en el mercado o en las finanzas personales cerca de la fecha pueden hacer más difícil refinanciar justo cuando se necesita.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
