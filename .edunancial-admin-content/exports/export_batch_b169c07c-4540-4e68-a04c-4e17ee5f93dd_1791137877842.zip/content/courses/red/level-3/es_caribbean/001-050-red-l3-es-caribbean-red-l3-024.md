---
id: RED-L3-024
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 24
title: "Por qué la tasa de capitalización y la tasa hipotecaria se tienen que comparar juntas"
source_title: "Why Cap Rate and Mortgage Rate Have to Be Compared Together"
description: "Aprende por qué comparar la tasa de capitalización de una propiedad con su tasa hipotecaria revela si el apalancamiento va a ayudar o perjudicar tu rendimiento."
slug: red-l3-024-cap-rate-vs-mortgage-rate
seo_title: "Por qué la tasa de capitalización y la tasa hipotecaria se tienen que comparar juntas | Edunancial"
meta_description: "Aprende por qué comparar la tasa de capitalización de una propiedad con su tasa hipotecaria revela si el apalancamiento va a ayudar o perjudicar tu rendimiento."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-024: Por qué la tasa de capitalización y la tasa hipotecaria se tienen que comparar juntas

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Definir la tasa de capitalización (cap rate)
- Explicar por qué comparar la tasa de capitalización con la tasa hipotecaria predice si el apalancamiento ayuda o perjudica
- Identificar el término que se usa cuando esta comparación favorece al prestatario

## Contenido principal

La **tasa de capitalización** (cap rate) es el ingreso operativo neto de una propiedad dividido entre su precio de compra (o su valor actual), expresado como porcentaje: una forma de medir el rendimiento de una propiedad como si se hubiera comprado completamente en efectivo, sin ningún financiamiento.

Este es el "por qué" de su conexión con el apalancamiento: comparar la tasa de capitalización con la tasa de interés de la hipoteca te dice, en términos generales, si tomar dinero prestado para comprar la propiedad probablemente va a ayudar o perjudicar tu rendimiento sobre el efectivo invertido (cash-on-cash, el rendimiento sobre el efectivo que realmente pusiste, como se presentó en la Lección 3). Si la tasa de capitalización es más alta que la tasa hipotecaria, a esto generalmente se le llama **apalancamiento positivo**: el rendimiento de la propiedad supera el costo de la deuda, y tomar prestado tiende a subir tu rendimiento sobre el efectivo por encima de la tasa de capitalización de la propiedad. Si la tasa hipotecaria es más alta que la tasa de capitalización, es **apalancamiento negativo**: el costo de la deuda supera el rendimiento propio de la propiedad, y tomar prestado tiende a bajar tu rendimiento sobre el efectivo por debajo de la tasa de capitalización (un tema que se explora más en la próxima lección).

[VERIFIED FACT] Esta comparación es una herramienta útil para filtrar negocios, no un proceso completo de evaluación: el rendimiento real sobre el efectivo también depende de los términos específicos del préstamo, del tamaño del pago inicial y de los gastos reales de la propiedad, todo cubierto en otras partes de esta ruta.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Una propiedad tiene una tasa de capitalización de 7%. Si las tasas hipotecarias para propiedades de inversión parecidas rondan el 6%, este es un escenario de apalancamiento positivo: tomar prestado a una tasa por debajo del rendimiento sin apalancamiento de la propiedad tiende a amplificar el rendimiento sobre el efectivo del inversionista por encima de 7%. Si las tasas hipotecarias rondaran en cambio el 8%, sería un escenario de apalancamiento negativo: el costo de la deuda supera el rendimiento propio de la propiedad, y el rendimiento sobre el efectivo tendería a caer por debajo de 7%, aunque la propiedad en sí no haya cambiado para nada.

## Prueba de práctica

1. ¿Qué mide la tasa de capitalización, y qué supuesto de financiamiento hace?
2. ¿Qué significa que una propiedad esté en una posición de "apalancamiento positivo"?
3. ¿Por qué la misma propiedad puede ser un negocio de "apalancamiento positivo" en un momento y de "apalancamiento negativo" en otro?

## Clave de respuestas

1. El ingreso operativo neto dividido entre el precio o valor de la propiedad, suponiendo una compra completa en efectivo, sin financiamiento.
2. La tasa de capitalización de la propiedad es más alta que la tasa de interés de la hipoteca, lo que significa que tomar prestado tiende a subir el rendimiento sobre el efectivo del inversionista por encima de la tasa de capitalización de la propiedad.
3. Porque las tasas hipotecarias cambian con el tiempo (y las tasas de capitalización también pueden cambiar con las condiciones del mercado): la posición de apalancamiento de una misma propiedad depende de las tasas de interés que haya al momento de financiar, no solo de la propiedad.

## Respuestas y explicaciones

1. Esto establece el punto de partida sin apalancamiento con que se compara el resto de la lección.
2. Esta es la definición central sobre la que se construye la lección.
3. Esto conecta el concepto con el riesgo de los ciclos de tasas de la Lección 6, y que se insinuó en la Lección 14: las cuentas de apalancamiento de un mismo activo cambian con las tasas de interés del mercado.

## Puntos clave
- La tasa de capitalización mide el rendimiento sin apalancamiento de una propiedad según su ingreso operativo neto y su precio.
- Comparar la tasa de capitalización con la tasa hipotecaria revela si el apalancamiento va a ayudar ("apalancamiento positivo") o perjudicar ("apalancamiento negativo") tu rendimiento sobre el efectivo.
- Esta comparación cambia con los ciclos de tasas de interés: la misma propiedad puede pasar de apalancamiento positivo a negativo a medida que cambian las tasas.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
