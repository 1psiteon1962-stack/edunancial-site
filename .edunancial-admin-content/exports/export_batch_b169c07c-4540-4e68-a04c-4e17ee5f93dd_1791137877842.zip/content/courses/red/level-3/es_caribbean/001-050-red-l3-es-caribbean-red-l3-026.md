---
id: RED-L3-026
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 26
title: "Por qué el congelamiento de tasa y la compra de puntos son herramientas de tiempo, no descuentos"
source_title: "Why Rate Locks and Buydowns Are Timing Tools, Not Discounts"
description: "Aprende por qué congelar una tasa o pagar puntos para bajarla se trata de manejar el riesgo del momento, no de conseguir una ganga."
slug: red-l3-026-rate-locks-and-buydowns
seo_title: "Por qué el congelamiento de tasa y la compra de puntos son herramientas de tiempo, no descuentos | Edunancial"
meta_description: "Aprende por qué congelar una tasa o pagar puntos para bajarla se trata de manejar el riesgo del momento, no de conseguir una ganga."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-026: Por qué el congelamiento de tasa y la compra de puntos son herramientas de tiempo, no descuentos

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar qué hace un congelamiento de tasa y por qué importa el tiempo entre la solicitud y el cierre
- Explicar cómo funciona la compra de una tasa más baja (puntos)
- Explicar por qué comprar puntos es un intercambio, no simplemente un descuento

## Contenido principal

Las tasas de interés se pueden mover entre el día en que solicitas un préstamo y el día en que cierras. Un **congelamiento de tasa** (rate lock) congela la tasa de interés que te cotizaron por un período fijo, y te protege de aumentos de tasa durante ese tiempo, pero también significa que no te beneficias si las tasas bajan antes del cierre, a menos que el congelamiento incluya una opción específica de bajada (float-down).

La **compra de una tasa más baja** (buydown, pagar "puntos") es distinta: es un cargo por adelantado que se paga en el cierre a cambio de una tasa de interés permanentemente más baja en el préstamo. [VERIFIED FACT] Un punto normalmente cuesta el 1% del monto del préstamo y comúnmente baja la tasa en una cantidad modesta, aunque la relación exacta varía según el prestamista y las condiciones del mercado.

Este es el "por qué" que importa: comprar puntos no es un descuento; es cambiar efectivo hoy por un pago más bajo con el tiempo. Que valga la pena depende de cuánto tiempo planeas mantener el préstamo, lo que conecta directamente con la lección sobre estrategia de salida de la Lección 15. Si planeas refinanciar o vender antes de que el ahorro mensual sume más que el costo inicial, la compra de puntos no se paga sola.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] A una inversionista le cotizan una tasa y puede pagar $3,000 por adelantado para bajarla, ahorrándose [ASSUMPTION] unos $60 al mes en el pago. Eso es un punto de equilibrio de 50 meses (unos 4 años) antes de que la compra de puntos "se pague sola". Si planea refinanciar en 2 años como parte de una estrategia BRRRR (Lección 9), probablemente no vale la pena. Si planea mantener el préstamo más de 15 años, probablemente sí.

## Prueba de práctica

1. ¿Contra qué protege un congelamiento de tasa, y contra qué no protege (sin una opción de bajada)?
2. ¿Cómo funciona la compra de puntos?
3. ¿Por qué la estrategia de salida de un inversionista afecta directamente si la compra de puntos tiene sentido?

## Clave de respuestas

1. Protege contra aumentos de tasa antes del cierre; sin una opción de bajada, no te deja beneficiarte si las tasas bajan en cambio.
2. Pagar un cargo por adelantado ("puntos") en el cierre a cambio de una tasa de interés permanentemente más baja en el préstamo.
3. Porque el costo inicial solo "se paga solo" después de que se acumulan suficientes meses de pagos más bajos; un período de tenencia esperado corto podría no dar tiempo suficiente para recuperar ese costo.

## Respuestas y explicaciones

1. Esto evalúa la limitación específica de un congelamiento de tasa estándar, no solo su beneficio.
2. Esta es la base mecánica del resto de la lección.
3. Esto conecta la decisión directamente con el principio de la Lección 15 de que la estrategia de salida debe dar forma a las decisiones de financiamiento.

## Puntos clave
- Un congelamiento de tasa protege contra aumentos de tasa antes del cierre, pero normalmente no te deja beneficiarte de una bajada de tasa a menos que incluya una opción de bajada.
- Comprar puntos cambia efectivo por adelantado por una tasa más baja durante la vida del préstamo: es un intercambio, no un descuento.
- Que la compra de puntos tenga sentido depende mucho de cuánto tiempo planeas mantener el préstamo.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
