---
id: RED-L3-029
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 29
title: "Por qué los convenios de un préstamo pueden limitar lo que haces con una propiedad"
source_title: "Why Loan Covenants Can Restrict What You Do With a Property"
description: "Aprende por qué algunos préstamos incluyen condiciones continuas que el prestatario tiene que mantener, y por qué violarlas puede tener consecuencias más allá de un pago atrasado."
slug: red-l3-029-loan-covenants
seo_title: "Por qué los convenios de un préstamo pueden limitar lo que haces con una propiedad | Edunancial"
meta_description: "Aprende por qué algunos préstamos incluyen condiciones continuas que el prestatario tiene que mantener, y por qué violarlas puede tener consecuencias más allá de un pago atrasado."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-029: Por qué los convenios de un préstamo pueden limitar lo que haces con una propiedad

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar qué es un convenio de préstamo
- Dar un ejemplo de un convenio común en el financiamiento de bienes raíces
- Explicar por qué violar un convenio puede tener consecuencias aunque no se atrase ningún pago

## Contenido principal

Un **convenio de préstamo** (loan covenant) es una condición continua, escrita en el contrato del préstamo, que el prestatario tiene que mantener durante toda la vida del préstamo, aparte de simplemente hacer los pagos a tiempo. Los convenios son más comunes en los préstamos comerciales (Lección 16) que en las hipotecas residenciales convencionales típicas.

Un ejemplo común es un convenio de DSCR mínimo (que conecta con la Lección 20): el contrato del préstamo podría exigir que la propiedad mantenga un DSCR por encima de cierto nivel durante todo el plazo del préstamo, no solo al momento de la aprobación. Otros convenios podrían limitar que se tome más deuda contra la propiedad, exigir la aprobación del prestamista antes de renovaciones grandes o exigir informes financieros regulares sobre el desempeño de la propiedad.

Este es el "por qué" de que importe: violar un convenio se considera estar en "incumplimiento" aunque cada pago se haya hecho a tiempo. [VERIFIED FACT] Según el contrato del préstamo, una violación de un convenio puede darle al prestamista el derecho de exigir el pago total del préstamo de inmediato, ajustar los términos o tomar otras acciones especificadas; las consecuencias exactas dependen completamente del lenguaje específico del contrato de ese préstamo.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Un préstamo comercial sobre un edificio de apartamentos incluye un convenio que exige que la propiedad mantenga un DSCR de al menos 1.15 durante todo el plazo del préstamo. El inversionista ha hecho cada pago a tiempo, pero un aumento temporal de la desocupación hace que el DSCR real de la propiedad baje a 1.05 durante un período de informe. [ASSUMPTION] Aunque no se atrasó ningún pago, esto podría causar un incumplimiento del convenio bajo el contrato del préstamo, y posiblemente darle al prestamista los derechos especificados en ese contrato, una consecuencia completamente separada del historial de pagos del inversionista.

## Prueba de práctica

1. ¿Qué es un convenio de préstamo?
2. Da un ejemplo de un convenio común en los préstamos de bienes raíces.
3. ¿Por qué una violación de un convenio se puede considerar un incumplimiento aunque los pagos estén al día?

## Clave de respuestas

1. Una condición continua escrita en el contrato de un préstamo que el prestatario tiene que mantener durante toda la vida del préstamo, aparte de hacer los pagos.
2. Un requisito de DSCR mínimo es un ejemplo común (otros incluyen límites a tomar más deuda o requisitos de aprobación del prestamista antes de cambios grandes a la propiedad).
3. Porque el contrato del préstamo define el incumplimiento según el mantenimiento de condiciones específicas, no solo según el historial de pagos; violar cualquier convenio definido puede causar un incumplimiento sin importar el estado de los pagos.

## Respuestas y explicaciones

1. Esta es la definición básica necesaria para el resto de la lección.
2. Esto conecta el concepto abstracto con un ejemplo concreto que ya se estableció en la Lección 20.
3. Este es el punto central y fácil de pasar por alto: el incumplimiento no se trata solo de pagos atrasados.

## Puntos clave
- Los convenios de préstamo son condiciones continuas que el prestatario tiene que mantener durante todo el plazo del préstamo, comunes en el financiamiento comercial.
- Un ejemplo común es un requisito de DSCR mínimo que se tiene que mantener, no solo cumplir al cierre.
- Violar un convenio puede causar un incumplimiento aunque cada pago se haya hecho a tiempo, con consecuencias definidas por el contrato específico del préstamo.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
