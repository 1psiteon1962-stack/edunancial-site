---
id: RED-L3-030
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 30
title: "Por qué la deuda mezzanine está entre el capital y la hipoteca"
source_title: "Why Mezzanine Debt Sits Between Equity and a Mortgage"
description: "Aprende qué es la deuda mezzanine, por qué tiene más riesgo y costo que una primera hipoteca, y dónde se usa normalmente."
slug: red-l3-030-mezzanine-debt
seo_title: "Por qué la deuda mezzanine está entre el capital y la hipoteca | Edunancial"
meta_description: "Aprende qué es la deuda mezzanine, por qué tiene más riesgo y costo que una primera hipoteca, y dónde se usa normalmente."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-030: Por qué la deuda mezzanine está entre el capital y la hipoteca

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar dónde está la deuda mezzanine en la estructura de capital de una propiedad
- Explicar por qué los prestamistas mezzanine cobran tasas más altas que los prestamistas de primera hipoteca
- Identificar un uso típico del financiamiento mezzanine

## Contenido principal

La "estructura de capital" (capital stack) de una propiedad describe las capas de dinero que se usan para financiarla, ordenadas según la prioridad de pago si algo sale mal. Una primera hipoteca normalmente está en lo más alto de ese orden: se paga primero con cualquier dinero que resulte si la propiedad se vende o se ejecuta. El capital propio (el efectivo del inversionista) normalmente está al fondo: se paga último, si sobra algo.

La **deuda mezzanine** está en el medio: es una capa secundaria de financiamiento, subordinada a la primera hipoteca pero con prioridad sobre los inversionistas de capital. Este es el "por qué" de su costo: como a los prestamistas mezzanine se les paga solo después de satisfacer la primera hipoteca, asumen más riesgo que un prestamista de primera hipoteca, y cobran por ese riesgo con una tasa de interés bastante más alta, muchas veces más cercana a lo que esperaría un inversionista de capital que a lo que cobraría un prestamista hipotecario.

La deuda mezzanine normalmente se usa en negocios comerciales más grandes donde la primera hipoteca sola no cubre todo el monto necesario, y el promotor quiere llenar el hueco con deuda en lugar de traer más inversionistas de capital y diluir más la propiedad.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] La compra de una propiedad comercial necesita $10 millones de capital total. Una primera hipoteca cubre $6.5 millones a una tasa relativamente baja que refleja su posición prioritaria de pago. En lugar de conseguir los $3.5 millones restantes completamente con inversionistas de capital, el promotor usa $1.5 millones de deuda mezzanine, con una tasa bastante más alta que refleja su posición subordinada, y consigue los $2 millones restantes en capital. Esta estructura en capas llena el hueco de financiamiento y cede menos propiedad de la que habría exigido conseguir todo el monto restante como capital.

## Prueba de práctica

1. ¿Dónde está la deuda mezzanine en la estructura de capital de una propiedad, en relación con una primera hipoteca y el capital propio?
2. ¿Por qué los prestamistas mezzanine cobran tasas más altas que los prestamistas de primera hipoteca?
3. ¿Por qué un promotor podría usar deuda mezzanine en lugar de conseguir más capital?

## Clave de respuestas

1. Entre la primera hipoteca (prioritaria) y el capital propio (subordinado): subordinada a la hipoteca pero con prioridad sobre los inversionistas de capital.
2. Porque se les paga solo después de satisfacer la primera hipoteca, lo que hace su posición más riesgosa, y eso se refleja en una tasa más alta.
3. Para llenar un hueco de financiamiento sin diluir más la propiedad entre inversionistas de capital, porque la deuda no exige ceder una parte de la propiedad.

## Respuestas y explicaciones

1. Esto establece la posición estructural que explica todo lo demás sobre la deuda mezzanine.
2. Esta es la lógica central de precio del riesgo en la lección.
3. Esto explica la razón práctica de negocio por la que los promotores escogen esta capa de financiamiento.

## Puntos clave
- La deuda mezzanine está entre una primera hipoteca y el capital propio en la estructura de capital de una propiedad.
- Su posición de pago subordinada significa más riesgo para el prestamista, que se cobra con una tasa de interés más alta.
- Se usa comúnmente en negocios más grandes para llenar un hueco de financiamiento sin diluir tanto la propiedad como lo haría conseguir más capital.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
