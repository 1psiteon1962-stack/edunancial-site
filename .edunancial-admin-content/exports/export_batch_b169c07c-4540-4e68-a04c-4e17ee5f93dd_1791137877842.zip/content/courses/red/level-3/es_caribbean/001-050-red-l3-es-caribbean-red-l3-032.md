---
id: RED-L3-032
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 32
title: "Por qué los préstamos de construcción se estructuran distinto a los préstamos de compra"
source_title: "Why Construction Loans Are Structured Differently Than Purchase Loans"
description: "Aprende por qué financiar una construcción nueva o una rehabilitación grande usa una estructura de préstamo distinta a una compra estándar, con el dinero entregado por etapas y no todo de una vez."
slug: red-l3-032-construction-loans
seo_title: "Por qué los préstamos de construcción se estructuran distinto a los préstamos de compra | Edunancial"
meta_description: "Aprende por qué financiar una construcción nueva o una rehabilitación grande usa una estructura de préstamo distinta a una compra estándar, con el dinero entregado por etapas y no todo de una vez."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-032: Por qué los préstamos de construcción se estructuran distinto a los préstamos de compra

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar por qué los préstamos de construcción entregan el dinero por etapas y no todo de una vez
- Explicar qué es un "calendario de desembolsos" y por qué las inspecciones están atadas a él
- Explicar por qué un préstamo de construcción a menudo se convierte en otro tipo de préstamo cuando termina la obra

## Contenido principal

Un préstamo de compra estándar entrega el monto completo del préstamo en el cierre, contra una propiedad que ya existe en su forma final. Financiar una construcción nueva o una rehabilitación grande es distinto, porque lo que se financia todavía no existe del todo: es un plan y un presupuesto, no un activo terminado que se pueda tasar.

Este es el "por qué" de la estructura: los **préstamos de construcción** entregan el dinero por etapas, en lo que se llama un **calendario de desembolsos** (draw schedule), atado a fases específicas terminadas del proyecto (cimientos, estructura, plomería y electricidad, terminaciones, etc.). [VERIFIED FACT] Los prestamistas normalmente exigen una inspección antes de entregar cada desembolso, para confirmar que el trabajo descrito realmente se terminó con la calidad esperada antes de adelantar más dinero. Esto protege al prestamista de entregar dinero por trabajo que no se ha hecho, y le da al prestatario fondos que van de acuerdo con su avance y su necesidad reales.

Como los préstamos de construcción son por naturaleza de corto plazo y están atados a que se termine un proyecto, a menudo se convierten en una hipoteca estándar a largo plazo (a veces de forma automática, en un préstamo de "construcción a permanente") cuando la obra termina y se puede tasar como un activo terminado, lo que conecta con los conceptos de refinanciamiento de la Lección 8.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Un inversionista construye un dúplex nuevo con un préstamo de construcción que tiene un calendario de desembolsos atado a cinco fases del proyecto. Después de que se vacían e inspeccionan los cimientos, se entrega el primer desembolso. Los siguientes desembolsos siguen el mismo patrón a medida que se terminan e inspeccionan la estructura, luego la plomería y electricidad, y luego las terminaciones interiores. Cuando la obra pasa la inspección final y se tasa como una propiedad terminada, el préstamo de construcción se convierte en una hipoteca estándar a largo plazo basada en el valor tasado de la propiedad terminada, muy parecido al paso de "refinanciar" de una estrategia BRRRR (Lección 9), pero para una construcción nueva en lugar de una propiedad existente.

## Prueba de práctica

1. ¿Por qué los préstamos de construcción no entregan el monto completo en el cierre, a diferencia de un préstamo de compra?
2. ¿Qué es un calendario de desembolsos, y por qué normalmente se exige una inspección antes de cada desembolso?
3. ¿Qué suele pasar con un préstamo de construcción cuando la obra termina?

## Clave de respuestas

1. Porque la propiedad que se financia todavía no existe del todo, así que el dinero se entrega por etapas de acuerdo con el avance real, en lugar de todo de una vez contra un activo terminado.
2. Un calendario de desembolsos entrega el dinero atado a fases específicas terminadas del proyecto; las inspecciones confirman que el trabajo descrito realmente se hizo antes de adelantar más dinero, lo que protege al prestamista de financiar trabajo que no ha ocurrido.
3. A menudo se convierte en una hipoteca estándar a largo plazo, a veces de forma automática mediante una estructura de construcción a permanente, cuando la obra termina y se puede tasar.

## Respuestas y explicaciones

1. Este es el "por qué" básico de toda la lección.
2. Esto explica el mecanismo específico (desembolsos más inspecciones) que hace funcionar en la práctica la entrega por etapas.
3. Esto conecta el financiamiento de construcción con el concepto de refinanciamiento que ya se estableció en la Lección 8.

## Puntos clave
- Los préstamos de construcción entregan el dinero por etapas (un calendario de desembolsos) y no todo de una vez, porque el activo todavía no existe del todo.
- Normalmente se exigen inspecciones antes de cada desembolso para confirmar que el trabajo descrito realmente se terminó.
- Los préstamos de construcción a menudo se convierten en una hipoteca estándar a largo plazo cuando la obra termina y se puede tasar.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
