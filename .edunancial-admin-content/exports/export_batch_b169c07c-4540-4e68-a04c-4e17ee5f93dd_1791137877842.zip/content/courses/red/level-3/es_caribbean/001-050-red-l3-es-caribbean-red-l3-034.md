---
id: RED-L3-034
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 34
title: "Por qué la depreciación y el servicio de la deuda se tienen que modelar juntos"
source_title: "Why Depreciation and Debt Service Have to Be Modeled Together"
description: "Aprende por qué una propiedad puede mostrar una pérdida tributaria en papel y aun así generar flujo de efectivo positivo después del pago de la hipoteca, y por qué esa diferencia importa."
slug: red-l3-034-depreciation-and-debt-service
seo_title: "Por qué la depreciación y el servicio de la deuda se tienen que modelar juntos | Edunancial"
meta_description: "Aprende por qué una propiedad puede mostrar una pérdida tributaria en papel y aun así generar flujo de efectivo positivo después del pago de la hipoteca, y por qué esa diferencia importa."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-034: Por qué la depreciación y el servicio de la deuda se tienen que modelar juntos

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar por qué la depreciación reduce el ingreso tributable sin reducir el flujo de efectivo real
- Explicar por qué el ingreso tributable y el flujo de efectivo pueden apuntar en direcciones opuestas en la misma propiedad
- Conectar este concepto con la discusión sobre préstamos DSCR de la Lección 20

## Contenido principal

La **depreciación** es una deducción tributaria que les permite a los dueños de propiedades deducir cada año una parte del valor de la propiedad como un "costo" de ser dueño, basada en la idea de que los edificios se desgastan con el tiempo, aunque, a diferencia de un gasto de mantenimiento, no sale dinero real de tu bolsillo cuando la reclamas.

Este es el "por qué" de que cree una diferencia importante: una propiedad puede mostrar una **pérdida tributaria** en papel (ingreso de alquiler menos gastos menos depreciación) y aun así generar un **flujo de efectivo positivo** en la realidad (ingreso de alquiler menos los gastos reales en efectivo, incluido el pago de la hipoteca, pero sin incluir la deducción de depreciación, que no es en efectivo). La depreciación reduce el ingreso tributable que ve el IRS (la agencia de impuestos federal de Estados Unidos) sin reducir el dinero real que cobra el inversionista.

Esto conecta directamente con la discusión sobre DSCR de la Lección 20: es exactamente esta diferencia (un inversionista de bienes raíces cuyas planillas de impuestos muestran un ingreso tributable relativamente bajo, o incluso negativo, a pesar de tener propiedades que rinden bien en flujo de efectivo) lo que llevó a que los préstamos DSCR califiquen según el ingreso de la propiedad en lugar de la planilla de impuestos personal del prestatario.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Una propiedad cobra $24,000 al año de renta, tiene $10,000 al año en gastos reales en efectivo (hipoteca, contribuciones, seguro, mantenimiento) y califica para $9,000 al año de depreciación. Flujo de efectivo real: $24,000 − $10,000 = $14,000 positivo. Ingreso tributable: $24,000 − $10,000 − $9,000 = $5,000, todavía positivo aquí, pero en muchos escenarios reales, sobre todo con propiedades más grandes o métodos de depreciación acelerada, esta cifra tributable puede volverse negativa mientras el flujo de efectivo sigue siendo muy positivo.

## Prueba de práctica

1. ¿Por qué la depreciación no reduce el flujo de efectivo real, aunque reduce el ingreso tributable?
2. ¿Qué puede pasar con la relación entre el ingreso tributable y el flujo de efectivo a medida que aumenta la depreciación?
3. ¿Cómo conecta este concepto con la discusión sobre préstamos DSCR de la Lección 20?

## Clave de respuestas

1. Porque la depreciación es una deducción que no es en efectivo: refleja una pérdida de valor supuesta, no un gasto real pagado durante el año.
2. El ingreso tributable puede quedar muy por debajo del flujo de efectivo real, y en algunos casos volverse negativo, mientras la propiedad genera un flujo de efectivo real sólido.
3. Los préstamos DSCR existen en parte para resolver el desajuste que describe esta lección: califican según el desempeño real del ingreso de la propiedad en lugar de una planilla de impuestos personal que la depreciación puede haber hecho ver más débil que la verdadera situación financiera.

## Respuestas y explicaciones

1. Esta es la mecánica básica de la que depende el resto de la lección.
2. Esto muestra cómo puede crecer la diferencia entre las dos cifras, y refuerza por qué importa para las decisiones de financiamiento.
3. Esto cierra de forma explícita el círculo con una lección anterior, y refuerza la estructura integrada de la ruta.

## Puntos clave
- La depreciación reduce el ingreso tributable sin reducir el flujo de efectivo real, porque es una deducción que no es en efectivo.
- Esto puede crear una diferencia importante entre lo que muestra una planilla de impuestos y lo que una propiedad realmente genera en efectivo.
- Esta diferencia es una razón clave de que existan los préstamos DSCR: calificar a los inversionistas según el desempeño real de la propiedad, no según una planilla de impuestos que la depreciación puede hacer ver más débil.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
