---
id: RED-L3-039
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 39
title: "Por qué la dación en pago y la venta corta son caminos de salida distintos"
source_title: "Why Deed-in-Lieu and Short Sales Are Different Exit Paths"
description: "Aprende sobre dos alternativas a la ejecución hipotecaria, la dación en pago y la venta corta, y por qué cada una puede hacer menos daño que dejar que la ejecución siga adelante."
slug: red-l3-039-deed-in-lieu-and-short-sales
seo_title: "Por qué la dación en pago y la venta corta son caminos de salida distintos | Edunancial"
meta_description: "Aprende sobre dos alternativas a la ejecución hipotecaria, la dación en pago y la venta corta, y por qué cada una puede hacer menos daño que dejar que la ejecución siga adelante."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-039: Por qué la dación en pago y la venta corta son caminos de salida distintos

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar qué es una dación en pago
- Explicar qué es una venta corta y cuándo se podría usar
- Explicar por qué ambas se consideran generalmente alternativas menos dañinas que una ejecución completa

## Contenido principal

Cuando un prestatario está en una situación financiera grave y el incumplimiento parece probable o ya ocurrió, la ejecución hipotecaria (Lección 38) no es el único resultado posible. Dos alternativas comunes son la dación en pago y la venta corta.

Una **dación en pago** (deed-in-lieu of foreclosure) es un acuerdo en que el prestatario le traspasa voluntariamente el título de la propiedad al prestamista, a cambio de que el prestamista lo libere de la obligación restante del préstamo, evitando un proceso formal de ejecución.

Una **venta corta** (short sale) ocurre cuando la propiedad se vende por menos del balance que queda del préstamo, con el acuerdo del prestamista de aceptar ese dinero como pago (total o parcial) de la deuda, en lugar de perseguir el balance completo.

Este es el "por qué" de que ambas existan como alternativas: [VERIFIED FACT] la ejecución hipotecaria generalmente es costosa y lenta para los prestamistas, y tanto la dación en pago como la venta corta pueden resolver la situación más rápido y con menos costo para ambas partes, comparado con un proceso de ejecución completo, aunque los resultados, el efecto en el crédito y cualquier responsabilidad restante del prestatario pueden variar mucho según la situación, el prestamista y la jurisdicción.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Una inversionista con una propiedad "bajo agua" (que vale menos que el balance del préstamo), y que no puede sostener los pagos, contacta a su prestamista antes de dejar de pagar por completo. En lugar de avanzar hacia la ejecución, negocian una venta corta: la propiedad se vende por menos del balance del préstamo, y el prestamista acepta ese dinero como solución de la deuda bajo los términos negociados. [ASSUMPTION] Este camino, aunque sigue siendo un resultado difícil, generalmente se considera menos dañino para la posición financiera total de la inversionista que dejar que la situación llegue hasta una ejecución completa.

## Prueba de práctica

1. ¿Qué es una dación en pago?
2. ¿Qué es una venta corta?
3. ¿Por qué un prestamista podría aceptar cualquiera de estas alternativas en lugar de seguir con la ejecución?

## Clave de respuestas

1. Un traspaso voluntario del título de la propiedad al prestamista a cambio de ser liberado de la obligación restante del préstamo, evitando la ejecución formal.
2. Vender la propiedad por menos del balance que queda del préstamo, con el acuerdo del prestamista de aceptar ese dinero como pago (total o parcial) de la deuda.
3. Porque la ejecución generalmente es costosa y lenta, y estas alternativas pueden resolver la situación más rápido y con menos costo tanto para el prestamista como para el prestatario.

## Respuestas y explicaciones

1. Esta es la base de definición de la primera alternativa que se discute.
2. Esta es la base de definición de la segunda alternativa.
3. Esto refuerza el propio incentivo del prestamista para considerar estas alternativas, y conecta con la discusión sobre el costo de la ejecución de la Lección 38.

## Puntos clave
- Una dación en pago traspasa voluntariamente el título al prestamista a cambio de ser liberado de la deuda restante.
- Una venta corta vende la propiedad por menos de lo que se debe, con el acuerdo del prestamista de aceptar ese dinero para la deuda.
- Ambas se consideran generalmente alternativas que pueden ser menos dañinas que una ejecución completa, aunque los resultados específicos varían según la situación.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Los resultados varían mucho según la situación y la jurisdicción; consulta a un abogado o a un profesional financiero con licencia para cualquier situación específica.*
