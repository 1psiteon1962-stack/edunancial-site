---
id: RED-L3-040
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 40
title: "Por qué someter a prueba de estrés la cobertura del servicio de la deuda te protege antes de una caída"
source_title: "Why Stress-Testing Debt Service Coverage Protects You Before a Downturn"
description: "Aprende a someter a prueba de estrés el DSCR de una propiedad contra un aumento de la desocupación o una baja en las rentas antes de comprometerte con un negocio apalancado."
slug: red-l3-040-stress-testing-dscr
seo_title: "Por qué someter a prueba de estrés la cobertura del servicio de la deuda te protege antes de una caída | Edunancial"
meta_description: "Aprende a someter a prueba de estrés el DSCR de una propiedad contra un aumento de la desocupación o una baja en las rentas antes de comprometerte con un negocio apalancado."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-040: Por qué someter a prueba de estrés la cobertura del servicio de la deuda te protege antes de una caída

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar qué significa someter a prueba de estrés el DSCR de una propiedad
- Aplicar una prueba de estrés sencilla usando una renta más baja o una desocupación más alta
- Explicar por qué esta práctica conecta casi todas las lecciones anteriores de esta ruta

## Contenido principal

La Lección 20 presentó el DSCR como una medida del ingreso de una propiedad en relación con sus pagos de deuda, calculada bajo condiciones esperadas en que "todo sale según lo planeado". **Someter a prueba de estrés** el DSCR significa recalcular esa misma razón bajo un escenario peor a propósito (más desocupación, renta más baja o gastos más altos) para ver si la propiedad todavía cubre su deuda si las condiciones resultan menos favorables de lo proyectado.

Este es el "por qué" de que importe: un negocio que se ve sólido con supuestos optimistas puede verse muy distinto cuando se aplican escenarios realistas a la baja (la desocupación y las reservas de la Lección 10, el escenario de choque de tasas de la Lección 14). Hacer la prueba de estrés antes de comprometerse con un negocio, no después de que llegue una caída, es lo que convierte las lecciones abstractas de manejo de riesgo de esta ruta en un hábito de evaluación concreto y repetible.

[ILLUSTRATIVE EXAMPLE] Una prueba de estrés sencilla podría recalcular el DSCR suponiendo una renta entre 10% y 15% más baja de lo proyectado, o una desocupación del doble de lo típico para ese mercado, y comprobar si el DSCR resultante se mantiene por encima de un límite cómodo (en línea con los DSCR mínimos discutidos en la Lección 20).

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Se proyecta que una propiedad genere $2,000 al mes de ingreso operativo neto contra un pago de deuda de $1,700 al mes: un DSCR de más o menos 1.18. Si se hace la prueba de estrés con la renta 12% más baja, el ingreso operativo neto baja a unos $1,760 al mes, para un DSCR bajo estrés de más o menos 1.04. [ASSUMPTION] Si el DSCR mínimo bajo estrés que acepta el propio inversionista es 1.10, este negocio no pasa la prueba de estrés aunque se vea razonable con la proyección original y optimista: una señal para negociar un precio de compra más bajo, poner más pago inicial para reducir el pago de la deuda, o no hacer el negocio.

## Prueba de práctica

1. ¿Qué significa someter a prueba de estrés el DSCR de una propiedad?
2. ¿Por qué la prueba de estrés se hace antes de comprometerse con un negocio y no después de que ocurra una caída?
3. En el ejemplo práctico, ¿qué acción específica podría llevar al inversionista a considerar el no pasar la prueba de estrés?

## Clave de respuestas

1. Recalcular el DSCR bajo un escenario peor a propósito, como más desocupación o una renta más baja, para ver si la propiedad todavía cubriría sus pagos de deuda.
2. Porque revela la fragilidad escondida mientras todavía se puede escoger no hacer el negocio, negociar o reestructurarlo, en lugar de descubrir la fragilidad solo después de que las condiciones ya empeoraron.
3. Negociar un precio de compra más bajo, aumentar el pago inicial para reducir el pago de la deuda, o no hacer el negocio.

## Respuestas y explicaciones

1. Esta es la base de definición de la lección.
2. Esto refuerza el tema de la planificación preventiva que atraviesa la ruta, en línea con el razonamiento del choque de tasas de la Lección 14.
3. Esto muestra el resultado práctico y accionable de una prueba de estrés, no solo un ejercicio académico.

## Puntos clave
- Someter a prueba de estrés el DSCR significa recalcularlo bajo un escenario peor a propósito que la proyección optimista.
- Esta práctica convierte los conceptos de manejo de riesgo de lecciones anteriores en un hábito de evaluación concreto y repetible.
- No pasar una prueba de estrés es una señal para renegociar los términos, aumentar el pago inicial o no hacer el negocio, antes de comprometerse, no después de una caída.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
