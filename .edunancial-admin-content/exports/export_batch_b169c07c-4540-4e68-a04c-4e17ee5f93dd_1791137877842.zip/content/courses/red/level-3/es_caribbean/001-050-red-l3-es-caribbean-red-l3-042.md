---
id: RED-L3-042
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 42
title: "Por qué los topes de las tasas ajustables importan más que la tasa de introducción"
source_title: "Why Adjustable-Rate Caps Matter More Than the Teaser Rate"
description: "Aprende por qué los topes de tasa de una hipoteca de tasa ajustable importan más para el riesgo a largo plazo que la atractiva tasa inicial."
slug: red-l3-042-arm-rate-caps
seo_title: "Por qué los topes de las tasas ajustables importan más que la tasa de introducción | Edunancial"
meta_description: "Aprende por qué los topes de tasa de una hipoteca de tasa ajustable importan más para el riesgo a largo plazo que la atractiva tasa inicial."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-042: Por qué los topes de las tasas ajustables importan más que la tasa de introducción

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar qué limitan los topes de tasa de una hipoteca de tasa ajustable
- Explicar por qué la tasa inicial "de introducción" es una mala base para evaluar el riesgo a largo plazo
- Identificar por qué entender el tope en el peor escenario importa más que la tasa inicial en el mejor escenario

## Contenido principal

La Lección 6 presentó el riesgo general de los préstamos de tasa ajustable a medida que crece un portafolio. Esta lección se enfoca en una característica de protección específica que tienen muchos ARM: los **topes de tasa** (rate caps). Estos normalmente limitan cuánto puede subir la tasa en cada período de ajuste, y cuánto puede subir en total durante la vida del préstamo.

Este es el "por qué" de que los topes importen más que la tasa inicial: la tasa inicial de un ARM, a veces llamada tasa de introducción (teaser rate), muchas veces es más baja que una tasa fija comparable precisamente para atraer prestatarios, pero no revela nada sobre el peor escenario del préstamo. Los topes sí lo revelan. [VERIFIED FACT] Las estructuras de topes varían según el préstamo, pero muchas veces incluyen un tope por ajuste (que limita cuánto puede subir la tasa en un solo reajuste) y un tope de por vida (que limita el aumento total posible durante todo el plazo del préstamo); entender ambos es necesario para saber el verdadero pago máximo que el préstamo podría llegar a exigir.

Un inversionista que evalúa un ARM debe evaluar el negocio contra el pago del peor escenario con el tope de por vida, no contra la atractiva tasa inicial, en línea con el principio de la prueba de estrés de la Lección 40, aplicado específicamente al riesgo de tasa.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Un ARM empieza con una tasa bastante más baja que las tasas fijas actuales, con una estructura que permite un aumento de hasta 2% por ajuste y un tope de por vida de 5% por encima de la tasa inicial. Un inversionista que evalúa solo la atractiva tasa inicial podría subestimar el riesgo real del préstamo. [ASSUMPTION] Evaluar bien el negocio significa calcular el pago con el tope de por vida completo de 5% y confirmar que el ingreso proyectado de la propiedad todavía podría cubrir ese pago del peor escenario, no solo el atractivo pago inicial.

## Prueba de práctica

1. ¿Qué limitan normalmente los topes de tasa de un ARM?
2. ¿Por qué la tasa inicial "de introducción" es una mala base para evaluar el riesgo real de un ARM?
3. Según esta lección, ¿contra qué debe evaluar un inversionista el negocio?

## Clave de respuestas

1. Cuánto puede subir la tasa de interés en cada período de ajuste, y cuánto puede subir en total durante la vida del préstamo.
2. Porque muchas veces se fija artificialmente baja para atraer prestatarios y no revela nada sobre el pago del peor escenario del préstamo.
3. Contra el pago del peor escenario calculado con el tope de por vida del préstamo, no contra la atractiva tasa inicial.

## Respuestas y explicaciones

1. Esta es la base de definición de la que depende la lección.
2. Esta es la advertencia central: no dejes que un número inicial atractivo sustituya el análisis del peor escenario.
3. Esto aplica directamente el principio de la prueba de estrés de la Lección 40 al riesgo específico de tasa.

## Puntos clave
- Los topes de tasa limitan cuánto puede subir la tasa de un ARM por ajuste y durante toda su vida.
- La tasa de introducción muchas veces se fija baja para atraer prestatarios y no refleja el verdadero riesgo del peor escenario del préstamo.
- Un negocio se debe evaluar contra el pago del peor escenario con el tope de por vida, no contra la atractiva tasa inicial.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Todas las cifras son estimados ilustrativos, no garantías. Consulta a un profesional con licencia antes de tomar decisiones financieras.*
