---
id: RED-L3-045
locale: es-Caribbean
source_locale: en-US
track: RED
level: 3
lesson: 45
title: "Por qué las estructuras de deuda en sociedades y empresas conjuntas reparten el riesgo de forma distinta"
source_title: "Why Partnership and JV Debt Structures Split Risk Differently"
description: "Aprende por qué traer un socio cambia cómo se reparten el riesgo de la deuda y la responsabilidad, y por qué ese reparto se tiene que dejar claro por escrito."
slug: red-l3-045-partnership-and-jv-debt
seo_title: "Por qué las estructuras de deuda en sociedades y empresas conjuntas reparten el riesgo de forma distinta | Edunancial"
meta_description: "Aprende por qué traer un socio cambia cómo se reparten el riesgo de la deuda y la responsabilidad, y por qué ese reparto se tiene que dejar claro por escrito."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-045: Por qué las estructuras de deuda en sociedades y empresas conjuntas reparten el riesgo de forma distinta

## Objetivos de aprendizaje
Al terminar esta lección, podrás:
- Explicar por qué una sociedad o empresa conjunta cambia cómo se comparte el riesgo de la deuda
- Explicar por qué la responsabilidad por el préstamo y el porcentaje de propiedad no siempre coinciden
- Explicar por qué un acuerdo escrito claro importa especialmente cuando la deuda es compartida

## Contenido principal

Hasta ahora, esta ruta ha discutido el apalancamiento mayormente desde la perspectiva de un solo inversionista. En una **sociedad** o **empresa conjunta (JV, por sus siglas en inglés)**, dos o más partes combinan capital, y a veces responsabilidad, para adquirir una propiedad juntas; muchas veces se usa para acceder a negocios más grandes de los que una sola parte podría hacer.

Este es el "por qué" de que cambie el panorama del riesgo: cómo se reparte la propiedad y cómo se reparte la responsabilidad por el préstamo no son automáticamente lo mismo, y se tienen que definir de forma explícita. [ILLUSTRATIVE EXAMPLE] Un socio podría aportar la mayor parte del capital y tener una parte mayor de la propiedad, mientras que un prestamista podría exigir de todas formas que ambos socios garanticen personalmente el préstamo (lo que conecta con la Lección 28) sin importar su porcentaje de propiedad; eso significa que un socio con una parte menor de la propiedad todavía podría cargar una exposición personal importante si el negocio cae en incumplimiento.

[VERIFIED FACT] Como estos acuerdos involucran a varias partes con niveles de participación, capital y tolerancia al riesgo que pueden ser distintos, un acuerdo de sociedad escrito y claro, que cubra el reparto de la propiedad, la responsabilidad, quién toma las decisiones y qué pasa si un socio quiere salir, generalmente se considera esencial, y normalmente conviene redactarlo con orientación legal.

## Ejemplo práctico

[ILLUSTRATIVE EXAMPLE] Dos socios compran una propiedad juntos: el Socio A aporta el 80% del pago inicial y tiene el 80% de la propiedad; el Socio B aporta el 20% y tiene el 20% de la propiedad. El prestamista exige que ambos socios garanticen personalmente el préstamo completo, sin importar su reparto de la propiedad. Si el negocio cae en incumplimiento, al Socio B, a pesar de tener una parte menor de la propiedad y un aporte de capital menor, todavía lo podrían perseguir personalmente por el monto garantizado completo, no solo por el 20%, a menos que el acuerdo de sociedad y los documentos del préstamo traten y limiten específicamente esa exposición.

## Prueba de práctica

1. ¿Por qué el porcentaje de propiedad y la responsabilidad por el préstamo no coinciden automáticamente en una sociedad?
2. En el ejemplo práctico, ¿qué riesgo enfrenta el Socio B a pesar de tener una parte menor de la propiedad?
3. ¿Por qué un acuerdo de sociedad escrito y claro es especialmente importante en estos acuerdos?

## Clave de respuestas

1. Porque los requisitos de garantía personal de un prestamista son independientes de cómo los socios acuerdan en privado repartir la propiedad: un prestamista puede exigir garantías completas a todos los socios sin importar su porcentaje de propiedad.
2. Que lo persigan personalmente por el monto completo garantizado del préstamo si el negocio cae en incumplimiento, no solo por una cantidad proporcional a su 20% de la propiedad, a menos que los acuerdos lo traten específicamente.
3. Porque define de forma explícita el reparto de la propiedad, la responsabilidad, la toma de decisiones y los términos de salida, y evita disputas o exposiciones inesperadas que de otra forma podrían surgir de suposiciones no dichas entre los socios.

## Respuestas y explicaciones

1. Esta es la distinción central, y fácil de pasar por alto, sobre la que se construye la lección.
2. Esto aplica el concepto abstracto al ejemplo numérico específico.
3. Esto refuerza el paso práctico y de protección que toda sociedad debe dar.

## Puntos clave
- En una sociedad, el porcentaje de propiedad y la responsabilidad por el préstamo no son automáticamente lo mismo y se tienen que definir de forma explícita.
- Un socio con una parte menor de la propiedad todavía puede cargar toda la responsabilidad personal si un prestamista exige que todos los socios garanticen el préstamo.
- Un acuerdo de sociedad escrito, claro y redactado por un profesional es esencial para definir estos términos y evitar disputas o exposiciones inesperadas.

---

*Esta lección es solo para educación financiera general y no constituye asesoría financiera, de inversión, fiscal ni legal personalizada. Consulta a un abogado con licencia al estructurar cualquier acuerdo de sociedad o empresa conjunta.*
