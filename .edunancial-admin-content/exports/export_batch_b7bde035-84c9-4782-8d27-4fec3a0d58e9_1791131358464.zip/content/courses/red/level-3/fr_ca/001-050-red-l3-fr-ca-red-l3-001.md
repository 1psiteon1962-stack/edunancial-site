---
id: RED-L3-001
locale: fr-CA
source_locale: en-US
track: RED
level: 3
lesson: 1
title: "Pourquoi la dette n'est pas toujours mauvaise : dette stratégique vs dette de consommation"
source_title: "Why Debt Isn't Always Bad: Strategic vs. Consumer Debt"
description: "Découvrez pourquoi toutes les dettes ne se valent pas, et pourquoi la dette derrière un immeuble à revenus peut bâtir un patrimoine alors que celle d'une carte de crédit le détruit."
slug: red-l3-001-strategic-vs-consumer-debt
seo_title: "Pourquoi la dette n'est pas toujours mauvaise : dette stratégique vs dette de consommation | Edunancial"
meta_description: "Découvrez pourquoi toutes les dettes ne se valent pas, et pourquoi la dette derrière un immeuble à revenus peut bâtir un patrimoine alors que celle d'une carte de crédit le détruit."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-001: Pourquoi la dette n'est pas toujours mauvaise : dette stratégique vs dette de consommation

## Objectifs d'apprentissage
À la fin de cette leçon, vous serez capable de :
- Expliquer la différence entre la dette stratégique et la dette de consommation
- Identifier dans quelle catégorie se range un prêt donné, et pourquoi c'est important
- Expliquer pourquoi le même mot, « dette », peut décrire deux situations financières opposées

## Contenu principal

On apprend à la plupart des gens une seule leçon sur la dette : l'éviter. Ce conseil a du sens pour un type de dette, et c'est un conseil dangereux pour un autre type.

La **dette de consommation** paie des choses qui perdent de la valeur dès que vous les achetez : des soldes de carte de crédit pour des choses déjà consommées, un crédit auto pour un véhicule qui se déprécie chaque année, un prêt pour des vacances. L'actif (ou le non-actif) ne produit aucun revenu. Vous payez des intérêts sur de l'argent déjà dépensé, sans que rien ne travaille pour rembourser ces intérêts à votre place.

La **dette stratégique**, parfois appelée dette productive, est différente sur un point précis : elle est adossée à un actif qui produit un revenu ou prend de la valeur, et c'est ce revenu (ou le projet de revendre l'actif) qui rembourse le prêt. Un prêt hypothécaire sur un immeuble à revenus en est l'exemple le plus clair. C'est le loyer du locataire, et non votre salaire, qui est censé couvrir le versement du prêt hypothécaire.

Voici le « pourquoi » qui compte à ce niveau : ce n'est ni le montant de la dette, ni même le taux d'intérêt, qui rend une dette bonne ou mauvaise. C'est le fait que la dette soit liée ou non à quelque chose qui se paie tout seul. [ILLUSTRATIVE EXAMPLE] Un prêt hypothécaire de 300 000 $ sur un immeuble à revenus qui dégage 500 $ par mois de cash-flow net après toutes les dépenses est une dette qui travaille. Un prêt hypothécaire de 300 000 $ sur une maison que vous n'avez pas les moyens de payer, et qui vous oblige à puiser dans votre épargne chaque mois pour le couvrir, est un passif déguisé en actif : même montant, même taux, un risque complètement différent.

[VERIFIED FACT] Les deux types de dette vous obligent légalement à rembourser, et les deux affectent votre crédit et votre capacité d'emprunt. Cette partie ne change pas. Ce qui change, c'est qui (ou quoi) effectue réellement le paiement : vous, avec vos propres revenus, ou l'actif, avec le revenu qu'il génère.

Cette distinction est la base de tout le reste de ce parcours. Chaque leçon à partir d'ici suppose que vous savez distinguer ces deux types de dette avant même de regarder les chiffres.

## Exemple pratique

Maria hésite entre deux prêts :

- **Prêt A** : un prêt de 25 000 $ pour une voiture neuve. Mensualité : 450 $ par mois. La voiture perd de la valeur chaque année où elle la possède.
- **Prêt B** : un prêt hypothécaire de 180 000 $ pour un duplex (immeuble de deux logements). Mensualité : 1 100 $ par mois. [ESTIMATE] Le loyer total des deux logements, après avoir mis de côté de l'argent pour l'inoccupation et les réparations, est estimé à 1 450 $ par mois.

Le prêt A est une dette de consommation : il est payé entièrement avec le salaire de Maria, et l'actif sous-jacent perd de la valeur pendant tout ce temps.

Le prêt B est une dette stratégique : le loyer des locataires devrait couvrir le versement et laisser 350 $ par mois de reste, et l'actif sous-jacent (le duplex) peut prendre de la valeur. Ce n'est pas Maria qui rembourse ce prêt, c'est le bien, à condition que [ASSUMPTION] les prévisions de loyer se confirment et que les logements restent raisonnablement occupés.

## Quiz d'entraînement

1. Quel est le seul facteur qui détermine si une dette est « stratégique » ou « de consommation », quel que soit le montant du prêt ou le taux d'intérêt ?
2. Vrai ou faux : un crédit auto ne peut jamais être considéré comme une dette stratégique.
3. Dans l'exemple pratique, pourquoi le prêt B est-il considéré comme une dette stratégique alors qu'il porte sur un montant bien plus élevé que le prêt A ?
4. Quel risque concret pourrait transformer la dette « stratégique » du duplex de Maria en quelque chose qui se comporte comme une dette de consommation ?

## Corrigé

1. Le fait que la dette soit adossée à un actif qui produit un revenu (ou qui prend de la valeur de façon fiable) suffisant pour couvrir le versement.
2. Faux : si la voiture sert à générer un revenu (par exemple, un véhicule de livraison dont le revenu couvre clairement le prêt), elle peut fonctionner comme une dette stratégique. Le contexte compte plus que l'étiquette de la catégorie.
3. Parce que la dette est censée être remboursée par les loyers du bien, et non par le salaire personnel de Maria.
4. Si les logements restent vides, si les loyers baissent ou si de grosses réparations rongent le cash-flow, Maria pourrait devoir payer le versement avec ses propres revenus ; à ce moment-là, la dette se comporte comme une dette de consommation, même si elle est garantie par un bien immobilier.

## Réponses et explications

1. Le montant du prêt et le taux d'intérêt comptent pour les conditions de l'opération, mais ils ne déterminent pas la *catégorie* de la dette. La catégorie dépend du lien entre la dette et le revenu auquel elle est rattachée.
2. C'est une question de « pourquoi », pas de « quoi » : elle vérifie que vous comprenez le principe de fond au lieu de retenir par cœur « voiture = mauvaise dette ». Le principe s'applique ailleurs : toute dette adossée à un usage qui génère un revenu peut être stratégique.
3. Le montant n'a rien à voir avec la classification. Ce qui compte, c'est le lien avec le revenu : le prêt B est conçu pour se rembourser tout seul.
4. C'est le risque central de l'effet de levier immobilier, et c'est pourquoi les leçons suivantes de ce parcours traitent en détail des réserves pour inoccupation et des marges de sécurité sur le cash-flow. Une dette stratégique peut se dégrader en dette de consommation si le côté revenu de l'équation s'effondre.

## Points clés
- Une dette n'est ni bonne ni mauvaise en soi : sa classification dépend de ce qui la rembourse.
- La dette stratégique est adossée à des actifs qui produisent un revenu ou prennent de la valeur ; la dette de consommation n'est adossée qu'à votre futur salaire.
- Un prêt du même montant, au même taux, peut présenter un risque radicalement différent selon ce seul facteur.
- Une dette stratégique peut quand même échouer : la cause de l'échec est généralement l'effondrement de l'hypothèse de revenu, pas la dette elle-même.

---

*Cette leçon est fournie uniquement à des fins d'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations illustratives, et non des garanties. Consultez un professionnel autorisé avant de prendre des décisions financières.*
