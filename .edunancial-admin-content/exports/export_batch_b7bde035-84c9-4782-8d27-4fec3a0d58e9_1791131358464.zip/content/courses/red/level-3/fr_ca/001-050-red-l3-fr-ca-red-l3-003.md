---
id: RED-L3-003
locale: fr-CA
source_locale: en-US
track: RED
level: 3
lesson: 3
title: "Pourquoi l'effet de levier multiplie à la fois les gains et les pertes"
source_title: "Why Leverage Multiplies Both Gains and Losses"
description: "Découvrez pourquoi utiliser de l'argent emprunté pour acheter de l'immobilier peut augmenter fortement vos rendements, et augmenter tout aussi fortement votre risque."
slug: red-l3-003-leverage-multiplies-gains-and-losses
seo_title: "Pourquoi l'effet de levier multiplie à la fois les gains et les pertes | Edunancial"
meta_description: "Découvrez pourquoi utiliser de l'argent emprunté pour acheter de l'immobilier peut augmenter fortement vos rendements, et augmenter tout aussi fortement votre risque."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-003: Pourquoi l'effet de levier multiplie à la fois les gains et les pertes

## Objectifs d'apprentissage
À la fin de cette leçon, vous serez capable de :
- Expliquer ce que signifie l'effet de levier dans le contexte immobilier
- Calculer comment l'effet de levier modifie le rendement en pourcentage d'un bien par rapport à un achat entièrement au comptant
- Expliquer pourquoi l'effet de levier est à double tranchant, en augmentant à la fois les gains et les pertes potentiels

## Contenu principal

L'effet de levier consiste à utiliser de l'argent emprunté pour contrôler un actif plus important que la somme que vous y avez investie. En immobilier, cela prend généralement la forme d'une mise de fonds : vous pouvez apporter 20 % du prix d'un bien et emprunter les 80 % restants.

Voici le « pourquoi » qui rend l'effet de levier puissant : votre rendement est calculé sur l'argent que *vous* avez investi, et non sur le prix total du bien. Si la valeur du bien augmente, ce gain s'applique au bien *entier*, mais vous n'avez eu à avancer qu'une fraction du prix d'achat pour en profiter.

[ILLUSTRATIVE EXAMPLE] Un bien de 200 000 $ qui prend 5 % de valeur en un an gagne 10 000 $. Si vous avez tout payé au comptant (200 000 $), votre rendement est de 5 %. Si vous avez fait une mise de fonds de 40 000 $ (20 %) et financé le reste, ce même gain de 10 000 $ représente maintenant un rendement de 25 % sur vos 40 000 $, parce que le gain est mesuré par rapport à une somme beaucoup plus petite de votre propre argent.

C'est exactement pour cela que l'effet de levier est à double tranchant. [ILLUSTRATIVE EXAMPLE] Si ce même bien avait plutôt perdu 5 % de sa valeur, l'acheteur au comptant serait en baisse de 5 %. L'acheteur qui a utilisé le levier serait en baisse de 25 % sur son capital investi : le même effet multiplicateur, mais dans l'autre sens. La dette ne diminue pas simplement parce que la valeur du bien a baissé.

C'est pourquoi les leçons de ce niveau insistent sur le mot « levier » plutôt que simplement « financement » : le levier décrit un multiplicateur mathématique, et les multiplicateurs s'appliquent aux pertes exactement aussi facilement qu'aux gains.

## Exemple pratique

Deux investisseurs examinent le même duplex à 250 000 $.

- **L'investisseur A** paie tout au comptant : 250 000 $ de sa poche.
- **L'investisseur B** fait une mise de fonds de 20 % (50 000 $) et finance le reste.

[ASSUMPTION] Supposons que le bien prenne 8 % de valeur en trois ans, puis, dans un scénario de repli, imaginons qu'il ait plutôt perdu 8 %.

Scénario de hausse : le bien gagne 20 000 $ de valeur.
- Rendement de l'investisseur A : 20 000 $ / 250 000 $ = 8 %
- Rendement de l'investisseur B : 20 000 $ / 50 000 $ = 40 %

Scénario de baisse : le bien perd 20 000 $ de valeur.
- Perte de l'investisseur A : 8 % du capital investi
- Perte de l'investisseur B : 40 % du capital investi, et l'investisseur B doit toujours la totalité du solde du prêt, quelle que soit la valeur actuelle du bien.

## Quiz d'entraînement

1. Quelle est la raison mathématique pour laquelle l'effet de levier augmente le rendement en pourcentage des gains ?
2. Pourquoi la dette d'un acheteur qui utilise le levier ne diminue-t-elle pas quand le bien perd de la valeur ?
3. Si l'investisseur B de l'exemple pratique avait fait une mise de fonds de 10 % au lieu de 20 %, ses variations en pourcentage (à la hausse ou à la baisse) seraient-elles plus grandes ou plus petites ? Pourquoi ?
4. Expliquez avec vos propres mots pourquoi « levier » est un mot plus juste que « financement » pour décrire ce qui se passe dans cette leçon.

## Corrigé

1. Parce que le rendement est mesuré par rapport à l'argent que l'investisseur a lui-même investi, et non par rapport au prix total du bien : un dénominateur plus petit transforme le même gain en dollars en un pourcentage plus élevé.
2. Le prêt est une obligation fixe, indépendante de la valeur de marché du bien ; seule la valeur nette (valeur du bien moins solde du prêt) évolue avec le marché.
3. Des variations plus grandes, parce qu'une mise de fonds plus petite signifie un dénominateur encore plus petit, et le même gain ou la même perte en dollars produit donc une variation en pourcentage encore plus forte.
4. « Financement » décrit simplement le fait d'emprunter de l'argent ; « levier » décrit l'effet multiplicateur que l'emprunt a sur vos rendements en pourcentage, à la hausse comme à la baisse. Le choix du mot reflète le mécanisme, et pas seulement la transaction.

## Réponses et explications

1. C'est le cœur mathématique de toute la leçon : moins de capital investi, même gain en dollars, pourcentage plus élevé.
2. C'est le « pourquoi » du risque de baisse lié au levier : la dette est fixe, la valeur nette est variable, donc toute la volatilité se concentre sur la part de la valeur nette, qui est déjà plus petite au départ.
3. Cette question vérifie que vous savez appliquer le principe à un nouveau scénario, au lieu de simplement vous souvenir des chiffres donnés.
4. Cette question teste la compréhension du concept, pas le vocabulaire : l'objectif est de reconnaître le levier comme un effet multiplicateur, l'idée sur laquelle s'appuie tout le reste de ce parcours.

## Points clés
- L'effet de levier consiste à contrôler un actif important avec une petite somme de votre propre argent.
- Les gains en pourcentage sont calculés par rapport à l'argent investi, donc le levier amplifie les rendements à la hausse.
- Le levier amplifie les pertes du même multiplicateur : la dette ne diminue pas quand la valeur de l'actif baisse.
- Une mise de fonds plus petite signifie des variations en pourcentage plus fortes dans les deux sens.

---

*Cette leçon est fournie uniquement à des fins d'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations illustratives, et non des garanties. Consultez un professionnel autorisé avant de prendre des décisions financières.*
