---
id: RED-L3-011
locale: fr-CA
source_locale: en-US
track: RED
level: 3
lesson: 11
title: "Pourquoi les prêteurs de portefeuille raisonnent autrement que les banques de détail"
source_title: "Why Portfolio Lenders Think Differently Than Retail Banks"
description: "Découvrez pourquoi les prêteurs qui gardent les prêts dans leurs propres comptes évaluent les opérations différemment des banques qui revendent leurs prêts sur le marché secondaire."
slug: red-l3-011-portfolio-lenders
seo_title: "Pourquoi les prêteurs de portefeuille raisonnent autrement que les banques de détail | Edunancial"
meta_description: "Découvrez pourquoi les prêteurs qui gardent les prêts dans leurs propres comptes évaluent les opérations différemment des banques qui revendent leurs prêts sur le marché secondaire."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-011: Pourquoi les prêteurs de portefeuille raisonnent autrement que les banques de détail

## Objectifs d'apprentissage
À la fin de cette leçon, vous serez capable de :
- Expliquer la différence entre un prêteur de portefeuille et un prêteur qui revend ses prêts
- Expliquer pourquoi cette différence change ce qu'un prêteur est prêt à accepter
- Identifier pourquoi les prêteurs de portefeuille peuvent être plus souples pour les opérations atypiques

## Contenu principal

La plupart des prêts hypothécaires conventionnels ne restent pas chez la banque qui les a accordés : ils sont revendus sur le marché secondaire à des investisseurs, souvent regroupés en titres adossés à des prêts hypothécaires (mortgage-backed securities). Comme ces prêts seront revendus, le prêteur d'origine doit suivre des règles strictes et standardisées pour que le prêt puisse être revendu.

Un **prêteur de portefeuille** (portfolio lender) fait les choses autrement : il garde le prêt dans ses propres comptes au lieu de le revendre. Voici le « pourquoi » qui compte : comme le prêteur porte lui-même le risque, il peut fixer ses propres règles d'analyse de financement au lieu de suivre les normes du marché secondaire. Cela signifie souvent plus de souplesse : évaluer une opération en fonction du potentiel de revenus du bien, de l'ensemble du portefeuille de l'investisseur, ou de types de biens atypiques qui ne rentreraient pas dans les règles standardisées.

[VERIFIED FACT] Cette souplesse n'est pas de la générosité automatique : les prêteurs de portefeuille prennent un risque plus direct en gardant le prêt, et ils demandent donc souvent des taux plus élevés ou une mise de fonds plus importante pour compenser.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un investisseur veut financer un immeuble à usage mixte (un commerce au rez-de-chaussée, des appartements au-dessus), un type de bien qui ne rentre pas bien dans les règles conventionnelles standard. Une banque de détail qui suit les règles du marché secondaire pourrait refuser le prêt d'emblée. Un prêteur de portefeuille, qui évalue l'opération selon les revenus globaux du bien et l'expérience de l'investisseur, pourrait l'accepter, à un taux plus élevé que celui d'un prêt conventionnel, pour refléter le risque supplémentaire qu'il prend directement.

## Quiz d'entraînement

1. Qu'arrive-t-il à la plupart des prêts hypothécaires conventionnels une fois accordés ?
2. Pourquoi un prêteur de portefeuille a-t-il plus de souplesse dans l'analyse de financement ?
3. Quelle est la contrepartie habituelle de cette souplesse supplémentaire ?

## Corrigé

1. Ils sont généralement revendus sur le marché secondaire, souvent regroupés en titres adossés à des prêts hypothécaires.
2. Parce qu'il garde le prêt dans ses propres comptes et en porte directement le risque, il n'est pas tenu par les règles standardisées imposées aux prêts destinés à être revendus.
3. Des taux d'intérêt plus élevés ou une mise de fonds plus importante exigée, puisque le prêteur prend un risque plus direct.

## Réponses et explications

1. Cette question pose la référence (le marché secondaire) à laquelle s'oppose le prêt de portefeuille.
2. C'est le mécanisme central de la leçon : celui qui porte le risque est celui qui fixe les règles.
3. Cette question rappelle que la souplesse n'est pas gratuite : son prix est intégré à l'opération.

## Points clés
- La plupart des prêts conventionnels sont revendus sur le marché secondaire et doivent respecter des règles standardisées.
- Les prêteurs de portefeuille gardent les prêts dans leurs propres comptes et peuvent fixer leurs propres règles d'analyse de financement.
- Cette souplesse s'accompagne souvent de taux plus élevés ou d'exigences de mise de fonds plus strictes.

---

*Cette leçon est fournie uniquement à des fins d'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations illustratives, et non des garanties. Consultez un professionnel autorisé avant de prendre des décisions financières.*
