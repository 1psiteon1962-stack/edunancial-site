---
id: RED-L3-013
locale: fr-CA
source_locale: en-US
track: RED
level: 3
lesson: 13
title: "Pourquoi le surendettement tue des placements par ailleurs bons"
source_title: "Why Over-Leveraging Kills Otherwise Good Investments"
description: "Découvrez pourquoi un bien fondamentalement solide peut quand même échouer en tant que placement si l'on empile trop de dettes dessus."
slug: red-l3-013-over-leveraging-risk
seo_title: "Pourquoi le surendettement tue des placements par ailleurs bons | Edunancial"
meta_description: "Découvrez pourquoi un bien fondamentalement solide peut quand même échouer en tant que placement si l'on empile trop de dettes dessus."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-013: Pourquoi le surendettement tue des placements par ailleurs bons

## Objectifs d'apprentissage
À la fin de cette leçon, vous serez capable de :
- Expliquer ce que signifie le surendettement dans le contexte immobilier
- Expliquer pourquoi un bon bien peut quand même devenir un mauvais placement à cause d'une dette excessive
- Identifier les signaux d'alerte du surendettement dans une opération

## Contenu principal

Jusqu'ici, chaque leçon a présenté l'effet de levier comme un outil qui peut jouer en faveur de l'investisseur. Cette leçon aborde volontairement l'autre face : l'effet de levier ne se demande pas si un bien est « bon », il multiplie simplement tout ce qui arrive, en bien comme en mal, comme vu dans la leçon 3.

Le **surendettement** (over-leveraging) se produit quand le montant de dette empilé sur un bien (ou sur un portefeuille) ne laisse presque aucune marge, voire aucune, pour les aléas normaux que tout bien connaît : inoccupation, réparations, changements de taux. Le bien lui-même peut être un actif réellement solide, bien situé, avec une vraie demande locative. C'est la taille de la dette par rapport à la capacité du bien à la rembourser qui transforme un bon actif en placement fragile.

[ILLUSTRATIVE EXAMPLE] Empiler un premier prêt hypothécaire, une HELOC (marge de crédit garantie par la valeur nette du bien) sur ce même bien et un prêt personnel utilisé pour la mise de fonds peut donner des dettes qui, prises une à une, paraissent raisonnables, mais qui, combinées, ne laissent à l'investisseur presque aucun coussin si une seule chose tourne mal. C'est pourquoi les leçons précédentes sur le DTI, le LTV, les réserves pour inoccupation et le cash-flow comptent toutes ensemble : le surendettement est ce qui arrive quand ces garde-fous sont ignorés ou poussés trop loin, un par un.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un investisseur achète un bien avec un premier prêt hypothécaire à 90 % de LTV (loan-to-value, rapport prêt-valeur), puis contracte un prêt personnel pour payer les travaux de rénovation au lieu de les payer comptant, et renonce à mettre de côté des réserves pour inoccupation pour économiser sur la mise de fonds. [ASSUMPTION] Si un seul locataire part de façon inattendue, le bien doit alors couvrir en même temps le premier prêt hypothécaire, le versement du prêt personnel et la perte de loyer, sans aucune réserve prévue. Un bien qui aurait facilement absorbé une période d'inoccupation normale avec un niveau de dette plus faible menace maintenant toute la trésorerie de l'investisseur.

## Quiz d'entraînement

1. Le surendettement signifie-t-il que le bien sous-jacent est un mauvais actif ? Pourquoi ?
2. Quel est le fil conducteur qui relie le surendettement aux leçons précédentes sur le DTI, le LTV et les réserves ?
3. Dans l'exemple pratique, quelles décisions précises se sont combinées pour créer cette situation fragile ?

## Corrigé

1. Non : le bien lui-même peut être solide ; le surendettement concerne la structure de dette empilée dessus, qui ne laisse aucune marge pour les revers normaux.
2. Le surendettement est ce qui arrive quand ces garde-fous individuels (limites de DTI, limites de LTV, réserves) sont chacun poussés trop loin ou ignorés, ce qui supprime le coussin que chacun est censé fournir.
3. Un premier prêt hypothécaire à LTV élevé, un prêt personnel ajouté pour les travaux et aucune réserve pour inoccupation : chaque décision paraît raisonnable seule, mais combinées, elles ont supprimé toute marge d'erreur.

## Réponses et explications

1. Cette question distingue la qualité de l'actif de la structure de financement qui l'entoure, ce qui est le point central de la leçon.
2. Cette question relie la leçon à l'ensemble du parcours, en montrant que le surendettement est un échec cumulatif des principes précédents, et non un concept nouveau et isolé.
3. Cette question vérifie que le lecteur sait relier une situation fragile à des décisions précises qui se sont additionnées.

## Points clés
- Le surendettement est un problème de structure de la dette, pas forcément un problème de qualité de l'actif.
- Plusieurs prêts empilés sur un même bien peuvent chacun paraître raisonnables tout en créant ensemble une vraie fragilité.
- Les garde-fous des leçons précédentes (DTI, LTV, réserves) existent précisément pour éviter ce résultat.

---

*Cette leçon est fournie uniquement à des fins d'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations illustratives, et non des garanties. Consultez un professionnel autorisé avant de prendre des décisions financières.*
