---
id: RED-L3-022
locale: fr-CA
source_locale: en-US
track: RED
level: 3
lesson: 22
title: "Pourquoi le paiement ballon crée une échéance cachée"
source_title: "Why Balloon Payments Create a Hidden Deadline"
description: "Découvrez pourquoi certains prêts exigent un gros paiement en une seule fois à la fin d'une durée courte, et pourquoi cette échéance doit être préparée des années à l'avance."
slug: red-l3-022-balloon-payments
seo_title: "Pourquoi le paiement ballon crée une échéance cachée | Edunancial"
meta_description: "Découvrez pourquoi certains prêts exigent un gros paiement en une seule fois à la fin d'une durée courte, et pourquoi cette échéance doit être préparée des années à l'avance."
author: "Waldemar M. Caban, JD MA"
---

# RED-L3-022: Pourquoi le paiement ballon crée une échéance cachée

## Objectifs d'apprentissage
À la fin de cette leçon, vous serez capable de :
- Expliquer ce qu'est un paiement ballon
- Expliquer pourquoi les structures avec paiement ballon sont courantes dans le crédit commercial
- Expliquer le risque de ne pas anticiper l'échéance d'un paiement ballon

## Contenu principal

Un **paiement ballon** (balloon payment) est un gros paiement en une seule fois, dû à la fin de la durée d'un prêt, qui couvre le solde restant non remboursé par les versements réguliers. Comme présenté dans la leçon 16, cette structure est courante dans le crédit commercial : un prêt peut être amorti comme s'il durait 25 ou 30 ans (ce qui garde des versements gérables), mais arriver réellement à échéance, c'est-à-dire que la totalité du solde restant devient exigible, après seulement 5 ou 10 ans.

Voici le « pourquoi » de cette échéance cachée : comme les versements sont calculées sur un tableau d'amortissement plus long que la durée réelle du prêt, seule une petite partie du capital est remboursée à la date d'échéance, comme le montre la leçon 7 sur l'amortissement. L'investisseur se retrouve à devoir un gros solde restant d'un seul coup, qu'il faut presque toujours régler par un refinancement ou une vente, et non de sa poche.

C'est pourquoi les prêts avec paiement ballon exigent de planifier la stratégie de sortie (leçon 15) des années à l'avance : si les conditions du marché, la valeur du bien ou l'éligibilité de l'investisseur évoluent défavorablement à l'approche de la date du paiement ballon, le refinancement peut devenir difficile ou coûteux juste au moment où on en a le plus besoin.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un investisseur contracte un prêt commercial sur un immeuble de 8 logements : les versements sont calculées sur un tableau d'amortissement de 25 ans, mais le prêt arrive à échéance au bout de 7 ans, date à laquelle la totalité du solde restant est due. [ASSUMPTION] Si, à l'approche de ces 7 ans, les taux d'intérêt ont augmenté et que les revenus du bien ont baissé, un nouveau prêt de refinancement pour couvrir le paiement ballon pourrait être plus difficile à obtenir, ou s'accompagner de conditions moins favorables, que si l'investisseur avait anticipé en constituant des réserves ou en prévoyant une option de refinancement plus précoce dans sa stratégie.

## Quiz d'entraînement

1. Qu'est-ce qu'un paiement ballon ?
2. Pourquoi une structure avec paiement ballon laisse-t-elle un gros solde restant à l'échéance ?
3. Quel risque crée le fait d'attendre l'approche de la date du paiement ballon pour s'y préparer ?

## Corrigé

1. Un gros paiement en une seule fois, dû à la fin de la durée d'un prêt, qui couvre le solde restant non remboursé par les paiements réguliers.
2. Parce que les versements sont calculées sur un tableau d'amortissement plus long que la durée réelle du prêt, si bien que relativement peu de capital est remboursé au moment où le prêt arrive à échéance.
3. Si les conditions du marché ou la situation financière de l'investisseur ont évolué défavorablement à la date du paiement ballon, refinancer pour couvrir ce paiement peut être difficile ou coûteux juste au moment où on en a le plus besoin.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. Cette question renvoie directement à la mécanique de l'amortissement vue dans la leçon 7.
3. C'est le risque central, et cette question renforce le thème de la planification de la stratégie de sortie de la leçon 15.

## Points clés
- Un paiement ballon est une somme globale due à l'échéance du prêt, courante dans les structures de crédit commercial.
- Comme les versements sont calculées sur un calendrier plus long que la durée réelle du prêt, un gros solde reste dû à l'échéance.
- Les échéances de paiement ballon doivent être préparées des années à l'avance, car des changements du marché ou de la situation financière personnelle près de l'échéance peuvent rendre le refinancement plus difficile exactement au moment où on en a besoin.

---

*Cette leçon est fournie uniquement à des fins d'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations illustratives, et non des garanties. Consultez un professionnel autorisé avant de prendre des décisions financières.*
