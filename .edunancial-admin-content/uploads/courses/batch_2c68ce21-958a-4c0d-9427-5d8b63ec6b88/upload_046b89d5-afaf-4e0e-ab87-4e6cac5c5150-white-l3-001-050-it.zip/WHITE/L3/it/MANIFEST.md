# WHITE-L3 — it (Italiano) — Manifesto

Lezioni: da WHITE-L3-001 a WHITE-L3-050 (50/50)
Lingua: it | Fonte: en-US (versione master inglese WHITE-L3)
Autore: Waldemar M. Caban, JD MA
Formato: 7 sezioni (Obiettivi di apprendimento, Contenuto principale, Esempio pratico, Quiz di esercitazione, Chiave delle risposte, Risposte e spiegazioni, Punti chiave) + avvertenza educativa a piè di pagina

## Verifica
- 50 file con front matter (id, locale, source_title, slug inglese mantenuto, campi SEO) e le 7 sezioni in ordine fisso.
- Numero di domande del quiz verificato rispetto alla lezione originale; etichette di contenuto ([VERIFIED FACT], [ILLUSTRATIVE EXAMPLE], [ASSUMPTION]) mantenute in inglese e contate.
- Traduzione, non localizzazione: termini e strumenti USA mantenuti (401(k), IRA, Roth IRA, IRS, ETF, S&P 500, P/E, REIT, IPO) e spiegati al primo uso; importi in $ come nell'originale. L'avvertenza di ogni lezione è tradotta secondo la propria variante.
- Registro: «tu», livello di lettura 7ª–8ª classe (USA). Si consiglia revisione da parte di un madrelingua prima della pubblicazione.
