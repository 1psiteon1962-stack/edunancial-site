# WHITE-L3 — de (Deutsch) — Manifest

Lektionen: WHITE-L3-001 bis WHITE-L3-050 (50/50)
Sprache: de | Quelle: en-US (englische Master-Version WHITE-L3)
Autor: Waldemar M. Caban, JD MA
Format: 7 Abschnitte (Lernziele, Hauptinhalt, Durchgerechnetes Beispiel, Übungsquiz, Lösungsschlüssel, Antworten und Erklärungen, Das Wichtigste in Kürze) + Bildungshinweis in der Fußzeile

## Prüfung
- 50 Dateien mit Front Matter (id, locale, source_title, englischer Slug beibehalten, SEO-Felder) und den 7 Abschnitten in fester Reihenfolge.
- Anzahl der Quizfragen gegen die Originallektion geprüft; Inhaltslabels ([VERIFIED FACT], [ILLUSTRATIVE EXAMPLE], [ASSUMPTION]) auf Englisch belassen und gezählt.
- Übersetzung, keine Lokalisierung: US-Begriffe und -Produkte beibehalten (401(k), IRA, Roth IRA, IRS, ETF, S&P 500, P/E, REIT, IPO) und beim ersten Vorkommen erklärt; $-Beträge wie im Original. Der Hinweis jeder Lektion wird in seiner eigenen Variante übersetzt.
- Anrede: „du“, Leseniveau Klasse 7–8 (USA). Vor der Veröffentlichung wird eine Durchsicht durch Muttersprachler empfohlen.
