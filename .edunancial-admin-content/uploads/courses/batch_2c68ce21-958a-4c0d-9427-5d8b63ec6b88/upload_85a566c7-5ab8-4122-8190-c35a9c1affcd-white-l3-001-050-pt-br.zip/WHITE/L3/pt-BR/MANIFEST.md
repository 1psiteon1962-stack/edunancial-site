# WHITE-L3 — pt-BR (Português, Brasil) — Manifesto

Lições: de WHITE-L3-001 a WHITE-L3-050 (50/50)
Idioma: pt-BR | Fonte: en-US (versão mestre em inglês do WHITE-L3)
Autor: Waldemar M. Caban, JD MA
Formato: 7 seções (Objetivos de aprendizagem, Conteúdo principal, Exemplo prático, Teste de prática, Gabarito, Respostas e explicações, Pontos-chave) + aviso educacional no rodapé

## Verificação
- 50 arquivos com front matter (id, locale, source_title, slug em inglês mantido, campos de SEO) e as 7 seções na ordem fixa.
- Quantidade de perguntas verificada contra a lição original; rótulos de conteúdo ([VERIFIED FACT], [ILLUSTRATIVE EXAMPLE], [ASSUMPTION]) mantidos em inglês e contados.
- Tradução, não localização: termos e programas dos EUA mantidos (401(k), IRA, Roth IRA, IRS, ETF, S&P 500, P/E, REIT, IPO) e explicados na primeira ocorrência; valores em $ como no original. O aviso educacional de cada lição é traduzido conforme sua própria variante.
- Registro: «você», nível de leitura do 7º ao 8º ano (EUA). Recomenda-se revisão por falante nativo antes da publicação.
