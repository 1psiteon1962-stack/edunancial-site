---
id: WHITE-L3-001
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 1
title: "Por que \"comprar na baixa, vender na alta\" é mais difícil de fazer do que de falar"
source_title: "Why \"Buy Low, Sell High\" Is Harder to Execute Than to Say"
description: "Entenda por que o conselho de investimento mais simples é também um dos mais difíceis de seguir na prática, e o que realmente atrapalha."
slug: white-l3-001-buy-low-sell-high
seo_title: "Por que \"comprar na baixa, vender na alta\" é mais difícil de fazer do que de falar | Edunancial"
meta_description: "Entenda por que o conselho de investimento mais simples é também um dos mais difíceis de seguir na prática, e o que realmente atrapalha."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-001: Por que "comprar na baixa, vender na alta" é mais difícil de fazer do que de falar

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar por que "comprar na baixa, vender na alta" é simples como ideia, mas difícil como comportamento
- Identificar as barreiras emocionais e de informação que jogam contra esse conselho
- Explicar por que "baixa" e "alta" só ficam claras quando olhamos para trás

## Conteúdo principal

Quase todo mundo já ouviu o conselho "compre na baixa, venda na alta". Ele é verdadeiro, e quase inútil sozinho, porque pressupõe que você consegue identificar a "baixa" e a "alta" enquanto está vivendo esses momentos, e não só quando olha um gráfico depois.

Este é o "porquê" da dificuldade: uma queda de preço que parece "baixa" quando olhamos para trás normalmente não parece uma oportunidade enquanto acontece; parece incerteza, notícia ruim e dor financeira de verdade. [VERIFIED FACT] Historicamente, os mercados caem com força em períodos de grande estresse ou incerteza econômica, que é justamente quando comprar pode parecer mais difícil, mesmo que esses períodos muitas vezes tenham vindo antes de recuperações. Da mesma forma, um preço que parece "alta" olhando para trás muitas vezes parece, na hora, um impulso impossível de parar: todo mundo parece estar ganhando dinheiro, e vender parece deixar ganhos na mesa.

Por isso, "comprar na baixa, vender na alta" é melhor entendido como a descrição de um resultado desejado do que como um conselho prático por si só. As próximas lições desta trilha aprofundam ferramentas, conceitos e padrões de comportamento específicos que tornam mais possível agir de forma racional quando seus instintos puxam para o lado oposto.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Durante uma forte queda do mercado, uma investidora vê sua carteira perder bastante valor. Olhando para trás, esse período acabou sendo uma ótima oportunidade de compra para o longo prazo. Mas, vivendo aquele momento, ela lia manchetes desanimadoras, via o saldo da conta cair todo dia e sentia uma ansiedade real com a possibilidade de perder mais; exatamente o oposto de uma sensação confortável de "isto claramente é a baixa". [ASSUMPTION] Historicamente, os investidores que compraram durante esse desconforto, em vez de esperar a confirmação de que o fundo já tinha passado, aproveitaram uma parte maior da recuperação; mas fazer isso exigiu agir contra o que o momento realmente fazia sentir.

## Teste de prática

1. Por que "comprar na baixa, vender na alta" é mais fácil de falar do que de fazer?
2. Por que uma verdadeira oportunidade de compra pode parecer desconfortável, e não óbvia, enquanto acontece?
3. Por que um período de forte alta pode parecer um mau momento para vender, mesmo que depois se revele um ponto alto?

## Gabarito

1. Porque a "baixa" e a "alta" só são claramente identificáveis olhando para trás; no momento, preços baixos costumam vir acompanhados de incerteza e notícias ruins, e preços altos, de um aparente impulso de alta.
2. Porque normalmente ela coincide com manchetes negativas, saldos de conta caindo e incerteza real sobre se os preços vão cair ainda mais.
3. Porque um impulso forte pode criar a sensação de que mais ganhos são prováveis, tornando emocionalmente difícil vender quando tudo parece forte.

## Respostas e explicações

1. Este é o paradoxo central que a lição apresenta.
2. Isto explica a experiência emocional específica que torna a "baixa" difícil de reconhecer em tempo real.
3. Isto espelha a resposta anterior pela direção oposta, pelo lado da "alta" do conselho.

## Pontos-chave
- "Comprar na baixa, vender na alta" descreve um resultado desejado, não uma estratégia prática por si só.
- Os verdadeiros pontos baixos costumam parecer incertos e desconfortáveis enquanto acontecem, e não oportunidades óbvias.
- Os verdadeiros pontos altos costumam parecer um impulso forte, o que dificulta vender.
- O restante desta trilha apresenta ferramentas e conceitos específicos que tornam mais viável agir de acordo com esse conselho.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Desempenho passado não garante resultados futuros. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
