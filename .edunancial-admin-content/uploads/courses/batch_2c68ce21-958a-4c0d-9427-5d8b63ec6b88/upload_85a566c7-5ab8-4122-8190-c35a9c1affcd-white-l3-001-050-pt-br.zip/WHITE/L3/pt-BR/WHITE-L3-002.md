---
id: WHITE-L3-002
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 2
title: "Por que a diversificação reduz o risco sem reduzir o retorno esperado (tanto quanto você imagina)"
source_title: "Why Diversification Reduces Risk Without Reducing Expected Return (as Much as You'd Think)"
description: "Entenda por que distribuir seus investimentos entre muitos ativos reduz o risco de forma mais eficiente do que reduz o retorno esperado, e por que esse benefício tem limite."
slug: white-l3-002-diversification-and-expected-return
seo_title: "Por que a diversificação reduz o risco sem reduzir o retorno esperado (tanto quanto você imagina) | Edunancial"
meta_description: "Entenda por que distribuir seus investimentos entre muitos ativos reduz o risco de forma mais eficiente do que reduz o retorno esperado, e por que esse benefício tem limite."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-002: Por que a diversificação reduz o risco sem reduzir o retorno esperado (tanto quanto você imagina)

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar por que a diversificação reduz o risco sem reduzir proporcionalmente o retorno esperado
- Diferenciar o risco específico de uma empresa do risco que afeta o mercado inteiro
- Explicar por que a diversificação traz benefícios cada vez menores a partir de certo ponto

## Conteúdo principal

Pode parecer que distribuir seu dinheiro entre muitos investimentos, em vez de concentrá-lo em um só, também distribuiria, e reduziria, o seu retorno esperado. Não é bem assim que funciona, e entender o porquê é o centro desta lição.

O risco de uma ação individual vem de duas fontes: o risco específico daquela empresa (um resultado trimestral ruim, um recall de produto, um processo judicial) e o risco que afeta o mercado inteiro (uma recessão, mudanças amplas nas taxas de juros). A diversificação, ou seja, ter muitas ações diferentes em vez de uma só, elimina grande parte do risco específico de cada empresa, porque é improvável que uma notícia ruim atinja todos os seus ativos ao mesmo tempo. Mas ela faz muito pouco para eliminar o risco do mercado como um todo, já que esse risco afeta quase tudo junto.

Este é o "porquê" de isso não reduzir proporcionalmente o retorno esperado: você não está diluindo suas melhores ideias com outras mais fracas de um jeito que necessariamente baixe seu resultado médio esperado; você está removendo o risco específico, e não recompensado, do azar de uma única empresa, enquanto mantém sua exposição esperada ao retorno geral do mercado. [VERIFIED FACT] Esse benefício tem retornos decrescentes: a redução de risco obtida ao acrescentar mais ativos cai bastante depois que a carteira chega a um número moderado de empresas diferentes, já que a maior parte do risco que sobra nesse ponto é o risco de mercado, que a diversificação não consegue eliminar.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora que tem ações de uma única empresa fica exposta ao risco específico dessa empresa: um escândalo, um produto fracassado ou um processo judicial poderiam prejudicar muito a carteira dela, mesmo que o mercado em geral esteja bem. Uma investidora com ações de 30 empresas diferentes, em setores diferentes, fica bem menos exposta à notícia ruim de uma empresa só; um problema em um ativo é um pequeno peso na carteira total, e não uma grande perda. [ASSUMPTION] Passar de 30 para 300 ativos normalmente acrescenta muito menos redução de risco do que passar de 1 para 30; a maior parte da redução possível do risco específico de empresa já foi obtida.

## Teste de prática

1. Quais são as duas fontes de risco de uma ação individual, conforme descrito nesta lição?
2. Por que a diversificação não reduz o retorno esperado na mesma proporção em que reduz o risco?
3. Por que acrescentar cada vez mais ativos acaba trazendo benefícios de redução de risco cada vez menores?

## Gabarito

1. O risco específico da empresa (exclusivo de um negócio) e o risco de mercado (que afeta quase tudo junto).
2. Porque a diversificação remove principalmente o risco específico da empresa, que não é recompensado, em vez de diluir a exposição geral esperada ao retorno do mercado.
3. Porque a maior parte do risco específico das empresas já foi reduzida depois de um número moderado de ativos, e o risco que sobra é em grande parte risco de mercado, que diversificar entre ações individuais não consegue eliminar.

## Respostas e explicações

1. Essa distinção é a base da qual toda a lição depende.
2. Este é o "porquê" central da lição, e muitas vezes mal compreendido.
3. Isto explica o padrão de retornos decrescentes e antecipa por que diversificar entre classes de ativos (tema de uma lição posterior) importa para o risco de mercado, que a diversificação entre ações individuais não alcança.

## Pontos-chave
- A diversificação reduz principalmente o risco específico da empresa, e não o risco de mercado.
- É por isso que ela pode diminuir o risco sem diminuir proporcionalmente o retorno esperado: ela remove um risco em grande parte não recompensado, e não o potencial de ganho.
- O benefício de redução de risco ao acrescentar mais ativos diminui bastante depois de um número moderado de empresas diferentes.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Todos os valores são estimativas ilustrativas, não garantias. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
