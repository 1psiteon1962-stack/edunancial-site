---
id: WHITE-L3-003
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 3
title: "Por que a correlação determina a diversificação real, e não apenas o número de ativos"
source_title: "Why Correlation Determines Real Diversification, Not Just Number of Holdings"
description: "Entenda por que ter muitos investimentos não é o mesmo que estar realmente diversificado, e por que a correlação é o conceito que de fato determina a redução do seu risco."
slug: white-l3-003-correlation-and-real-diversification
seo_title: "Por que a correlação determina a diversificação real, e não apenas o número de ativos | Edunancial"
meta_description: "Entenda por que ter muitos investimentos não é o mesmo que estar realmente diversificado, e por que a correlação é o conceito que de fato determina a redução do seu risco."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-003: Por que a correlação determina a diversificação real, e não apenas o número de ativos

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Definir correlação no contexto dos retornos de investimentos
- Explicar por que ter muitos ativos que se movem juntos não é diversificação real
- Explicar por que uma correlação baixa ou negativa entre ativos traz benefícios de diversificação mais fortes

## Conteúdo principal

A Lição 2 mostrou que a diversificação reduz o risco específico das empresas. Esta lição acrescenta um ajuste importante: simplesmente ter muitos ativos diferentes não basta; o que importa é como esses ativos se movem uns em relação aos outros, um conceito chamado **correlação**.

A correlação mede o quanto dois investimentos tendem a se mover juntos. Ativos altamente correlacionados tendem a subir e cair nos mesmos momentos, pelos mesmos motivos. Ativos com correlação baixa ou negativa tendem a reagir de forma diferente aos mesmos acontecimentos: um pode ficar estável ou até subir enquanto o outro cai.

Este é o "porquê" de isso importar mais do que a simples quantidade de ativos: [ILLUSTRATIVE EXAMPLE] um investidor com 50 ações diferentes de tecnologia está diversificado em número, entre muitas empresas, mas se todas as 50 forem altamente correlacionadas, com probabilidade de cair juntas em uma queda ampla do setor de tecnologia, o benefício real da diversificação é muito menor do que o número "50" sugere. A verdadeira redução de risco vem de combinar ativos que não reagem todos da mesma forma aos mesmos acontecimentos.

[VERIFIED FACT] A correlação entre ativos não é fixa para sempre: ela pode mudar com o tempo e, o que é importante, tende a aumentar em períodos de forte estresse no mercado, quando ativos que normalmente se movem de forma relativamente independente podem começar a cair juntos, reduzindo o benefício protetor da diversificação justamente quando ele é mais desejado.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Um investidor monta uma carteira com 40 ações, todas do mesmo setor e da mesma região geográfica. Apesar do grande número de ativos, elas tendem a reagir de forma parecida a mudanças nas taxas de juros, notícias regulatórias e mudanças econômicas mais amplas que afetam aquele setor; ou seja, a carteira se comporta mais como uma aposta concentrada do que como uma carteira diversificada. Um segundo investidor tem apenas 15 ações, mas distribuídas entre setores, regiões e tipos de ativo diferentes, com correlação historicamente mais baixa entre si. [ASSUMPTION] Mesmo com menos ativos no total, a carteira do segundo investidor pode ter um desempenho mais estável e realmente mais diversificado durante uma queda de um setor específico do que a carteira maior, porém altamente correlacionada, do primeiro investidor.

## Teste de prática

1. O que a correlação mede entre dois investimentos?
2. Por que uma carteira com muitos ativos ainda pode não ter diversificação real?
3. Por que os benefícios da diversificação podem enfraquecer justamente em períodos de forte estresse no mercado?

## Gabarito

1. O quanto os retornos de dois investimentos tendem a se mover juntos.
2. Se esses ativos forem altamente correlacionados, com probabilidade de reagir de forma parecida aos mesmos acontecimentos, a carteira se comporta mais como uma aposta concentrada do que como uma carteira realmente diversificada, independentemente do número de ativos.
3. Porque a correlação entre ativos tende a aumentar em períodos de forte estresse no mercado, o que significa que ativos antes menos correlacionados podem começar a se mover juntos, reduzindo o benefício protetor justamente quando ele é mais necessário.

## Respostas e explicações

1. Esta é a definição básica necessária para o restante da lição.
2. Isto amplia e refina diretamente o conceito de diversificação da Lição 2.
3. Esta é uma ressalva importante e honesta sobre os limites da diversificação durante uma crise.

## Pontos-chave
- A diversificação real depende da correlação entre os ativos, e não apenas do número total de ativos.
- Muitos ativos altamente correlacionados trazem muito menos redução de risco do que a quantidade sozinha sugere.
- A correlação pode mudar com o tempo e muitas vezes aumenta em períodos de forte estresse no mercado, enfraquecendo o efeito protetor da diversificação justamente quando ele mais importa.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Todos os valores são estimativas ilustrativas, não garantias. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
