---
id: WHITE-L3-004
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 4
title: "Por que volatilidade e risco não são exatamente a mesma coisa"
source_title: "Why Volatility and Risk Aren't Exactly the Same Thing"
description: "Entenda por que um gráfico de preços cheio de altos e baixos não é automaticamente o mesmo que risco financeiro real, e por que essa diferença importa na hora de avaliar um investimento."
slug: white-l3-004-volatility-vs-risk
seo_title: "Por que volatilidade e risco não são exatamente a mesma coisa | Edunancial"
meta_description: "Entenda por que um gráfico de preços cheio de altos e baixos não é automaticamente o mesmo que risco financeiro real, e por que essa diferença importa na hora de avaliar um investimento."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-004: Por que volatilidade e risco não são exatamente a mesma coisa

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Diferenciar volatilidade (oscilação de preço) de risco (chance de perda permanente)
- Explicar por que um investimento volátil não é automaticamente arriscado
- Explicar por que um investimento de baixa volatilidade ainda pode ter um risco relevante

## Conteúdo principal

Na linguagem do dia a dia dos investimentos, "volatilidade" e "risco" muitas vezes são usados como sinônimos. Vale a pena separá-los com cuidado. **Volatilidade** descreve o quanto e com que frequência um preço sobe e desce; é uma característica estatística e mensurável do histórico de preços. **Risco**, no sentido que mais importa para um investidor, é a chance de uma perda real e permanente de capital, ou de não alcançar seus objetivos financeiros.

Este é o "porquê" de não serem a mesma coisa: uma ação pode ser muito volátil, oscilando bastante para cima e para baixo, e ainda assim estar a caminho de entregar bons retornos no longo prazo, desde que o negócio por trás dela continue sólido e você não precise vender durante uma queda. Por outro lado, um investimento pode parecer calmo e de baixa volatilidade na superfície e, ainda assim, ter um risco real de perda permanente; por exemplo, um título de renda fixa de um emissor com dificuldades financeiras que é negociado a um preço estável até o momento em que dá calote.

[VERIFIED FACT] Essa distinção importa principalmente para a forma como um investidor deve reagir ao movimento dos preços: a volatilidade sozinha, sem mudança nos fundamentos do investimento ou no seu próprio prazo, não é necessariamente um sinal para vender; mas uma mudança real no risco de perda permanente de um investimento é um sinal bem mais sério, que vale a pena levar em conta para agir.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] A Ação A sobe e desce bastante de um mês para o outro, mas pertence a uma empresa financeiramente saudável e em crescimento; um investidor que a mantém no longo prazo, sem se incomodar com as oscilações de curto prazo, pode ter bons retornos ao longo do tempo, apesar do caminho acidentado. A Ação B é negociada em uma faixa de preço estreita e estável por meses, dando uma aparência de segurança; mas a empresa por trás dela está, discretamente, assumindo dívidas insustentáveis. [ASSUMPTION] Quando esse problema de dívida finalmente se tornar público, o preço "estável" da Ação B pode cair de forma brusca e permanente; a baixa volatilidade até aquele momento escondia um risco real e crescente, em vez de refletir segurança de verdade.

## Teste de prática

1. Qual é a principal diferença entre volatilidade e risco, conforme definidos nesta lição?
2. Por que um investimento muito volátil não é necessariamente "arriscado" no sentido que mais importa?
3. Por que um investimento de baixa volatilidade ainda pode ter um risco oculto significativo?

## Gabarito

1. A volatilidade mede o quanto um preço oscila; o risco se refere à chance de uma perda real e permanente de capital ou de não alcançar objetivos financeiros.
2. Porque oscilações de preço de curto prazo não refletem necessariamente uma mudança na solidez do negócio por trás do investimento, nem na sua capacidade de atravessá-las sem precisar vender.
3. Porque um preço estável não garante que os fundamentos sejam sólidos; problemas podem crescer em silêncio antes de, finalmente, causar uma queda de preço brusca e permanente.

## Respostas e explicações

1. Esta é a distinção fundamental em torno da qual a lição foi construída.
2. Isto corrige a suposição comum de que toda volatilidade significa perigo.
3. Isto corrige a suposição, igualmente comum, de que estabilidade de preço significa segurança.

## Pontos-chave
- A volatilidade mede a oscilação de preço; o risco se refere à chance de perda permanente ou de não alcançar objetivos financeiros.
- Um investimento volátil não é automaticamente arriscado se os fundamentos continuarem sólidos e você conseguir atravessar as oscilações.
- Um investimento que parece estável ainda pode ter um risco real e oculto, se os problemas por trás dele ainda não apareceram no preço.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Todos os valores são estimativas ilustrativas, não garantias. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
