---
id: WHITE-L3-005
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 5
title: "Por que as opções dão direitos, e não obrigações, e por que isso tem um custo"
source_title: "Why Options Give You Rights, Not Obligations — And Why That Costs Something"
description: "Entenda a estrutura básica dos contratos de opções, por que comprar uma opção dá apenas um direito, e por que esse direito não é de graça."
slug: white-l3-005-options-rights-not-obligations
seo_title: "Por que as opções dão direitos, e não obrigações, e por que isso tem um custo | Edunancial"
meta_description: "Entenda a estrutura básica dos contratos de opções, por que comprar uma opção dá apenas um direito, e por que esse direito não é de graça."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-005: Por que as opções dão direitos, e não obrigações, e por que isso tem um custo

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Definir uma opção de compra (call) e uma opção de venda (put)
- Explicar por que comprar uma opção dá um direito, e não uma obrigação
- Explicar por que esse direito exige o pagamento de um prêmio

## Conteúdo principal

Uma **opção** é um contrato que dá ao comprador o direito, mas não a obrigação, de comprar ou vender um ativo-objeto (como uma ação) a um preço específico (o preço de exercício) até uma data específica, ou nessa data (a data de vencimento). Uma **opção de compra (call)** dá o direito de comprar pelo preço de exercício; uma **opção de venda (put)** dá o direito de vender pelo preço de exercício.

Este é o "porquê" de isso ser diferente de simplesmente ter a ação: como você só é obrigado a agir se isso for vantajoso para você, a perda máxima de quem compra a opção se limita ao que pagou pelo contrato, chamado de **prêmio**, enquanto o ganho potencial pode ser grande se o ativo-objeto se mover a favor. Essa assimetria (perda limitada, ganho potencial maior) é exatamente o que o comprador está pagando.

[VERIFIED FACT] O vendedor (ou "lançador") de uma opção está do outro lado dessa operação e assume a obrigação de cumprir o contrato se o comprador decidir exercer seu direito; é por isso que vender opções tem um perfil de risco fundamentalmente diferente, tratado em uma lição posterior. O prêmio não é arbitrário; ele reflete o preço atual do ativo-objeto, o preço de exercício, o tempo que falta até o vencimento e a volatilidade esperada do ativo.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora compra uma opção de compra (call) de uma ação que está sendo negociada a $50, com preço de exercício de $55, pagando um prêmio de $2 por ação. Se a ação subir para $65 antes do vencimento, ela pode exercer seu direito de comprar a $55, bem abaixo do preço de mercado, com um lucro relevante, descontado o prêmio de $2 que pagou. Se a ação ficar abaixo de $55 ou cair, ela simplesmente deixa a opção vencer, e sua perda total se limita ao prêmio de $2 que pagou; ela nunca foi obrigada a comprar a $55 se isso não fizesse sentido.

## Teste de prática

1. Qual é a principal diferença entre ter uma opção e ser obrigado a agir com base nela?
2. O que uma opção de compra (call) dá ao comprador o direito de fazer?
3. Por que a perda de quem compra a opção fica limitada ao prêmio pago, mesmo que o ativo-objeto se mova fortemente contra ele?

## Gabarito

1. Ter (comprar) uma opção dá um direito, e não uma obrigação: o comprador pode escolher se vai exercê-la ou não, ao contrário de ter a ação diretamente, o que não envolve nenhuma escolha sobre "ativar" a posição.
2. O direito de comprar o ativo-objeto pelo preço de exercício até a data de vencimento, ou nessa data.
3. Porque o comprador não é obrigado a exercer a opção: se ela for desfavorável, ele simplesmente a deixa vencer, perdendo apenas o prêmio que já pagou, e nada mais.

## Respostas e explicações

1. Esta é a distinção fundamental por trás de todas as outras lições sobre opções nesta trilha.
2. Esta é a definição específica de uma opção de compra, em contraste com uma opção de venda.
3. Isto explica o motivo mecânico da assimetria de perda limitada descrita no Conteúdo principal.

## Pontos-chave
- Uma opção dá ao comprador um direito, e não uma obrigação, de comprar (call) ou vender (put) um ativo a um preço definido antes do vencimento.
- Como exercer é opcional, a perda do comprador se limita ao prêmio pago, enquanto o ganho potencial pode ser maior.
- O vendedor da opção assume o lado da obrigação do contrato, que tem um perfil de risco diferente, tratado em uma lição posterior.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Operar opções envolve risco significativo e não é adequado para todos os investidores. Consulte um profissional financeiro licenciado antes de operar opções.*
