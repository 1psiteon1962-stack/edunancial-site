---
id: WHITE-L3-006
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 6
title: "Por que uma call aposta na direção e um straddle aposta no movimento"
source_title: "Why a Call Bets on Direction and a Straddle Bets on Movement"
description: "Entenda a diferença entre uma aposta direcional com opções e um straddle, que lucra com um movimento grande em qualquer direção."
slug: white-l3-006-call-vs-straddle
seo_title: "Por que uma call aposta na direção e um straddle aposta no movimento | Edunancial"
meta_description: "Entenda a diferença entre uma aposta direcional com opções e um straddle, que lucra com um movimento grande em qualquer direção."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-006: Por que uma call aposta na direção e um straddle aposta no movimento

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o que é a estratégia straddle
- Diferenciar apostar na direção de apostar no movimento/na volatilidade
- Identificar uma situação em que um straddle se encaixaria melhor do que uma simples opção de compra (call) ou opção de venda (put)

## Conteúdo principal

A Lição 5 apresentou as opções de compra (calls) e as opções de venda (puts) como apostas direcionais: uma call lucra se o ativo-objeto subir, uma put lucra se ele cair. Mas e se você tiver confiança de que algo grande está para acontecer, como a divulgação de resultados ou um anúncio importante, mas tiver dúvida real sobre para que lado o preço vai?

Um **straddle** combina a compra de uma call e de uma put sobre o mesmo ativo-objeto, com o mesmo preço de exercício e o mesmo vencimento. Este é o "porquê" de isso mudar a aposta: em vez de apostar na direção, um straddle aposta no **tamanho do movimento**. Ele lucra se o ativo-objeto se mover bastante em qualquer direção, o suficiente para cobrir o custo somado dos dois prêmios, e perde valor se o preço ficar relativamente parado, já que as duas opções venceriam valendo pouco.

[VERIFIED FACT] Como um straddle envolve comprar duas opções em vez de uma, ele custa mais no início do que uma única call ou put; ou seja, o ativo-objeto precisa se mover mais, em qualquer direção, só para empatar a posição combinada.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora espera que a próxima divulgação de resultados de uma empresa provoque uma grande oscilação no preço, mas não tem uma opinião forte sobre se a notícia será positiva ou negativa. Em vez de comprar só uma call (apostando na alta) ou só uma put (apostando na queda), ela compra um straddle: uma call e uma put com o mesmo preço de exercício. [ASSUMPTION] Se a ação disparar depois dos resultados, a call ganha valor suficiente para mais do que compensar a perda da put e o prêmio total pago, resultando em lucro. Se, em vez disso, a ação despencar, a put cumpre a mesma função no sentido oposto. Mas se a ação quase não se mexer para nenhum lado, as duas opções podem vencer valendo pouco, e ela perde a maior parte ou todo o prêmio somado que pagou.

## Teste de prática

1. O que um straddle combina, em termos de estrutura?
2. Como apostar no "movimento" é diferente de apostar na "direção"?
3. Por que um straddle precisa de um movimento de preço maior para dar lucro do que uma única call ou put precisaria?

## Gabarito

1. A compra de uma call e de uma put sobre o mesmo ativo-objeto, com o mesmo preço de exercício e o mesmo vencimento.
2. Apostar na direção significa lucrar só se o preço se mover para um lado específico (para cima, no caso de uma call; para baixo, no caso de uma put); apostar no movimento significa lucrar com um movimento grande em qualquer direção, seja para que lado for.
3. Porque o custo somado de comprar duas opções (a call e a put) é maior do que o de comprar só uma, então o preço precisa se mover mais para cobrir esse prêmio total maior antes que a posição comece a dar lucro.

## Respostas e explicações

1. Esta é a definição estrutural necessária para entender o restante da lição.
2. Esta é a distinção conceitual central em torno da qual a lição foi construída.
3. Isto reforça o custo-benefício de combinar duas posições em vez de uma.

## Pontos-chave
- Um straddle combina uma call e uma put com o mesmo preço de exercício e o mesmo vencimento, apostando no movimento, e não na direção.
- Ele lucra com um movimento de preço grande em qualquer direção e perde valor se o preço ficar relativamente parado.
- Como custa mais do que uma única opção, ele exige um movimento maior para dar lucro.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Operar opções envolve risco significativo e não é adequado para todos os investidores. Consulte um profissional financeiro licenciado antes de operar opções.*
