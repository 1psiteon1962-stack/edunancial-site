---
id: WHITE-L3-007
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 7
title: "Por que a perda de valor com o tempo trabalha contra quem compra opções"
source_title: "Why Time Decay Works Against Option Buyers"
description: "Entenda por que uma opção perde valor simplesmente com a passagem do tempo, mesmo que o preço do ativo-objeto não mude."
slug: white-l3-007-time-decay
seo_title: "Por que a perda de valor com o tempo trabalha contra quem compra opções | Edunancial"
meta_description: "Entenda por que uma opção perde valor simplesmente com a passagem do tempo, mesmo que o preço do ativo-objeto não mude."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-007: Por que a perda de valor com o tempo trabalha contra quem compra opções

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o que é a perda de valor com o tempo e por que ela afeta especificamente as opções
- Explicar por que essa perda se acelera à medida que o vencimento se aproxima
- Explicar por que a perda de valor com o tempo trabalha contra quem compra opções e a favor de quem as vende

## Conteúdo principal

O valor de uma opção vem de dois componentes: o valor intrínseco (o quanto o preço de exercício já é vantajoso em comparação com o preço atual de mercado) e o valor no tempo (o valor adicional que reflete a chance de a opção se tornar mais lucrativa antes do vencimento). À medida que o vencimento se aproxima, esse componente de valor no tempo diminui, um processo chamado de **perda de valor com o tempo** (em inglês, "time decay").

Este é o "porquê" de isso acontecer: menos tempo restante significa menos oportunidade de o preço do ativo-objeto se mover a favor antes de a opção vencer. Uma opção que faltam seis meses para vencer tem muito mais tempo para, possivelmente, se tornar lucrativa do que uma opção idêntica com uma semana restante; por isso ela vale mais, com todo o resto igual, apenas por causa do tempo adicional.

[VERIFIED FACT] A perda de valor com o tempo não é linear: normalmente ela se acelera à medida que o vencimento se aproxima, o que significa que uma opção pode perder uma grande parte do valor no tempo que lhe resta nas últimas semanas ou dias, mesmo que o preço do ativo-objeto não tenha se mexido. É por isso que quem compra opções trabalha contra um relógio que não para de encolher, enquanto quem vende opções (tema da próxima lição) geralmente se beneficia dessa mesma passagem do tempo.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Um investidor compra uma opção de compra (call) que faltam três meses para vencer. O preço da ação fica exatamente parado nos dois primeiros meses. Apesar de não haver nenhum movimento de preço, o valor da opção ainda assim caiu de forma relevante nesses dois meses, apenas por causa da perda de valor com o tempo; simplesmente resta menos tempo para a ação fazer o movimento que tornaria a opção lucrativa. [ASSUMPTION] No último mês, à medida que o vencimento se aproxima, essa erosão do valor no tempo se acelera ainda mais, de modo que até um pequeno atraso a mais no movimento da ação pode prejudicar bastante o valor que resta na opção.

## Teste de prática

1. Quais são os dois componentes do valor de uma opção?
2. Por que o valor no tempo de uma opção diminui à medida que o vencimento se aproxima, mesmo que o preço do ativo-objeto não se mexa?
3. Por que a perda de valor com o tempo se acelera, em vez de acontecer em um ritmo firme e constante?

## Gabarito

1. O valor intrínseco (o quanto o preço de exercício é vantajoso em comparação com o preço atual de mercado) e o valor no tempo (que reflete a oportunidade restante de um movimento favorável antes do vencimento).
2. Porque menos tempo restante significa menos oportunidade de o preço do ativo-objeto se mover a favor, o que reduz o valor da opção mesmo sem nenhuma mudança de preço.
3. Porque, à medida que o vencimento se aproxima, resta proporcionalmente muito menos tempo para um movimento favorável acontecer, o que faz o valor no tempo restante se desgastar mais rápido na reta final do que no início da vida da opção.

## Respostas e explicações

1. Isto estabelece a estrutura de valor em duas partes da qual o restante da lição depende.
2. Este é o mecanismo central da perda de valor com o tempo.
3. Isto acrescenta a nuance importante sobre a aceleração, preparando a dinâmica favorável ao vendedor discutida na próxima lição.

## Pontos-chave
- O valor de uma opção combina valor intrínseco e valor no tempo; o valor no tempo diminui à medida que o vencimento se aproxima.
- Essa "perda de valor com o tempo" acontece mesmo sem nenhum movimento no preço do ativo-objeto.
- A perda de valor com o tempo se acelera perto do vencimento, trabalhando contra quem compra opções e a favor de quem as vende.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Operar opções envolve risco significativo e não é adequado para todos os investidores. Consulte um profissional financeiro licenciado antes de operar opções.*
