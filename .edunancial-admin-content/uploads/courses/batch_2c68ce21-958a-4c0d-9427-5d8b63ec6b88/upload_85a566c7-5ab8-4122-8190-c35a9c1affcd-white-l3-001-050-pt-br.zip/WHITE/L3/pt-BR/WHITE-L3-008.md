---
id: WHITE-L3-008
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 8
title: "Por que vender opções inverte completamente o perfil de risco"
source_title: "Why Selling Options Flips the Risk Profile Entirely"
description: "Entenda por que vender (lançar) uma opção coloca você no lado da obrigação do contrato, com um perfil de risco muito diferente do de quem compra."
slug: white-l3-008-selling-options-risk-profile
seo_title: "Por que vender opções inverte completamente o perfil de risco | Edunancial"
meta_description: "Entenda por que vender (lançar) uma opção coloca você no lado da obrigação do contrato, com um perfil de risco muito diferente do de quem compra."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-008: Por que vender opções inverte completamente o perfil de risco

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar por que vender uma opção cria uma obrigação, e não um direito
- Explicar por que o ganho máximo de quem vende uma opção tem um teto, enquanto o risco pode ser muito maior
- Diferenciar uma posição de opção coberta de uma descoberta ("naked")

## Conteúdo principal

A Lição 5 mostrou que comprar uma opção dá um direito, com perda limitada (o prêmio) e ganho potencial maior. Vender, ou "lançar", uma opção inverte completamente essa estrutura: o vendedor recebe o prêmio no início, mas assume a **obrigação** de cumprir o contrato se o comprador decidir exercê-lo.

Este é o "porquê" de isso inverter o perfil de risco: o ganho máximo do vendedor tem como teto o prêmio recebido; é o máximo que ele pode ganhar com a posição. Mas a perda potencial, principalmente para um vendedor que ainda não tem o ativo-objeto (uma posição "naked", ou descoberta), pode ser muito maior, já que o preço do ativo-objeto pode se mover bastante contra ele e ele continua obrigado a cumprir o contrato.

[VERIFIED FACT] Uma **call coberta** (covered call), ou seja, vender uma opção de compra sobre uma ação que o vendedor já tem, limita o risco prático dessa posição específica, já que, se o comprador exercer, o vendedor simplesmente entrega ações que já possui, em vez de precisar comprá-las a um preço de mercado possivelmente muito mais alto. Vender opções sem já ter o ativo-objeto (venda "naked", ou descoberta) envolve um risco bem maior e é geralmente considerado uma estratégia avançada.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora vende uma call coberta sobre uma ação que já tem, negociada atualmente a $50, com preço de exercício de $55, recebendo um prêmio de $2. Se a ação ficar abaixo de $55, a opção vence sem valor, e ela fica com o prêmio de $2 como lucro puro, além de continuar com suas ações. Se a ação subir para $70, o comprador exerce a opção, e ela é obrigada a vender suas ações a $55, perdendo o ganho adicional acima de $55; mas o risco dela era limitado, já que ela já tinha as ações que foram vendidas. Compare isso com um vendedor de call descoberta, sem ações: a $70, ele seria obrigado a comprar ações pelo preço atual de mercado só para entregá-las a $55, uma perda potencialmente grande e, em princípio, sem limite.

## Teste de prática

1. Como o perfil de risco de vender uma opção é diferente do de comprar uma?
2. O que é uma call coberta, e por que ela limita o risco prático em comparação com uma call descoberta?
3. Qual é o ganho máximo possível para quem vende uma opção?

## Gabarito

1. Vender uma opção cria a obrigação de cumprir o contrato se ele for exercido, com um ganho máximo limitado (o prêmio), mas um risco potencialmente muito maior; o inverso da perda limitada e do ganho potencial maior de quem compra.
2. Uma call coberta é a venda de uma opção de compra sobre ações que o vendedor já tem; ela limita o risco porque, se for exercida, o vendedor entrega ações que já possui, em vez de precisar comprá-las a um preço de mercado possivelmente muito mais alto.
3. O prêmio recebido quando a opção foi vendida; esse é o lucro máximo possível da posição, por mais que o ativo-objeto se mova a favor do vendedor.

## Respostas e explicações

1. Este é o conceito central de inversão do perfil de risco em torno do qual a lição foi construída.
2. Isto diferencia as duas formas de venda e explica por que ser "coberta" reduz especificamente o risco prático.
3. Isto reforça o lado do ganho limitado no perfil de risco assimétrico do vendedor.

## Pontos-chave
- Vender uma opção cria uma obrigação, e não um direito, com um ganho máximo limitado (o prêmio) e um risco potencialmente muito maior.
- Uma call coberta, vendida sobre ações que você já tem, limita o risco prático em comparação com uma opção descoberta (naked).
- Vender opções descobertas envolve um risco bem maior e é geralmente considerado uma estratégia avançada.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Operar opções envolve risco significativo e não é adequado para todos os investidores. Consulte um profissional financeiro licenciado antes de operar opções.*
