---
id: WHITE-L3-009
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 9
title: "Por que a margem amplia ganhos e perdas como a alavancagem imobiliária"
source_title: "Why Margin Amplifies Gains and Losses Like Real Estate Leverage"
description: "Entenda como funciona comprar ações com margem, e por que isso multiplica tanto os ganhos quanto as perdas de um jeito parecido com a alavancagem imobiliária."
slug: white-l3-009-margin-and-leverage
seo_title: "Por que a margem amplia ganhos e perdas como a alavancagem imobiliária | Edunancial"
meta_description: "Entenda como funciona comprar ações com margem, e por que isso multiplica tanto os ganhos quanto as perdas de um jeito parecido com a alavancagem imobiliária."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-009: Por que a margem amplia ganhos e perdas como a alavancagem imobiliária

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar como funciona comprar ações com margem
- Explicar por que a margem amplia proporcionalmente tanto os ganhos quanto as perdas
- Relacionar esse conceito com a alavancagem imobiliária tratada em outras partes deste currículo

## Conteúdo principal

A **margem** permite que um investidor pegue dinheiro emprestado com uma corretora para comprar mais títulos e valores mobiliários do que o próprio dinheiro permitiria, usando os ativos da conta como garantia do empréstimo. Esse conceito é parecido com a alavancagem imobiliária discutida na trilha RED deste currículo: o dinheiro emprestado permite controlar uma posição maior com uma quantia menor de capital próprio.

Este é o "porquê" de o mesmo efeito multiplicador valer aqui: o seu retorno percentual é calculado em relação ao dinheiro que você mesmo investiu, e não ao tamanho total da posição; então, se a posição se valorizar, esse ganho é medido sobre uma base menor, ampliando o seu retorno percentual. Se a posição perder valor, a mesma conta amplia a sua perda percentual exatamente da mesma forma, e você continua devendo o valor total emprestado, não importa o desempenho do investimento.

[VERIFIED FACT] Os empréstimos com margem normalmente cobram juros, o que acrescenta um custo contínuo à posição, e as corretoras exigem que se mantenha um nível mínimo de patrimônio próprio na conta; se o valor da conta cair demais, isso pode disparar uma chamada de margem (margin call), tema da próxima lição.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Um investidor tem $10,000 em dinheiro e usa margem para comprar $20,000 em ações (pegando emprestados os outros $10,000). Se a ação subir 10%, a posição ganha $2,000: um retorno de 20% sobre os $10,000 originais do investidor, e não de 10%. Se, em vez disso, a ação cair 10%, a posição perde $2,000: uma perda de 20% sobre os $10,000 originais, e o investidor continua devendo os $10,000 inteiros que pegou emprestado, seja qual for o novo valor, mais baixo, da ação.

## Teste de prática

1. O que comprar com margem permite que um investidor faça?
2. Por que a margem amplia os ganhos e as perdas percentuais em comparação com uma compra feita só com dinheiro próprio?
3. Que custo contínuo a margem normalmente acrescenta, além do risco ampliado?

## Gabarito

1. Pegar dinheiro emprestado com uma corretora para comprar mais títulos e valores mobiliários do que o próprio dinheiro permitiria, usando os ativos da conta como garantia.
2. Porque os retornos são medidos sobre a quantia menor que o próprio investidor aplicou, e não sobre o tamanho total da posição, então o mesmo ganho ou perda em dólares se torna uma variação percentual maior.
3. Os juros cobrados sobre o empréstimo com margem, que acrescentam um custo contínuo, seja qual for o desempenho do investimento.

## Respostas e explicações

1. Esta é a base de definição da lição.
2. Este é o mesmo mecanismo multiplicador da alavancagem imobiliária, aplicado aqui ao investimento com margem.
3. Isto acrescenta uma dimensão de custo específica da margem, que não tem um paralelo tão direto na discussão sobre alavancagem imobiliária.

## Pontos-chave
- A margem permite pegar emprestado para comprar mais títulos e valores mobiliários do que o dinheiro próprio permitiria, usando a conta como garantia.
- Isso amplia proporcionalmente tanto os ganhos quanto as perdas, espelhando o efeito multiplicador da alavancagem visto no mercado imobiliário.
- Os empréstimos com margem cobram juros contínuos e exigem manter um patrimônio mínimo na conta, com o risco de uma chamada de margem se o valor da conta cair demais.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Operar com margem envolve risco significativo, incluindo a possibilidade de perder mais do que o seu investimento original. Consulte um profissional financeiro licenciado antes de operar com margem.*
