---
id: WHITE-L3-010
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 10
title: "Por que uma chamada de margem pode obrigar você a vender no pior momento possível"
source_title: "Why a Margin Call Can Force You to Sell at the Worst Possible Time"
description: "Entenda o que é uma chamada de margem (margin call), por que ela acontece automaticamente, e por que pode obrigar você a vender justamente quando os preços já estão em queda."
slug: white-l3-010-margin-calls
seo_title: "Por que uma chamada de margem pode obrigar você a vender no pior momento possível | Edunancial"
meta_description: "Entenda o que é uma chamada de margem (margin call), por que ela acontece automaticamente, e por que pode obrigar você a vender justamente quando os preços já estão em queda."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-010: Por que uma chamada de margem pode obrigar você a vender no pior momento possível

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o que dispara uma chamada de margem
- Explicar por que uma chamada de margem pode obrigar a vender em um momento especialmente ruim
- Explicar por que esse risco cresce com o nível de alavancagem usado

## Conteúdo principal

A Lição 9 apresentou o efeito da margem de ampliar tanto os ganhos quanto as perdas. Esta lição trata do mecanismo específico que transforma uma posição com margem que está perdendo dinheiro em uma venda forçada, e muitas vezes feita no pior momento: a **chamada de margem** (margin call).

As corretoras exigem que se mantenha um nível mínimo de patrimônio próprio em uma conta de margem (a exigência de margem de manutenção). Se o valor de uma posição cair a ponto de o patrimônio da conta ficar abaixo desse mínimo, a corretora emite uma chamada de margem: uma exigência para depositar mais dinheiro ou mais ativos, ou para vender parte da posição, de modo a colocar a conta de volta dentro das regras.

Este é o "porquê" de isso ser especialmente prejudicial: uma chamada de margem é disparada pela queda dos preços, o que significa que ela normalmente acontece justamente quando o investidor já está tendo perdas; e, se ele não puder ou não conseguir colocar mais dinheiro rapidamente, a corretora pode vender os ativos do investidor automaticamente, muitas vezes sem consultá-lo de novo, para restabelecer o nível de patrimônio exigido. [VERIFIED FACT] Isso pode forçar uma venda a um preço deprimido, tornando as perdas definitivas exatamente no momento em que, como na discussão da Lição 1, uma oportunidade de "comprar na baixa" poderia estar se formando; a alavancagem tira a opção de simplesmente esperar a tempestade passar.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora usa margem para comprar uma posição em ações maior do que o dinheiro dela sozinho permitiria. A ação cai com força, e o patrimônio da conta fica abaixo da exigência de manutenção da corretora, disparando uma chamada de margem. [ASSUMPTION] Sem conseguir depositar dinheiro adicional com rapidez suficiente, a corretora vende automaticamente parte da posição dela para colocar a conta de volta dentro das regras, tornando as perdas definitivas ao preço deprimido, mesmo que a ação se recupere depois. Uma investidora com a mesma ação, sem margem, teria tido a opção de simplesmente manter a posição durante a queda, já que nenhuma exigência de venda forçada se aplicava à posição dela, sem alavancagem.

## Teste de prática

1. O que dispara uma chamada de margem?
2. Por que uma chamada de margem é considerada especialmente mal cronometrada?
3. Que opção um investidor com margem perde, que um investidor sem alavancagem ainda tem durante uma queda?

## Gabarito

1. O patrimônio da conta cair abaixo do nível de margem de manutenção exigido pela corretora, normalmente por causa de uma queda no valor da posição alavancada.
2. Porque ela é disparada pela queda dos preços, o que significa que obriga a agir justamente quando o investidor já está tendo perdas, podendo torná-las definitivas a um preço deprimido.
3. A opção de simplesmente manter a posição durante uma queda e esperar uma possível recuperação; a margem pode forçar uma venda, independentemente da preferência do próprio investidor de esperar.

## Respostas e explicações

1. Este é o gatilho mecânico do qual o restante da lição depende.
2. Este é o "porquê" central: o descompasso entre o momento em que acontece uma chamada de margem e o momento em que o investidor idealmente gostaria de vender.
3. Isto se conecta diretamente ao tema da Lição 1 sobre a dificuldade de comprar na baixa e aguentar as quedas.

## Pontos-chave
- Uma chamada de margem é disparada quando o patrimônio de uma conta cai abaixo do nível de manutenção exigido pela corretora.
- Como é disparada pela queda dos preços, ela pode forçar uma venda a um preço deprimido, tornando as perdas definitivas em um momento ruim.
- A margem tira do investidor a opção de simplesmente aguentar uma queda, opção que os investidores sem alavancagem continuam tendo.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Operar com margem envolve risco significativo, incluindo a venda forçada de ativos. Consulte um profissional financeiro licenciado antes de operar com margem.*
