---
id: WHITE-L3-011
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 11
title: "Por que a venda a descoberto tem risco teoricamente ilimitado"
source_title: "Why Short Selling Has Theoretically Unlimited Risk"
description: "Entenda como funciona a venda a descoberto, por que ela lucra com a queda do preço, e por que a sua perda potencial é, pela própria estrutura, ilimitada."
slug: white-l3-011-short-selling-risk
seo_title: "Por que a venda a descoberto tem risco teoricamente ilimitado | Edunancial"
meta_description: "Entenda como funciona a venda a descoberto, por que ela lucra com a queda do preço, e por que a sua perda potencial é, pela própria estrutura, ilimitada."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-011: Por que a venda a descoberto tem risco teoricamente ilimitado

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar como a venda a descoberto funciona na prática
- Explicar por que o ganho máximo de quem vende a descoberto tem um teto, mas a perda potencial é teoricamente ilimitada
- Explicar o que é um short squeeze e por que ele pode acelerar as perdas

## Conteúdo principal

A **venda a descoberto** (short selling) consiste em pegar emprestadas ações de uma empresa (normalmente por meio de uma corretora), vendê-las imediatamente pelo preço atual e, mais tarde, comprá-las de volta (de preferência a um preço menor) para devolvê-las a quem emprestou, lucrando com a diferença se o preço cair.

Este é o "porquê" de a venda a descoberto ter um formato de risco fundamentalmente diferente de simplesmente ter uma ação: o preço de uma ação só pode cair até zero, então o ganho máximo possível para quem vende a descoberto tem um teto (o valor total da ação, se ela chegar a zero). Mas o preço de uma ação não tem limite teórico para cima: ele pode continuar subindo indefinidamente, o que significa que a perda potencial de quem vende a descoberto, que em algum momento precisa comprar de volta as ações emprestadas pelo preço a que elas tiverem chegado, é teoricamente ilimitada.

[VERIFIED FACT] Esse risco pode se acelerar por meio de um **short squeeze** (aperto dos vendidos): se o preço de uma ação muito vendida a descoberto começa a subir, os vendedores a descoberto, diante de perdas crescentes, podem ser forçados (às vezes por mecanismos parecidos com uma chamada de margem, Lição 10) a comprar as ações de volta para limitar suas perdas, e essa própria pressão de compra pode empurrar o preço ainda mais para cima, levando mais vendedores a descoberto a fazer o mesmo, em um ciclo que se autoalimenta.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Um investidor pega emprestadas e vende a descoberto 100 ações de uma empresa negociadas a $50, esperando que o preço caia. Se o preço de fato cair para $30, ele pode comprar as ações de volta por $3,000 e devolvê-las, embolsando a diferença de $2,000 (antes dos custos): um ganho bom, mas limitado, já que a ação poderia, no máximo, cair até zero. Se, em vez disso, a ação subir inesperadamente para $150, ele precisaria gastar $15,000 para comprar de volta as ações que vendeu por $5,000: uma perda de $10,000, e se o preço continuasse subindo, essa perda continuaria crescendo, sem limite.

## Teste de prática

1. Como a venda a descoberto funciona na prática?
2. Por que o ganho máximo possível de quem vende a descoberto tem um teto, enquanto a perda potencial é teoricamente ilimitada?
3. O que é um short squeeze, e como ele pode acelerar as perdas de quem vende a descoberto?

## Gabarito

1. Pegar ações emprestadas, vendê-las pelo preço atual e, mais tarde, comprá-las de volta para devolvê-las a quem emprestou, lucrando se o preço de recompra for menor que o preço de venda.
2. O preço de uma ação só pode cair até zero (o que limita o ganho), mas não tem limite teórico para o quanto pode subir (o que deixa a perda potencial ilimitada).
3. Um ciclo que se autoalimenta, no qual a alta dos preços obriga os vendedores a descoberto a comprar as ações de volta para limitar suas perdas, e essa pressão de compra empurra os preços ainda mais para cima, provocando mais compras forçadas.

## Respostas e explicações

1. Esta é a base mecânica de toda a lição.
2. Este é o formato de risco assimétrico central que diferencia a venda a descoberto de simplesmente ter ações.
3. Isto explica um mecanismo de aceleração real, já observado historicamente, ligado ao risco de perda ilimitada descrito acima.

## Pontos-chave
- A venda a descoberto lucra com a queda do preço de uma ação: você pega ações emprestadas, vende e, mais tarde, compra de volta a um preço (de preferência) menor.
- O ganho máximo tem um teto, já que uma ação só pode cair até zero, mas a perda potencial é teoricamente ilimitada, já que o preço não tem limite para cima.
- Um short squeeze pode acelerar as perdas por meio de um ciclo de compras forçadas que se autoalimenta à medida que os preços sobem.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. A venda a descoberto envolve risco significativo, potencialmente ilimitado, e não é adequada para todos os investidores. Consulte um profissional financeiro licenciado antes de vender a descoberto.*
