---
id: WHITE-L3-012
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 12
title: "Por que os aportes regulares (preço médio) reduzem o risco de momento, e não o risco do investimento"
source_title: "Why Dollar-Cost Averaging Reduces Timing Risk, Not Investment Risk"
description: "Entenda por que investir um valor fixo em um calendário regular reduz o risco de escolher um mau momento, sem reduzir o risco do próprio investimento."
slug: white-l3-012-dollar-cost-averaging
seo_title: "Por que os aportes regulares (preço médio) reduzem o risco de momento, e não o risco do investimento | Edunancial"
meta_description: "Entenda por que investir um valor fixo em um calendário regular reduz o risco de escolher um mau momento, sem reduzir o risco do próprio investimento."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-012: Por que os aportes regulares (preço médio) reduzem o risco de momento, e não o risco do investimento

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar como funcionam os aportes regulares pelo preço médio (dollar-cost averaging, ou DCA)
- Explicar o tipo específico de risco que o DCA reduz
- Explicar por que o DCA não reduz o risco do próprio investimento

## Conteúdo principal

Os **aportes regulares pelo preço médio** (em inglês, dollar-cost averaging, ou DCA) significam investir um valor fixo de dinheiro em intervalos regulares, por exemplo todo mês, qualquer que seja o preço em cada intervalo, em vez de investir uma quantia maior de uma vez só.

Este é o "porquê" de isso tratar especificamente do risco de momento, voltando à Lição 1: como você compra em muitos níveis de preço diferentes ao longo do tempo, evita o risco de investir todo o seu dinheiro logo antes de uma queda grande, no pior momento. Algumas compras acontecem a preços mais altos, outras a preços mais baixos, e o custo médio por ação se suaviza ao longo do período de investimento.

[VERIFIED FACT] O DCA não reduz o risco real nem a volatilidade do investimento em si: a ação, o fundo ou o ativo que você está comprando continua com as mesmas características fundamentais de risco, não importa como você distribui suas compras no tempo. O que o DCA muda é a sua exposição a um único ponto de entrada ruim, e não o comportamento próprio do investimento depois que ele é seu.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora tem $12,000 para investir. Investir tudo de uma vez, logo antes de uma forte queda do mercado, significaria que o valor inteiro ficaria imediatamente exposto a essa queda. Investir $1,000 por mês durante 12 meses, em vez disso, significa que só os primeiros aportes ficam expostos à queda inteira, se ela acontecer no começo desse período; os aportes seguintes compram aos preços, agora mais baixos, fazendo uma média do custo total da investidora (o preço médio). [ASSUMPTION] Se, em vez disso, o mercado subir de forma constante durante os 12 meses, o DCA teria resultado em um custo médio maior do que investir a quantia inteira de imediato; o DCA protege contra um cenário específico de mau momento, mas não garante um resultado melhor do que investir tudo de uma vez em todos os cenários (uma comparação tratada diretamente na próxima lição).

## Teste de prática

1. Como funcionam os aportes regulares pelo preço médio (DCA)?
2. Que tipo específico de risco o DCA trata?
3. O DCA reduz o risco do próprio investimento? Por quê?

## Gabarito

1. Investir um valor fixo em intervalos regulares, qualquer que seja o preço, em vez de investir uma quantia grande de uma vez só.
2. O risco de momento: o risco de investir uma quantia grande logo antes de uma queda, no pior momento.
3. Não: as características de risco e de volatilidade do próprio investimento continuam as mesmas; o DCA só muda o quanto você fica exposto a um único ponto de entrada, possivelmente mal escolhido.

## Respostas e explicações

1. Esta é a definição mecânica necessária para o restante da lição.
2. Esta é a distinção central e precisa que a lição faz: o DCA é uma ferramenta de momento, e não uma ferramenta para reduzir o risco do próprio investimento.
3. Isto reforça a distinção e antecipa o custo-benefício explorado na próxima lição.

## Pontos-chave
- O DCA consiste em investir um valor fixo em intervalos regulares, em vez de tudo de uma vez.
- Ele reduz especificamente o risco de momento: o risco de um único investimento grande feito no pior momento.
- O DCA não muda o risco nem a volatilidade do próprio investimento, apenas a sua exposição a um ponto de entrada ruim.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Todos os valores são estimativas ilustrativas, não garantias. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
