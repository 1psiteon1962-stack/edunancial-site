---
id: WHITE-L3-013
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 13
title: "Por que investir tudo de uma vez muitas vezes supera os aportes regulares (e por que as pessoas ainda escolhem os aportes regulares)"
source_title: "Why Lump-Sum Investing Often Outperforms DCA (and Why People Still Choose DCA)"
description: "Entenda por que investir tudo de uma vez tende, estatisticamente, a superar os aportes regulares pelo preço médio em mercados em alta, e por que muitos investidores ainda assim preferem o DCA."
slug: white-l3-013-lump-sum-vs-dca
seo_title: "Por que investir tudo de uma vez muitas vezes supera os aportes regulares (e por que as pessoas ainda escolhem os aportes regulares) | Edunancial"
meta_description: "Entenda por que investir tudo de uma vez tende, estatisticamente, a superar os aportes regulares pelo preço médio em mercados em alta, e por que muitos investidores ainda assim preferem o DCA."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-013: Por que investir tudo de uma vez muitas vezes supera os aportes regulares (e por que as pessoas ainda escolhem os aportes regulares)

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar por que investir tudo de uma vez tende a superar o DCA (aportes regulares pelo preço médio) em um mercado que normalmente sobe
- Explicar por que muitos investidores ainda escolhem o DCA, apesar dessa tendência estatística
- Explicar por que isso é uma troca legítima, e não simplesmente um erro de conta de quem faz DCA

## Conteúdo principal

A Lição 12 mostrou que o DCA protege contra um cenário específico de mau momento. Este é o "porquê" de esta lição ir além: como os mercados historicamente subiram mais vezes do que caíram na maioria dos períodos longos, investir uma quantia de uma vez, em vez de distribuí-la, na maioria das vezes resultou em um desfecho melhor, já que uma parte maior do seu dinheiro fica investida e exposta a possíveis ganhos por mais tempo, em vez de ficar parcialmente parada enquanto é aplicada aos poucos.

[VERIFIED FACT] Esta é uma tendência estatística baseada em padrões históricos, e não uma garantia para nenhum período futuro específico: houve períodos em que o DCA teria superado o investimento de uma vez, principalmente os que começaram pouco antes de uma queda grande.

Então, por que muitos investidores ainda escolhem o DCA, mesmo entendendo essa tendência? O motivo se liga ao tema comportamental da Lição 1: o DCA reduz o risco emocional de investir uma quantia grande logo antes de uma queda e depois, movido por arrependimento ou medo, abandonar a estratégia por completo. Um investidor que escolhe o DCA e segue o seu plano, mesmo que isso produza um resultado esperado estatisticamente menor, pode acabar em melhor situação do que um que escolhe investir tudo de uma vez, mas entra em pânico e vende durante uma queda posterior.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora recebe uma grande herança e precisa decidir entre investir tudo imediatamente ou distribuir o valor ao longo de um ano com DCA. [ASSUMPTION] Historicamente, em um ano escolhido ao acaso, investir a quantia inteira imediatamente teria superado o DCA na maioria das vezes, já que os mercados subiram na maior parte dos períodos históricos. Mas essa investidora sabe, por experiência própria, que um investimento grande e repentino seguido de uma queda do mercado provavelmente lhe causaria muita ansiedade e poderia levá-la a vender no prejuízo. Escolher o DCA, mesmo com um retorno esperado estatisticamente menor, pode ser a melhor decisão para ela especificamente, se isso significar que ela terá mais chance de seguir o seu plano de investimento durante as oscilações do mercado.

## Teste de prática

1. Por que investir tudo de uma vez tende, estatisticamente, a superar o DCA na maioria dos períodos históricos?
2. Essa tendência é uma garantia para algum período futuro específico? Por quê?
3. Por que um investidor poderia, de forma racional, escolher o DCA mesmo assim, apesar dessa tendência estatística?

## Gabarito

1. Porque os mercados historicamente subiram mais vezes do que caíram em períodos longos, então ter mais dinheiro investido por mais tempo normalmente aproveita mais essa tendência de alta do que aplicar o dinheiro aos poucos.
2. Não: ela se baseia em padrões históricos, e houve períodos específicos, principalmente os que começaram antes de uma queda grande, em que o DCA teria se saído melhor.
3. Porque o DCA pode reduzir o risco emocional de um mau momento e da venda em pânico que viria depois, podendo levar a um resultado real melhor do que uma estratégia estatisticamente superior que o investidor poderia abandonar durante uma queda.

## Respostas e explicações

1. Este é o raciocínio estatístico central por trás do título da lição.
2. Esta é uma ressalva importante e devidamente cautelosa contra o excesso de confiança em padrões históricos.
3. Isto liga a decisão de volta à psicologia do investidor, reforçando que a "melhor" escolha no papel nem sempre é a melhor escolha para o comportamento de uma pessoa específica.

## Pontos-chave
- Investir tudo de uma vez historicamente superou o DCA na maioria das vezes, já que os mercados tenderam a subir na maior parte dos períodos longos.
- Isto é uma tendência estatística, e não uma garantia para nenhum período específico.
- Muitos investidores escolhem o DCA mesmo assim, de forma racional, porque ele pode reduzir o risco emocional de um mau momento e aumentar a chance de seguir um plano de investimento no longo prazo.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Desempenho passado não garante resultados futuros. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
