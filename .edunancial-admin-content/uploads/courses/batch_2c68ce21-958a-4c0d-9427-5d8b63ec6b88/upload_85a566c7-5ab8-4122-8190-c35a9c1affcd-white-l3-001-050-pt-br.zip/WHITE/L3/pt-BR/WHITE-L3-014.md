---
id: WHITE-L3-014
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 14
title: "Por que o rebalanceamento obriga você a vender na alta e comprar na baixa automaticamente"
source_title: "Why Rebalancing Forces You to Sell High and Buy Low Automatically"
description: "Entenda como funciona o rebalanceamento da carteira, e por que ele transforma a disciplina de \"comprar na baixa, vender na alta\" em um processo mecânico, em vez de depender da força de vontade."
slug: white-l3-014-rebalancing
seo_title: "Por que o rebalanceamento obriga você a vender na alta e comprar na baixa automaticamente | Edunancial"
meta_description: "Entenda como funciona o rebalanceamento da carteira, e por que ele transforma a disciplina de \"comprar na baixa, vender na alta\" em um processo mecânico, em vez de depender da força de vontade."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-014: Por que o rebalanceamento obriga você a vender na alta e comprar na baixa automaticamente

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o que significa rebalancear uma carteira
- Explicar por que o rebalanceamento obriga, de forma mecânica, a vender os vencedores relativos e comprar os perdedores relativos
- Relacionar esse conceito com o desafio central da Lição 1

## Conteúdo principal

A Lição 1 abriu esta trilha com a dificuldade de realmente executar o "comprar na baixa, vender na alta". O **rebalanceamento** oferece uma solução parcial e mecânica: significa ajustar periodicamente uma carteira de volta à sua alocação-alvo original (por exemplo, 60% em ações e 40% em títulos de renda fixa) depois que os movimentos do mercado afastaram essas proporções do alvo.

Este é o "porquê" de isso embutir automaticamente o comportamento desejado: se as ações foram bem e agora representam 70% da carteira, em vez dos 60% do alvo, rebalancear significa vender parte das ações (que subiram em valor relativo) e comprar mais títulos de renda fixa (que ficaram para trás) para restabelecer o alvo original; ou seja, vender mecanicamente parte do que subiu e comprar parte do que não subiu, sem precisar prever o próximo movimento do mercado.

[VERIFIED FACT] O rebalanceamento pode ser feito em um calendário fixo (por exemplo, uma vez por ano) ou ser acionado quando as alocações se afastam além de um certo limite; qualquer uma das duas abordagens tira a emoção das decisões do processo, substituindo-a por uma regra definida com antecedência.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora começa com uma carteira de 60% em ações e 40% em títulos de renda fixa. Depois de um ano forte para as ações, a carteira se desviou para 72% em ações e 28% em títulos. Rebalancear significa vender ações suficientes e comprar títulos suficientes para voltar ao alvo de 60/40; ou seja, realizar mecanicamente parte do lucro da classe de ativos vencedora e reforçar a que ficou para trás, seguindo uma regra definida com antecedência, e não uma previsão sobre o que vai acontecer. [ASSUMPTION] Se as ações continuarem subindo depois, esse rebalanceamento "custou" à investidora parte do ganho adicional; se as ações recuarem, o rebalanceamento parecerá visionário olhando para trás; mas, de qualquer forma, o processo foi seguido de maneira consistente, e não por reação.

## Teste de prática

1. O que significa rebalancear uma carteira?
2. Por que o rebalanceamento resulta, de forma mecânica, em vender os ativos de desempenho relativamente melhor e comprar os de desempenho relativamente pior?
3. Por que isso tira a emoção das decisões do processo?

## Gabarito

1. Ajustar periodicamente uma carteira de volta à sua alocação de ativos-alvo original, depois que os movimentos do mercado afastaram as proporções reais desse alvo.
2. Porque uma classe de ativos que foi bem cresce até representar uma parte maior da carteira do que o pretendido, então voltar à alocação-alvo exige vender parte dela; o inverso vale para uma classe de ativos com desempenho pior, que precisa ser reforçada.
3. Porque a decisão de vender ou comprar se baseia em uma regra definida com antecedência (a alocação-alvo e um calendário ou limite de rebalanceamento), e não em um julgamento feito na hora sobre para onde o mercado vai.

## Respostas e explicações

1. Esta é a base de definição para o restante da lição.
2. Isto explica o mecanismo específico que embute a disciplina de "comprar na baixa, vender na alta" no processo.
3. Isto liga o processo mecânico de volta ao desafio comportamental apresentado na Lição 1.

## Pontos-chave
- O rebalanceamento restabelece periodicamente a alocação de ativos-alvo original de uma carteira.
- Isso resulta, de forma mecânica, em vender os ativos que foram relativamente bem e comprar os que ficaram para trás, sem precisar prever o desempenho futuro.
- Seguir um calendário ou limite definido com antecedência tira a emoção das decisões do processo.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Todos os valores são estimativas ilustrativas, não garantias. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
