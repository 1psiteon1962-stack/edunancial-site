---
id: WHITE-L3-015
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 15
title: "Por que o risco da sequência de retornos importa mais na aposentadoria do que na fase de acumulação"
source_title: "Why Sequence of Returns Risk Matters More in Retirement Than Accumulation"
description: "Entenda por que a ordem em que os retornos dos investimentos acontecem pode importar mais do que o próprio retorno médio, principalmente depois que você começa a fazer retiradas."
slug: white-l3-015-sequence-of-returns-risk
seo_title: "Por que o risco da sequência de retornos importa mais na aposentadoria do que na fase de acumulação | Edunancial"
meta_description: "Entenda por que a ordem em que os retornos dos investimentos acontecem pode importar mais do que o próprio retorno médio, principalmente depois que você começa a fazer retiradas."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-015: Por que o risco da sequência de retornos importa mais na aposentadoria do que na fase de acumulação

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o que significa o risco da sequência de retornos
- Explicar por que o mesmo retorno médio pode produzir resultados muito diferentes dependendo da ordem
- Explicar por que esse risco é bem menor na fase de acumulação do que durante as retiradas da aposentadoria

## Conteúdo principal

A maioria das discussões sobre retorno de investimentos se concentra no retorno médio anual de um período. O **risco da sequência de retornos** destaca algo que a média sozinha esconde: a *ordem* em que esses retornos acontecem pode mudar bastante o resultado final, principalmente quando há retiradas regulares.

Este é o "porquê" de a ordem importar tanto durante as retiradas: se uma carteira tem retornos ruins no começo de um período de retiradas, o investidor é obrigado a vender mais cotas (ou uma porcentagem maior da carteira) a preços deprimidos para bancar cada retirada, reduzindo para sempre a base de ativos que sobra para se recuperar quando o mercado finalmente melhorar. Os mesmos retornos ruins acontecendo mais tarde, depois de alguns anos de retiradas, causam menos estrago: simplesmente resta menos tempo para que um estrago feito cedo se acumule negativamente.

[VERIFIED FACT] Durante a fase de acumulação (quando o investidor está colocando dinheiro, e não retirando), a sequência de retornos importa bem menos, já que não há vendas forçadas em plena queda; o investidor pode simplesmente continuar fazendo aportes e esperar uma recuperação, sem ser obrigado a tornar as perdas definitivas por meio de retiradas.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Dois aposentados começam com o mesmo valor de carteira e fazem a mesma retirada anual, e os dois têm exatamente o mesmo retorno médio anual ao longo de 20 anos, mas em ordem diferente. O Aposentado A tem retornos ruins nos primeiros anos da aposentadoria, o que o obriga a fazer retiradas maiores (como porcentagem de uma carteira que está encolhendo) durante essa queda. O Aposentado B tem os mesmos anos ruins, mas mais tarde no período de 20 anos, depois que a carteira já cresceu com os anos bons do começo. [ASSUMPTION] Apesar dos retornos médios idênticos, a carteira do Aposentado A pode ficar sem dinheiro bem antes da do Aposentado B, apenas por causa do momento em que os retornos ruins aconteceram em relação ao calendário de retiradas.

## Teste de prática

1. O que o risco da sequência de retornos descreve?
2. Por que retornos ruins no começo de um período de retiradas podem causar muito mais estrago do que os mesmos retornos ruins acontecendo mais tarde?
3. Por que o risco da sequência de retornos importa bem menos durante a fase de acumulação?

## Gabarito

1. O risco de que a ordem em que os retornos dos investimentos acontecem, e não apenas a média deles, afete bastante o resultado de uma carteira, principalmente quando há retiradas regulares.
2. Porque retornos ruins no começo obrigam a fazer retiradas maiores como porcentagem de uma carteira que já está encolhendo, reduzindo para sempre a base de ativos disponível para aproveitar uma recuperação posterior.
3. Porque, sem retiradas forçadas, o investidor pode simplesmente continuar fazendo aportes e esperar a queda passar sem precisar vender durante ela, então a ordem dos retornos não se acumula da mesma forma.

## Respostas e explicações

1. Esta é a definição básica da lição.
2. Este é o mecanismo central que explica por que o momento, e não apenas o retorno médio, importa tanto na aposentadoria.
3. Isto compara diretamente as fases de acumulação e de retiradas, deixando claro quando esse risco é mais relevante.

## Pontos-chave
- O risco da sequência de retornos significa que a ordem dos retornos dos investimentos pode importar tanto quanto a média deles, principalmente quando há retiradas.
- Retornos ruins no começo de um período de retiradas causam um estrago desproporcional, já que obrigam a vender uma parte maior de uma carteira que está encolhendo.
- Esse risco é bem menor na fase de acumulação, já que não há vendas forçadas que tornem definitivas as perdas do começo.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Todos os valores são estimativas ilustrativas, não garantias. Consulte um profissional financeiro licenciado antes de tomar decisões de planejamento de aposentadoria.*
