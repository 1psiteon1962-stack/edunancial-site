---
id: WHITE-L3-017
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 17
title: "Por que dividendos não são \"dinheiro de graça\""
source_title: "Why Dividends Aren't \"Free Money\""
description: "Entenda por que o pagamento de um dividendo reduz o preço de uma ação em mais ou menos o mesmo valor, e por que os dividendos são uma redistribuição de valor, e não um bônus."
slug: white-l3-017-dividends-not-free-money
seo_title: "Por que dividendos não são \"dinheiro de graça\" | Edunancial"
meta_description: "Entenda por que o pagamento de um dividendo reduz o preço de uma ação em mais ou menos o mesmo valor, e por que os dividendos são uma redistribuição de valor, e não um bônus."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-017: Por que dividendos não são "dinheiro de graça"

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar por que o preço de uma ação normalmente cai mais ou menos o valor do dividendo na data ex-dividendo
- Explicar por que um dividendo é uma redistribuição de um valor que já existia, e não riqueza nova
- Explicar por que o "retorno total" é a forma mais completa de avaliar um investimento que paga dividendos

## Conteúdo principal

É fácil pensar no pagamento de um dividendo como dinheiro extra, somado ao valor que a ação já tem; um bônus por manter a ação. Este é o "porquê" de essa forma de ver enganar: uma empresa paga dividendos com o próprio caixa, o que reduz os ativos que sobram para a empresa. [VERIFIED FACT] Na data ex-dividendo, o preço de uma ação normalmente cai aproximadamente o valor do dividendo pago, refletindo que a empresa agora vale um pouco menos, por ter distribuído parte do seu caixa aos acionistas.

Isso significa que um dividendo não é riqueza nova surgindo do nada; é uma redistribuição de um valor que já existia dentro da empresa, que agora passa para o bolso do acionista em dinheiro, em vez de continuar como parte do preço da ação. O acionista não fica realmente mais rico no momento em que o dividendo é pago; ele simplesmente tem o mesmo valor total, dividido entre um preço de ação um pouco menor e o dividendo recebido em dinheiro.

É por isso que o **retorno total**, que soma a valorização do preço e os dividendos, é a medida mais completa do desempenho real de um investimento, em vez de olhar a renda de dividendos ou a valorização do preço separadamente.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma ação é negociada a $100 no dia anterior ao pagamento de um dividendo de $2 por ação. Na data ex-dividendo, com todo o resto igual, o preço da ação normalmente se ajusta para baixo, para aproximadamente $98, refletindo os $2 por ação que acabaram de sair da empresa como pagamento em dinheiro. Um investidor com uma ação agora tem $98 em ação mais $2 em dinheiro: continua com $100 de valor total, o mesmo de antes do pagamento do dividendo. O dividendo não criou riqueza nova; ele simplesmente converteu $2 de valor que já existia na ação em $2 em dinheiro.

## Teste de prática

1. O que normalmente acontece com o preço de uma ação na data ex-dividendo, e por quê?
2. Por que é melhor entender um dividendo como uma redistribuição de valor, e não como riqueza nova?
3. Por que o "retorno total" é considerado uma medida de desempenho mais completa do que olhar apenas os dividendos?

## Gabarito

1. O preço normalmente cai aproximadamente o valor do dividendo, porque o caixa da empresa, e portanto o seu valor total, diminuiu nesse mesmo valor.
2. Porque o valor total do acionista (preço da ação mais dividendo recebido) continua mais ou menos o mesmo logo depois do pagamento; o dividendo simplesmente converte parte do valor que já existia na ação em dinheiro, em vez de acrescentar valor novo.
3. Porque ele combina a valorização do preço e a renda de dividendos, captando o desempenho completo do investimento, e não apenas uma parte dele.

## Respostas e explicações

1. Este é o fato mecânico em torno do qual toda a lição foi construída.
2. Esta é a mudança de perspectiva central que a lição foi feita para ensinar.
3. Isto apresenta a forma de avaliação mais completa para a qual o conceito aponta.

## Pontos-chave
- O preço de uma ação normalmente cai mais ou menos o valor do dividendo na data ex-dividendo.
- Um dividendo redistribui aos acionistas, em dinheiro, um valor que já existia na empresa; ele não cria riqueza nova por si só.
- O retorno total, que soma a valorização do preço e os dividendos, é uma forma mais completa de avaliar o desempenho real de um investimento.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Todos os valores são estimativas ilustrativas, não garantias. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
