---
id: WHITE-L3-018
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 18
title: "Por que a duration de um título mede a sensibilidade às taxas de juros"
source_title: "Why Bond Duration Measures Interest Rate Sensitivity"
description: "Entenda o que a duration de um título de renda fixa mede, por que títulos com duration mais longa são mais sensíveis a mudanças nas taxas de juros, e por que isso importa para quem investe em renda fixa."
slug: white-l3-018-bond-duration
seo_title: "Por que a duration de um título mede a sensibilidade às taxas de juros | Edunancial"
meta_description: "Entenda o que a duration de um título de renda fixa mede, por que títulos com duration mais longa são mais sensíveis a mudanças nas taxas de juros, e por que isso importa para quem investe em renda fixa."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-018: Por que a duration de um título mede a sensibilidade às taxas de juros

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Definir a duration de um título de renda fixa
- Explicar por que títulos com duration mais longa são mais sensíveis a mudanças nas taxas de juros
- Explicar por que dois títulos com a mesma data de vencimento podem ter durations diferentes

## Conteúdo principal

A **duration** (ou duração) é uma medida da sensibilidade de um título de renda fixa a mudanças nas taxas de juros, expressa de um jeito que parece anos, mas que representa algo mais específico: mais ou menos, o quanto se espera que o preço de um título mude para uma determinada mudança nas taxas de juros.

Este é o "porquê" de uma duration mais longa significar mais sensibilidade: um título que leva mais tempo para pagar os seus fluxos de caixa é mais afetado por uma mudança nas taxas vigentes, porque uma parte maior do seu valor depende de fluxos de caixa mais distantes no tempo, que são mais fortemente afetados por uma mudança na taxa usada para avaliá-los hoje (um conceito ligado à relação entre taxas de juros e preços de títulos, tratada na próxima lição).

[VERIFIED FACT] A duration não é idêntica ao prazo de vencimento de um título: a taxa de cupom do título (os pagamentos de juros feitos ao longo do caminho) também afeta a duration; um título que faz pagamentos regulares maiores devolve uma parte maior do seu valor mais cedo, o que geralmente lhe dá uma duration um pouco mais curta do que a de um título com a mesma data de vencimento, mas com pagamentos regulares menores ou nenhum (um título sem cupom, por exemplo, tem duration igual ao seu prazo total, já que todo o seu valor é devolvido só no final).

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Dois títulos vencem em 10 anos. O Título A faz pagamentos de juros regulares e relevantes ao longo do caminho, devolvendo parte do seu valor ao investidor antes do vencimento, o que lhe dá uma duration um pouco menor que 10 anos. O Título B é um título sem cupom (zero-coupon), que não paga nada até vencer e devolve todo o seu valor apenas ao final dos 10 anos, o que lhe dá uma duration igual ao seu prazo total de 10 anos. [ASSUMPTION] Se as taxas de juros subirem na mesma medida, normalmente se esperaria que o preço do Título B caísse mais do que o do Título A, apenas por causa da sua duration mais longa, mesmo que os dois títulos vençam ao mesmo tempo.

## Teste de prática

1. O que a duration de um título mede?
2. Por que uma duration mais longa geralmente significa maior sensibilidade a mudanças nas taxas de juros?
3. Por que dois títulos com a mesma data de vencimento podem ter durations diferentes?

## Gabarito

1. A sensibilidade de um título a mudanças nas taxas de juros; mais ou menos, o quanto se espera que o seu preço mude para uma determinada mudança nas taxas.
2. Porque uma parte maior do valor do título depende de fluxos de caixa mais distantes no tempo, que são mais fortemente afetados por uma mudança na taxa usada para avaliá-los hoje.
3. Porque a duration também depende do tamanho e do momento dos pagamentos regulares de juros de um título; um título que devolve mais valor mais cedo (pagamentos de cupom maiores) tem duration mais curta do que um que devolve a maior parte, ou todo o seu valor, apenas no vencimento.

## Respostas e explicações

1. Esta é a definição básica necessária para o restante da lição.
2. Este é o mecanismo central que explica a relação entre a duration e a sensibilidade às taxas de juros.
3. Isto acrescenta uma nuance importante que diferencia a duration do simples prazo até o vencimento.

## Pontos-chave
- A duration mede a sensibilidade de um título a mudanças nas taxas de juros, o que é diferente da sua data de vencimento.
- Títulos com duration mais longa geralmente são mais sensíveis a mudanças nas taxas de juros do que títulos com duration mais curta.
- Os pagamentos de cupom de um título afetam a sua duration: pagamentos maiores e mais frequentes geralmente encurtam a duration em relação ao prazo de vencimento.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Todos os valores são estimativas ilustrativas, não garantias. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
