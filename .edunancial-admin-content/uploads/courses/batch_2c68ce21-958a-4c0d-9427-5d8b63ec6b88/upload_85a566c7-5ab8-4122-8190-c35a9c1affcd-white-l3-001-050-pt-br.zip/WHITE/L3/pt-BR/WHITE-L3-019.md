---
id: WHITE-L3-019
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 19
title: "Por que os preços dos títulos e as taxas de juros se movem em direções opostas"
source_title: "Why Bond Prices and Interest Rates Move in Opposite Directions"
description: "Entenda o motivo mecânico pelo qual a alta das taxas de juros faz cair o preço dos títulos de renda fixa já existentes, e por que essa relação é previsível, e não aleatória."
slug: white-l3-019-bond-prices-and-rates
seo_title: "Por que os preços dos títulos e as taxas de juros se movem em direções opostas | Edunancial"
meta_description: "Entenda o motivo mecânico pelo qual a alta das taxas de juros faz cair o preço dos títulos de renda fixa já existentes, e por que essa relação é previsível, e não aleatória."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-019: Por que os preços dos títulos e as taxas de juros se movem em direções opostas

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar por que os preços dos títulos caem quando as taxas de juros sobem
- Explicar por que os preços dos títulos sobem quando as taxas de juros caem
- Explicar por que essa relação é uma questão de comparação, e não de risco específico da empresa

## Conteúdo principal

Os títulos de renda fixa pagam uma taxa de juros fixa (o cupom), definida quando são emitidos. Mas as taxas de juros do mercado em geral mudam com o tempo. Este é o "porquê" de isso criar uma relação previsível e inversa entre os preços dos títulos já existentes e as taxas de juros atuais: os pagamentos fixos de um título já existente ficam mais ou menos atraentes dependendo do que os títulos novos estão oferecendo no momento.

Se as taxas de juros sobem depois que um título é emitido, os títulos novos chegam oferecendo pagamentos fixos mais altos do que a taxa fixa do título mais antigo, o que torna o título mais antigo, que paga menos, menos atraente em comparação. Para que o título mais antigo continue competitivo para um possível comprador, o seu preço precisa cair, o que na prática aumenta o seu rendimento (o retorno em relação ao preço) para acompanhar as condições atuais do mercado. O inverso acontece se as taxas de juros caem: os pagamentos fixos relativamente mais altos do título mais antigo parecem mais atraentes do que o que está disponível agora, então o seu preço sobe.

[VERIFIED FACT] Essa relação se aplica ao preço de um título se ele for vendido antes do vencimento; um investidor que mantém um título até o vencimento continua recebendo os pagamentos fixos originais e a devolução do valor principal, como prometido (supondo que não haja calote), não importa o que aconteça com as taxas de juros ou com o preço do título nesse meio-tempo.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora tem um título que paga uma taxa fixa de 3%. Depois, as taxas de juros do mercado em geral sobem, e títulos novos e parecidos passam a oferecer 5%. Se ela quisesse vender seu título de 3% antes do vencimento, precisaria oferecê-lo por um preço menor do que pagou, já que, caso contrário, um comprador poderia simplesmente comprar um título novo de 5%; é o ajuste de preço que torna o título mais antigo dela, que paga menos, competitivo de novo. Se, em vez disso, ela mantiver o título até o vencimento, continuará recebendo os pagamentos originais de 3% e terá o seu principal de volta, como prometido, sem ser afetada pelo que aconteceu com as taxas vigentes nesse meio-tempo.

## Teste de prática

1. Por que o preço de um título cai quando as taxas de juros sobem?
2. Por que o preço de um título sobe quando as taxas de juros caem?
3. Essa relação de preços afeta um investidor que mantém um título até o vencimento? Por quê?

## Gabarito

1. Porque os títulos novos passam a oferecer pagamentos fixos mais altos, o que torna o título mais antigo, que paga menos, menos atraente, a menos que o seu preço caia para tornar o seu rendimento efetivo competitivo.
2. Porque os pagamentos fixos relativamente mais altos do título mais antigo ficam mais atraentes do que as taxas mais baixas disponíveis agora, aumentando a procura por ele e empurrando o seu preço para cima.
3. Não, em termos dos pagamentos prometidos: um investidor que mantém o título até o vencimento continua recebendo os pagamentos fixos originais e o principal, como prometido (supondo que não haja calote), apesar das oscilações de preço ao longo do caminho.

## Respostas e explicações

1. Este é o mecanismo central que explica a relação inversa.
2. Isto confirma o entendimento da relação na direção oposta.
3. Este é um esclarecimento importante que diferencia o risco de preço de mercado das condições contratuais de pagamento do título.

## Pontos-chave
- Os preços dos títulos e as taxas de juros se movem em direções opostas: taxas em alta, preços dos títulos existentes em queda, e vice-versa.
- Isso acontece porque os pagamentos fixos dos títulos existentes ficam mais ou menos atraentes em comparação com as taxas disponíveis agora.
- Essa relação de preços afeta a venda de um título antes do vencimento; manter até o vencimento continua entregando os pagamentos originais prometidos, apesar das mudanças nas taxas ao longo do caminho.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Todos os valores são estimativas ilustrativas, não garantias. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
