---
id: WHITE-L3-020
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 20
title: "Por que o risco de crédito e o risco de taxa de juros são riscos diferentes dos títulos"
source_title: "Why Credit Risk and Interest Rate Risk Are Different Bond Risks"
description: "Entenda por que um título de renda fixa pode perder valor por dois motivos completamente diferentes, e por que entender qual deles está acontecendo muda a forma como você deve pensar a respeito."
slug: white-l3-020-credit-risk-vs-interest-rate-risk
seo_title: "Por que o risco de crédito e o risco de taxa de juros são riscos diferentes dos títulos | Edunancial"
meta_description: "Entenda por que um título de renda fixa pode perder valor por dois motivos completamente diferentes, e por que entender qual deles está acontecendo muda a forma como você deve pensar a respeito."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-020: Por que o risco de crédito e o risco de taxa de juros são riscos diferentes dos títulos

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Diferenciar o risco de crédito do risco de taxa de juros nos títulos de renda fixa
- Explicar por que esses dois riscos podem afetar o preço de um título de forma independente um do outro
- Explicar por que a classificação de risco (rating) de um título reflete principalmente o risco de crédito, e não o risco de taxa de juros

## Conteúdo principal

A Lição 19 explicou como os preços dos títulos se movem na direção oposta à das taxas de juros em geral; esse é o **risco de taxa de juros**, e ele se aplica a praticamente todos os títulos, até aos mais seguros. Existe um segundo risco, separado, que também afeta os preços dos títulos: o **risco de crédito**, ou seja, o risco de que o emissor do título não consiga fazer os pagamentos prometidos, por causa de problemas financeiros ou de calote.

Este é o "porquê" de ser importante mantê-los separados: o preço de um título pode cair porque as taxas de juros em geral subiram, sem nenhuma mudança na saúde financeira do emissor; isso é risco de taxa de juros, e afeta até os títulos dos emissores financeiramente mais sólidos. O preço de um título também pode cair porque o mercado ficou preocupado com a capacidade de pagamento daquele emissor específico, mesmo que as taxas de juros em geral não tenham se mexido; isso é risco de crédito, e é específico daquele emissor.

[VERIFIED FACT] As classificações de crédito dos títulos, atribuídas por agências de classificação de risco independentes, foram feitas para refletir o risco de crédito de um emissor, ou seja, a probabilidade de calote, e não a sensibilidade do título a mudanças nas taxas de juros; uma classificação de crédito muito alta (um sinal de baixo risco de crédito) ainda pode estar ligada a um título com risco de taxa de juros relevante, se ele tiver uma duration longa (Lição 18).

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Dois títulos têm queda de preço no mesmo período. O emissor do Título A continua financeiramente forte e sem mudanças, mas a queda aconteceu porque as taxas de juros em geral subiram: um evento puro de risco de taxa de juros. Enquanto isso, o emissor do Título B divulgou notícias financeiras preocupantes, que levantaram dúvidas reais sobre a sua capacidade de fazer pagamentos futuros: um evento de risco de crédito, que fez o preço cair independentemente do que as taxas de juros fizeram. [ASSUMPTION] Um investidor que confunda essas duas causas poderia supor, por engano, que a queda de preço do Título B é temporária e causada pelas taxas, como a do Título A, quando na verdade ela reflete um problema mais sério e específico do emissor.

## Teste de prática

1. Qual é a diferença entre o risco de crédito e o risco de taxa de juros nos títulos de renda fixa?
2. Por que o preço de um título pode cair por causa do risco de taxa de juros mesmo que a saúde financeira do emissor não tenha mudado?
3. O que a classificação de crédito de um título reflete principalmente, de acordo com esta lição?

## Gabarito

1. O risco de taxa de juros é o risco de mudanças de preço por causa dos movimentos das taxas de juros em geral, e afeta praticamente todos os títulos; o risco de crédito é o risco de que um emissor específico não consiga fazer os pagamentos prometidos, independentemente das taxas em geral.
2. Porque o risco de taxa de juros reflete como os pagamentos fixos de um título se comparam às taxas disponíveis agora no mercado, um fator totalmente separado da condição financeira do próprio emissor.
3. O risco de crédito do emissor, ou seja, a probabilidade de calote, e não a sensibilidade do título a mudanças nas taxas de juros.

## Respostas e explicações

1. Esta é a distinção central em torno da qual a lição foi construída.
2. Isto se liga diretamente ao mecanismo explicado na Lição 19.
3. Isto esclarece um ponto comum de confusão: um título com classificação alta ainda pode ter um risco de taxa de juros relevante.

## Pontos-chave
- O risco de taxa de juros afeta quase todos os títulos e é causado pelos movimentos das taxas em geral, independentemente da saúde financeira do emissor.
- O risco de crédito é específico de um emissor e reflete a chance de ele não fazer os pagamentos prometidos.
- As classificações de crédito dos títulos refletem especificamente o risco de crédito, e não a sensibilidade de um título a mudanças nas taxas de juros.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Todos os valores são estimativas ilustrativas, não garantias. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
