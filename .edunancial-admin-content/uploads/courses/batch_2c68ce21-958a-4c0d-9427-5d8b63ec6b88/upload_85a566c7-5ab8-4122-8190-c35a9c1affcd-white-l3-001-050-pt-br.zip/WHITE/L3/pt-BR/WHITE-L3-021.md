---
id: WHITE-L3-021
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 21
title: "Por que ETFs e fundos mútuos são diferentes em negociação, impostos e custo"
source_title: "Why ETFs and Mutual Funds Differ in Trading, Tax, and Cost"
description: "Entenda as diferenças práticas entre ETFs e fundos mútuos, e por que essas diferenças podem importar mais do que as semelhanças gerais entre eles."
slug: white-l3-021-etf-vs-mutual-fund
seo_title: "Por que ETFs e fundos mútuos são diferentes em negociação, impostos e custo | Edunancial"
meta_description: "Entenda as diferenças práticas entre ETFs e fundos mútuos, e por que essas diferenças podem importar mais do que as semelhanças gerais entre eles."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-021: Por que ETFs e fundos mútuos são diferentes em negociação, impostos e custo

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar como ETFs e fundos mútuos se diferenciam na forma de negociação
- Explicar por que os ETFs muitas vezes são mais eficientes em impostos do que fundos mútuos comparáveis
- Explicar por que as estruturas de custo podem ser diferentes entre os dois

## Conteúdo principal

Tanto os **ETFs (exchange-traded funds, ou fundos negociados em bolsa)** quanto os **fundos mútuos** (mutual funds, fundos de investimento tradicionais dos EUA) reúnem o dinheiro dos investidores em uma cesta diversificada de títulos e valores mobiliários, e os dois podem seguir estratégias ou índices parecidos; mas eles se diferenciam em alguns pontos práticos que vale a pena entender.

Este é o "porquê" de a negociação ser diferente: os ETFs são negociados ao longo do dia em uma bolsa, como ações individuais, a preços que oscilam continuamente de acordo com a atividade do mercado. Os fundos mútuos normalmente têm preço calculado e são negociados só uma vez por dia, depois do fechamento do mercado, pelo valor patrimonial líquido calculado naquele dia; você não sabe o preço exato de execução quando faz uma ordem de fundo mútuo durante o pregão.

[VERIFIED FACT] Os ETFs também costumam ser mais eficientes em impostos do que fundos mútuos comparáveis, em grande parte por causa de um mecanismo estrutural na forma como as cotas de ETF são criadas e resgatadas, que tende a gerar menos distribuições tributáveis de ganhos de capital para os cotistas do que o processo usado por muitos fundos mútuos; mas isso varia de fundo para fundo e não é automático para todo ETF.

As estruturas de custo também podem ser diferentes: muitos ETFs, principalmente os que seguem índices amplos, tendem a ter taxas de administração (expense ratios) menores do que os fundos mútuos de gestão ativa, embora também existam fundos mútuos de índice de baixo custo; o custo deve ser comparado fundo a fundo, em vez de ser presumido apenas pelo tipo de estrutura.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora quer comprar cotas de um fundo de índice do S&P 500 (índice das 500 grandes empresas dos EUA). Se escolher a versão ETF, ela pode fazer uma ordem durante o horário do pregão e ver o preço executado na hora, como na compra de uma ação. Se escolher a versão fundo mútuo, a ordem dela é executada pelo valor patrimonial líquido do fundo calculado depois do fechamento do mercado naquele dia; ela só vai saber o preço exato depois que o pregão terminar. [ASSUMPTION] Ao longo de vários anos, se a versão ETF por acaso gerar menos distribuições tributáveis de ganhos de capital por causa do seu mecanismo estrutural, quem investe no ETF pode acabar com um retorno depois dos impostos um pouco melhor, mesmo que os ativos dos fundos e o desempenho antes dos impostos sejam muito parecidos.

## Teste de prática

1. Como a negociação de ETFs é diferente da negociação de fundos mútuos ao longo do dia?
2. Por que os ETFs muitas vezes são mais eficientes em impostos do que fundos mútuos comparáveis?
3. É correto presumir que todos os ETFs são mais baratos do que todos os fundos mútuos? Por quê?

## Gabarito

1. Os ETFs são negociados ao longo do dia, a preços que oscilam continuamente, como ações; os fundos mútuos normalmente têm preço calculado e são negociados uma vez por dia, depois do fechamento do mercado, pelo valor patrimonial líquido daquele dia.
2. Em grande parte por causa de um mecanismo estrutural na forma como as cotas de ETF são criadas e resgatadas, que tende a gerar menos distribuições tributáveis de ganhos de capital do que os processos de muitos fundos mútuos.
3. Não: embora os ETFs e os fundos de índice em geral tendam a ter custos menores do que os fundos de gestão ativa, também existem fundos mútuos de índice de baixo custo, então o custo deve ser comparado fundo a fundo, em vez de ser presumido apenas pelo tipo de estrutura.

## Respostas e explicações

1. Esta é a principal diferença estrutural entre os dois tipos de fundo.
2. Este é o mecanismo central de eficiência tributária, com a devida ressalva de que não é automático para todo ETF.
3. Isto corrige uma generalização simplista sobre custo que nem sempre é verdadeira.

## Pontos-chave
- Os ETFs são negociados ao longo do dia, como ações; os fundos mútuos são negociados uma vez por dia, por um valor patrimonial líquido calculado.
- Os ETFs muitas vezes, mas nem sempre, são mais eficientes em impostos por causa da sua estrutura de criação e resgate de cotas.
- O custo deve ser comparado fundo a fundo, já que existem opções de baixo custo tanto entre ETFs quanto entre fundos mútuos.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
