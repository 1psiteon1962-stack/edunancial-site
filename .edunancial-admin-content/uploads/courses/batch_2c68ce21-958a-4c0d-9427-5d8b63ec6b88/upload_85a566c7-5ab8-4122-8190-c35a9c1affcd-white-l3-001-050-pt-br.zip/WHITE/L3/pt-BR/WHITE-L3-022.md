---
id: WHITE-L3-022
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 22
title: "Por que as taxas de administração se acumulam ao longo de décadas"
source_title: "Why Expense Ratios Compound Over Decades"
description: "Entenda por que uma taxa anual de fundo que parece pequena pode custar dezenas de milhares de dólares em um horizonte de investimento longo, e por que é fácil subestimar esse efeito."
slug: white-l3-022-expense-ratios-compound
seo_title: "Por que as taxas de administração se acumulam ao longo de décadas | Edunancial"
meta_description: "Entenda por que uma taxa anual de fundo que parece pequena pode custar dezenas de milhares de dólares em um horizonte de investimento longo, e por que é fácil subestimar esse efeito."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-022: Por que as taxas de administração se acumulam ao longo de décadas

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o que é a taxa de administração (expense ratio) de um fundo
- Explicar por que uma pequena diferença percentual nas taxas se transforma, com os juros compostos, em uma grande diferença em dólares ao longo de décadas
- Explicar por que as taxas são uma das poucas variáveis de investimento que o investidor pode controlar totalmente

## Conteúdo principal

A **taxa de administração** (em inglês, expense ratio) é a taxa anual que um fundo cobra, expressa como porcentagem do valor investido; por exemplo, uma taxa de 1% significa $10 por ano para cada $1,000 investidos. Sozinho, o número 1% parece pequeno. Este é o "porquê" de não ser: essa taxa é cobrada todo ano, e não uma vez só, e ela reduz o dinheiro que está rendendo juros compostos a seu favor durante todo o tempo em que você fica com o fundo.

[ILLUSTRATIVE EXAMPLE] Ao comparar dois fundos com desempenho idêntico antes das taxas, um cobrando 0.05% e outro cobrando 1%, em um período de várias décadas, a diferença nas taxas se acumula em uma distância grande no valor final da conta, já que o fundo de taxa mais alta, na prática, rende um pouco menos todos os anos, e essa diferença se acumula contra você do mesmo jeito que os retornos se acumulam a seu favor.

É por isso que muitos investidores experientes prestam muita atenção especificamente às taxas dos fundos: ao contrário dos retornos futuros do mercado, que ninguém pode controlar nem prever, a taxa que você paga é conhecida de antemão e está totalmente sob o seu controle, pela escolha do fundo em que você investe. [VERIFIED FACT] Com todo o resto igual, uma taxa de administração menor aumenta diretamente o seu retorno líquido, embora as taxas devam ser avaliadas junto com outros fatores relevantes, como a estratégia do fundo, os seus ativos e a sua eficiência tributária (Lição 21), e não de forma completamente isolada.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Um investidor coloca $10,000 em um fundo e não acrescenta mais nada, e uma versão de baixo custo e outra de custo mais alto desse fundo têm, por acaso, retornos idênticos antes das taxas, ao longo de um período de 30 anos. [ASSUMPTION] Mesmo uma diferença aparentemente modesta de 0.95 ponto percentual nas taxas anuais, acumulada ao longo de 30 anos, poderia resultar em um saldo final bem menor no fundo de taxa mais alta; possivelmente uma diferença grande o bastante para representar anos de renda na aposentadoria, o que mostra como uma pequena porcentagem anual se torna um valor absoluto significativo em dólares em um horizonte longo o suficiente.

## Teste de prática

1. O que a taxa de administração representa?
2. Por que uma pequena diferença percentual nas taxas importa tanto em um período de várias décadas?
3. Por que muitos investidores experientes prestam atenção especial às taxas, em comparação com outros fatores de investimento?

## Gabarito

1. A taxa anual que um fundo cobra, expressa como porcentagem do valor investido.
2. Porque a taxa é cobrada todo ano e reduz o valor que rende juros compostos ao longo do tempo, e essa diferença se acumula contra o investidor do mesmo jeito que os retornos se acumulam a favor dele.
3. Porque as taxas são conhecidas de antemão e estão totalmente sob o controle do investidor, ao contrário dos retornos futuros do mercado, que não podem ser previstos nem controlados.

## Respostas e explicações

1. Esta é a base de definição da lição.
2. Esta é a ideia central sobre juros compostos em torno da qual a lição foi construída.
3. Isto reforça por que ficar atento às taxas é uma alavanca de investimento que, de forma única, você pode controlar.

## Pontos-chave
- A taxa de administração é uma taxa anual cobrada como porcentagem do valor investido.
- Mesmo uma pequena diferença percentual nas taxas se transforma em uma grande diferença em dólares em um período de várias décadas.
- As taxas são um dos poucos fatores de investimento totalmente sob o controle do investidor, por isso merecem muita atenção.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Todos os valores são estimativas ilustrativas, não garantias. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
