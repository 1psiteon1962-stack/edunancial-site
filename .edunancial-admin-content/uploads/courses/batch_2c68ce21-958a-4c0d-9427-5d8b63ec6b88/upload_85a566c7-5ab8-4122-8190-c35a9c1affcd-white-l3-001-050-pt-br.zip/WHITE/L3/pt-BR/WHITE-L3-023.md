---
id: WHITE-L3-023
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 23
title: "Por que investir em índices é apostar no mercado, e não em um gestor"
source_title: "Why Index Investing Bets on the Market, Not a Manager"
description: "Entenda em que investir em índices realmente aposta, e por que essa é uma aposta fundamentalmente diferente de escolher ações individuais ou gestores de fundos ativos."
slug: white-l3-023-index-investing
seo_title: "Por que investir em índices é apostar no mercado, e não em um gestor | Edunancial"
meta_description: "Entenda em que investir em índices realmente aposta, e por que essa é uma aposta fundamentalmente diferente de escolher ações individuais ou gestores de fundos ativos."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-023: Por que investir em índices é apostar no mercado, e não em um gestor

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o que um fundo de índice faz
- Explicar a aposta específica que um investidor em índices está fazendo, em comparação com um investidor ativo
- Explicar por que essa abordagem elimina o risco de escolha do gestor

## Conteúdo principal

Um **fundo de índice** foi feito para acompanhar um índice de mercado específico (como um índice amplo do mercado de ações), mantendo os mesmos títulos e valores mobiliários, mais ou menos nas mesmas proporções, que esse índice, em vez de ter um gestor escolhendo ativamente quais títulos comprar ou vender na tentativa de superar o índice.

Este é o "porquê" de isso representar uma aposta fundamentalmente diferente: um investidor em índices não está apostando em nenhuma empresa individual, nem na habilidade de nenhum gestor de fundos específico em escolher ações; ele está apostando no crescimento geral do mercado mais amplo (ou do segmento de mercado) que o índice representa, no longo prazo. Isso elimina uma camada inteira de risco que o investimento ativo carrega: o risco de que as ações que você escolheu, ou as escolhas do gestor que você escolheu, tenham desempenho pior do que o mercado como um todo.

[VERIFIED FACT] Isso não significa que investir em índices elimina todo o risco: os fundos de índice continuam tendo o risco de o próprio mercado mais amplo cair, já que foram feitos especificamente para se mover junto com esse mercado, e não para proteger contra as suas quedas.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora que escolhe um fundo de gestão ativa está, implicitamente, apostando que o gestor do fundo consegue escolher ativos individuais que, juntos, superem o mercado mais amplo depois das taxas; uma aposta na habilidade e nas decisões daquele gestor específico. Uma investidora que escolhe, em vez disso, um fundo de índice amplo do mercado está apostando que o mercado como um todo vai crescer com o tempo, sem precisar identificar quais empresas específicas ou qual gestor específico fará as escolhas. [ASSUMPTION] Se o mercado mais amplo subir durante o período em que ela mantém o investimento, a investidora em índices participa desse crescimento, sejam quais forem as empresas individuais que o impulsionaram; ela não precisa ter identificado corretamente os vencedores específicos com antecedência.

## Teste de prática

1. O que um fundo de índice tenta fazer?
2. Que aposta específica um investidor em índices está fazendo, em comparação com um investidor em fundos ativos?
3. Investir em índices elimina totalmente o risco do investimento? Por quê?

## Gabarito

1. Acompanhar um índice de mercado específico, mantendo os mesmos títulos e valores mobiliários mais ou menos nas mesmas proporções, em vez de ter um gestor escolhendo ativamente os ativos.
2. Uma aposta no crescimento geral do mercado mais amplo ou de um segmento de mercado, e não uma aposta na habilidade de algum gestor ou investidor específico em escolher ações.
3. Não: os fundos de índice continuam tendo o risco de queda do mercado mais amplo, já que foram feitos para acompanhar o movimento desse mercado, e não para proteger contra as suas quedas.

## Respostas e explicações

1. Esta é a definição básica da lição.
2. Esta é a distinção conceitual central entre investir em índices e investir de forma ativa.
3. Este é um esclarecimento importante contra a ideia equivocada e simplista de que "fundos de índice não têm risco".

## Pontos-chave
- Os fundos de índice acompanham um índice de mercado, em vez de depender da escolha ativa de ações por um gestor.
- Investir em índices é apostar no crescimento do mercado mais amplo como um todo, e não na habilidade de um gestor individual ou na escolha de ações.
- Os fundos de índice continuam tendo risco de mercado: eles se movem junto com o mercado, inclusive nas quedas.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
