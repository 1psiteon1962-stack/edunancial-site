---
id: WHITE-L3-024
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 24
title: "Por que a gestão ativa precisa superar as próprias taxas para agregar valor"
source_title: "Why Active Management Has to Overcome Its Own Fees to Add Value"
description: "Entenda por que um fundo de gestão ativa precisa superar o mercado por mais do que uma pequena margem para realmente entregar um resultado melhor do que um fundo de índice de baixo custo."
slug: white-l3-024-active-management-vs-fees
seo_title: "Por que a gestão ativa precisa superar as próprias taxas para agregar valor | Edunancial"
meta_description: "Entenda por que um fundo de gestão ativa precisa superar o mercado por mais do que uma pequena margem para realmente entregar um resultado melhor do que um fundo de índice de baixo custo."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-024: Por que a gestão ativa precisa superar as próprias taxas para agregar valor

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar por que superar o mercado antes das taxas não é o mesmo que superá-lo depois das taxas
- Explicar por que a gestão ativa tem uma barreira de desempenho embutida em comparação com os fundos de índice
- Explicar por que essa barreira se acumula com o tempo, de forma parecida com o efeito da taxa de administração da Lição 22

## Conteúdo principal

A Lição 22 mostrou como as taxas se acumulam contra o investidor com o tempo. Este é o "porquê" de isso criar um desafio específico para os fundos de gestão ativa: como os fundos ativos geralmente cobram taxas mais altas do que os fundos de índice (Lição 21), o gestor não precisa apenas escolher investimentos que superem o mercado; ele precisa superá-lo por uma margem suficiente para cobrir essa diferença de taxas, ou o investidor acaba em pior situação do que se simplesmente tivesse um fundo de índice de baixo custo, mesmo que as escolhas do gestor tecnicamente "superem o mercado" antes das taxas.

[VERIFIED FACT] Superar o mercado de forma consistente, depois das taxas, por longos períodos, historicamente se mostrou difícil para o fundo de gestão ativa médio, com base em estudos que comparam o desempenho de fundos ativos com os índices de referência relevantes em períodos de vários anos; embora fundos e gestores individuais possam superar o mercado, e de fato superem, em períodos específicos, e os resultados variem conforme o fundo, a estratégia e o período.

É por isso que a comparação para avaliar um fundo ativo não deveria ser "o gestor escolheu bons investimentos?", e sim "as escolhas do gestor superaram o mercado por uma margem suficiente para vencer a diferença de taxas em relação a uma alternativa de índice comparável e de baixo custo?"; uma barreira bem mais alta do que simplesmente superar o mercado.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Um fundo de gestão ativa cobra uma taxa de administração de 1.2%; um fundo de índice comparável cobra 0.05%, uma diferença de cerca de 1.15 ponto percentual por ano. Se as escolhas de ações do fundo ativo superarem o índice em 0.8% antes das taxas em determinado ano, o fundo ainda assim teve desempenho pior do que a alternativa de índice de baixo custo depois de descontadas as taxas, porque o desempenho superior do gestor não foi grande o bastante para cobrir a diferença de taxas. [ASSUMPTION] Ao longo de muitos anos, um fundo ativo precisaria superar o mercado de forma consistente por mais do que essa diferença de taxas, e não só de vez em quando ou por uma pequena margem, para realmente agregar valor líquido em comparação com a alternativa de índice.

## Teste de prática

1. Por que superar o mercado antes das taxas não é o mesmo que superá-lo depois das taxas?
2. Que barreira de desempenho específica o gestor de um fundo ativo precisa ultrapassar para agregar valor em comparação com um fundo de índice comparável?
3. O que as pesquisas históricas geralmente descobriram sobre a capacidade do fundo de gestão ativa médio de ultrapassar essa barreira de forma consistente por longos períodos?

## Gabarito

1. Porque as taxas mais altas do fundo são descontadas dos retornos, então o desempenho superior antes das taxas pode ser anulado, total ou parcialmente, pela diferença de taxas em relação a uma alternativa de índice de custo mais baixo.
2. Superar o mercado por mais do que a diferença de taxas entre o fundo ativo e um fundo de índice comparável de baixo custo, e não apenas superar o mercado.
3. Que fazer isso de forma consistente, por longos períodos, historicamente se mostrou difícil para o fundo de gestão ativa médio, embora os resultados variem conforme o fundo, a estratégia e o período específicos.

## Respostas e explicações

1. Esta é a distinção central em torno da qual a lição foi construída.
2. Isto redefine o critério de avaliação da gestão ativa de uma forma mais precisa e útil.
3. Isto oferece um contexto das pesquisas históricas com a devida cautela, sem exagerar como se fosse uma regra universal.

## Pontos-chave
- As taxas mais altas da gestão ativa criam uma barreira de desempenho embutida em comparação com o investimento em índices de custo mais baixo.
- Um gestor precisa superar o mercado por mais do que essa diferença de taxas, e não apenas superar o mercado, para agregar valor líquido.
- Historicamente, o fundo de gestão ativa médio teve dificuldade para fazer isso de forma consistente por longos períodos, embora os resultados individuais variem.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Desempenho passado não garante resultados futuros. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
