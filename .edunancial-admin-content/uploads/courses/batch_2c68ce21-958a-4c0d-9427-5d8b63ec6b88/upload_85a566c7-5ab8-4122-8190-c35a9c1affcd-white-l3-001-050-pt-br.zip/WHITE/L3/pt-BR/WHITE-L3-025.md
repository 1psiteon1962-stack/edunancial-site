---
id: WHITE-L3-025
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 25
title: "Por que o desempenho passado de um fundo não prevê o desempenho futuro"
source_title: "Why Past Fund Performance Doesn't Predict Future Performance"
description: "Entenda por que um histórico recente forte de um fundo não é um sinal confiável de como ele vai se sair daqui para frente."
slug: white-l3-025-past-performance-not-predictive
seo_title: "Por que o desempenho passado de um fundo não prevê o desempenho futuro | Edunancial"
meta_description: "Entenda por que um histórico recente forte de um fundo não é um sinal confiável de como ele vai se sair daqui para frente."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-025: Por que o desempenho passado de um fundo não prevê o desempenho futuro

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar por que o desempenho passado de um fundo tem valor limitado para prever o desempenho futuro
- Explicar o que significa "perseguir desempenho" e por que isso pode prejudicar os retornos
- Explicar por que esse conceito se liga ao viés de recência, discutido mais adiante nesta trilha

## Conteúdo principal

É intuitivo supor que um fundo que foi bem recentemente provavelmente vai continuar indo bem; afinal, ele deve estar fazendo algo certo. Este é o "porquê" de essa intuição muitas vezes não se sustentar: [VERIFIED FACT] pesquisas extensas que comparam as posições dos fundos nos rankings de desempenho histórico em diferentes períodos geralmente encontraram uma persistência fraca; ou seja, os fundos com melhor desempenho em um período não são, de forma confiável, os melhores no período seguinte, e esse padrão já foi observado pelos órgãos reguladores, o que é parte do motivo pelo qual os avisos padronizados incluem a frase de que desempenho passado não garante resultados futuros.

Vários fatores contribuem para essa persistência fraca: um desempenho recente forte pode refletir um ambiente temporariamente favorável ao estilo ou ao setor específico daquele fundo, e não uma vantagem de habilidade que possa se repetir; estratégias ou setores que vão bem muitas vezes veem as condições mudarem ou ficarem mais concorridas, o que reduz a vantagem futura; e mudanças de gestor, o crescimento do patrimônio do fundo e outros fatores podem afetar os resultados futuros de um fundo, independentemente do seu histórico.

É por isso que correr atrás dos campeões recentes, colocando dinheiro no fundo que foi melhor recentemente, costuma ser chamado de **perseguir desempenho** (performance chasing), e pode levar os investidores a comprar sistematicamente depois de fortes altas (possivelmente perto de um pico) e vender depois de períodos decepcionantes (possivelmente perto de um fundo), o que se liga a uma versão, no nível dos fundos, do erro de "comprar na alta, vender na baixa" discutido no começo desta trilha.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Um investidor percebe que um fundo teve os melhores retornos da sua categoria nos últimos três anos e decide investir pesado com base nesse histórico. [ASSUMPTION] Se o desempenho forte desse fundo foi impulsionado principalmente por um ambiente temporariamente favorável ao seu estilo de investimento específico, e esse ambiente mudar nos anos seguintes, o fundo pode ter desempenho pior daqui para frente, deixando o investidor com uma experiência decepcionante, apesar de ter escolhido com base em um histórico que parecia impressionante.

## Teste de prática

1. O que as pesquisas geralmente descobriram sobre a persistência do melhor desempenho de fundos em diferentes períodos?
2. O que é "perseguir desempenho", e por que isso pode ser um problema?
3. Por que um desempenho recente forte pode refletir um ambiente temporário, e não uma habilidade do gestor que possa se repetir?

## Gabarito

1. Uma persistência geralmente fraca: os melhores em um período não são, de forma confiável, os melhores no período seguinte.
2. Colocar dinheiro nos fundos que tiveram o melhor desempenho recente; isso pode levar a comprar depois que uma forte alta já aconteceu e a vender depois de um período fraco, possivelmente perto de um pico e de um fundo, respectivamente.
3. Porque o estilo de investimento ou o foco setorial específico de um fundo pode simplesmente ter sido favorecido pelas condições daquele período, e não porque o gestor demonstrou uma vantagem de habilidade repetível e com chance de continuar.

## Respostas e explicações

1. Esta é a descoberta central de pesquisa em torno da qual a lição foi construída.
2. Isto define e explica o padrão de comportamento arriscado contra o qual a lição alerta.
3. Isto explica o motivo por trás da persistência de desempenho muitas vezes fraca.

## Pontos-chave
- O desempenho passado dos fundos geralmente mostrou valor fraco para prever o desempenho futuro, segundo as pesquisas disponíveis.
- Perseguir desempenho, ou seja, comprar os fundos com melhor desempenho recente, pode levar a uma versão, no nível dos fundos, de comprar na alta e vender na baixa.
- Um desempenho recente forte pode refletir condições temporariamente favoráveis, e não uma vantagem de habilidade do gestor que possa se repetir.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Desempenho passado não garante resultados futuros. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
