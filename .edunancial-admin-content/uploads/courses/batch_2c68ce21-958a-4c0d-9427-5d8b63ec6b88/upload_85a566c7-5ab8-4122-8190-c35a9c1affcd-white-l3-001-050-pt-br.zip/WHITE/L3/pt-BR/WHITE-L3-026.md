---
id: WHITE-L3-026
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 26
title: "Por que os vieses comportamentais custam mais aos investidores do que as taxas"
source_title: "Why Behavioral Biases Cost Investors More Than Fees Do"
description: "Entenda por que a psicologia do investidor, e não só as taxas dos fundos, costuma ser apontada como um dos maiores freios aos retornos reais dos investimentos."
slug: white-l3-026-behavioral-biases-cost
seo_title: "Por que os vieses comportamentais custam mais aos investidores do que as taxas | Edunancial"
meta_description: "Entenda por que a psicologia do investidor, e não só as taxas dos fundos, costuma ser apontada como um dos maiores freios aos retornos reais dos investimentos."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-026: Por que os vieses comportamentais custam mais aos investidores do que as taxas

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o que é o "behavior gap" (lacuna de comportamento) nos investimentos
- Explicar por que o comportamento do investidor pode custar mais do que as taxas, com base nesta lição
- Ter uma prévia dos vieses específicos tratados nas próximas duas lições

## Conteúdo principal

A Lição 22 mostrou como as taxas se acumulam contra os retornos. Esta lição apresenta um freio relacionado, e em algumas análises até maior, sobre os retornos reais dos investidores: o próprio comportamento.

O **behavior gap** (lacuna de comportamento) é a diferença entre o retorno que um investimento (como um fundo ou o mercado como um todo) realmente gera e o retorno que o investidor médio nesse mesmo investimento realmente obtém. [VERIFIED FACT] Vários estudos do setor que analisaram essa lacuna constataram que o retorno do investidor médio muitas vezes fica abaixo do retorno do próprio investimento, algo atribuído em grande parte a compras e vendas mal cronometradas, movidas por reações emocionais aos movimentos do mercado: comprar depois que um fundo ou o mercado já subiu (a busca por desempenho, Lição 25) e vender depois que ele já caiu (ecoando o desafio central da Lição 1).

Veja o "porquê" disso importar mais do que uma simples comparação de taxas: um fundo com taxa de administração (expense ratio) baixa não protege o investidor dessa lacuna de comportamento. Um investidor que vende em pânico durante uma queda e volta a comprar depois que a recuperação já começou pode ter um desempenho bem pior do que o retorno divulgado pelo próprio fundo, por mais baixas que sejam as taxas desse fundo.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Um fundo de índice amplo de mercado divulga um retorno médio anual forte ao longo de um período de 20 anos. [ASSUMPTION] Estudos sobre o comportamento do investidor médio nesse mesmo fundo, porém, podem mostrar que os investidores, como grupo, obtiveram um retorno médio bem menor no mesmo período. Isso não acontece porque o fundo teve um desempenho diferente para investidores diferentes, e sim porque muitos investidores colocaram e tiraram dinheiro em momentos desfavoráveis: perderam alguns dos melhores dias do fundo por estarem fora do mercado durante as recuperações e pegaram mais dos piores dias por estarem investidos durante as quedas.

## Teste de prática

1. O que é o "behavior gap" (lacuna de comportamento)?
2. Por que um fundo com taxas baixas ainda pode gerar um resultado ruim, na vida real, para um investidor?
3. Quais são os dois comportamentos específicos que esta lição aponta como causas comuns da lacuna de comportamento?

## Gabarito

1. A diferença entre o retorno divulgado de um investimento e o retorno que o investidor médio nesse investimento realmente obtém.
2. Porque as taxas baixas do fundo não protegem contra compras e vendas mal cronometradas, movidas por reações emocionais aos movimentos do mercado. O comportamento, e não as taxas, pode ser o maior freio sobre os resultados reais.
3. Comprar depois que um fundo ou o mercado já subiu (busca por desempenho) e vender depois que ele já caiu, levado por reações emocionais em vez de um plano consistente.

## Respostas e explicações

1. Esta é a definição fundamental da lição.
2. Esta é a ideia central que diferencia a lacuna de comportamento do custo das taxas visto na Lição 22.
3. Isto antecipa os vieses específicos explorados com mais profundidade nas próximas duas lições.

## Pontos-chave
- A lacuna de comportamento descreve a diferença entre o retorno real de um investimento e o que o investidor médio nele realmente ganha.
- Estudos em geral constataram que essa lacuna costuma ser atribuída a compras e vendas mal cronometradas, movidas por reações emocionais.
- Taxas baixas, sozinhas, não protegem contra essa lacuna: o comportamento do investidor pode ser um freio tão grande ou maior sobre os retornos reais.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Desempenho passado não garante resultados futuros. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
