---
id: WHITE-L3-027
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 27
title: "Por que a aversão à perda faz os investidores venderem os vencedores cedo demais e segurarem os perdedores por tempo demais"
source_title: "Why Loss Aversion Makes Investors Sell Winners Too Early and Hold Losers Too Long"
description: "Entenda por que a dor de uma perda costuma ser mais forte do que o prazer de um ganho equivalente, e como esse desequilíbrio distorce as decisões de investimento."
slug: white-l3-027-loss-aversion
seo_title: "Por que a aversão à perda faz os investidores venderem os vencedores cedo demais e segurarem os perdedores por tempo demais | Edunancial"
meta_description: "Entenda por que a dor de uma perda costuma ser mais forte do que o prazer de um ganho equivalente, e como esse desequilíbrio distorce as decisões de investimento."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-027: Por que a aversão à perda faz os investidores venderem os vencedores cedo demais e segurarem os perdedores por tempo demais

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Definir aversão à perda
- Explicar o "efeito disposição" e como ele resulta da aversão à perda
- Explicar por que esse padrão pode prejudicar sistematicamente os retornos de longo prazo

## Conteúdo principal

A **aversão à perda** descreve um padrão de comportamento bem documentado: para a maioria das pessoas, a dor emocional de perder uma certa quantia de dinheiro costuma ser mais forte do que o prazer emocional de ganhar essa mesma quantia. Essa assimetria, embora seja uma parte normal da psicologia humana, pode distorcer as decisões de investimento de um jeito específico e previsível.

Veja o "porquê" disso levar a um erro comum chamado **efeito disposição**: investidores influenciados pela aversão à perda tendem a vender investimentos vencedores cedo demais, garantindo um ganho modesto para "se sentir bem" e evitar o risco de esse ganho desaparecer, enquanto seguram investimentos perdedores por muito mais tempo do que os fundamentos justificariam, na esperança de evitar "realizar" a perda simplesmente não vendendo, mesmo quando as perspectivas do investimento realmente pioraram.

[VERIFIED FACT] Esse padrão foi documentado em grandes conjuntos de dados reais de negociação de investidores, que mostram uma tendência geral de vender os vencedores com mais frequência do que os perdedores, em relação ao desempenho real de cada posição. É um padrão que, se seguido de forma consistente, pode prejudicar sistematicamente os retornos de longo prazo, ao cortar cedo as posições vencedoras e deixar as perdedoras seguirem caindo.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora tem duas posições: uma subiu 15%, a outra caiu 15%. Influenciada pela aversão à perda, ela vende a posição vencedora para "garantir" o ganho e sentir que conquistou algo, enquanto segura a posição perdedora, dizendo a si mesma que vai vender quando ela "voltar ao zero a zero", para não ter que aceitar a perda. [ASSUMPTION] Se a posição vencedora continuar indo bem depois que ela vendeu, e a perdedora continuar caindo enquanto ela espera uma recuperação que talvez nunca venha, esse padrão (movido pela assimetria emocional da aversão à perda, e não pelas perspectivas reais de cada investimento) terá custado mais a ela do que uma decisão baseada apenas nos fundamentos de cada posição.

## Teste de prática

1. O que a aversão à perda descreve?
2. O que é o "efeito disposição" e como ele resulta da aversão à perda?
3. Por que seguir esse padrão de forma consistente pode prejudicar os retornos de longo prazo?

## Gabarito

1. A tendência de a dor emocional de uma perda ser mais forte do que o prazer emocional de um ganho equivalente.
2. A tendência de vender investimentos vencedores cedo demais (para garantir uma boa sensação) e segurar investimentos perdedores por tempo demais (para evitar o desconforto de realizar uma perda), uma consequência comportamental direta da aversão à perda.
3. Porque ele corta sistematicamente as posições vencedoras antes de elas completarem seu percurso e permite que as perdedoras continuem caindo, em vez de basear as decisões de venda nas perspectivas reais de cada investimento.

## Respostas e explicações

1. Este é o conceito psicológico fundamental da lição.
2. Este é o padrão de comportamento de investimento específico, com nome próprio, que resulta da aversão à perda.
3. Isto explica a consequência prática do padrão, que prejudica o retorno.

## Pontos-chave
- A aversão à perda descreve a tendência de as perdas doerem mais do que ganhos equivalentes dão prazer.
- Isso pode levar ao efeito disposição: vender os vencedores cedo demais e segurar os perdedores por tempo demais.
- Esse padrão, bem documentado em dados reais de negociação, pode prejudicar sistematicamente os retornos de longo prazo se seguido de forma consistente.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
