---
id: WHITE-L3-028
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 28
title: "Por que o viés de recência distorce a percepção de risco depois de um movimento do mercado"
source_title: "Why Recency Bias Distorts Risk Perception After a Market Move"
description: "Entenda por que os investidores tendem a dar peso demais aos acontecimentos recentes ao avaliar o risco, e por que isso pode levar a decisões em momentos ruins."
slug: white-l3-028-recency-bias
seo_title: "Por que o viés de recência distorce a percepção de risco depois de um movimento do mercado | Edunancial"
meta_description: "Entenda por que os investidores tendem a dar peso demais aos acontecimentos recentes ao avaliar o risco, e por que isso pode levar a decisões em momentos ruins."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-028: Por que o viés de recência distorce a percepção de risco depois de um movimento do mercado

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Definir viés de recência
- Explicar por que os acontecimentos recentes do mercado parecem prever o futuro mais do que realmente preveem
- Explicar como o viés de recência pode empurrar os investidores para decisões em momentos ruins, tanto em mercados em alta quanto em queda

## Conteúdo principal

O **viés de recência** descreve a tendência de dar mais peso aos acontecimentos recentes ao formar expectativas sobre o futuro do que um quadro histórico mais completo realmente justificaria.

Veja o "porquê" disso distorcer as decisões de investimento: depois de um longo período de fortes ganhos no mercado, o viés de recência pode fazer com que retornos fortes contínuos pareçam o estado normal e esperado das coisas, levando os investidores a assumir mais risco ou investir de forma mais agressiva justamente quando as condições podem estar mudando. Depois de uma longa queda, o mesmo viés pode fazer com que novas quedas pareçam inevitáveis, levando os investidores a vender ou a evitar investir justamente quando os padrões históricos (e a discussão da Lição 1 sobre pontos "baixos" que só parecem óbvios em retrospecto) podem sugerir que uma recuperação poderia vir mais cedo ou mais tarde.

[VERIFIED FACT] Esse viés é um padrão bem documentado na pesquisa comportamental, diferente de uma atualização racional das expectativas com base em informações realmente novas: o viés de recência dá peso demais especificamente ao padrão *mais recente*, em vez de considerar toda a gama de resultados históricos e suas diferentes probabilidades.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Depois de vários anos de ganhos fortes e constantes no mercado, um investidor passa a sentir que esse ritmo de crescimento é a expectativa normal daqui para frente, o que o leva a assumir mais risco de investimento do que pretendia no início. Depois de uma queda forte que vem em seguida, essa sensação se inverte: agora a queda recente parece que simplesmente vai continuar, o que o leva a vender perto do fundo e a evitar reinvestir mesmo quando as condições começam a se estabilizar. [ASSUMPTION] Nos dois casos, as expectativas dele foram moldadas de forma desproporcional pelo período mais recente, e não por uma perspectiva histórica mais completa de como os mercados se movimentaram ao longo de ciclos de alta e de baixa com o tempo.

## Teste de prática

1. O que o viés de recência descreve?
2. Como o viés de recência pode afetar o comportamento do investidor depois de um longo período de fortes ganhos no mercado?
3. Como o viés de recência pode afetar o comportamento do investidor depois de uma longa queda?

## Gabarito

1. A tendência de dar peso desproporcional aos acontecimentos recentes ao formar expectativas sobre o futuro, em comparação com um quadro histórico mais completo.
2. Ele pode fazer com que retornos fortes contínuos pareçam o estado normal esperado, levando os investidores a assumir mais risco justamente quando as condições podem estar mudando.
3. Ele pode fazer com que novas quedas pareçam inevitáveis, levando os investidores a vender ou evitar investir justamente quando os padrões históricos podem sugerir que uma recuperação poderia vir mais cedo ou mais tarde.

## Respostas e explicações

1. Esta é a definição fundamental da lição.
2. Isto aplica o viés ao cenário de alta, ligando-o ao excesso de risco assumido.
3. Isto aplica o viés ao cenário de queda, voltando ao desafio central da Lição 1.

## Pontos-chave
- O viés de recência dá peso desproporcional aos acontecimentos recentes ao formar expectativas sobre o futuro.
- Depois de ganhos fortes, ele pode levar a assumir risco demais; depois de quedas, pode levar a vender em momentos ruins.
- Esse viés dá peso demais ao padrão mais recente, em vez de considerar toda a gama do comportamento histórico do mercado.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Desempenho passado não garante resultados futuros. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
