---
id: WHITE-L3-029
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 29
title: "Por que a inflação corrói o poder de compra mesmo em uma carteira \"segura\""
source_title: "Why Inflation Erodes Purchasing Power Even in a \"Safe\" Portfolio"
description: "Entenda por que manter apenas ativos muito estáveis e de baixo retorno ainda pode fazer você perder poder de compra com o tempo, mesmo sem nenhuma perda no mercado."
slug: white-l3-029-inflation-and-safe-portfolios
seo_title: "Por que a inflação corrói o poder de compra mesmo em uma carteira \"segura\" | Edunancial"
meta_description: "Entenda por que manter apenas ativos muito estáveis e de baixo retorno ainda pode fazer você perder poder de compra com o tempo, mesmo sem nenhuma perda no mercado."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-029: Por que a inflação corrói o poder de compra mesmo em uma carteira "segura"

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar a diferença entre retorno nominal e retorno real (ajustado pela inflação)
- Explicar por que uma carteira "segura" e de baixo retorno ainda pode perder poder de compra com o tempo
- Ligar este conceito à discussão sobre moeda fiduciária tratada em outras partes deste currículo

## Conteúdo principal

O **retorno nominal** de um investimento é o seu ganho percentual declarado, sem ajuste pela inflação. O **retorno real** subtrai a inflação desse número nominal, mostrando a mudança efetiva no poder de compra. Essa distinção se liga diretamente à discussão sobre moeda fiduciária em outras partes deste currículo: se o poder de compra da moeda fiduciária tende a encolher com o tempo, um investimento que não supera esse encolhimento está perdendo valor real, mesmo que seu saldo nominal esteja tecnicamente crescendo ou se mantendo estável.

Veja o "porquê" de uma carteira "segura" ainda poder ser arriscada em termos reais: ativos muito estáveis e de retorno muito baixo (dinheiro parado em uma conta que rende poucos juros, por exemplo) podem escapar totalmente da volatilidade do mercado, mas, se o retorno deles não acompanhar a inflação, o poder de compra desse dinheiro encolhe a cada ano, mesmo que o valor nominal em dólares não caia nada. [VERIFIED FACT] Isso às vezes é chamado de risco de inflação, e é fácil de ignorar porque não aparece como uma perda visível no extrato da conta, como acontece com uma queda do mercado: o número em si não diminui, mas o que ele consegue comprar, sim.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Um investidor mantém $50,000 em dinheiro, rendendo uma taxa de juros muito baixa, justamente para evitar qualquer risco de mercado. [ASSUMPTION] Se a inflação ficar bem acima dessa taxa de juros por vários anos, o saldo de $50,000 em si não diminui (pode até crescer um pouco com os juros ganhos), mas os bens e serviços que esses $50,000 conseguem comprar diminuíram silenciosamente, já que os preços subiram mais rápido do que o saldo da conta. O extrato nunca mostra uma "perda", o que torna essa corrosão fácil de passar despercebida em comparação com uma queda visível do mercado.

## Teste de prática

1. Qual é a diferença entre retorno nominal e retorno real?
2. Por que uma carteira "segura" e de baixo retorno ainda pode perder valor real com o tempo?
3. Por que o risco de inflação é fácil de ignorar em comparação com o risco de mercado?

## Gabarito

1. O retorno nominal é o ganho percentual declarado, sem ajuste pela inflação; o retorno real subtrai a inflação para mostrar a mudança efetiva no poder de compra.
2. Porque, se o retorno não acompanhar a inflação, o poder de compra do dinheiro encolhe, mesmo que seu valor nominal em dólares esteja estável ou crescendo.
3. Porque o saldo da conta em si não diminui de forma visível, como aconteceria em uma queda do mercado: a corrosão acontece no que o dinheiro consegue comprar, e não no número que aparece no extrato.

## Respostas e explicações

1. Esta é a distinção fundamental em torno da qual a lição foi construída.
2. Este é o risco central, fácil de ignorar, que a lição destaca.
3. Isto explica por que esse risco em particular é psicologicamente fácil de deixar passar, em comparação com uma perda no mercado.

## Pontos-chave
- O retorno real, e não o nominal, reflete a mudança efetiva no poder de compra de um investimento.
- Uma carteira "segura" e de baixo retorno ainda pode perder valor real com o tempo se seu retorno não acompanhar a inflação.
- O risco de inflação é fácil de ignorar porque não aparece como uma perda visível no extrato da conta.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Todos os números são estimativas ilustrativas, não garantias. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
