---
id: WHITE-L3-030
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 30
title: "Por que ativos diferentes reagem de formas diferentes à inflação"
source_title: "Why Different Assets Respond Differently to Inflation"
description: "Entenda por que alguns investimentos tendem a resistir melhor em períodos de inflação do que outros, e por que não existe uma proteção perfeita contra a inflação."
slug: white-l3-030-assets-and-inflation
seo_title: "Por que ativos diferentes reagem de formas diferentes à inflação | Edunancial"
meta_description: "Entenda por que alguns investimentos tendem a resistir melhor em períodos de inflação do que outros, e por que não existe uma proteção perfeita contra a inflação."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-030: Por que ativos diferentes reagem de formas diferentes à inflação

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar por que os ativos de renda fixa costumam ser mais vulneráveis à inflação do que os ativos com potencial de crescimento
- Identificar exemplos de tipos de ativos frequentemente citados como possíveis proteções contra a inflação
- Explicar por que nenhum ativo sozinho é uma proteção garantida e perfeita contra a inflação

## Conteúdo principal

A Lição 29 mostrou que a inflação corrói o poder de compra. Veja o "porquê" de tipos diferentes de ativos reagirem de formas diferentes a essa corrosão: ativos com pagamentos fixos, que não mudam (como a maioria dos títulos de renda fixa tradicionais), não têm nenhum mecanismo embutido para aumentar seus pagamentos se a inflação subir, o que significa que seu valor real fica diretamente exposto ao risco de inflação. Ativos ligados a receitas, lucros ou valor físico que crescem (ações de empresas que conseguem aumentar preços, imóveis com aluguéis que podem ser reajustados ou certos títulos do governo criados especificamente para se ajustar à inflação) têm mais potencial de acompanhar a alta dos preços com o tempo.

[VERIFIED FACT] Entre as possíveis proteções contra a inflação mais comentadas estão as ações (em especial de empresas com poder de precificação), os imóveis, certas commodities (matérias-primas) e os títulos do governo atrelados à inflação. Mas nenhuma delas é uma proteção garantida ou perfeita em todo período de inflação; cada uma também pode ser afetada por outros fatores (taxas de juros, condições econômicas, problemas específicos do setor) que podem compensar ou até superar qualquer benefício ligado à inflação em um determinado período.

É por isso que pensar em termos de "qual ativo sozinho protege contra a inflação" simplifica demais o conceito. Uma abordagem mais realista trata a resistência à inflação como um fator entre vários a serem pesados em uma carteira diversificada, e não como um problema resolvido por um único investimento.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Durante um período de inflação em alta, uma empresa capaz de repassar custos maiores aos clientes por meio de aumentos de preço pode manter suas margens de lucro e o valor de suas ações melhor do que um título que paga uma taxa fixa definida antes de o período inflacionário começar. [ASSUMPTION] Porém, se esse mesmo período inflacionário também vier acompanhado de juros em alta que prejudiquem as avaliações das ações de modo geral (um fator separado), o desempenho da ação pode não refletir de forma limpa apenas o benefício de proteção contra a inflação. Isso mostra por que nenhum ativo reage à inflação de forma totalmente isolada de tudo o mais que está acontecendo no mercado ao mesmo tempo.

## Teste de prática

1. Por que ativos de renda fixa, como os títulos tradicionais, costumam ser mais vulneráveis à inflação do que ativos com potencial de crescimento?
2. Cite dois tipos de ativos frequentemente citados como possíveis proteções contra a inflação.
3. Por que nenhum ativo sozinho é considerado uma proteção garantida e perfeita contra a inflação?

## Gabarito

1. Porque seus pagamentos são fixos e não aumentam se a inflação subir, o que expõe diretamente seu valor real à corrosão da inflação.
2. Quaisquer dois entre: ações (especialmente de empresas com poder de precificação), imóveis, certas commodities, títulos do governo atrelados à inflação.
3. Porque cada tipo de ativo também pode ser afetado por outros fatores não relacionados (como mudanças nas taxas de juros ou condições específicas do setor) que podem compensar ou superar qualquer benefício ligado à inflação em um determinado período.

## Respostas e explicações

1. Isto se liga diretamente à vulnerabilidade dos pagamentos fixos descrita de forma mais geral na Lição 29.
2. Isto traz exemplos concretos baseados em categorias frequentemente citadas.
3. Este é um alerta importante, com as devidas ressalvas, contra simplificar demais a estratégia de proteção contra a inflação.

## Pontos-chave
- Os ativos de renda fixa costumam ser mais vulneráveis à inflação, já que seus pagamentos não aumentam.
- Ações, imóveis, commodities e títulos atrelados à inflação são frequentemente citados como possíveis proteções contra a inflação.
- Nenhum ativo sozinho é uma proteção garantida e perfeita contra a inflação, já que outros fatores podem compensar ou superar qualquer benefício ligado a ela.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Todos os números são estimativas ilustrativas, não garantias. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
