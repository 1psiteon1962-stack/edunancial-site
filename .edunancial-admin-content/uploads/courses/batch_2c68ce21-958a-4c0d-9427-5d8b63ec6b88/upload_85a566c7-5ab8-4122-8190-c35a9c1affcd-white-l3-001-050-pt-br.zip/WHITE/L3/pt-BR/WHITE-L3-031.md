---
id: WHITE-L3-031
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 31
title: "Por que o risco cambial afeta os investimentos internacionais"
source_title: "Why Currency Risk Affects International Investments"
description: "Entenda por que investir em ativos cotados em moeda estrangeira acrescenta uma camada de risco separada do desempenho do próprio investimento."
slug: white-l3-031-currency-risk
seo_title: "Por que o risco cambial afeta os investimentos internacionais | Edunancial"
meta_description: "Entenda por que investir em ativos cotados em moeda estrangeira acrescenta uma camada de risco separada do desempenho do próprio investimento."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-031: Por que o risco cambial afeta os investimentos internacionais

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o que é risco cambial
- Explicar por que o retorno de um investimento internacional depende de dois fatores separados
- Explicar por que os movimentos da moeda podem ajudar ou prejudicar o retorno, independentemente do desempenho do investimento em si

## Conteúdo principal

Quando um investidor compra um investimento internacional (uma ação ou um título estrangeiro, por exemplo), esse investimento normalmente tem preço na moeda local. Converter os retornos de volta para a moeda do país do investidor introduz um fator separado: o **risco cambial**, que é o risco de os movimentos da taxa de câmbio entre as duas moedas afetarem o retorno efetivo do investidor, independentemente de como o investimento em si se saiu.

Veja o "porquê" disso criar dois fatores separados no retorno total: o investimento pode ir bem na sua moeda local, mas, se essa moeda local se desvalorizar bastante em relação à moeda do investidor antes da conversão, parte ou todo esse ganho pode ser anulado. Por outro lado, um retorno modesto na moeda local, somado a uma moeda que se valoriza em relação à moeda do investidor, pode resultar em um retorno total melhor do que o desempenho local sozinho sugeriria.

[VERIFIED FACT] Os movimentos das moedas podem ser difíceis de prever e são influenciados por muitos fatores, incluindo diferenças nas taxas de juros entre países, condições econômicas e o humor geral do mercado. Alguns fundos internacionais oferecem versões com hedge cambial (proteção contra a variação da moeda), criadas especificamente para reduzir esse risco em particular, deixando o retorno do investidor mais próximo apenas do desempenho local do investimento, embora o próprio hedge tenha seus custos e contrapartidas.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora compra ações de uma empresa estrangeira que sobem 10% na moeda local ao longo de um ano. Se essa moeda local se desvalorizar 8% em relação à moeda do país dela no mesmo período, o retorno efetivo dela, depois de convertido de volta, fica muito mais perto de uns 2%: a maior parte do ganho local foi anulada pelo movimento desfavorável da moeda. [ASSUMPTION] Se, em vez disso, essa moeda local tivesse se valorizado 8% em relação à moeda dela, o retorno convertido poderia ter ficado mais perto de 18%, com o movimento da moeda trabalhando a favor dela, além do ganho de 10% do investimento.

## Teste de prática

1. O que é risco cambial?
2. Por que o retorno total de um investimento internacional depende de dois fatores separados?
3. Para que serve um fundo com hedge cambial?

## Gabarito

1. O risco de os movimentos da taxa de câmbio entre a moeda do investidor e a moeda local do investimento afetarem o retorno efetivo do investidor, independentemente do desempenho do próprio investimento.
2. Porque o retorno depende tanto de como o investimento se sai na sua moeda local quanto de como o valor dessa moeda local muda em relação à moeda do investidor antes da conversão.
3. Reduzir o risco cambial, deixando o retorno do investidor mais próximo do desempenho do investimento na moeda local, embora isso tenha seus próprios custos e contrapartidas.

## Respostas e explicações

1. Esta é a definição fundamental da lição.
2. Este é o conceito central de "dois fatores" que a lição explica.
3. Isto apresenta a ferramenta criada para lidar com esse risco específico, junto com uma ressalva honesta sobre suas contrapartidas.

## Pontos-chave
- O risco cambial é o risco de os movimentos da taxa de câmbio afetarem o retorno de um investimento internacional, separadamente do desempenho do próprio investimento.
- O retorno total de um investimento internacional depende tanto do desempenho na moeda local quanto do movimento dessa moeda em relação à moeda do investidor.
- Os fundos com hedge cambial são criados para reduzir esse risco específico, embora o hedge tenha seus próprios custos e contrapartidas.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Todos os números são estimativas ilustrativas, não garantias. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
