---
id: WHITE-L3-032
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 32
title: "Por que os REITs permitem investir em imóveis sem comprar um imóvel"
source_title: "Why REITs Let You Invest in Real Estate Without Buying Property"
description: "Entenda como funcionam os fundos de investimento imobiliário (REITs), por que eles são negociados como ações e como ligam as trilhas RED e WHITE deste currículo."
slug: white-l3-032-reits
seo_title: "Por que os REITs permitem investir em imóveis sem comprar um imóvel | Edunancial"
meta_description: "Entenda como funcionam os fundos de investimento imobiliário (REITs), por que eles são negociados como ações e como ligam as trilhas RED e WHITE deste currículo."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-032: Por que os REITs permitem investir em imóveis sem comprar um imóvel

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o que é um REIT
- Explicar por que os REITs permitem que os investidores tenham exposição a imóveis sem ser donos diretos de uma propriedade
- Ligar este conceito aos conceitos de alavancagem e fluxo de caixa tratados na trilha RED deste currículo

## Conteúdo principal

Um **REIT (Real Estate Investment Trust, um tipo de fundo de investimento imobiliário dos EUA)** é uma empresa que possui, opera ou financia imóveis que geram renda, e cujas cotas podem ser compradas e vendidas em uma bolsa de valores, como qualquer outra ação negociada publicamente. Ele faz a ponte entre as trilhas RED (imóveis) e WHITE (ativos de papel) deste currículo.

Veja o "porquê" de os REITs oferecerem uma experiência diferente de comprar um imóvel diretamente, como visto ao longo da trilha RED: o investidor de um REIT compra cotas que representam uma participação em uma carteira diversificada de imóveis (muitas vezes vários imóveis em diferentes mercados), sem gerenciar inquilinos diretamente, cuidar da manutenção ou providenciar o financiamento de cada imóvel. Essas responsabilidades ficam com a equipe de gestão do próprio REIT. Em troca, o investidor normalmente abre mão do controle direto e dos tratamentos tributários específicos (como a depreciação, vista na trilha RED) disponíveis para quem é dono direto de um imóvel.

[VERIFIED FACT] Os REITs em geral são obrigados a distribuir a grande maioria de sua renda tributável aos acionistas na forma de dividendos, e isso é parte do motivo de os REITs serem conhecidos por um dividend yield (rendimento de dividendos) relativamente alto em comparação com muitas outras categorias de ações. Mas, como visto na Lição 17, um dividendo continua sendo uma distribuição de valor, e não um bônus a mais em cima dele.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora quer exposição a imóveis comerciais, mas não tem o capital, o tempo ou a vontade de gerenciar diretamente um imóvel de aluguel alavancado, como descrito ao longo da trilha RED deste currículo. Em vez disso, ela compra cotas de um REIT que possui uma grande carteira de escritórios e lojas. Ela ganha exposição à renda e à possível valorização dos imóveis, recebe distribuições regulares de dividendos vindos da renda de aluguel do REIT e pode comprar ou vender suas cotas na bolsa de valores a qualquer momento durante o horário de negociação. É uma experiência de "investir em imóveis" muito diferente de financiar e gerenciar diretamente um imóvel de aluguel individual.

## Teste de prática

1. O que é um REIT?
2. O que o investidor de um REIT ganha, e do que abre mão, em comparação com ser dono direto de um imóvel?
3. Por que os REITs costumam ser conhecidos por um rendimento de dividendos relativamente alto?

## Gabarito

1. Uma empresa que possui, opera ou financia imóveis que geram renda, com cotas negociadas em bolsa de valores como outras ações negociadas publicamente.
2. Ganha exposição diversificada a imóveis sem responsabilidades de gestão direta nem decisões de financiamento de cada imóvel, mas abre mão do controle direto e de certos tratamentos tributários (como a depreciação) disponíveis para quem é dono direto de um imóvel.
3. Porque os REITs em geral são obrigados a distribuir a grande maioria de sua renda tributável aos acionistas na forma de dividendos.

## Respostas e explicações

1. Esta é a definição fundamental que liga os conceitos das trilhas RED e WHITE.
2. Esta é a principal troca que a lição destaca entre investir em REITs e ser dono direto de um imóvel.
3. Isto se liga a uma exigência estrutural própria dos REITs, retomando também o alerta da Lição 17 sobre dividendos.

## Pontos-chave
- Os REITs permitem que os investidores tenham exposição a imóveis por meio de cotas negociadas em bolsa, sem as responsabilidades de ser dono direto de um imóvel.
- Isso troca o controle direto e certos benefícios tributários por liquidez e diversificação.
- A exigência de distribuir uma parte alta da renda é o motivo de os REITs serem conhecidos por um rendimento de dividendos relativamente alto.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
