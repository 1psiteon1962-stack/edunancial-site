---
id: WHITE-L3-033
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 33
title: "Por que a concentração setorial aumenta o risco mesmo em uma carteira que parece diversificada"
source_title: "Why Sector Concentration Increases Risk Even in a Diversified-Looking Portfolio"
description: "Entenda por que ter muitas ações concentradas no mesmo setor pode deixar uma carteira mais exposta ao risco do que parece à primeira vista."
slug: white-l3-033-sector-concentration
seo_title: "Por que a concentração setorial aumenta o risco mesmo em uma carteira que parece diversificada | Edunancial"
meta_description: "Entenda por que ter muitas ações concentradas no mesmo setor pode deixar uma carteira mais exposta ao risco do que parece à primeira vista."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-033: Por que a concentração setorial aumenta o risco mesmo em uma carteira que parece diversificada

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o que significa concentração setorial
- Explicar por que uma carteira pode parecer diversificada pelo número de ativos e ainda assim estar concentrada em um setor
- Ligar este conceito à discussão sobre correlação da Lição 3

## Conteúdo principal

A Lição 3 mostrou que é a correlação, e não apenas o número de ativos, que determina a diversificação real. A **concentração setorial** é uma forma específica e comum de esse risco de correlação aparecer: uma carteira com muitas empresas diferentes que atuam todas no mesmo setor ou indústria.

Veja o "porquê" disso importar: empresas do mesmo setor muitas vezes reagem a muitas das mesmas forças econômicas e regulatórias. Empresas de tecnologia são afetadas pelas mesmas mudanças nos gastos com tecnologia, empresas de energia pelos mesmos movimentos nos preços das commodities, empresas de saúde pelas mesmas mudanças nas regras. [VERIFIED FACT] Essa sensibilidade compartilhada significa que uma carteira pode ter um grande número de ações individuais e ainda assim se comportar, no conjunto, como uma aposta concentrada na sorte desse único setor: a correlação entre os ativos enfraquece o benefício de diversificação que o simples número de ativos sugeriria.

É por isso que avaliar a diversificação de uma carteira deve incluir uma análise específica da exposição por setor, e não só uma contagem de quantas empresas diferentes você tem.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora tem 25 ações diferentes e se sente bem diversificada só pelo número. Olhando mais de perto, 20 dessas 25 são empresas de tecnologia. Se uma queda ampla afetar especificamente o setor de tecnologia (uma mudança nas taxas de juros que prejudique principalmente as avaliações das empresas de tecnologia de alto crescimento, por exemplo), a grande maioria da carteira dela fica exposta a essa mesma pressão ao mesmo tempo, apesar do número aparentemente diversificado de ativos. [ASSUMPTION] Uma carteira com os mesmos 25 ativos no total, mas distribuídos de forma mais equilibrada entre vários setores diferentes, provavelmente sofreria um impacto geral menor com essa mesma queda específica do setor.

## Teste de prática

1. O que é concentração setorial?
2. Por que uma carteira com muitas ações individuais ainda pode se comportar como uma aposta concentrada?
3. Como esta lição se liga ao conceito de correlação da Lição 3?

## Gabarito

1. Uma carteira com muitas empresas concentradas no mesmo setor ou indústria, em vez de distribuídas entre setores diferentes.
2. Porque empresas do mesmo setor muitas vezes reagem a muitas das mesmas forças econômicas e regulatórias, o que torna seus retornos altamente correlacionados, mesmo sendo tecnicamente empresas diferentes.
3. A concentração setorial é um exemplo comum e específico do problema de correlação apresentado na Lição 3: muitos ativos que se movem juntos oferecem muito menos diversificação real do que o número sozinho sugere.

## Respostas e explicações

1. Esta é a definição fundamental da lição.
2. Isto aplica diretamente o conceito de correlação da Lição 3 a um cenário concreto e comum.
3. Isto fecha explicitamente o ciclo entre as duas lições, reforçando a estrutura integrada da trilha.

## Pontos-chave
- Concentração setorial significa que os ativos de uma carteira estão agrupados no mesmo setor, mesmo que o número total de ativos pareça diversificado.
- Empresas do mesmo setor tendem a ser altamente correlacionadas, o que enfraquece o benefício de diversificação que o número de ativos sozinho sugeriria.
- A diversificação de uma carteira deve ser avaliada pela exposição por setor, e não só pela contagem de quantas empresas diferentes você tem.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
