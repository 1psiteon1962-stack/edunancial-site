---
id: WHITE-L3-034
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 34
title: "Por que a alocação de ativos importa mais do que escolher ações individuais"
source_title: "Why Asset Allocation Matters More Than Individual Stock Picking"
description: "Entenda por que a combinação de classes de ativos em uma carteira tende a determinar os resultados de longo prazo mais do que as ações específicas escolhidas dentro de cada classe."
slug: white-l3-034-asset-allocation-vs-stock-picking
seo_title: "Por que a alocação de ativos importa mais do que escolher ações individuais | Edunancial"
meta_description: "Entenda por que a combinação de classes de ativos em uma carteira tende a determinar os resultados de longo prazo mais do que as ações específicas escolhidas dentro de cada classe."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-034: Por que a alocação de ativos importa mais do que escolher ações individuais

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Definir alocação de ativos
- Explicar por que as pesquisas em geral constataram que a alocação de ativos pesa mais nos resultados de longo prazo de uma carteira do que a escolha de títulos individuais
- Explicar por que isso não significa que as escolhas de investimentos individuais não importam nada

## Conteúdo principal

A **alocação de ativos** é a forma como uma carteira é dividida entre grandes categorias de investimentos (ações, títulos de renda fixa, imóveis, dinheiro em caixa e outras), e não quais ativos específicos são escolhidos dentro de cada categoria.

Veja o "porquê" de a alocação tender a importar mais do que as escolhas individuais para a maioria dos investidores de longo prazo: [VERIFIED FACT] uma série de pesquisas acadêmicas e do setor sobre o retorno de carteiras constatou, em geral, que as decisões amplas de alocação de ativos explicam uma parte substancial da variação no desempenho de longo prazo das carteiras de diferentes investidores, mais do que os ativos específicos escolhidos dentro de cada classe. Ainda assim, as conclusões e os métodos variam entre os estudos, e a escolha de ativos individuais ainda pode afetar bastante os resultados dentro de uma determinada alocação.

Isso se liga a conceitos vistos ao longo desta trilha: como a diversificação dentro de uma classe de ativos (Lições 2 e 3) já reduz boa parte do risco específico de cada empresa, o maior fator que sobra para definir o perfil geral de risco e retorno de uma carteira passa a ser a combinação ampla entre classes de ativos com características de risco e retorno realmente diferentes. As ações em geral oferecem maior potencial de crescimento no longo prazo com mais volatilidade, os títulos de renda fixa em geral oferecem mais estabilidade com menor potencial de crescimento no longo prazo, e assim por diante.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Dois investidores têm carteiras bem diversificadas dentro das classes de ativos que escolheram, mas o Investidor A coloca 80% em ações e 20% em títulos, enquanto o Investidor B coloca 30% em ações e 70% em títulos. [ASSUMPTION] Ao longo de um período longo, a diferença no desempenho geral e na volatilidade das carteiras deles provavelmente será determinada em grande parte por essa diferença ampla de alocação, e não pelas ações ou títulos individuais que cada um escolheu dentro de suas respectivas alocações, mesmo que os dois tenham feito escolhas individuais razoavelmente boas.

## Teste de prática

1. O que é alocação de ativos?
2. O que as pesquisas em geral constataram sobre a importância relativa da alocação de ativos em comparação com a escolha de ativos individuais para os resultados de longo prazo de uma carteira?
3. Isso significa que a escolha de ativos individuais não importa nada? Por quê?

## Gabarito

1. A forma como uma carteira é dividida entre grandes categorias de investimentos, como ações, títulos de renda fixa, imóveis e dinheiro em caixa.
2. Que as decisões de alocação de ativos tendem a explicar uma parte substancial da variação no desempenho de longo prazo das carteiras, mais do que os ativos específicos escolhidos dentro de cada classe, embora as conclusões variem entre os estudos.
3. Não. A escolha de ativos individuais ainda pode afetar bastante os resultados dentro de uma determinada alocação; a lição enfatiza a importância relativa, e não que as escolhas individuais sejam irrelevantes.

## Respostas e explicações

1. Esta é a definição fundamental da lição.
2. Esta é a principal afirmação baseada em pesquisas em torno da qual a lição foi construída, com as devidas ressalvas.
3. Isto evita a conclusão simplista de que as escolhas individuais não importam dentro de uma alocação.

## Pontos-chave
- A alocação de ativos é a forma como uma carteira é dividida entre grandes categorias de investimento, como ações, títulos de renda fixa e dinheiro em caixa.
- As pesquisas em geral constataram que as decisões de alocação pesam mais nos resultados de longo prazo de uma carteira do que a escolha de ativos individuais, embora as duas coisas importem.
- Isso se liga aos conceitos de diversificação das lições anteriores: depois que o risco específico de cada empresa é reduzido pela diversificação, a combinação ampla de ativos passa a ser o maior fator restante nos resultados.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Desempenho passado não garante resultados futuros. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
