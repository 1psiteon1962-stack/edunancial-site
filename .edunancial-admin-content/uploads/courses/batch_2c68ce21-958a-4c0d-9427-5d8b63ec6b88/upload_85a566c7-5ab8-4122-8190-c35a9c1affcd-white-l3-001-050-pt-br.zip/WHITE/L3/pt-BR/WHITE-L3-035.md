---
id: WHITE-L3-035
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 35
title: "Por que uma glide path (trajetória de ajuste) reduz o risco conforme você envelhece"
source_title: "Why a Glide Path Shifts Risk as You Age"
description: "Entenda por que muitas estratégias de investimento de longo prazo mudam aos poucos a alocação de ativos de uma carteira, de mais agressiva para mais conservadora, e por que esse momento importa."
slug: white-l3-035-glide-path
seo_title: "Por que uma glide path (trajetória de ajuste) reduz o risco conforme você envelhece | Edunancial"
meta_description: "Entenda por que muitas estratégias de investimento de longo prazo mudam aos poucos a alocação de ativos de uma carteira, de mais agressiva para mais conservadora, e por que esse momento importa."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-035: Por que uma glide path (trajetória de ajuste) reduz o risco conforme você envelhece

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o que é uma "glide path" (trajetória de ajuste) na estratégia de investimento
- Explicar por que mudar para uma alocação mais conservadora com o tempo se liga ao risco de sequência de retornos
- Explicar a lógica geral por trás de reduzir o risco à medida que uma data-alvo (como a aposentadoria) se aproxima

## Conteúdo principal

Uma **glide path** (trajetória de ajuste) descreve um plano definido de antemão para mudar aos poucos a alocação de ativos de uma carteira (Lição 34) de uma combinação mais agressiva, voltada ao crescimento, para uma combinação mais conservadora, voltada à estabilidade, à medida que o investidor se aproxima de uma data-alvo específica, geralmente a aposentadoria. Os target-date funds (fundos com data-alvo) são um exemplo comum de produto de investimento construído em torno desse conceito.

Veja o "porquê" de esse momento importar, ligando-se diretamente ao risco de sequência de retornos da Lição 15: uma carteira que ainda tem muitos anos pela frente antes de precisar ser usada tem mais tempo para se recuperar de uma queda, então normalmente pode se dar ao luxo de ter mais ações, pelo seu maior potencial de crescimento no longo prazo. À medida que a data-alvo se aproxima e o tempo para se recuperar de uma possível queda diminui, mudar aos poucos para ativos mais estáveis (como títulos de renda fixa) reduz o risco de sofrer uma grande queda, em um momento ruim, logo antes de o dinheiro ser necessário, que é exatamente o risco descrito na Lição 15.

[VERIFIED FACT] Os diferentes modelos de glide path variam em quão agressiva ou conservadora é a mudança ao longo do tempo, e em se a mudança continua mesmo depois de atingida a data-alvo. Não existe uma glide path única e universal, e o ritmo adequado de ajuste depende das circunstâncias individuais e da tolerância ao risco.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Um fundo com data-alvo criado para alguém que vai se aposentar daqui a uns 30 anos pode começar com uma carteira bem concentrada em ações, aproveitando o longo horizonte de tempo para potencialmente se recuperar de quaisquer quedas pelo caminho. À medida que a data-alvo de aposentadoria se aproxima ao longo dessas décadas, o fundo aumenta aos poucos a parcela em títulos de renda fixa e reduz a exposição a ações, com o objetivo de diminuir a vulnerabilidade da carteira a uma queda em um momento ruim, justamente quando o investidor pode precisar começar a fazer retiradas.

## Teste de prática

1. O que uma "glide path" descreve?
2. Por que uma carteira normalmente muda de mais agressiva para mais conservadora à medida que a data-alvo se aproxima?
3. Como esse conceito se liga diretamente ao risco de sequência de retornos da Lição 15?

## Gabarito

1. Um plano definido de antemão para mudar aos poucos a alocação de ativos de uma carteira de mais agressiva para mais conservadora à medida que uma data-alvo, como a aposentadoria, se aproxima.
2. Porque há menos tempo restante para se recuperar de uma possível queda à medida que a data-alvo chega perto, então reduzir a exposição a ativos mais voláteis ajuda a proteger contra uma queda em um momento ruim logo antes de o dinheiro ser necessário.
3. O risco de sequência de retornos mostrou que retornos ruins logo antes ou durante as retiradas podem causar um estrago desproporcional. Uma glide path é criada especificamente para reduzir a vulnerabilidade a esse risco exato, diminuindo a exposição à volatilidade à medida que a data-alvo se aproxima.

## Respostas e explicações

1. Esta é a definição fundamental da lição.
2. Isto explica a lógica que liga o horizonte de tempo ao nível de risco adequado.
3. Isto liga explicitamente o conceito à Lição 15, reforçando a estrutura integrada da trilha.

## Pontos-chave
- Uma glide path muda aos poucos a alocação de uma carteira de mais agressiva para mais conservadora à medida que a data-alvo se aproxima.
- Esse momento enfrenta diretamente o risco de sequência de retornos, reduzindo a vulnerabilidade a uma queda em um momento ruim perto da data-alvo.
- Os modelos de glide path variam, e o ritmo adequado de ajuste depende das circunstâncias individuais e da tolerância ao risco.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
