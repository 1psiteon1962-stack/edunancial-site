---
id: WHITE-L3-037
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 37
title: "Por que o tax-loss harvesting (colheita de prejuízos fiscais) transforma uma perda em um benefício futuro"
source_title: "Why Tax-Loss Harvesting Turns a Loss Into a Future Benefit"
description: "Entenda como funciona o tax-loss harvesting, por que ele transforma uma perda não realizada em um benefício fiscal utilizável e por que o processo exige cuidado."
slug: white-l3-037-tax-loss-harvesting
seo_title: "Por que o tax-loss harvesting (colheita de prejuízos fiscais) transforma uma perda em um benefício futuro | Edunancial"
meta_description: "Entenda como funciona o tax-loss harvesting, por que ele transforma uma perda não realizada em um benefício fiscal utilizável e por que o processo exige cuidado."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-037: Por que o tax-loss harvesting (colheita de prejuízos fiscais) transforma uma perda em um benefício futuro

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o conceito geral do tax-loss harvesting (colheita de prejuízos fiscais)
- Explicar por que é preciso "realizar" uma perda vendendo o investimento para usá-la para fins fiscais
- Explicar por que essa estratégia exige entender uma regra tratada na próxima lição

## Conteúdo principal

O **tax-loss harvesting** (colheita de prejuízos fiscais) é uma estratégia geral de vender de propósito um investimento que perdeu valor, para "realizar" a perda, ou seja, para que ela se torne uma perda efetiva e registrada para fins fiscais, e não apenas uma perda não realizada no papel. Essa perda pode então, potencialmente, ser usada para compensar ganhos tributáveis em outras partes da carteira, sujeito às regras tributárias específicas que se aplicam em cada país.

Veja o "porquê" de isso exigir uma venda de verdade: enquanto um investimento estiver simplesmente guardado com um valor abaixo do preço de compra, isso em geral é considerado uma perda não realizada. Ela existe no papel, mas ainda não foi "travada" por meio de uma transação, e em muitos sistemas tributários só uma perda realizada pode ser usada para fins fiscais. Vender a posição converte essa perda no papel em uma perda realizada.

[VERIFIED FACT] Como muitos investidores querem manter sua exposição geral ao mercado ou sua estratégia de investimento mesmo enquanto colhem uma perda, eles muitas vezes reinvestem o dinheiro da venda em um investimento parecido (mas não idêntico) logo em seguida. Isso introduz uma regra importante, tratada na próxima lição, que limita a rapidez com que você pode recomprar um investimento substancialmente idêntico e ainda assim declarar a perda fiscal.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora tem um fundo que perdeu bastante valor desde a compra. Em vez de simplesmente continuar com ele, ela vende a posição, realizando a perda para fins fiscais, e reinveste o dinheiro em um fundo parecido, mas não idêntico, para manter mais ou menos a mesma exposição ao mercado. [ASSUMPTION] A perda realizada pode potencialmente ser usada, sujeito às regras tributárias aplicáveis, para compensar outros ganhos tributáveis que ela tenha em outras partes da carteira naquele ano, transformando o que parecia um resultado puramente negativo em pelo menos um benefício fiscal prático e parcial.

## Teste de prática

1. O que é, de modo geral, o tax-loss harvesting?
2. Por que simplesmente manter um investimento que caiu não gera uma perda fiscal utilizável em muitos sistemas tributários?
3. Por que um investidor pode reinvestir em um investimento parecido, mas não idêntico, depois de colher uma perda?

## Gabarito

1. Vender de propósito um investimento que caiu para realizar a perda para fins fiscais, potencialmente compensando ganhos tributáveis em outras partes, sujeito às regras aplicáveis.
2. Porque uma perda não realizada (no papel) ainda não foi "travada" por meio de uma transação de verdade, e muitos sistemas tributários exigem que a perda seja realizada por meio de uma venda antes de poder ser usada.
3. Para manter mais ou menos a mesma exposição geral ao mercado ou a mesma estratégia de investimento e ainda assim realizar a perda fiscal, em vez de simplesmente ficar com o dinheiro parado ou sair totalmente daquela parte do mercado.

## Respostas e explicações

1. Esta é a definição fundamental da lição.
2. Isto explica o motivo mecânico pelo qual a venda é necessária, um conceito-chave para entender a estratégia.
3. Isto prepara o motivo prático pelo qual os investidores normalmente reinvestem rápido, o que introduz a restrição tratada na próxima lição.

## Pontos-chave
- O tax-loss harvesting realiza de propósito uma perda por meio de uma venda, potencialmente compensando outros ganhos tributáveis, sujeito às regras tributárias aplicáveis.
- Em muitos sistemas tributários, normalmente só uma perda realizada, e não uma perda não realizada no papel, pode ser usada para fins fiscais.
- Os investidores muitas vezes reinvestem em um investimento parecido para manter a exposição ao mercado, o que introduz uma regra importante de prazo, tratada a seguir.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. As regras tributárias variam muito de país para país; consulte um profissional tributário licenciado antes de colocar em prática qualquer estratégia tributária.*
