---
id: WHITE-L3-038
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 38
title: "Por que a regra de wash sale (venda de fachada) limita o tax-loss harvesting"
source_title: "Why the Wash-Sale Rule Limits Tax-Loss Harvesting"
description: "Entenda o que é uma wash sale, por que essa regra existe e por que ela limita diretamente a forma como o tax-loss harvesting pode ser feito."
slug: white-l3-038-wash-sale-rule
seo_title: "Por que a regra de wash sale (venda de fachada) limita o tax-loss harvesting | Edunancial"
meta_description: "Entenda o que é uma wash sale, por que essa regra existe e por que ela limita diretamente a forma como o tax-loss harvesting pode ser feito."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-038: Por que a regra de wash sale (venda de fachada) limita o tax-loss harvesting

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o conceito geral por trás de uma regra do tipo wash sale (venda de fachada)
- Explicar por que essa regra existe
- Explicar como essa regra limita diretamente a estratégia de tax-loss harvesting da Lição 37

## Conteúdo principal

A Lição 37 explicou que os investidores muitas vezes querem reinvestir rápido depois de colher uma perda fiscal, para manter sua exposição ao mercado. Muitos sistemas tributários incluem uma regra, muitas vezes chamada de regra de wash sale (venda de fachada), criada especificamente para impedir que um certo tipo de tax-loss harvesting seja usado de forma abusiva.

Veja o "porquê" de essa regra existir: sem ela, um investidor poderia vender um investimento só para realizar uma perda fiscal e, logo em seguida, recomprar exatamente o mesmo investimento (ou um substancialmente idêntico), mantendo na prática exatamente a mesma posição e ainda assim declarando um benefício fiscal. Muitas autoridades fiscais consideram isso um abuso do conceito de realização de perdas, e não uma mudança real na posição de investimento.

[VERIFIED FACT] Os mecanismos específicos de uma regra do tipo wash sale (incluindo o prazo exato durante o qual recomprar o mesmo ativo ou um substancialmente idêntico anula a perda, e como "substancialmente idêntico" é definido) variam de país para país e são estabelecidos por leis tributárias específicas. Por isso, esta é uma área em que uma orientação atual e específica para cada país importa mais do que suposições gerais.

É por isso que o tax-loss harvesting, como apresentado na Lição 37, normalmente envolve reinvestir em um investimento realmente diferente (embora parecido em estratégia ou exposição), e não no mesmo investimento, para cumprir esse tipo de regra e ainda manter uma posição de mercado comparável.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora vende um fundo com prejuízo para colher o benefício fiscal e, logo no dia seguinte, recompra exatamente o mesmo fundo, com a intenção de declarar a perda no seu imposto de renda. [ASSUMPTION] Se uma regra do tipo wash sale no país dela anular perdas em recompras do mesmo ativo ou de um substancialmente idêntico dentro de um certo prazo, essa transação pode não gerar o benefício fiscal pretendido: a perda pode ser anulada por essa regra, apesar da intenção dela de colhê-la. Comprar, em vez disso, um fundo realmente diferente, embora com posicionamento parecido, normalmente evitaria esse problema específico, sujeito às regras aplicáveis.

## Teste de prática

1. O que uma regra do tipo wash sale, de modo geral, foi criada para impedir?
2. Por que essa regra existe, de acordo com esta lição?
3. Como essa regra molda a forma como o tax-loss harvesting normalmente é feito na prática?

## Gabarito

1. Que um investidor venda um investimento só para realizar uma perda fiscal e, logo em seguida, recompre o mesmo investimento ou um substancialmente idêntico, ainda declarando o benefício fiscal.
2. Porque fazer isso manteria, na prática, exatamente a mesma posição de investimento e ainda assim declararia uma perda, o que muitas autoridades fiscais consideram um abuso do conceito de realização de perdas.
3. Normalmente significa que os investidores reinvestem o dinheiro em um investimento realmente diferente, embora com posicionamento parecido, e não no mesmo investimento, para cumprir a regra e manter uma exposição ao mercado comparável.

## Respostas e explicações

1. Este é o conceito fundamental por trás desse tipo de regra.
2. Isto explica a justificativa da política pública por trás da existência da regra.
3. Isto se liga diretamente à estratégia prática descrita na Lição 37, mostrando como os dois conceitos funcionam juntos.

## Pontos-chave
- Uma regra do tipo wash sale em geral anula uma perda fiscal se o mesmo investimento, ou um substancialmente idêntico, for recomprado dentro de um certo prazo.
- Essa regra existe para impedir que os investidores declarem uma perda fiscal enquanto mantêm, na prática, exatamente a mesma posição de investimento.
- Os mecanismos específicos variam muito de país para país, o que torna esta uma área em que uma orientação profissional atualizada é especialmente importante.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. As regras tributárias variam muito de país para país; consulte um profissional tributário licenciado antes de colocar em prática qualquer estratégia tributária.*
