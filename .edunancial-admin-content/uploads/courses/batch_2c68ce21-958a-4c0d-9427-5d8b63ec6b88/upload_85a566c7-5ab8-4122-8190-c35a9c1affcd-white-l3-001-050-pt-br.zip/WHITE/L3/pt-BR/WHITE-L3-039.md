---
id: WHITE-L3-039
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 39
title: "Por que os ganhos de capital são tributados de forma diferente conforme o prazo de permanência"
source_title: "Why Capital Gains Are Taxed Differently Based on Holding Period"
description: "Entenda por que o tempo que você mantém um investimento antes de vendê-lo pode afetar a forma como o ganho é tributado, e por que isso cria um incentivo real em torno do momento da venda."
slug: white-l3-039-holding-period-and-capital-gains
seo_title: "Por que os ganhos de capital são tributados de forma diferente conforme o prazo de permanência | Edunancial"
meta_description: "Entenda por que o tempo que você mantém um investimento antes de vendê-lo pode afetar a forma como o ganho é tributado, e por que isso cria um incentivo real em torno do momento da venda."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-039: Por que os ganhos de capital são tributados de forma diferente conforme o prazo de permanência

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o conceito geral de tratamento dos ganhos de capital com base no prazo de permanência
- Explicar por que muitos sistemas tributários tratam de forma diferente os prazos de permanência mais curtos e mais longos
- Explicar por que isso cria um incentivo real e intencional em torno do momento de investir e vender

## Conteúdo principal

Muitos sistemas tributários diferenciam os ganhos com investimentos mantidos por um prazo mais curto dos ganhos com investimentos mantidos por um prazo mais longo antes da venda, muitas vezes aplicando alíquotas diferentes a cada categoria. [VERIFIED FACT] Os prazos de permanência específicos e as alíquotas aplicáveis variam muito de país para país e são definidos por leis tributárias específicas. Conhecer o conceito de modo geral é útil, mas os números exatos devem ser verificados para cada situação e cada país.

Veja o "porquê" de essa diferença existir com frequência: muitos sistemas tributários são pensados, pelo menos em parte, para incentivar a manutenção dos investimentos por mais tempo em vez de negociações frequentes de curto prazo, muitas vezes tributando os ganhos de investimentos mantidos por um prazo mais curto com uma alíquota maior do que os ganhos de investimentos mantidos por mais tempo.

Isso cria um incentivo real e intencional que vale a pena entender: um investidor decidindo se vende um investimento que está perto de atingir um prazo de permanência relevante pode, com razão, levar em conta a possível diferença de imposto nessa decisão sobre o momento da venda. Não como a única consideração, mas como um fator relevante ao lado das perspectivas do próprio investimento e dos objetivos mais amplos do investidor.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora está pensando em vender um investimento que valorizou bastante, e ela está perto de atingir um prazo de permanência mais longo que, no país dela, aplicaria uma alíquota mais favorável ao ganho. [ASSUMPTION] Se a visão geral dela sobre a posição não mudou de forma significativa, esperar um pouco mais para passar desse prazo pode resultar em menos imposto total a pagar na venda. Mas isso deve ser pesado contra a visão real dela sobre as perspectivas e o risco do investimento no curto prazo, e não tratado como algo que automaticamente passa por cima dessas considerações.

## Teste de prática

1. Que diferença geral muitos sistemas tributários fazem em relação aos ganhos de capital?
2. Por que muitos sistemas tributários aplicam esse tipo de diferença, de acordo com esta lição?
3. Como essa diferença pode, com razão, entrar na decisão de um investidor sobre o momento da venda?

## Gabarito

1. Uma diferença entre os ganhos com investimentos mantidos por um prazo mais curto e os ganhos com investimentos mantidos por um prazo mais longo, muitas vezes tributados com alíquotas diferentes.
2. Para incentivar a manutenção dos investimentos por mais tempo em vez de negociações frequentes de curto prazo, muitas vezes aplicando uma alíquota maior aos ganhos de prazo mais curto.
3. Um investidor perto de atingir um prazo de permanência mais longo pode, com razão, considerar o possível benefício fiscal de esperar, como um fator relevante ao lado das perspectivas do próprio investimento e dos seus objetivos mais amplos, e não como o único fator de decisão.

## Respostas e explicações

1. Esta é a base conceitual geral da lição, com as devidas ressalvas por causa das diferenças entre países.
2. Isto explica a justificativa de política pública geralmente citada para esse tipo de diferença.
3. Isto aplica o conceito na prática, alertando contra deixar as considerações fiscais passarem totalmente por cima de um bom julgamento de investimento.

## Pontos-chave
- Muitos sistemas tributários aplicam alíquotas diferentes aos ganhos conforme o tempo que o investimento foi mantido antes da venda.
- Essa diferença muitas vezes é pensada para incentivar a manutenção por mais tempo em vez de negociações frequentes de curto prazo.
- O prazo de permanência pode, com razão, entrar na decisão de venda, mas deve ser pesado junto com as perspectivas do próprio investimento, e não passar por cima delas automaticamente.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. As regras tributárias variam muito de país para país; consulte um profissional tributário licenciado para obter orientação específica para a sua situação.*
