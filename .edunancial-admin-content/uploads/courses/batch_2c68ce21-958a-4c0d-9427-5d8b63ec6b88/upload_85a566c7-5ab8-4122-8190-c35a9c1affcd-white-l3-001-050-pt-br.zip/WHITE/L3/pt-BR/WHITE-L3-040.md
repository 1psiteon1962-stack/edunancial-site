---
id: WHITE-L3-040
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 40
title: "Por que o custo de aquisição (cost basis) determina o seu ganho tributável real"
source_title: "Why Cost Basis Determines Your Real Taxable Gain"
description: "Entenda o que significa custo de aquisição, por que ele nem sempre é tão simples quanto o preço original de compra e por que acompanhá-lo com precisão importa."
slug: white-l3-040-cost-basis
seo_title: "Por que o custo de aquisição (cost basis) determina o seu ganho tributável real | Edunancial"
meta_description: "Entenda o que significa custo de aquisição, por que ele nem sempre é tão simples quanto o preço original de compra e por que acompanhá-lo com precisão importa."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-040: Por que o custo de aquisição (cost basis) determina o seu ganho tributável real

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Definir custo de aquisição (cost basis)
- Explicar por que o custo de aquisição pode ser mais complexo do que apenas o preço original de compra
- Explicar por que acompanhar o custo de aquisição com precisão afeta diretamente o cálculo do ganho tributável

## Conteúdo principal

O **custo de aquisição** (cost basis) em geral é o valor original usado para determinar o ganho ou a perda tributável quando um investimento é vendido; na forma mais simples, é o preço de compra. Veja o "porquê" de ele muitas vezes ser mais complexo do que essa descrição simples: o custo de aquisição pode ser ajustado por vários fatores ao longo do período em que você mantém o investimento, incluindo dividendos reinvestidos (Lição 17) que foram usados para comprar mais cotas ou ações, já que cada reinvestimento normalmente estabelece seu próprio custo de aquisição, com base no preço daquela compra.

[VERIFIED FACT] Acompanhar o custo de aquisição com precisão importa diretamente porque ele determina o ganho tributável calculado (preço de venda menos custo de aquisição) quando o investimento é vendido. Subestimar o custo de aquisição superestima o ganho tributável, o que pode fazer você pagar mais imposto do que o necessário, enquanto superestimar o custo de aquisição subestima o ganho, o que pode criar problemas com o fisco.

Em muitos países, as corretoras são obrigadas a acompanhar e informar os dados de custo de aquisição para muitos tipos de conta, o que tornou isso um trabalho manual menor para os investidores do que já foi. Mas entender o conceito por trás continua sendo útil, principalmente em situações com várias compras ao longo do tempo, dividendos reinvestidos ou contas e situações em que o acompanhamento do custo de aquisição pode ser menos automático.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora compra cotas de um fundo ao longo de vários anos, aumentando sua posição em momentos diferentes e também tendo os dividendos reinvestidos automaticamente em mais cotas pelo caminho. Cada uma dessas compras (as compras originais e cada reinvestimento de dividendos) estabelece seu próprio custo de aquisição, com base no preço daquela transação específica. [ASSUMPTION] Quando ela finalmente vende uma parte da posição total, o ganho tributável calculado depende de quais cotas específicas (e seus respectivos custos de aquisição) são consideradas vendidas, conforme o método contábil usado. Isso mostra por que simplesmente usar o primeiro preço de compra como "o" custo de aquisição da posição inteira provavelmente seria impreciso.

## Teste de prática

1. O que o custo de aquisição em geral significa?
2. Por que o custo de aquisição pode ser mais complexo do que simplesmente o preço original de compra?
3. O que acontece se o custo de aquisição for subestimado no cálculo de um ganho tributável?

## Gabarito

1. O valor original usado para determinar o ganho ou a perda tributável quando um investimento é vendido.
2. Porque as compras adicionais ao longo do tempo, incluindo os dividendos reinvestidos, estabelecem cada uma seu próprio custo de aquisição, fazendo com que o custo da posição total seja uma combinação de várias transações, e não um número único.
3. O ganho tributável calculado fica superestimado, o que pode fazer você pagar mais imposto do que o realmente necessário.

## Respostas e explicações

1. Esta é a definição fundamental da lição.
2. Esta é a principal complexidade que a lição destaca, ligada diretamente ao conceito de dividendos reinvestidos da Lição 17.
3. Isto reforça a importância prática de acompanhar o custo de aquisição com precisão.

## Pontos-chave
- O custo de aquisição é o valor original usado para calcular o ganho ou a perda tributável em uma venda, e muitas vezes é mais complexo do que um único preço de compra.
- Os dividendos reinvestidos e as várias compras ao longo do tempo estabelecem cada um seu próprio custo de aquisição, o que exige um acompanhamento cuidadoso.
- Acompanhar o custo de aquisição com precisão afeta diretamente o ganho tributável calculado, com consequências reais se ele for superestimado ou subestimado.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. As regras tributárias variam muito de país para país; consulte um profissional tributário licenciado para obter orientação específica para a sua situação.*
