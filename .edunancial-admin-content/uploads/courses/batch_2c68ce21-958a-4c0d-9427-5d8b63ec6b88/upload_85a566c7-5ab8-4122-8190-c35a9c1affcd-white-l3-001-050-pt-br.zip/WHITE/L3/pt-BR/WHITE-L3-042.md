---
id: WHITE-L3-042
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 42
title: "Por que a liquidez é diferente entre uma ação blue chip e uma ação pouco negociada"
source_title: "Why Liquidity Differs Between a Blue-Chip Stock and a Thinly Traded One"
description: "Entenda o que liquidez significa para um ativo e por que uma ação pouco negociada pode ser mais difícil e mais cara de comprar ou vender do que o preço sozinho sugere."
slug: white-l3-042-liquidity-differences
seo_title: "Por que a liquidez é diferente entre uma ação blue chip e uma ação pouco negociada | Edunancial"
meta_description: "Entenda o que liquidez significa para um ativo e por que uma ação pouco negociada pode ser mais difícil e mais cara de comprar ou vender do que o preço sozinho sugere."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-042: Por que a liquidez é diferente entre uma ação blue chip e uma ação pouco negociada

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Definir liquidez no contexto de um ativo negociado
- Explicar por que a baixa liquidez pode aumentar o spread entre compra e venda (bid-ask spread)
- Explicar por que o risco de liquidez importa mesmo para um investidor que não pretende negociar com frequência

## Conteúdo principal

A **liquidez** descreve a facilidade com que um ativo pode ser comprado ou vendido sem afetar muito o seu preço, e em geral reflete quanta atividade regular de negociação (volume) existe naquele ativo. Uma ação muito negociada e bem conhecida normalmente tem alta liquidez: um grande número de ações muda de mãos o tempo todo, e as ordens de compra e venda geralmente podem ser executadas rapidamente, a preços muito próximos do último preço negociado.

Veja o "porquê" de um ativo pouco negociado se comportar de forma diferente: com menos compradores e vendedores negociando ativamente, o **bid-ask spread** (a diferença entre o maior preço que um comprador está disposto a pagar no momento e o menor preço que um vendedor está disposto a aceitar no momento) tende a ser maior. [VERIFIED FACT] Um spread maior significa que um investidor que compra e logo em seguida vende um ativo pouco negociado em geral perderia mais com esse spread do que perderia com um ativo de alta liquidez, mesmo antes de considerar qualquer movimento de preço. É um custo implícito de negociar em um mercado menos líquido.

O risco de liquidez importa mesmo para quem negocia pouco e pensa no longo prazo: se um dia você precisar vender uma posição pouco negociada, especialmente em um volume maior ou durante um período de estresse no mercado, talvez tenha que aceitar um preço menos favorável, ou vender aos poucos ao longo do tempo, para não empurrar o preço ainda mais para baixo com as suas próprias vendas.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] A ação de uma empresa grande e muito conhecida tem milhões de ações negociadas por dia, com um bid-ask spread de apenas alguns centavos: um investidor em geral consegue comprar ou vender uma posição típica rapidamente, com um custo de spread mínimo. A ação de uma empresa pequena e pouco negociada pode ter só alguns milhares de ações negociadas em um dia típico, com um spread muito maior. [ASSUMPTION] Uma investidora que precise vender uma posição significativa nessa ação pouco negociada pode perceber que as suas próprias vendas empurram o preço mais para baixo do que uma venda comparável na ação de alta liquidez empurraria, simplesmente porque há menos compradores disponíveis para absorver as ações ao preço atual.

## Teste de prática

1. O que a liquidez descreve no contexto de um ativo negociado?
2. Por que a baixa liquidez tende a aumentar o bid-ask spread?
3. Por que o risco de liquidez importa mesmo para um investidor que não pretende negociar com frequência?

## Gabarito

1. A facilidade com que um ativo pode ser comprado ou vendido sem afetar muito o seu preço, geralmente refletindo o nível de atividade regular de negociação naquele ativo.
2. Porque, com menos compradores e vendedores ativos, a diferença entre o que os compradores estão dispostos a pagar e o que os vendedores estão dispostos a aceitar tende a aumentar, refletindo a menor atividade de negociação.
3. Porque vender um dia uma posição pouco negociada, especialmente em grande volume ou durante um estresse no mercado, pode exigir aceitar um preço menos favorável ou vender aos poucos, já que há menos compradores disponíveis para absorver as ações.

## Respostas e explicações

1. Esta é a definição fundamental da lição.
2. Isto explica o mecanismo específico que liga a liquidez ao custo de negociação.
3. Isto estende o conceito ao investidor de longo prazo, e não só a quem negocia ativamente, ampliando sua relevância.

## Pontos-chave
- A liquidez descreve a facilidade com que um ativo pode ser comprado ou vendido sem afetar muito o seu preço.
- Ativos pouco negociados tendem a ter bid-ask spreads maiores, um custo implícito de negociar em um mercado menos líquido.
- O risco de liquidez importa mesmo para investidores de longo prazo, já que vender um dia uma posição grande ou pouco negociada pode exigir aceitar um preço menos favorável.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
