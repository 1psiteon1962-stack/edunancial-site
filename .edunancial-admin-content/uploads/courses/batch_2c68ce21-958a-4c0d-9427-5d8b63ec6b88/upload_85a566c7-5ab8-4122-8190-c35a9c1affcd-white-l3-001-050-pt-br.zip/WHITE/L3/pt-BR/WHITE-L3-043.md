---
id: WHITE-L3-043
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 43
title: "Por que ordens a mercado e ordens limitadas servem a propósitos diferentes"
source_title: "Why Market Orders and Limit Orders Serve Different Purposes"
description: "Entenda a diferença entre uma ordem a mercado e uma ordem limitada, e por que escolher a certa depende do que você realmente quer controlar."
slug: white-l3-043-market-vs-limit-orders
seo_title: "Por que ordens a mercado e ordens limitadas servem a propósitos diferentes | Edunancial"
meta_description: "Entenda a diferença entre uma ordem a mercado e uma ordem limitada, e por que escolher a certa depende do que você realmente quer controlar."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-043: Por que ordens a mercado e ordens limitadas servem a propósitos diferentes

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar a diferença entre uma ordem a mercado e uma ordem limitada
- Explicar por que cada tipo de ordem prioriza uma variável diferente: velocidade ou preço
- Ligar este conceito à discussão sobre liquidez da Lição 42

## Conteúdo principal

Uma **ordem a mercado** instrui a corretora a comprar ou vender um ativo imediatamente pelo melhor preço disponível no momento. Uma **ordem limitada** instrui a corretora a comprar ou vender apenas a um preço definido ou melhor, podendo esperar para ser executada (ou nem ser executada) se esse preço não estiver disponível.

Veja o "porquê" de a escolha entre elas depender do que você está priorizando: uma ordem a mercado prioriza a velocidade e a certeza de execução. Ela quase sempre será executada rapidamente, mas você não sabe o preço exato de antemão, especialmente em um ativo menos líquido (o que se liga diretamente à discussão sobre bid-ask spread da Lição 42) ou em condições de movimento rápido. Uma ordem limitada prioriza o controle do preço: você sabe o pior preço que vai aceitar, mas abre mão da certeza de execução, já que a ordem pode nem ser executada se o mercado nunca chegar ao preço que você definiu.

[VERIFIED FACT] Para ativos de alta liquidez com bid-ask spreads estreitos, a diferença prática entre uma ordem a mercado e uma ordem limitada colocada de forma razoável muitas vezes é pequena. A diferença se torna mais significativa para ativos menos líquidos, ordens maiores ou períodos de alta volatilidade, em que a incerteza de preço com uma ordem a mercado pode ser maior.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora quer comprar ações de uma empresa pouco negociada (como no exemplo da Lição 42). Usar uma ordem a mercado garante que a compra aconteça rapidamente, mas o bid-ask spread maior significa que ela pode pagar um preço visivelmente mais alto do que o último preço negociado sugeria. Usar, em vez disso, uma ordem limitada, definida em um preço máximo específico que ela está disposta a pagar, a protege de um preço de execução inesperadamente alto. Mas, se o preço da ação se afastar do limite dela antes de haver ações suficientes disponíveis a esse preço, a ordem dela pode nem ser executada, e ela pode perder a oportunidade de comprar.

## Teste de prática

1. Qual é a principal diferença entre uma ordem a mercado e uma ordem limitada?
2. O que uma ordem a mercado prioriza, e do que ela abre mão em troca?
3. Em que tipos de situação a escolha entre ordens a mercado e limitadas se torna mais significativa, de acordo com esta lição?

## Gabarito

1. Uma ordem a mercado é executada imediatamente pelo melhor preço disponível; uma ordem limitada só é executada a um preço definido ou melhor, podendo nem ser executada.
2. Ela prioriza a velocidade e a certeza de execução, abrindo mão da certeza sobre o preço exato de execução.
3. Ativos menos líquidos, ordens de tamanho maior ou períodos de alta volatilidade, ou seja, situações em que a incerteza de preço com uma ordem a mercado se torna maior, o que se liga à discussão sobre liquidez da Lição 42.

## Respostas e explicações

1. Esta é a distinção fundamental da lição.
2. Isto esclarece a troca específica que as ordens a mercado fazem.
3. Isto liga diretamente a decisão sobre o tipo de ordem ao conceito de liquidez da lição anterior.

## Pontos-chave
- Uma ordem a mercado prioriza a velocidade e a certeza de execução em vez da certeza de preço.
- Uma ordem limitada prioriza o controle do preço, mas corre o risco de nem ser executada.
- Essa troca se torna especialmente significativa para ativos menos líquidos, ordens grandes ou condições de mercado voláteis.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
