---
id: WHITE-L3-044
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 44
title: "Por que os IPOs têm um risco próprio em comparação com empresas de capital aberto já estabelecidas"
source_title: "Why IPOs Carry Unique Risk Compared to Established Public Companies"
description: "Entenda por que comprar ações de uma empresa que acabou de abrir o capital é diferente de investir em uma empresa já estabelecida, e por que o histórico curto acrescenta uma incerteza específica."
slug: white-l3-044-ipo-risk
seo_title: "Por que os IPOs têm um risco próprio em comparação com empresas de capital aberto já estabelecidas | Edunancial"
meta_description: "Entenda por que comprar ações de uma empresa que acabou de abrir o capital é diferente de investir em uma empresa já estabelecida, e por que o histórico curto acrescenta uma incerteza específica."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-044: Por que os IPOs têm um risco próprio em comparação com empresas de capital aberto já estabelecidas

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o que é um IPO
- Explicar por que uma empresa que acabou de abrir o capital tem riscos diferentes dos de uma empresa já estabelecida
- Explicar por que é comum haver volatilidade de preço logo depois de um IPO

## Conteúdo principal

Um **IPO (Initial Public Offering, ou oferta pública inicial de ações)** é o processo pelo qual uma empresa privada vende ações ao público pela primeira vez, tornando-se uma empresa de capital aberto. Veja o "porquê" de investir em torno de um IPO ter um risco diferente de comprar uma empresa de capital aberto já estabelecida: uma empresa que acabou de abrir o capital normalmente tem um histórico público muito mais curto. Há menos dados históricos sobre como suas ações são negociadas, como a gestão se comunica com os acionistas e como o negócio se sai sob a fiscalização e as exigências de divulgação de uma empresa de capital aberto.

[VERIFIED FACT] O preço das ações em um IPO normalmente é definido com base nas projeções da própria empresa e nas avaliações dos bancos de investimento, e não em um longo período de negociação real no mercado aberto. Historicamente, as ações recém-lançadas muitas vezes tiveram uma volatilidade de preço significativa no início da negociação, à medida que o mercado como um todo forma sua própria visão independente sobre o valor da empresa, que pode ser bem diferente do preço do IPO.

Isso se liga à distinção entre volatilidade e risco da Lição 4: essa volatilidade inicial não reflete necessariamente uma mudança no negócio em si. Ela pode simplesmente refletir o processo de formação de preço do mercado funcionando com muito menos informação pública do que existe para uma empresa já estabelecida.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma empresa conclui seu IPO a um preço de oferta definido. [ASSUMPTION] Nas primeiras semanas e meses de negociação pública, a ação pode oscilar bastante acima e abaixo desse preço de oferta, à medida que diferentes investidores formam opiniões variadas sobre seu valor, com poucos dados históricos de negociação para apoiar essas visões. Um investidor que compra logo no preço do IPO fica exposto a essa volatilidade inicial de formação de preço de um jeito que um investidor que compra ações de uma empresa com anos de histórico de negociação pública normalmente não fica.

## Teste de prática

1. O que é um IPO?
2. Por que uma empresa que acabou de abrir o capital tem um risco diferente de uma empresa de capital aberto já estabelecida?
3. Por que as ações recém-lançadas muitas vezes têm uma volatilidade de preço significativa no início?

## Gabarito

1. O processo pelo qual uma empresa privada vende ações ao público pela primeira vez, tornando-se uma empresa de capital aberto.
2. Porque ela tem um histórico público muito mais curto: menos dados históricos sobre o comportamento da negociação, a comunicação da gestão e o desempenho sob as exigências de divulgação de uma empresa de capital aberto.
3. Porque o preço do IPO é definido sem um longo período de negociação pública real, e o mercado leva tempo para formar sua própria visão independente sobre o valor da empresa, que pode ser bem diferente do preço de oferta inicial.

## Respostas e explicações

1. Esta é a definição fundamental da lição.
2. Esta é a principal distinção de risco que a lição destaca.
3. Isto liga a explicação sobre volatilidade à estrutura mais ampla de volatilidade versus risco da Lição 4.

## Pontos-chave
- Um IPO é quando uma empresa privada vende ações ao público pela primeira vez.
- Empresas que acabaram de abrir o capital têm um risco próprio por causa do histórico curto de negociação pública e de informações menos testadas pelo mercado.
- A volatilidade de preço logo depois do IPO muitas vezes reflete o processo de formação de preço do mercado, e não necessariamente uma mudança no negócio em si.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
