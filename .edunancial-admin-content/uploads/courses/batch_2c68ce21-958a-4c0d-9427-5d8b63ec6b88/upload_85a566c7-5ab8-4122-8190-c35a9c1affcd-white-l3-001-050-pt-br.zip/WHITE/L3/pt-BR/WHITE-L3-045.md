---
id: WHITE-L3-045
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 45
title: "Por que a recompra de ações afeta os acionistas de forma diferente dos dividendos"
source_title: "Why Stock Buybacks Affect Shareholders Differently Than Dividends"
description: "Entenda como a recompra de ações devolve valor aos acionistas de forma diferente de um dividendo, e por que os efeitos fiscais e sobre a quantidade de ações são diferentes."
slug: white-l3-045-stock-buybacks
seo_title: "Por que a recompra de ações afeta os acionistas de forma diferente dos dividendos | Edunancial"
meta_description: "Entenda como a recompra de ações devolve valor aos acionistas de forma diferente de um dividendo, e por que os efeitos fiscais e sobre a quantidade de ações são diferentes."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-045: Por que a recompra de ações afeta os acionistas de forma diferente dos dividendos

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o que é uma recompra de ações
- Explicar como uma recompra devolve valor aos acionistas de forma diferente de um dividendo
- Explicar uma diferença importante, ligada aos impostos, entre as duas abordagens

## Conteúdo principal

Uma **recompra de ações (buyback)** acontece quando uma empresa usa seu próprio dinheiro para comprar de volta ações dela mesma no mercado, reduzindo o número total de ações em circulação. Esse é um mecanismo diferente dos pagamentos de dividendos vistos na Lição 17 para devolver valor aos acionistas.

Veja o "porquê" de o efeito de uma recompra ser diferente do de um dividendo: em vez de distribuir dinheiro diretamente aos acionistas (o que, como a Lição 17 explicou, corresponde a uma queda mais ou menos equivalente no preço da ação), a recompra reduz o número de ações em circulação. Isso significa que cada ação restante representa uma participação um pouco maior na empresa. [VERIFIED FACT] Se o valor total e o lucro da empresa continuarem os mesmos enquanto a quantidade de ações diminui, indicadores importantes por ação, como o lucro por ação, tendem a aumentar, o que pode sustentar um preço de ação mais alto, mantidas as demais condições.

Uma diferença importante, ligada aos impostos, entre as duas abordagens: um dividendo em geral gera um fato tributável imediato para o acionista que o recebe (sujeito às regras tributárias aplicáveis), enquanto uma recompra não gera diretamente um fato tributável para os acionistas que não vendem. Qualquer benefício aparece como um possível aumento no valor das ações restantes, que os acionistas só realizam (e sobre o qual podem ter que pagar imposto) se e quando decidirem vender.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma empresa tem $1 million de lucro e 1 million de ações em circulação, o que dá $1 de lucro por ação. Se ela usar o dinheiro disponível para recomprar 100,000 ações, reduzindo a quantidade para 900,000, esse mesmo lucro de $1 million passa a representar cerca de $1.11 de lucro por ação, um número maior só por causa da redução na quantidade de ações, supondo que o lucro continue o mesmo. Uma acionista que não vende nenhuma ação não recebe um pagamento imediato em dinheiro (ao contrário de um dividendo) e não enfrenta um fato tributável imediato, mas as ações que ela já tem podem passar a valer um pouco mais se o mercado valorizar os indicadores por ação melhores de acordo.

## Teste de prática

1. O que é uma recompra de ações?
2. Como o mecanismo de uma recompra para devolver valor é diferente do de um dividendo?
3. Qual é uma diferença importante, ligada aos impostos, entre uma recompra e um dividendo para um acionista que não vende?

## Gabarito

1. Uma empresa usar seu próprio dinheiro para recomprar ações dela mesma, reduzindo o número total de ações em circulação.
2. Um dividendo distribui dinheiro diretamente aos acionistas (com uma queda de preço que compensa, conforme a Lição 17); uma recompra reduz a quantidade de ações, aumentando a participação proporcional de cada ação restante sem uma distribuição direta de dinheiro.
3. Um dividendo em geral gera um fato tributável imediato para o acionista; uma recompra não gera diretamente um fato tributável para um acionista que não vende, já que qualquer benefício aparece apenas como um possível aumento de valor nas ações que ele ainda tem.

## Respostas e explicações

1. Esta é a definição fundamental da lição.
2. Esta é a principal distinção mecânica entre as duas abordagens, comparada diretamente com a Lição 17.
3. Isto destaca uma diferença prática e significativa em como e quando os acionistas são afetados pelos impostos.

## Pontos-chave
- Uma recompra de ações reduz o número de ações em circulação, aumentando a participação proporcional de cada ação restante.
- Isso é mecanicamente diferente de um dividendo, que distribui dinheiro diretamente, com um ajuste correspondente no preço.
- As recompras em geral não geram um fato tributável imediato para os acionistas que não vendem, ao contrário dos dividendos.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. As regras tributárias variam muito de país para país; consulte um profissional tributário licenciado para obter orientação específica para a sua situação.*
