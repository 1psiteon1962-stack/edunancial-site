---
id: WHITE-L3-046
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 46
title: "Por que o beta mede a volatilidade de uma ação em relação ao mercado"
source_title: "Why Beta Measures a Stock's Volatility Relative to the Market"
description: "Entenda o que o beta mede, por que um beta acima ou abaixo de 1.0 diz algo específico sobre o comportamento esperado de uma ação e o que o beta não capta."
slug: white-l3-046-beta-and-relative-volatility
seo_title: "Por que o beta mede a volatilidade de uma ação em relação ao mercado | Edunancial"
meta_description: "Entenda o que o beta mede, por que um beta acima ou abaixo de 1.0 diz algo específico sobre o comportamento esperado de uma ação e o que o beta não capta."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-046: Por que o beta mede a volatilidade de uma ação em relação ao mercado

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Definir o beta como uma medida de volatilidade relativa
- Interpretar o que um beta acima, abaixo ou igual a 1.0 em geral sugere
- Explicar uma limitação do beta como medida de risco

## Conteúdo principal

O **beta** é uma medida estatística que descreve como o preço de uma ação costuma se mover em relação ao mercado como um todo, normalmente um índice de referência. Um beta de 1.0 sugere que a ação, historicamente, se moveu mais ou menos em linha com o mercado. Um beta acima de 1.0 sugere uma volatilidade historicamente maior que a do mercado (movendo-se mais na mesma direção dos movimentos do mercado); um beta abaixo de 1.0 sugere uma volatilidade historicamente menor que a do mercado.

Veja o "porquê" de esta poder ser uma ferramenta útil, ainda que limitada: o beta oferece uma forma rápida e padronizada de comparar quão sensíveis diferentes ações foram aos movimentos gerais do mercado. Isso é útil quando você pensa em como uma ação pode contribuir para a volatilidade geral de uma carteira (o que se liga aos conceitos de diversificação e correlação das Lições 2 e 3).

[VERIFIED FACT] O beta é calculado com dados históricos de preço e reflete a volatilidade relativa do passado, e não uma garantia de comportamento futuro. Além disso, ele mede especificamente a sensibilidade aos movimentos amplos do mercado, e não o risco total de uma ação. Isso significa que duas ações com o mesmo beta ainda podem ter perfis de risco específicos da empresa (Lição 2) muito diferentes, que o beta sozinho não capta.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] A Ação A tem um beta de 1.5, o que sugere que historicamente ela se moveu cerca de 50% a mais do que o mercado em qualquer direção: se o mercado sobe 10%, a Ação A historicamente pode ter subido uns 15%, e o contrário em uma queda. A Ação B tem um beta de 0.6, o que sugere movimentos historicamente mais contidos em relação ao mercado. [ASSUMPTION] Um investidor montando uma carteira pode usar esses números históricos de beta como um dos dados para pensar em como cada ação poderia contribuir para a volatilidade geral da carteira, lembrando que o beta reflete padrões passados e não capta os riscos específicos e individuais de cada empresa, separados dos movimentos amplos do mercado.

## Teste de prática

1. O que o beta mede?
2. O que um beta acima de 1.0 em geral sugere sobre a volatilidade histórica de uma ação em relação ao mercado?
3. Que limitação esta lição aponta sobre usar o beta como uma medida completa de risco?

## Gabarito

1. Como o preço de uma ação costuma se mover em relação ao mercado como um todo, normalmente um índice de referência.
2. Que a ação historicamente se moveu com volatilidade maior que a do mercado, movendo-se mais na mesma direção dos movimentos do mercado.
3. O beta reflete especificamente a volatilidade relativa passada em relação aos movimentos amplos do mercado, e não é uma garantia de comportamento futuro; ele também não capta o risco específico da empresa, separado do mercado como um todo.

## Respostas e explicações

1. Esta é a definição fundamental da lição.
2. Isto confirma a interpretação do limite numérico específico.
3. Este é um alerta importante contra tratar o beta como uma medida completa do risco total de uma ação.

## Pontos-chave
- O beta mede a volatilidade histórica de uma ação em relação ao mercado como um todo, sendo que 1.0 representa uma volatilidade no nível do mercado.
- Um beta acima de 1.0 sugere uma volatilidade relativa historicamente maior; abaixo de 1.0, historicamente menor.
- O beta reflete padrões passados e especificamente a volatilidade ligada ao mercado: ele não capta o risco específico da empresa nem garante o comportamento futuro.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Desempenho passado não garante resultados futuros. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
