---
id: WHITE-L3-047
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 47
title: "Por que diversificar entre classes de ativos, e não só entre ações, reduz o risco da carteira"
source_title: "Why Diversifying Across Asset Classes, Not Just Stocks, Reduces Portfolio Risk"
description: "Entenda por que combinar ações com outras classes de ativos, como títulos de renda fixa ou imóveis, pode reduzir o risco geral da carteira de um jeito que diversificar só entre ações não consegue."
slug: white-l3-047-asset-class-diversification
seo_title: "Por que diversificar entre classes de ativos, e não só entre ações, reduz o risco da carteira | Edunancial"
meta_description: "Entenda por que combinar ações com outras classes de ativos, como títulos de renda fixa ou imóveis, pode reduzir o risco geral da carteira de um jeito que diversificar só entre ações não consegue."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-047: Por que diversificar entre classes de ativos, e não só entre ações, reduz o risco da carteira

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar por que diversificar entre classes de ativos enfrenta um tipo de risco que diversificar só entre ações não consegue enfrentar
- Ligar este conceito à discussão sobre correlação da Lição 3
- Explicar por que combinar ativos com padrões de comportamento historicamente diferentes pode suavizar o desempenho geral da carteira

## Conteúdo principal

As Lições 2 e 3 trataram da diversificação e da correlação dentro de uma categoria de investimentos parecidos, principalmente ações. Esta lição estende a mesma lógica a um nível mais amplo: diversificar entre **classes de ativos** totalmente diferentes, como ações, títulos de renda fixa, imóveis (os REITs da Lição 32, por exemplo), dinheiro em caixa e outras.

Veja o "porquê" de isso enfrentar um tipo de risco que a diversificação só em ações não consegue: mesmo uma carteira de ações bem diversificada, distribuída entre muitas empresas e setores, continua exposta ao risco de mercado que afeta as ações de modo geral (como mostrado na Lição 2). Uma queda geral da bolsa afeta quase todas as ações ao mesmo tempo, por mais bem diversificada que seja a seleção de ações. [VERIFIED FACT] Classes de ativos diferentes historicamente mostraram relações variadas entre si em diferentes condições de mercado, às vezes com correlação baixa ou negativa. Os títulos de renda fixa, por exemplo, em alguns momentos tiveram um desempenho diferente das ações durante quedas da bolsa, embora essa relação não seja fixa nem garantida e possa mudar dependendo do ambiente econômico específico (o que se liga à discussão sobre ciclos de juros da Lição 43 da trilha RED).

Combinar classes de ativos com padrões de comportamento realmente diferentes, em vez de diversificar só dentro de uma classe de ativos, enfrenta o risco de mercado que a diversificação só em ações especificamente não consegue reduzir.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora tem uma carteira bem diversificada de 50 ações diferentes, de muitos setores. Durante uma queda ampla da bolsa, quase todos os seus ativos caem juntos, já que a queda reflete um risco de mercado contra o qual a diversificação em ações dela, por mais completa que seja, não consegue proteger. [ASSUMPTION] Se ela também tivesse colocado uma parte da carteira em títulos de renda fixa, e esses títulos tivessem tido um desempenho diferente durante essa mesma queda (como aconteceu em alguns períodos históricos), a queda da carteira como um todo poderia ter sido bem menor do que a de uma carteira só de ações, mesmo uma que fosse extremamente bem diversificada dentro da classe de ações.

## Teste de prática

1. Que tipo de risco a diversificação entre classes de ativos enfrenta que a diversificação só entre ações não consegue enfrentar?
2. Por que mesmo uma carteira de ações muito bem diversificada ainda pode sofrer quedas significativas durante uma queda geral do mercado?
3. A relação entre o desempenho de diferentes classes de ativos durante uma queda é fixa e garantida? Por quê?

## Gabarito

1. O risco de mercado, ou seja, o risco que afeta uma classe de ativos inteira (como as ações) de modo geral, independentemente de quão diversificados sejam os ativos individuais dentro dessa classe.
2. Porque o risco de mercado afeta quase todas as ações ao mesmo tempo, e a diversificação entre ações enfrenta principalmente o risco específico de cada empresa (Lição 2), e não esse risco mais amplo, no nível do mercado.
3. Não. O desempenho relativo de diferentes classes de ativos em várias condições de mercado variou ao longo da história e não é fixo nem garantido, então esse benefício deve ser entendido como uma tendência histórica, e não como um resultado garantido.

## Respostas e explicações

1. Esta é a distinção central em torno da qual a lição foi construída, estendendo a estrutura das Lições 2 e 3 a uma escala mais ampla.
2. Isto reforça diretamente o conceito de risco de mercado apresentado pela primeira vez na Lição 2.
3. Esta é uma ressalva importante, com o devido cuidado, contra confiar demais nas relações históricas entre classes de ativos.

## Pontos-chave
- Diversificar entre classes de ativos enfrenta o risco de mercado que diversificar só dentro de uma classe de ativos (como as ações) não consegue enfrentar.
- Classes de ativos diferentes historicamente mostraram correlação variada entre si em diferentes condições, às vezes baixa ou negativa.
- Essa relação não é fixa nem garantida e pode mudar dependendo do ambiente econômico mais amplo.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Desempenho passado não garante resultados futuros. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
