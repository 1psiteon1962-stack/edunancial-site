---
id: WHITE-L3-048
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 48
title: "Por que o tamanho da posição determina o quanto uma única aposta ruim pode prejudicar você"
source_title: "Why Position Sizing Determines How Much a Single Bad Bet Can Hurt You"
description: "Entenda por que o quanto você investe em cada posição importa tanto quanto a posição ser uma boa ideia, e por que o tamanho da posição é uma forma de controle de risco."
slug: white-l3-048-position-sizing
seo_title: "Por que o tamanho da posição determina o quanto uma única aposta ruim pode prejudicar você | Edunancial"
meta_description: "Entenda por que o quanto você investe em cada posição importa tanto quanto a posição ser uma boa ideia, e por que o tamanho da posição é uma forma de controle de risco."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-048: Por que o tamanho da posição determina o quanto uma única aposta ruim pode prejudicar você

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o que significa tamanho da posição
- Explicar por que uma boa ideia de investimento ainda pode prejudicar uma carteira se a posição for grande demais
- Ligar este conceito à ideia de dimensionar o risco com frações de ações usada em outras partes deste currículo

## Conteúdo principal

O **tamanho da posição** é a parte da carteira destinada a cada investimento individual. Essa é uma decisão diferente de *quais* investimentos escolher: mesmo uma ideia de investimento excelente pode criar um risco desproporcional para a carteira se uma parte grande demais do capital total for colocada nela.

Veja o "porquê" de o tamanho da posição funcionar como uma forma própria de controle de risco, separada da qualidade da escolha do investimento: nenhuma tese de investimento, por mais bem pesquisada que seja, tem garantia de dar certo. Acontecimentos inesperados, informações novas ou simples azar podem afetar até uma posição escolhida com cuidado. Se essa posição representa uma parte pequena da carteira, um resultado decepcionante é um revés administrável. Se ela representa uma parte muito grande, o mesmo resultado decepcionante pode prejudicar bastante a carteira inteira, por mais sólido que fosse o raciocínio original.

[VERIFIED FACT] Isso se liga a um princípio mais amplo usado em outras partes deste currículo: estruturar o risco de forma que as perdas sejam reais e sentidas, ensinando lições de verdade, mas nunca catastróficas para a situação financeira como um todo. O tamanho da posição é uma das ferramentas mais diretas e controláveis que um investidor tem para manter o possível prejuízo de cada posição dentro de um limite tolerável.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora identifica o que acredita ser uma ótima oportunidade de investimento depois de uma pesquisa cuidadosa. Colocar 5% da carteira nessa ideia significa que, se ela der errado (mesmo com perda total nessa posição), o estrago na carteira como um todo é limitado e recuperável. [ASSUMPTION] Colocar 50% da carteira na mesma ideia, com base na mesma pesquisa e na mesma convicção, significa que esse mesmo resultado ruim poderia atrasar bastante toda a situação financeira dela. A qualidade da ideia não mudou, mas o tamanho da posição mudou radicalmente o quanto aquele resultado específico poderia prejudicá-la.

## Teste de prática

1. O que é o tamanho da posição?
2. Por que mesmo uma ideia de investimento bem pesquisada ainda pode criar um risco desproporcional para a carteira?
3. Como o tamanho da posição funciona como uma ferramenta de controle de risco, separada da escolha do investimento?

## Gabarito

1. A parte da carteira destinada a cada investimento individual.
2. Porque nenhuma tese de investimento tem garantia de dar certo, e se uma posição com mau desempenho representa uma parte grande demais da carteira, o estrago resultante pode ser significativo, por mais sólido que fosse o raciocínio original.
3. Ao limitar o quanto o resultado de cada posição, bom ou ruim, pode afetar a carteira como um todo, o tamanho da posição controla diretamente o possível prejuízo, independentemente da qualidade da escolha do investimento em si.

## Respostas e explicações

1. Esta é a definição fundamental da lição.
2. Esta é a ideia central de gestão de risco em torno da qual a lição foi construída.
3. Isto reforça que o tamanho da posição e a escolha do investimento são duas decisões separadas, ambas importantes.

## Pontos-chave
- O tamanho da posição determina quanto da carteira vai para cada investimento individual.
- Mesmo uma ideia bem pesquisada pode causar um estrago desproporcional na carteira se a posição for grande demais, seja qual for o raciocínio por trás dela.
- O tamanho da posição é uma ferramenta direta e controlável de gestão de risco, separada da qualidade da escolha do investimento em si.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
