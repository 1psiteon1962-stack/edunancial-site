---
id: WHITE-L3-049
locale: pt-BR
source_locale: en-US
track: WHITE
level: 3
lesson: 49
title: "Por que um plano de investimento por escrito protege você das suas próprias emoções"
source_title: "Why a Written Investment Plan Protects You From Your Own Emotions"
description: "Entenda por que escrever o seu plano de investimento com antecedência protege contra os erros comportamentais vistos ao longo desta trilha, cometidos no calor do momento."
slug: white-l3-049-written-investment-plan
seo_title: "Por que um plano de investimento por escrito protege você das suas próprias emoções | Edunancial"
meta_description: "Entenda por que escrever o seu plano de investimento com antecedência protege contra os erros comportamentais vistos ao longo desta trilha, cometidos no calor do momento."
author: "Waldemar M. Caban, JD MA"
---

# WHITE-L3-049: Por que um plano de investimento por escrito protege você das suas próprias emoções

## Objetivos de aprendizagem
Ao final desta lição, você será capaz de:
- Explicar o propósito geral de um plano de investimento por escrito
- Explicar por que decidir as coisas com antecedência protege contra decisões emocionais no calor do momento
- Resumir como isso reúne vários conceitos comportamentais vistos anteriormente nesta trilha

## Conteúdo principal

Esta trilha tratou de várias formas específicas pelas quais a emoção e a psicologia podem distorcer as decisões de investimento: a aversão à perda (Lição 27), o viés de recência (Lição 28), a busca por desempenho (Lição 25) e a lacuna de comportamento mais ampla que, juntos, eles criam (Lição 26). Um **plano de investimento por escrito**, às vezes chamado de investment policy statement (declaração de política de investimentos), é uma ferramenta prática criada para combater todos eles de uma vez.

Veja o "porquê" de escrever um plano com antecedência importar: decisões tomadas com calma, com antecedência, antes que um acontecimento específico do mercado tenha provocado uma reação emocional, tendem a ser mais coerentes com os objetivos reais de longo prazo do investidor do que decisões tomadas por reação, no meio de uma queda estressante ou de uma alta empolgante. Um plano por escrito, que define a alocação de ativos desejada (Lição 34), as regras de rebalanceamento (Lição 14) e os critérios gerais para comprar ou vender, dá ao investidor um ponto de referência combinado de antemão ao qual voltar, em vez de improvisar uma resposta enquanto as emoções estão à flor da pele.

[VERIFIED FACT] Essa abordagem não elimina a experiência emocional da volatilidade do mercado, mas pode reduzir a chance de agir com base nessa emoção de formas que contrariem os objetivos e a estratégia que o próprio investidor definiu antes, com calma e reflexão.

## Exemplo prático

[ILLUSTRATIVE EXAMPLE] Uma investidora escreve um plano de investimento durante um período tranquilo, definindo a alocação de ativos desejada, um plano de rebalancear uma vez por ano e os critérios que vai usar antes de fazer qualquer mudança significativa na estratégia. [ASSUMPTION] Meses depois, durante uma queda forte do mercado, ela sente uma vontade enorme de vender tudo e ficar em dinheiro. Voltar ao plano por escrito (criado antes desse momento emocional específico) a lembra do raciocínio original de longo prazo e das regras de rebalanceamento, o que pode ajudá-la a evitar uma decisão por reação que a versão mais calma e anterior dela já tinha previsto e planejado resistir.

## Teste de prática

1. Qual é o propósito geral de um plano de investimento por escrito?
2. Por que as decisões tomadas com calma e com antecedência tendem a ser mais coerentes com os objetivos de longo prazo do que as decisões por reação, no calor do momento?
3. Cite dois conceitos comportamentais específicos, vistos anteriormente nesta trilha, que um plano por escrito foi criado para ajudar a combater.

## Gabarito

1. Servir como um ponto de referência combinado de antemão, que define a alocação desejada do investidor, as regras de rebalanceamento e os critérios de decisão, ajudando a orientar o comportamento de forma consistente ao longo do tempo.
2. Porque as decisões por reação tomadas durante um acontecimento estressante ou empolgante do mercado têm mais chance de ser influenciadas pela emoção (aversão à perda, viés de recência) do que pelos objetivos reais de longo prazo do investidor, pensados com calma.
3. Quaisquer dois entre: aversão à perda, viés de recência, busca por desempenho, a lacuna de comportamento mais ampla.

## Respostas e explicações

1. Este é o propósito fundamental em torno do qual a lição foi construída.
2. Este é o raciocínio psicológico central por trás do valor de planejar com antecedência.
3. Isto verifica se o leitor consegue reunir conceitos de várias lições anteriores nesta ferramenta final e integradora.

## Pontos-chave
- Um plano de investimento por escrito serve como um ponto de referência combinado de antemão para a alocação, o rebalanceamento e os critérios de decisão.
- As decisões tomadas com calma e com antecedência tendem a ser mais coerentes com os objetivos de longo prazo do que as decisões por reação, movidas pela emoção.
- Essa ferramenta enfrenta diretamente vários conceitos comportamentais vistos ao longo desta trilha, incluindo a aversão à perda, o viés de recência e a busca por desempenho.

---

*Esta lição tem fins exclusivamente de educação financeira geral e não constitui aconselhamento financeiro, de investimentos, tributário ou jurídico personalizado. Consulte um profissional financeiro licenciado antes de tomar decisões de investimento.*
