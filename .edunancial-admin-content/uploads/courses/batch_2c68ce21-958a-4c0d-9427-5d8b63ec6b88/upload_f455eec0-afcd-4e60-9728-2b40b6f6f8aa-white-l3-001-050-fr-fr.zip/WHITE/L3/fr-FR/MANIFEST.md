# WHITE-L3 — fr-FR (Français, France) — Manifeste

Leçons : WHITE-L3-001 à WHITE-L3-050 (50/50)
Langue : fr-FR | Source : en-US (version maîtresse anglaise WHITE-L3)
Auteur : Waldemar M. Caban, JD MA
Format : 7 sections (Objectifs d'apprentissage, Contenu principal, Exemple pratique, Quiz d'entraînement, Corrigé, Réponses et explications, Points clés) + avertissement éducatif en pied de page

## Vérification
- 50 fichiers avec front matter (id, locale, source_title, slug anglais conservé, champs SEO) et les 7 sections dans l'ordre fixe.
- Nombre de questions du quiz vérifié par rapport à la leçon source ; étiquettes de contenu ([VERIFIED FACT], [ILLUSTRATIVE EXAMPLE], [ASSUMPTION]) conservées en anglais et comptées.
- Traduction, non localisation : termes et dispositifs américains conservés (401(k), IRA, Roth IRA, IRS, ETF, S&P 500, P/E, REIT, IPO) et expliqués à la première occurrence ; montants en $ au format français (10 000 $, 0,05 %). L'avertissement de chaque leçon est traduit selon sa propre variante.
- Registre : « vous », niveau de lecture 7e–8e année (É.-U.). Relecture par un locuteur natif recommandée avant publication.
