# RED-L3 — nl (Nederlands) — Manifest

Lessen: RED-L3-001 t/m RED-L3-050 (50/50)
Taal: nl | Bron: en-US (Engelse masterversie RED-L3)
Auteur: Waldemar M. Caban, JD MA
Formaat: 7 secties (Leerdoelen, Kerninhoud, Uitgewerkt voorbeeld, Oefenquiz, Antwoordsleutel, Antwoorden en uitleg, Belangrijkste punten) + educatieve disclaimer onderaan

## Controle
- 50 bestanden met front matter (id, locale, source_title, Engelse slug behouden, SEO-velden) en de 7 secties in vaste volgorde.
- Aantal quizvragen gecontroleerd tegen de bronles; inhoudslabels ([VERIFIED FACT], [ILLUSTRATIVE EXAMPLE], [ESTIMATE], [ASSUMPTION], [HYPOTHETICAL ...]) in het Engels behouden en geteld.
- Vertaling, geen lokalisatie: Amerikaanse termen en regelingen behouden (1031, IRS, W-2, LLC, HELOC, DSCR, DTI, LTV, ARM, BRRRR, escrow) en bij eerste gebruik uitgelegd; $-bedragen zoals in de bron.
- Register: ‘je’, leesniveau groep 7–8 (VS: grade 7–8). Controle door een moedertaalspreker aanbevolen vóór publicatie.
