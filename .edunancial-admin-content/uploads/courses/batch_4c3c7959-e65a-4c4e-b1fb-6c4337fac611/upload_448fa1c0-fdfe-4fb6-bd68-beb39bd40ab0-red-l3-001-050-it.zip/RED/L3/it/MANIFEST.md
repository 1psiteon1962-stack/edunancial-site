# RED-L3 — it (Italiano) — Manifesto

Lezioni: da RED-L3-001 a RED-L3-050 (50/50)
Lingua: it | Fonte: en-US (versione master inglese RED-L3)
Autore: Waldemar M. Caban, JD MA
Formato: 7 sezioni (Obiettivi di apprendimento, Contenuto principale, Esempio pratico, Quiz di esercitazione, Chiave delle risposte, Risposte e spiegazioni, Punti chiave) + avvertenza educativa a piè di pagina

## Verifica
- 50 file con front matter (id, locale, source_title, slug inglese mantenuto, campi SEO) e le 7 sezioni in ordine fisso.
- Numero di domande del quiz verificato rispetto alla lezione originale; etichette di contenuto ([VERIFIED FACT], [ILLUSTRATIVE EXAMPLE], [ESTIMATE], [ASSUMPTION], [HYPOTHETICAL ...]) mantenute in inglese e contate.
- Traduzione, non localizzazione: termini e programmi USA mantenuti (1031, IRS, W-2, LLC, HELOC, DSCR, DTI, LTV, ARM, BRRRR, escrow) e spiegati al primo uso; importi in $ come nell'originale.
- Registro: «tu», livello di lettura 7ª–8ª classe (USA). Si consiglia revisione da parte di un madrelingua prima della pubblicazione.
