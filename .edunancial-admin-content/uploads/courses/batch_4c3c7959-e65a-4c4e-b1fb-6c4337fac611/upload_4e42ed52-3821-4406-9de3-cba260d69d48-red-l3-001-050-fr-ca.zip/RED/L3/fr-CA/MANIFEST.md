# RED-L3 — fr-CA (Français, Canada) — Manifeste

Leçons : RED-L3-001 à RED-L3-050 (50/50)
Langue : fr-CA | Source : en-US (version maîtresse anglaise RED-L3), adaptée à partir de la version fr-FR vérifiée
Auteur : Waldemar M. Caban, JD MA
Format : 7 sections (Objectifs d'apprentissage, Contenu principal, Exemple pratique, Quiz d'entraînement, Corrigé, Réponses et explications, Points clés) + avertissement éducatif en pied de page

## Vérification
- 50 fichiers avec front matter (id, locale, source_title, slug anglais conservé, champs SEO) et les 7 sections dans l'ordre fixe.
- Nombre de questions du quiz vérifié par rapport à la leçon source; étiquettes de contenu ([VERIFIED FACT], [ILLUSTRATIVE EXAMPLE], [ESTIMATE], [ASSUMPTION], [HYPOTHETICAL ...]) conservées en anglais et comptées.
- Traduction, non localisation : termes et programmes américains conservés (1031, IRS, W-2, LLC, HELOC, DSCR, DTI, LTV, ARM, BRRRR, escrow) et expliqués à la première occurrence; montants en $ (150 000 $, 1,18).
- Terminologie québécoise : prêt hypothécaire, versement, mise de fonds, valeur nette, taux d'inoccupation, immeuble à revenus, placement, marge de crédit, reprise de finance, compte en fidéicommis, impôt foncier.
- Registre : « vous », niveau de lecture 7e–8e année (É.-U.). Relecture par un locuteur natif recommandée avant publication.
