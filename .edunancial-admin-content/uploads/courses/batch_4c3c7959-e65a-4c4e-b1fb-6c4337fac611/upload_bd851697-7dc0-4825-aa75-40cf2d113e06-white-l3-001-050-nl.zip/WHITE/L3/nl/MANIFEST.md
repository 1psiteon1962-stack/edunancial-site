# WHITE-L3 — nl (Nederlands) — Manifest

Lessen: WHITE-L3-001 t/m WHITE-L3-050 (50/50)
Taal: nl | Bron: en-US (Engelse masterversie WHITE-L3)
Auteur: Waldemar M. Caban, JD MA
Formaat: 7 secties (Leerdoelen, Kerninhoud, Uitgewerkt voorbeeld, Oefenquiz, Antwoordsleutel, Antwoorden en uitleg, Belangrijkste punten) + educatieve disclaimer onderaan

## Controle
- 50 bestanden met front matter (id, locale, source_title, Engelse slug behouden, SEO-velden) en de 7 secties in vaste volgorde.
- Aantal quizvragen gecontroleerd tegen de bronles; inhoudslabels ([VERIFIED FACT], [ILLUSTRATIVE EXAMPLE], [ASSUMPTION]) in het Engels behouden en geteld.
- Vertaling, geen lokalisatie: Amerikaanse termen en producten behouden (401(k), IRA, Roth IRA, IRS, ETF, S&P 500, P/E, REIT, IPO) en bij eerste gebruik uitgelegd; $-bedragen zoals in de bron. De disclaimer van elke les is vertaald volgens de eigen variant.
- Register: ‘je’, leesniveau VS grade 7–8. Controle door een moedertaalspreker aanbevolen vóór publicatie.
