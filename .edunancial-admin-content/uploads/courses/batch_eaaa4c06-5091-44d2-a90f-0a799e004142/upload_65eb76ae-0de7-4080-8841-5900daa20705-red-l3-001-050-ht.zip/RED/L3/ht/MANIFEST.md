# RED-L3 — ht (Kreyòl ayisyen) — Manifès

Leson: RED-L3-001 rive RED-L3-050 (50/50)
Lang: ht | Sous: en-US (vèsyon mèt angle RED-L3)
Otè: Waldemar M. Caban, JD MA
Fòma: 7 seksyon (Objektif aprantisaj, Kontni prensipal, Egzanp pratik, Egzamen pratik, Kle repons yo, Repons ak eksplikasyon, Pwen kle yo) + avètisman edikatif anba paj la

## Verifikasyon
- 50 fichye ak front matter (id, locale, source_title, slug angle kenbe, chan SEO) ak 7 seksyon yo nan lòd fiks.
- Kantite kesyon egzamen pratik yo verifye kont leson orijinal la; etikèt kontni yo ([VERIFIED FACT], [ILLUSTRATIVE EXAMPLE], [ESTIMATE], [ASSUMPTION], [HYPOTHETICAL ...]) rete an angle epi yo konte yo.
- Tradiksyon, pa lokalizasyon: tèm ak pwogram Etazini yo rete (1031, IRS, W-2, LLC, HELOC, DSCR, DTI, LTV, ARM, BRRRR, escrow) epi yo eksplike yo premye fwa yo parèt; montan an $ rete jan yo ye nan sous la.
- Rejis: « ou », nivo lekti 7yèm–8yèm ane (Etazini). Nou rekòmande yon revizyon pa yon moun ki pale kreyòl natifnatal anvan piblikasyon.
