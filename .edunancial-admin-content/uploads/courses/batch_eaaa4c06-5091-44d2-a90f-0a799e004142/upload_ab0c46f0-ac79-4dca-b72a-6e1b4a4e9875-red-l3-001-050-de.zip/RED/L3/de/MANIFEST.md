# RED-L3 — de (Deutsch) — Manifest

Lektionen: RED-L3-001 bis RED-L3-050 (50/50)
Sprache: de | Quelle: en-US (englische Master-Version RED-L3)
Autor: Waldemar M. Caban, JD MA
Format: 7 Abschnitte (Lernziele, Hauptinhalt, Durchgerechnetes Beispiel, Übungsquiz, Lösungsschlüssel, Antworten und Erklärungen, Das Wichtigste in Kürze) + Bildungshinweis in der Fußzeile

## Prüfung
- 50 Dateien mit Front Matter (id, locale, source_title, englischer Slug beibehalten, SEO-Felder) und den 7 Abschnitten in fester Reihenfolge.
- Anzahl der Quizfragen gegen die Originallektion geprüft; Inhaltslabels ([VERIFIED FACT], [ILLUSTRATIVE EXAMPLE], [ESTIMATE], [ASSUMPTION], [HYPOTHETICAL ...]) auf Englisch belassen und gezählt.
- Übersetzung, keine Lokalisierung: US-Begriffe und -Programme beibehalten (1031, IRS, W-2, LLC, HELOC, DSCR, DTI, LTV, ARM, BRRRR, Escrow) und beim ersten Vorkommen erklärt; $-Beträge wie im Original.
- Anrede: „du“, Leseniveau Klasse 7–8 (USA). Vor der Veröffentlichung wird eine Durchsicht durch Muttersprachler empfohlen.
