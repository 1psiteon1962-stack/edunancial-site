# RED-L3 — pt-BR (Português, Brasil) — Manifesto

Lições: de RED-L3-001 a RED-L3-050 (50/50)
Idioma: pt-BR | Fonte: en-US (versão mestre em inglês do RED-L3)
Autor: Waldemar M. Caban, JD MA
Formato: 7 seções (Objetivos de aprendizagem, Conteúdo principal, Exemplo prático, Teste de prática, Gabarito, Respostas e explicações, Pontos-chave) + aviso educacional no rodapé

## Verificação
- 50 arquivos, cada um com front matter (id, locale, source_title, slug em inglês mantido, campos de SEO) e as 7 seções na ordem fixa.
- Perguntas de prática, gabarito e explicações correspondem uma a uma à lição original (quantidade de perguntas verificada).
- Rótulos de conteúdo ([VERIFIED FACT], [ILLUSTRATIVE EXAMPLE], [ESTIMATE], [ASSUMPTION], [HYPOTHETICAL ...]) mantidos em inglês e contados contra a fonte.
- Tradução, não localização: termos e programas dos EUA mantidos (1031, IRS, W-2, LLC, HELOC, DSCR, DTI, LTV, ARM, BRRRR, escrow), explicados em português na primeira ocorrência; valores em $ como exemplos.
- Notas de terminologia: "financiamento"/"prestação" para mortgage/payment; "entrada" para down payment; "patrimônio" para equity; "vacância"; "taxa de capitalização" para cap rate; "gravame" para lien; "execução do imóvel" para foreclosure; "dação em pagamento" para deed-in-lieu; "duplex" = imóvel de duas unidades.
- Registro: "você", nível de leitura do 7º ao 8º ano. Recomenda-se revisão por falante nativo antes da publicação.
