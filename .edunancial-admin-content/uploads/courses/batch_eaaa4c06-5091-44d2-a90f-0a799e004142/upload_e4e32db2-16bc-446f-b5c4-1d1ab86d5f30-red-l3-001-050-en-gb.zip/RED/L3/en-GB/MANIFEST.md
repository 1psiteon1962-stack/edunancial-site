# RED-L3 — en-GB (English, United Kingdom) — Manifest

Lessons: RED-L3-001 to RED-L3-050 (50/50)
Locale: en-GB | Source: en-US (RED-L3 English master)
Author: Waldemar M. Caban, JD MA
Format: 7 sections (Learning Objectives, Core Content, Worked Example, Practice Quiz, Answer Key, Answers and Explanations, Key Takeaways) + educational disclaimer footer

## Verification
- 50 files, each with front matter (id, locale, source_title, English slug kept, SEO fields) and all 7 sections in locked order.
- Quiz questions, answer key, and explanations match the source lesson one-to-one.
- Content labels ([VERIFIED FACT], [ILLUSTRATIVE EXAMPLE], [ESTIMATE], [ASSUMPTION], [OPINION], [REGION-SPECIFIC RULE]) preserved exactly, count-checked against source.
- Conversion scope: British spelling (-ise/-isation, favour, neighbourhood, programme for schemes, modelled) and minimal vocabulary (holiday for vacation). Translation, not localisation: US loan programmes, dollar amounts, and US legal/tax terms are kept as in the source, and remain flagged [REGION-SPECIFIC RULE] where the source flags them.
