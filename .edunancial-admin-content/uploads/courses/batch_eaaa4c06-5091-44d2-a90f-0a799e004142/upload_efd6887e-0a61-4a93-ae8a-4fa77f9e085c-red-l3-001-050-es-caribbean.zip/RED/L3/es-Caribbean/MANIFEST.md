# RED-L3 — es-Caribbean (Español, Caribe) — Manifiesto

Lecciones: de RED-L3-001 a RED-L3-050 (50/50)
Idioma: es-Caribbean | Fuente: en-US (maestro en inglés de RED-L3)
Autor: Waldemar M. Caban, JD MA
Formato: 7 secciones (Objetivos de aprendizaje, Contenido principal, Ejemplo práctico, Prueba de práctica, Clave de respuestas, Respuestas y explicaciones, Puntos clave) + nota educativa al pie

## Verificación
- 50 archivos, cada uno con front matter (id, locale, source_title, slug en inglés mantenido, campos SEO) y las 7 secciones en el orden fijo.
- Preguntas de práctica, clave de respuestas y explicaciones coinciden una a una con la lección fuente (número de preguntas verificado).
- Etiquetas de contenido ([VERIFIED FACT], [ILLUSTRATIVE EXAMPLE], [ESTIMATE], [ASSUMPTION], [HYPOTHETICAL ...]) mantenidas en inglés y contadas contra la fuente.
- Traducción, no localización: se mantienen los términos y programas de EE. UU. (1031, IRS, W-2, LLC, HELOC, DSCR, DTI, LTV, ARM, BRRRR), explicados en español la primera vez; montos en $ como ejemplos.
- Notas terminológicas: "contribución sobre la propiedad" para property tax (uso caribeño); "carro"; "pago inicial" para down payment; "tasa de capitalización" para cap rate; "gravamen" para lien; "ejecución hipotecaria" para foreclosure; "dación en pago" para deed-in-lieu.
- Registro: "tú" informal, nivel de lectura de 7.º a 8.º grado. Se recomienda revisión por un hablante nativo antes de publicar.
