# RED-L3 — fr-FR (Français, France) — Manifeste

Leçons : RED-L3-001 à RED-L3-050 (50/50)
Langue : fr-FR | Source : en-US (version maîtresse anglaise RED-L3)
Auteur : Waldemar M. Caban, JD MA
Format : 7 sections (Objectifs d'apprentissage, Contenu principal, Exemple pratique, Quiz d'entraînement, Corrigé, Réponses et explications, Points clés) + avertissement éducatif en pied de page

## Vérification
- 50 fichiers avec front matter (id, locale, source_title, slug anglais conservé, champs SEO) et les 7 sections dans l'ordre fixe.
- Nombre de questions du quiz vérifié par rapport à la leçon source ; étiquettes de contenu ([VERIFIED FACT], [ILLUSTRATIVE EXAMPLE], [ESTIMATE], [ASSUMPTION], [HYPOTHETICAL ...]) conservées en anglais et comptées.
- Traduction, non localisation : termes et programmes américains conservés (1031, IRS, W-2, LLC, HELOC, DSCR, DTI, LTV, ARM, BRRRR, escrow) et expliqués à la première occurrence ; montants en $ conservés (format français : 150 000 $, 1,18).
- Registre : « vous », niveau de lecture 7e–8e année (US). Relecture par un locuteur natif recommandée avant publication.
