---
id: BLACK-L2-001
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 1
title: "De l'exécutant au leader : la première interaction entre les pièces"
summary: "Vois comment le passage de contributeur individuel à leader touche à la fois tes activités, ta mesure du succès et tes relations avec tes anciens collègues."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-001
### De l'exécutant au leader : la première interaction entre les pièces

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer comment le passage de contributeur individuel à leader touche plusieurs pièces à la fois, en écho à la leçon d'ouverture de chaque couleur précédente.
- Nommer au moins trois aspects que cette transition touche souvent.
- Appliquer la pensée de niveau 2 « qu'est-ce que ce geste touche d'autre? » à une transition vers le leadership.

**2. Contenu principal**
Le niveau 1 a présenté des notions de leadership une à une — la gestion, l'autorité, les équipes — comme des pièces séparées. Le niveau 2 commence, comme dans chaque couleur, en observant ce qui arrive au reste de l'échiquier quand une personne passe de faire le travail elle-même à diriger d'autres personnes qui le font.

Pense à une contributrice individuelle très performante qui obtient, pour la première fois, un poste de leadership. Cette seule transition touche plusieurs pièces à la fois : ses activités quotidiennes passent de l'exécution personnelle des tâches à l'orientation, à l'accompagnement et à la prise de décisions au nom des autres (approfondi à la leçon 2 avec la distinction entre gestion et leadership); sa mesure du succès passe de son rendement personnel au rendement de l'équipe, une mesure vraiment différente qui exige un autre état d'esprit; et ses relations avec d'anciens collègues qui relèvent maintenant d'elle changent d'une façon qui demande une attention volontaire et réfléchie, plutôt que de supposer que les anciennes relations entre pairs continuent sans changement.

C'est la même discipline « qu'est-ce que ce geste touche d'autre? » bâtie dans le niveau 2 de chaque couleur précédente, maintenant appliquée directement à la transition vers le leadership. BLACK-L2 examine les compétences nécessaires pour diriger des personnes et des organisations — une compétence distincte des compétences techniques ou fonctionnelles qui donnent souvent à quelqu'un l'occasion de diriger au départ.

**3. Exemple pratique**
Promue de meilleure vendeuse à cheffe d'équipe des ventes, une nouvelle gestionnaire continue d'abord de passer la plupart de son temps à conclure elle-même des ventes, l'activité qui lui a valu sa promotion, au lieu de consacrer son temps à accompagner les nouveaux membres de son équipe (en écho à la distinction de la leçon 2). Elle se rend vite compte que cette transition exige plus qu'un changement de titre : ses activités quotidiennes, sa mesure du succès et ses relations avec ses anciens collègues demandent toutes une attention volontaire, plutôt que de supposer que ce qui l'a fait réussir comme contributrice individuelle la fera automatiquement réussir comme leader.

**4. Quiz de pratique**
1. Selon cette leçon, lequel des éléments suivants N'EST PAS une des pièces que touche souvent le passage d'exécutant à leader?
   a) Les activités quotidiennes et la mesure du succès
   b) Les relations avec les anciens collègues
   c) L'endroit préféré pour dîner
   d) Le rendement de l'équipe par rapport au rendement personnel
2. Vrai ou faux : Les compétences qui font de quelqu'un un excellent contributeur individuel se transfèrent automatiquement et entièrement pour en faire un excellent leader.
3. Pourquoi l'approche initiale de la nouvelle gestionnaire des ventes était-elle insuffisante?
   a) Elle a immédiatement consacré tout son temps à accompagner son équipe
   b) Elle a continué d'exécuter les tâches elle-même au lieu de passer à l'orientation et à l'accompagnement qu'exigeait son nouveau rôle
   c) Le leadership en vente n'exige aucune compétence différente de l'exécution des ventes
   d) Aucun ancien collègue ne relevait maintenant d'elle
4. Quelle est la compétence clé de niveau 2 que bâtit cette leçon, en écho à la leçon d'ouverture de chaque couleur précédente?
   a) Mémoriser une seule formule de leadership
   b) Se demander « qu'est-ce que ce geste touche d'autre? » avant d'agir
   c) Éviter complètement toute transition vers le leadership
   d) Ignorer le rendement de l'équipe comme mesure du succès

**5. Corrigé**
1. c  2. Faux  3. b  4. b

**6. Réponses et explications**
1. L'endroit préféré pour dîner n'a aucun lien avec cette transition; les trois autres sont des pièces directement touchées.
2. Les compétences de contributeur individuel ne se transfèrent pas automatiquement au leadership; la transition exige des compétences distinctes développées tout au long de ce niveau.
3. Le fait que la nouvelle gestionnaire continue d'exécuter les tâches elle-même montrait qu'elle n'avait pas encore fait le passage à l'orientation et à l'accompagnement qu'exigeait vraiment son rôle de leader.
4. Cette leçon renforce la même habitude de pensée à plusieurs pièces bâtie dans le niveau 2 de chaque couleur précédente.

**7. Points clés à retenir**
- Le passage d'exécutant à leader touche en même temps les activités quotidiennes, la mesure du succès et les relations avec les anciens collègues.
- Un excellent rendement comme contributeur individuel ne se transfère pas automatiquement en un excellent leadership.
- BLACK-L2 examine les compétences distinctes nécessaires pour diriger des personnes et des organisations, et non les compétences techniques qui donnent souvent l'occasion de diriger.
- Cette leçon renforce la même habitude de pensée à plusieurs pièces bâtie dans le niveau 2 de chaque couleur précédente.
