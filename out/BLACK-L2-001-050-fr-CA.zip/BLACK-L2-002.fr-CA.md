---
id: BLACK-L2-002
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 2
title: "Gestion ou leadership : une distinction essentielle"
summary: "Distingue la gestion, qui organise le travail connu, du leadership, qui donne une direction et guide le changement, et vois pourquoi les deux sont nécessaires."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-002
### Gestion ou leadership : une distinction essentielle

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Distinguer de façon conceptuelle la gestion du leadership.
- Expliquer pourquoi les deux fonctions sont nécessaires, et non concurrentes.
- Appliquer cette distinction à une situation de travail hypothétique.

**2. Contenu principal**
La gestion consiste généralement à organiser les ressources, les processus et les personnes pour atteindre efficacement des objectifs définis et existants — planifier, coordonner et suivre l'exécution d'un travail connu. Le leadership consiste généralement à donner une direction, à inspirer et à influencer les personnes vers une vision, et à traverser le changement et l'incertitude — une fonction distincte, même si elle chevauche souvent celle de la gestion, qui est plus opérationnelle et axée sur l'exécution.

Ce ne sont pas des fonctions concurrentes dont l'une serait supérieure par nature; la plupart des personnes efficaces en position d'autorité combinent les deux, en appliquant leurs compétences de gestion pour que les activités courantes se déroulent efficacement, et leurs compétences de leadership pour donner une direction, bâtir la confiance (approfondi à la leçon 9) et traverser le type de changement organisationnel (approfondi à la leçon 35) que la seule gestion opérationnelle ne règle pas. Une personne peut être une gestionnaire compétente sans être une leader efficace, et inversement, mais les postes les plus solides d'une organisation exigent habituellement de développer les deux capacités.

**3. Exemple pratique**
En faisant le point sur son propre rôle, un directeur de service constate qu'il excelle dans la dimension gestion de son travail — organiser efficacement les processus existants de son équipe et en suivre l'exécution — mais qu'il néglige la dimension leadership : donner une direction motivante sur la prochaine étape de son service et bâtir le genre de confiance qui aiderait son équipe à traverser un changement organisationnel à venir. Reconnaissant que les deux dimensions sont nécessaires, et non concurrentes, il commence à développer volontairement sa capacité de leadership en plus de ses compétences de gestion déjà solides.

**4. Quiz de pratique**
1. En quoi consiste généralement la gestion?
   a) Donner une direction et inspirer les personnes vers une vision
   b) Organiser les ressources, les processus et les personnes pour atteindre efficacement des objectifs définis et existants
   c) Un type de crédit d'impôt
   d) Une notion identique au leadership, sans aucune distinction
2. En quoi consiste généralement le leadership, par rapport à la gestion?
   a) Uniquement des activités opérationnelles axées sur l'exécution
   b) Donner une direction, inspirer et influencer les personnes, et traverser le changement et l'incertitude
   c) Une notion sans lien avec l'orientation de l'organisation
   d) Uniquement le suivi des processus existants
3. Vrai ou faux : La gestion et le leadership sont des fonctions concurrentes, et développer l'une se fait forcément au détriment de l'autre.
4. Pourquoi le directeur de service a-t-il reconnu une lacune dans ses propres capacités?
   a) Il avait déjà pleinement développé la gestion et le leadership
   b) Il excellait en gestion, mais négligeait la dimension leadership qui consiste à donner une direction et à bâtir la confiance
   c) La gestion et le leadership sont identiques et n'exigent aucun développement distinct
   d) Il n'avait aucune équipe à diriger ou à gérer

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La gestion consiste généralement à organiser les ressources et les personnes pour atteindre efficacement des objectifs définis et existants.
2. Le leadership consiste généralement à donner une direction, à inspirer les personnes et à traverser le changement et l'incertitude.
3. La gestion et le leadership sont des fonctions complémentaires, et non concurrentes, que la plupart des personnes efficaces en position d'autorité développent ensemble.
4. Le fait de reconnaître son déséquilibre entre gestion et leadership a amené le directeur, avec raison, à développer volontairement sa capacité de leadership moins développée.

**7. Points clés à retenir**
- La gestion organise les ressources et les personnes pour atteindre efficacement des objectifs définis et existants.
- Le leadership donne une direction, inspire les personnes et traverse le changement et l'incertitude.
- Ce sont des fonctions complémentaires, et non concurrentes — la plupart des personnes efficaces en position d'autorité développent les deux.
- Savoir reconnaître la dimension qui a besoin d'être développée est en soi une compétence de leadership précieuse.
