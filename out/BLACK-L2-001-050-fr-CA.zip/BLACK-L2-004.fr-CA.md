---
id: BLACK-L2-004
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 4
title: "Retour sur la délégation : la compétence de leadership qui la soutient (BLACK rencontre BLUE)"
summary: "Vois la délégation comme une compétence de leadership qui repose sur la communication, la confiance et la discipline émotionnelle, et pas seulement comme une technique de gestion."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-004
### Retour sur la délégation : la compétence de leadership qui la soutient (BLACK rencontre BLUE)

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Renforcer, du point de vue des compétences de leadership, la discussion de BLUE-L2-026 sur la délégation.
- Nommer les compétences de leadership précises qu'exige la délégation.
- Appliquer cette notion à une situation de délégation hypothétique.

**2. Contenu principal**
En revenant sur la discussion de BLUE-L2-026 sur la délégation, cette leçon examine les compétences de leadership précises qui soutiennent une délégation efficace : une communication claire (approfondie à la leçon 10) des attentes et des résultats souhaités, un vrai travail de confiance (leçon 9) qui permet d'accepter une approche différente de celle du leader, et la discipline émotionnelle nécessaire pour résister à l'envie de reprendre une tâche déléguée au premier signe d'une approche différente — mais pas forcément moins bonne.

Cette leçon présente la délégation comme une compétence de leadership avant tout, et non comme une simple technique de gestion ou un outil de gestion du temps : les obstacles psychologiques relevés dans BLUE-L2-026 — croire que « personne ne peut le faire aussi bien que moi », être mal à l'aise avec un style différent — sont de vrais défis de leadership qui exigent le travail de confiance, la communication et la discipline émotionnelle que ce niveau aborde tout au long, et non une simple liste d'étapes à suivre.

**3. Exemple pratique**
Ayant de la difficulté à déléguer une responsabilité précise alors qu'un membre compétent de son équipe est disponible, une leader constate que sa difficulté ne vient pas surtout de la complexité technique de la tâche, mais de son propre malaise devant une approche différente de la sienne et de sa confiance encore peu développée envers la capacité de ce membre de l'équipe. Reconnaissant que la délégation est avant tout une compétence de leadership qui exige un vrai travail de confiance et de la discipline émotionnelle, et non une simple technique de gestion, elle travaille précisément ces capacités de leadership sous-jacentes, plutôt que de simplement répéter ses tentatives de délégation sans s'attaquer au vrai obstacle.

**4. Quiz de pratique**
1. Quelles compétences de leadership cette leçon nomme-t-elle comme base d'une délégation efficace?
   a) Uniquement des procédures techniques d'attribution des tâches
   b) Une communication claire, un vrai travail de confiance et la discipline émotionnelle d'accepter une approche différente
   c) Une notion sans aucun lien avec le leadership
   d) Uniquement des techniques de planification du temps
2. Comment cette leçon présente-t-elle la délégation, en s'appuyant sur BLUE-L2-026?
   a) Comme une simple technique de gestion ou un outil de gestion du temps
   b) Comme une compétence de leadership avant tout, qui exige un travail de confiance, de la communication et de la discipline émotionnelle
   c) Comme une notion sans aucun lien avec le leadership
   d) Comme une liste de vérification purement technique, sans aucune compétence émotionnelle ou relationnelle
3. Vrai ou faux : Les difficultés de délégation viennent toujours surtout de la complexité technique d'une tâche, jamais du malaise émotionnel du leader ou de son niveau de confiance.
4. Pourquoi la leader de l'exemple pratique a-t-elle changé sa façon d'aborder sa difficulté à déléguer?
   a) Elle a reconnu que la difficulté était purement technique et n'exigeait aucun développement en leadership
   b) Elle a reconnu que sa difficulté venait d'une confiance peu développée et d'un malaise émotionnel, ce qui exigeait un vrai développement de ses compétences de leadership
   c) Elle n'avait aucun membre de l'équipe à qui déléguer
   d) La délégation n'a aucun lien avec la confiance ou la discipline émotionnelle

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une communication claire, un vrai travail de confiance et la discipline émotionnelle sont les compétences de leadership nommées comme base d'une délégation efficace.
2. Cette leçon présente la délégation comme une compétence de leadership avant tout, et non comme une simple technique de gestion ou un outil de gestion du temps.
3. Les difficultés de délégation viennent souvent du malaise émotionnel du leader ou d'une confiance peu développée, et pas seulement de la complexité technique d'une tâche.
4. En reconnaissant ses lacunes de leadership sous-jacentes, la leader a réorienté, avec raison, ses efforts de développement vers la confiance et la discipline émotionnelle.

**7. Points clés à retenir**
- Cette leçon revient sur la discussion de BLUE-L2-026 sur la délégation, en la présentant comme une compétence de leadership avant tout.
- Une délégation efficace exige une communication claire, un vrai travail de confiance et la discipline émotionnelle d'accepter des approches différentes.
- Les difficultés de délégation viennent souvent d'une confiance peu développée ou d'un malaise émotionnel, et pas seulement de la complexité technique d'une tâche.
- S'attaquer à la lacune de leadership sous-jacente, plutôt que de répéter les tentatives de délégation, règle les difficultés persistantes à déléguer.
