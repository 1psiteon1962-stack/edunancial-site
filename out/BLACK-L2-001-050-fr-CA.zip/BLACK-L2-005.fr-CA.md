---
id: BLACK-L2-005
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 5
title: "Autorité ou influence : deux sources différentes de pouvoir en leadership"
summary: "Distingue l'autorité que donne un poste de l'influence qu'on gagne par la confiance et l'expertise, et vois pourquoi l'autorité seule produit surtout de l'obéissance."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-005
### Autorité ou influence : deux sources différentes de pouvoir en leadership

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Distinguer de façon conceptuelle l'autorité de l'influence.
- Expliquer pourquoi l'influence compte souvent plus que l'autorité officielle pour un leadership vraiment efficace.
- Appliquer cette distinction à une situation de leadership hypothétique.

**2. Contenu principal**
L'autorité désigne généralement le pouvoir officiel, lié au poste, de diriger les actions des autres, habituellement accordé par un rôle ou un titre dans l'organisation — par exemple, l'autorité d'une gestionnaire pour attribuer des tâches. L'influence désigne généralement la capacité d'agir sur les croyances, les attitudes ou les comportements des autres grâce au respect, à la confiance (leçon 9), à l'expertise ou à une vraie relation, indépendamment de toute autorité officielle liée au poste.

Un leader peut détenir beaucoup d'autorité avec très peu d'influence réelle — les membres de l'équipe peuvent techniquement se conformer aux directives par obligation, tout en retenant leur engagement, leurs efforts ou leurs commentaires honnêtes —, alors qu'une personne sans aucune autorité officielle peut parfois exercer une influence importante grâce à son expertise, à sa fiabilité ou à la qualité de ses relations. Un leadership efficace exige généralement de bâtir une vraie influence en plus de l'autorité officielle que donne un poste, puisque l'autorité seule tend à produire de l'obéissance plutôt que l'engagement réel que peut générer un leadership fondé sur l'influence.

**3. Exemple pratique**
Nouvellement promu à un poste de gestion, un leader constate que son autorité officielle seule ne produit qu'une conformité technique de la part de son équipe — les tâches sont faites, mais sans l'engagement, l'initiative ou les commentaires honnêtes qu'il espérait. Reconnaissant la distinction que décrit cette leçon, il travaille volontairement à bâtir une vraie influence en plus de son autorité officielle : il démontre son expertise, respecte ses engagements de façon constante et bâtit des relations authentiques avec les membres de son équipe, ce qui lui permet de gagner peu à peu le genre d'engagement réel que son autorité seule n'avait pas produit.

**4. Quiz de pratique**
1. Dans ce contexte de leadership, qu'est-ce que l'autorité?
   a) La capacité d'agir sur les croyances ou les comportements des autres grâce au respect et à la confiance
   b) Le pouvoir officiel, lié au poste, de diriger les actions des autres, habituellement accordé par un rôle dans l'organisation
   c) Un type de crédit d'impôt
   d) Une notion identique à l'influence, sans aucune distinction
2. Qu'est-ce que l'influence, par rapport à l'autorité?
   a) Uniquement le pouvoir officiel lié au poste
   b) La capacité d'agir sur les croyances, les attitudes ou les comportements des autres grâce au respect, à la confiance, à l'expertise ou à une relation, indépendamment de l'autorité officielle
   c) Une notion sans lien avec l'efficacité du leadership
   d) Uniquement l'obéissance produite par un titre
3. Vrai ou faux : Une personne qui détient beaucoup d'autorité officielle a automatiquement autant d'influence réelle sur son équipe.
4. Pourquoi l'autorité officielle seule du leader nouvellement promu s'est-elle révélée insuffisante?
   a) L'autorité officielle produit toujours automatiquement un engagement réel
   b) Son autorité ne produisait qu'une conformité technique, et non l'engagement réel et les commentaires honnêtes que génère un leadership fondé sur l'influence
   c) L'autorité et l'influence sont des notions identiques qui n'exigent aucun développement distinct
   d) Il n'avait aucun membre d'équipe à diriger

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'autorité est le pouvoir officiel, lié au poste, de diriger les actions des autres, habituellement accordé par un rôle dans l'organisation.
2. L'influence est la capacité d'agir sur les croyances, les attitudes ou les comportements des autres grâce au respect, à la confiance, à l'expertise ou à une relation, indépendamment de l'autorité.
3. L'autorité officielle ne produit pas automatiquement une influence réelle; ce sont deux sources de pouvoir en leadership distinctes, quoique complémentaires.
4. L'autorité seule du leader ne produisait qu'une conformité technique, ce qui l'a poussé à bâtir une vraie influence par son expertise, sa constance et ses relations.

**7. Points clés à retenir**
- L'autorité est un pouvoir officiel lié au poste; l'influence est la capacité d'agir sur les autres indépendamment de l'autorité officielle.
- Un leader peut détenir de l'autorité avec très peu d'influence réelle, ce qui produit de l'obéissance plutôt qu'un engagement réel.
- Un leadership efficace exige généralement de bâtir une vraie influence en plus de l'autorité officielle que donne un poste.
- Le leadership fondé sur l'influence tend à générer un engagement réel, alors que l'autorité seule tend à générer une simple obéissance.
