---
id: BLACK-L2-008
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 8
title: "Retour sur la responsabilité de l'employeur : le leadership comme intendance"
summary: "Comprends le leadership comme une responsabilité envers le gagne-pain, le développement et le bien-être des personnes, et pas seulement envers leur rendement."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-008
### Retour sur la responsabilité de l'employeur : le leadership comme intendance

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Renforcer, du point de vue du leadership, le thème de la responsabilité de l'employeur de BLUE-L2-020.
- Expliquer le leadership comme une forme d'intendance du gagne-pain et du développement des personnes.
- Appliquer cette notion à une décision de leadership hypothétique.

**2. Contenu principal**
En revenant sur le thème de la responsabilité de l'employeur de BLUE-L2-020, cette leçon prolonge directement cette idée dans la pratique du leadership : diriger des personnes comporte une vraie responsabilité envers leur gagne-pain, leur développement professionnel et leur bien-être, et pas seulement envers le résultat de leurs tâches. Ça présente le leadership comme une forme d'intendance — on confie au leader une influence importante sur l'expérience quotidienne des personnes, leurs occasions de croissance et, souvent, une part importante de leur revenu et de leur stabilité, une responsabilité qui devrait guider la façon de prendre les décisions de leadership tout au long de ce niveau.

Cette idée d'intendance ne veut pas dire qu'un leader doit toujours faire passer les préférences d'un membre de l'équipe avant les besoins légitimes de l'organisation, mais elle veut dire que les décisions de leadership — sur la rétroaction (leçons 12 et 13), la gestion du rendement (leçons 23 à 27) et le changement organisationnel (leçons 35 et 36) — devraient être prises en tenant vraiment compte des personnes touchées, en écho à l'accent constant de ce niveau sur le fait que le leadership a un vrai poids, et n'est pas seulement une fonction de gestion technique.

**3. Exemple pratique**
Devant une décision difficile sur la réorganisation des responsabilités de son équipe, une leader examine volontairement l'effet réel sur le développement, la stabilité et l'expérience quotidienne de chaque membre de l'équipe touché, et pas seulement l'efficacité organisationnelle que la réorganisation pourrait apporter. Cette approche axée sur l'intendance, en écho au thème de la responsabilité de l'employeur de BLUE-L2-020, l'amène à mettre en œuvre le changement avec une communication plus réfléchie et plus de soutien pour les membres de l'équipe touchés qu'une approche axée uniquement sur l'efficacité, tout en allant quand même de l'avant avec une réorganisation qu'elle croit vraiment utile aux besoins légitimes de l'organisation.

**4. Quiz de pratique**
1. Sur quoi cette leçon revient-elle à partir de BLUE-L2-020?
   a) Une notion sans aucun lien avec la responsabilité du leader
   b) Le thème de la responsabilité de l'employeur, prolongé directement dans la pratique du leadership comme une forme d'intendance
   c) Uniquement une discussion sur les pratiques d'embauche
   d) Uniquement une discussion sur la stratégie de prix
2. Selon cette leçon, qu'implique généralement l'intendance en leadership?
   a) Faire passer l'efficacité organisationnelle avant tout, sans tenir compte des personnes touchées
   b) Tenir vraiment compte du gagne-pain, du développement et du bien-être des personnes dans les décisions de leadership
   c) Une notion sans lien avec les décisions de rétroaction ou de gestion du rendement
   d) Ignorer complètement les besoins légitimes de l'organisation
3. Vrai ou faux : L'intendance en leadership veut dire qu'un leader doit toujours faire passer les préférences d'un membre de l'équipe avant tout besoin légitime de l'organisation.
4. Pourquoi la leader a-t-elle tenu compte du développement et de la stabilité des membres de son équipe avant de mettre en œuvre la réorganisation?
   a) Elle n'avait aucun vrai besoin organisationnel à régler
   b) Son approche axée sur l'intendance l'a amenée à tenir compte de l'effet réel sur les personnes touchées, et pas seulement de l'efficacité organisationnelle
   c) L'intendance n'a aucun lien avec la prise de décisions en leadership
   d) Elle voulait éviter complètement la réorganisation, peu importe le besoin organisationnel

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Cette leçon revient sur le thème de la responsabilité de l'employeur de BLUE-L2-020, prolongé directement dans la pratique du leadership comme une forme d'intendance.
2. L'intendance en leadership implique de tenir vraiment compte du gagne-pain, du développement et du bien-être des personnes dans les décisions de leadership.
3. L'intendance ne veut pas dire de toujours faire passer les préférences individuelles avant les besoins légitimes de l'organisation, mais de tenir vraiment compte des personnes touchées.
4. Le souci d'intendance de la leader a guidé, avec raison, sa façon de mettre en œuvre un changement qu'elle croyait toujours vraiment utile à l'organisation.

**7. Points clés à retenir**
- Cette leçon revient sur le thème de la responsabilité de l'employeur de BLUE-L2-020, en présentant le leadership comme une forme d'intendance.
- Le leadership comporte une vraie responsabilité envers le gagne-pain, le développement et le bien-être des personnes, et pas seulement envers le résultat de leurs tâches.
- Ça ne veut pas dire de toujours faire passer les préférences individuelles avant les besoins légitimes de l'organisation.
- Cette idée d'intendance devrait guider les décisions de leadership en matière de rétroaction, de gestion du rendement et de changement.
