---
id: BLACK-L2-009
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 9
title: "Bâtir la confiance comme leader : la base de tout le reste"
summary: "Comprends pourquoi la confiance soutient la délégation, la rétroaction et les conversations difficiles, et comment elle se bâtit peu à peu par la constance, la compétence et un vrai souci des autres."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-009
### Bâtir la confiance comme leader : la base de tout le reste

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi la confiance sert de base à un leadership efficace.
- Nommer les composantes générales de la confiance.
- Appliquer cette notion à une situation hypothétique où il faut bâtir la confiance.

**2. Contenu principal**
En s'appuyant sur la discussion sur l'influence de la leçon 5, la confiance sert de vraie base à presque toutes les autres capacités de leadership que ce niveau aborde : la délégation (leçon 4) exige de faire confiance à la capacité d'un membre de l'équipe; la rétroaction (leçons 12 et 13) est reçue avec plus d'ouverture quand la confiance existe; et les conversations difficiles (leçon 14) se déroulent de façon plus constructive quand une base de confiance existe déjà entre les personnes concernées.

Les composantes générales de la confiance comprennent la constance (respecter ses engagements de façon fiable au fil du temps), la compétence (démontrer une vraie capacité dans les domaines pertinents) et un vrai souci des autres (les membres de l'équipe sentent que le leader tient vraiment compte de leur bien-être, en écho à la discussion sur l'intendance de la leçon 8). La confiance se bâtit généralement peu à peu, par la démonstration répétée et constante de ces composantes au fil du temps, plutôt que par un seul geste ou une seule déclaration, et elle peut être abîmée assez rapidement par un seul manquement important à l'une d'elles.

**3. Exemple pratique**
En travaillant à bâtir la confiance avec une équipe nouvellement formée, une leader se concentre volontairement sur la constance (respecter de façon fiable chaque engagement qu'elle prend, aussi petit soit-il), sur la démonstration d'une vraie compétence dans son rôle et sur un souci authentique du bien-être et du développement de chaque membre de son équipe. Elle reconnaît que ce processus prendra du temps et un comportement constant, et non une seule activité de consolidation d'équipe ou un discours motivant, et qu'un seul engagement important non respecté pourrait miner sérieusement la confiance qu'elle a travaillé à bâtir.

**4. Quiz de pratique**
1. Selon cette leçon, pourquoi la confiance sert-elle de base aux autres capacités de leadership?
   a) La confiance n'a aucun lien avec la délégation, la rétroaction ou les conversations difficiles
   b) La délégation, l'ouverture à la rétroaction et les conversations difficiles se déroulent toutes plus efficacement quand une base de confiance existe déjà
   c) La confiance compte seulement pour l'autorité officielle, jamais pour les autres fonctions du leadership
   d) La confiance et l'efficacité du leadership sont des notions sans lien
2. Selon cette leçon, quelle est une composante générale de la confiance?
   a) L'incohérence et l'imprévisibilité
   b) La constance, une compétence démontrée et un vrai souci du bien-être des membres de l'équipe
   c) Un type de crédit d'impôt
   d) Éviter de donner suite à ses engagements
3. Vrai ou faux : La confiance peut généralement se bâtir rapidement grâce à un seul geste important ou à une seule déclaration motivante.
4. Pourquoi la leader a-t-elle reconnu que bâtir la confiance prendrait du temps?
   a) La confiance se bâtit instantanément grâce à un seul événement ou à une seule déclaration
   b) La confiance se bâtit généralement peu à peu, par la démonstration répétée de constance, de compétence et d'un vrai souci des autres au fil du temps
   c) La confiance n'a aucun lien avec un comportement constant au fil du temps
   d) Elle ne tenait pas à bâtir une vraie confiance avec son équipe

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La délégation, l'ouverture à la rétroaction et les conversations difficiles se déroulent toutes plus efficacement quand une base de confiance existe déjà.
2. La constance, une compétence démontrée et un vrai souci du bien-être des membres de l'équipe sont des composantes générales de la confiance.
3. La confiance se bâtit généralement peu à peu par un comportement constant et soutenu, et non par un seul geste ou une seule déclaration.
4. Le fait de reconnaître que la confiance se bâtit progressivement a guidé, avec raison, l'approche constante et soutenue de la leader.

**7. Points clés à retenir**
- La confiance sert de base à la délégation, à l'ouverture à la rétroaction et aux conversations difficiles constructives.
- Ses composantes générales comprennent la constance, une compétence démontrée et un vrai souci du bien-être des membres de l'équipe.
- La confiance se bâtit généralement peu à peu par un comportement constant et soutenu, et non par un seul geste.
- La confiance peut être abîmée assez rapidement par un seul manquement important, ce qui rend la constance essentielle en tout temps.
