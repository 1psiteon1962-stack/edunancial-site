---
id: BLACK-L2-010
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 10
title: "La communication comme compétence de leadership : la clarté avant l'éloquence"
summary: "Apprends pourquoi un leader doit viser la clarté plutôt que des formules impressionnantes, et comment éviter les erreurs de communication les plus courantes."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-010
### La communication comme compétence de leadership : la clarté avant l'éloquence

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi la clarté, et non l'éloquence, est la norme principale d'une communication efficace en leadership.
- Nommer les erreurs de communication courantes qu'un leader devrait éviter.
- Appliquer cette notion à une situation de communication hypothétique.

**2. Contenu principal**
Une communication efficace en leadership donne la priorité à la clarté — s'assurer que le message voulu est vraiment compris, sans ambiguïté, par les personnes qui le reçoivent — plutôt qu'à l'éloquence, à la complexité ou à des formules impressionnantes qui peuvent embrouiller le vrai message au lieu de le clarifier. Les erreurs de communication courantes comprennent le fait de supposer que le public partage un contexte qu'il n'a pas réellement, d'enterrer le point principal sous un long préambule ou trop de nuances, et de ne pas vérifier que le message a réellement été compris comme prévu, en supposant simplement qu'un message bien livré est forcément bien reçu.

Ça se relie directement à la discussion sur la délégation de la leçon 4 et à celle sur la confiance de la leçon 9 : une communication floue sur les attentes nuit à une délégation efficace, et une communication qui semble évasive ou trop compliquée peut elle-même éroder la confiance sur laquelle ce niveau insiste, puisque les membres de l'équipe peuvent raisonnablement se demander si ce manque de clarté reflète une vraie incertitude, un malaise ou quelque chose qu'on cache volontairement.

**3. Exemple pratique**
En examinant les commentaires reçus sur sa façon de communiquer, un leader découvre que son équipe sort souvent des réunions sans savoir clairement quel est le point principal ou quelles sont les prochaines étapes, même si ses communications contiennent souvent beaucoup de détails et un vocabulaire recherché. Reconnaissant qu'il s'agit d'un problème de clarté, et non d'un manque d'éloquence, il revoit sa façon de communiquer pour commencer par l'énoncé le plus clair possible du point principal et des prochaines étapes précises, en vérifiant que les gens ont vraiment compris plutôt que de supposer que ses explications détaillées suffisaient à être bien reçues.

**4. Quiz de pratique**
1. Selon cette leçon, quelle est la norme principale d'une communication efficace en leadership?
   a) L'éloquence et une complexité impressionnante
   b) La clarté — s'assurer que le message voulu est vraiment compris, sans ambiguïté
   c) Un type de crédit d'impôt
   d) La longueur et le niveau de détail, peu importe la clarté
2. Quelle est une erreur de communication courante que cette leçon nomme?
   a) Vérifier que le message a réellement été compris comme prévu
   b) Supposer que le public partage un contexte qu'il n'a pas réellement, ou enterrer le point principal sous un long préambule
   c) Commencer par l'énoncé le plus clair possible du point principal
   d) Une erreur sans aucun lien avec l'efficacité du leadership
3. Vrai ou faux : Un message bien livré est automatiquement bien reçu par le public.
4. Pourquoi le leader a-t-il revu sa façon de communiquer après avoir reçu des commentaires?
   a) Son équipe comprenait déjà parfaitement chaque point principal
   b) Il a reconnu que ses communications détaillées et recherchées ne produisaient pas une vraie clarté pour son équipe
   c) L'éloquence et la complexité sont toujours la bonne norme de communication
   d) Il ne tenait pas à améliorer la compréhension de son équipe

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La clarté — s'assurer que le message voulu est vraiment compris, sans ambiguïté — est la norme principale d'une communication efficace en leadership.
2. Supposer un contexte partagé ou enterrer le point principal sous un long préambule sont des erreurs de communication courantes.
3. Un message bien livré n'est pas automatiquement bien reçu; vérifier la compréhension reste une étape supplémentaire nécessaire.
4. En revoyant sa façon de faire, le leader a réglé, avec raison, le problème de clarté que causaient ses communications détaillées et compliquées.

**7. Points clés à retenir**
- Une communication efficace en leadership donne la priorité à la clarté plutôt qu'à l'éloquence ou à une complexité impressionnante.
- Les erreurs courantes comprennent supposer un contexte partagé, enterrer le point principal et ne pas vérifier la compréhension réelle.
- Ça se relie directement aux discussions sur la délégation de la leçon 4 et sur la confiance de la leçon 9.
- Vérifier la vraie compréhension, au lieu de supposer qu'un message bien livré est bien reçu, est une discipline de communication essentielle.
