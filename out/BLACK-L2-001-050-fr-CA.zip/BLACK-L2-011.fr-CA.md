---
id: BLACK-L2-011
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 11
title: "L'écoute active : la compétence de leadership sous-utilisée"
summary: "Apprends à écouter vraiment, avec toute ton attention, des questions de clarification et une reformulation, au lieu d'attendre ton tour pour répondre."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-011
### L'écoute active : la compétence de leadership sous-utilisée

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle l'écoute active.
- Distinguer l'écoute active du simple fait d'entendre ou d'attendre son tour pour répondre.
- Appliquer cette notion à une conversation de leadership hypothétique.

**2. Contenu principal**
En s'appuyant directement sur la discussion sur la communication de la leçon 10, l'écoute active consiste à se concentrer vraiment sur la compréhension du message réel de la personne qui parle — y compris ses préoccupations ou le sens sous-jacent, en écho à la façon de reformuler les objections de ORANGE-L2-027 —, plutôt que d'entendre passivement les mots en préparant mentalement sa réponse, ou d'écouter seulement à moitié en étant distrait par d'autres tâches ou d'autres pensées.

L'écoute active comprend généralement des pratiques précises : accorder une attention réelle et entière, poser des questions de clarification pour confirmer sa compréhension (en écho à la discussion sur la vérification de la leçon 10) et reformuler ce qu'on a compris avant de répondre, pour que la personne sente qu'on l'a vraiment écoutée, et non simplement tolérée, avant que le leader passe à son propre point. C'est une compétence de leadership souvent sous-utilisée, justement parce qu'elle exige une vraie discipline pour résister à la tendance naturelle à se concentrer sur sa réponse pendant que l'autre personne parle encore.

**3. Exemple pratique**
Pendant qu'un membre de son équipe exprime une préoccupation au sujet de l'échéancier d'un projet, un leader résiste à sa tendance naturelle à formuler tout de suite sa réponse pendant que l'autre parle encore. Il lui accorde plutôt une attention réelle et entière et pose des questions de clarification pour bien comprendre la préoccupation sous-jacente, en écho à la reformulation de ORANGE-L2-027. Il reformule ensuite ce qu'il a compris avant de donner sa propre réponse, pour que le membre de l'équipe sente qu'on l'a vraiment écouté. Ce dernier dira plus tard que ça a fait une vraie différence dans son aisance à soulever d'autres préoccupations par la suite.

**4. Quiz de pratique**
1. Selon cette leçon, en quoi consiste généralement l'écoute active?
   a) Entendre passivement les mots en préparant mentalement sa réponse
   b) Se concentrer vraiment sur la compréhension du message réel de la personne qui parle, y compris ses préoccupations sous-jacentes
   c) Un type de crédit d'impôt
   d) Écouter seulement à moitié en étant distrait par d'autres tâches
2. Pourquoi décrit-on l'écoute active comme une compétence de leadership souvent sous-utilisée?
   a) Elle n'exige aucune discipline et vient naturellement à tout le monde
   b) Elle exige une vraie discipline pour résister à la tendance naturelle à formuler sa réponse pendant que l'autre parle encore
   c) L'écoute active n'a aucun lien avec l'efficacité du leadership
   d) La plupart des leaders la pratiquent déjà de façon constante et habile
3. Vrai ou faux : Reformuler ce qu'on a compris avant de répondre est inutile si le leader est sûr d'avoir bien compris la personne qui parle.
4. Pourquoi le membre de l'équipe se sentait-il plus à l'aise de soulever d'autres préoccupations après l'écoute active du leader?
   a) Le leader a tout de suite donné sa propre réponse sans poser de questions de clarification
   b) L'attention réelle et la reformulation du leader ont fait sentir au membre de l'équipe qu'on l'avait vraiment écouté, et non simplement toléré
   c) L'écoute active n'a eu aucun effet sur l'aisance du membre de l'équipe
   d) Le leader a complètement rejeté la préoccupation du membre de l'équipe

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'écoute active consiste à se concentrer vraiment sur la compréhension du message réel de la personne qui parle, y compris ses préoccupations sous-jacentes.
2. L'écoute active exige une vraie discipline pour résister à la tendance naturelle à formuler sa réponse pendant que l'autre parle.
3. Reformuler ce qu'on a compris aide à confirmer la vraie compréhension et fait sentir à la personne qu'on l'a vraiment écoutée, peu importe à quel point le leader est sûr de lui.
4. L'attention réelle et la reformulation du leader ont fait sentir au membre de l'équipe qu'on l'avait écouté, ce qui lui a donné l'aisance nécessaire pour soulever d'autres préoccupations.

**7. Points clés à retenir**
- L'écoute active consiste à se concentrer vraiment sur la compréhension du message réel, et non à entendre passivement en préparant sa réponse.
- Ça se relie directement à la discussion sur la communication de la leçon 10 et à la reformulation des préoccupations sous-jacentes de ORANGE-L2-027.
- Ses pratiques comprennent une attention entière, des questions de clarification et la reformulation de ce qu'on a compris avant de répondre.
- Cette compétence souvent sous-utilisée exige une vraie discipline pour résister à l'envie naturelle de formuler sa réponse trop tôt.
