---
id: BLACK-L2-012
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 12
title: "Donner de la rétroaction : précise, rapide et utilisable"
summary: "Apprends à donner une rétroaction qui vise un comportement précis, arrive au bon moment et indique quoi faire ensuite."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-012
### Donner de la rétroaction : précise, rapide et utilisable

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Nommer les caractéristiques générales d'une rétroaction efficace.
- Expliquer pourquoi une rétroaction vague ou tardive va à l'encontre de son propre but.
- Appliquer cette notion à une situation de rétroaction hypothétique.

**2. Contenu principal**
Une rétroaction efficace est généralement précise (elle vise un comportement ou un résultat particulier et identifiable, et non une vague impression générale), rapide (elle est donnée assez près de l'événement réel pour rester pertinente et utilisable, au lieu d'être reportée à une évaluation officielle bien plus tard) et utilisable (elle donne une orientation claire sur ce que la personne pourrait précisément faire autrement ou continuer de faire, au lieu de seulement nommer un problème sans proposer de piste constructive).

Une rétroaction vague (« tu dois mieux communiquer ») ne donne généralement pas l'orientation précise et utilisable dont la personne a besoin pour s'améliorer vraiment, alors qu'une rétroaction tardive (parler d'un incident vieux de plusieurs mois seulement pendant l'évaluation annuelle, en écho à la discussion de la leçon 24 sur la gestion du rendement continue plutôt qu'annuelle) perd une grande partie de sa pertinence et de sa valeur pratique, puisque la personne ne se souvient peut-être plus clairement des circonstances précises ou n'a eu aucune occasion de s'ajuster entre-temps.

**3. Exemple pratique**
En donnant de la rétroaction à un membre de son équipe sur une présentation récente à un client, une leader évite une phrase vague comme « tes présentations doivent s'améliorer ». Elle précise plutôt que la section des données de la présentation manquait d'une organisation visuelle claire, donne un exemple précis d'une autre façon de faire que la personne pourrait utiliser la prochaine fois, et livre cette rétroaction dans la journée qui suit la présentation, au lieu d'attendre une évaluation prévue des mois plus tard. Cette approche précise, rapide et utilisable donne au membre de l'équipe de l'information vraiment utile qu'il peut appliquer dès sa prochaine présentation.

**4. Quiz de pratique**
1. Selon cette leçon, qu'implique généralement une rétroaction « précise »?
   a) Une vague impression générale, sans comportement particulier identifiable
   b) Viser un comportement ou un résultat particulier et identifiable
   c) Un type de crédit d'impôt
   d) Une rétroaction reportée à une évaluation officielle bien plus tard
2. Pourquoi une rétroaction tardive perd-elle une grande partie de sa pertinence et de sa valeur pratique?
   a) Une rétroaction tardive a toujours plus de valeur qu'une rétroaction rapide
   b) La personne ne se souvient peut-être plus clairement des circonstances précises ou n'a eu aucune occasion de s'ajuster entre-temps
   c) Le moment n'a aucun lien avec l'utilité de la rétroaction
   d) Une rétroaction donnée des mois plus tard est toujours aussi utilisable qu'une rétroaction immédiate
3. Vrai ou faux : Une rétroaction vague comme « tu dois mieux communiquer » donne généralement une orientation assez précise et utilisable pour une vraie amélioration.
4. Pourquoi la rétroaction de la leader sur la présentation était-elle plus utile qu'une phrase vague?
   a) Elle était tout aussi vague et imprécise
   b) Elle nommait précisément le problème, proposait une solution concrète et était donnée rapidement, ce qui la rendait vraiment utilisable
   c) Elle a été reportée à une évaluation prévue bien plus tard
   d) Elle ne donnait aucun exemple concret ni orientation précise

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une rétroaction précise vise un comportement ou un résultat particulier et identifiable, et non une vague impression générale.
2. Une rétroaction tardive perd de sa pertinence puisque la personne ne se souvient peut-être plus des circonstances ou n'a pas eu l'occasion de s'ajuster.
3. Une rétroaction vague ne donne généralement pas l'orientation précise et utilisable nécessaire à une vraie amélioration.
4. La rétroaction précise, rapide et utilisable de la leader a donné au membre de l'équipe de l'information vraiment utile pour sa prochaine présentation.

**7. Points clés à retenir**
- Une rétroaction efficace est précise, rapide et utilisable, et non vague ou tardive.
- Une rétroaction vague ne donne pas l'orientation précise nécessaire à une vraie amélioration.
- Une rétroaction tardive perd sa pertinence et sa valeur pratique à mesure que les circonstances et les souvenirs s'estompent.
- Ça prépare la discussion de la leçon 24 sur une gestion du rendement continue, et non seulement annuelle.
