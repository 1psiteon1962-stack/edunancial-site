---
id: BLACK-L2-013
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 13
title: "Recevoir de la rétroaction : une discipline de croissance pour le leader"
summary: "Comprends pourquoi l'ouverture d'un leader à la rétroaction façonne la culture de son équipe, et apprends à éviter les réactions défensives qui découragent l'honnêteté."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-013
### Recevoir de la rétroaction : une discipline de croissance pour le leader

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi l'ouverture d'un leader à la rétroaction compte pour la culture de l'organisation.
- Nommer les réactions défensives courantes qui empêchent de vraiment recevoir la rétroaction.
- Appliquer cette notion à une situation hypothétique de rétroaction ascendante.

**2. Contenu principal**
En s'appuyant directement sur la leçon 12, cette leçon aborde l'autre direction : la discipline du leader à vraiment recevoir la rétroaction, y compris de membres de l'équipe qui n'ont aucune autorité officielle sur lui (en écho à la discussion de la leçon 42 sur la gestion ascendante). Un leader qui montre une vraie ouverture à la rétroaction — y compris sur sa propre façon de diriger — donne un exemple puissant qui façonne la culture plus large de l'organisation (approfondie à la leçon 28) en matière de rétroaction et de sécurité psychologique (leçon 30).

Les réactions défensives courantes qui empêchent de vraiment recevoir la rétroaction comprennent le fait de s'expliquer ou de se justifier tout de suite au lieu de d'abord vraiment considérer la rétroaction, de rejeter une rétroaction selon l'ancienneté ou le statut perçu de la personne qui la donne plutôt que selon son contenu réel, et de ne pas agir visiblement à la suite de la rétroaction de façon à montrer qu'elle a vraiment été entendue. Toutes ces réactions découragent les membres de l'équipe de donner une rétroaction honnête à l'avenir, en écho à la discussion sur la confiance de la leçon 9.

**3. Exemple pratique**
Conscient de sa tendance à expliquer tout de suite son raisonnement chaque fois qu'un membre de son équipe critique sa façon de diriger, un leader travaille volontairement à prendre une pause et à vraiment considérer ces commentaires avant de répondre, au lieu de justifier par réflexe sa décision. Quand une employée lui fait remarquer franchement que sa façon de communiquer lui a semblé trop brusque pendant une période stressante, il résiste à l'envie d'expliquer tout de suite le stress qu'il vivait. Il reconnaît plutôt sincèrement la rétroaction et ajuste visiblement son approche par la suite — donnant ainsi l'exemple de l'ouverture à la rétroaction qu'il espère voir dans toute la culture de son équipe.

**4. Quiz de pratique**
1. Selon cette leçon, pourquoi l'ouverture d'un leader à la rétroaction compte-t-elle?
   a) Elle n'a aucun lien avec la culture de l'organisation
   b) Elle donne un exemple puissant qui façonne la culture plus large de l'organisation en matière de rétroaction et de sécurité psychologique
   c) Les leaders ne devraient jamais recevoir de rétroaction de membres de l'équipe qui n'ont aucune autorité officielle sur eux
   d) La réception de la rétroaction compte seulement du haut vers le bas, jamais du bas vers le haut
2. Quelle est une réaction défensive courante qui empêche de vraiment recevoir la rétroaction?
   a) Considérer vraiment la rétroaction avant de répondre
   b) S'expliquer ou se justifier tout de suite au lieu de d'abord vraiment considérer la rétroaction
   c) Agir visiblement à la suite de la rétroaction pour montrer qu'elle a été entendue
   d) Une réaction sans lien avec la réception de la rétroaction
3. Vrai ou faux : Rejeter une rétroaction selon l'ancienneté de la personne qui la donne, plutôt que selon son contenu réel, est décrit comme une bonne pratique de réception de la rétroaction.
4. Pourquoi le leader a-t-il résisté à l'envie d'expliquer tout de suite sa façon de communiquer liée au stress?
   a) Il voulait justifier son comportement par réflexe au lieu de vraiment considérer la rétroaction
   b) Il a reconnu que montrer l'exemple d'une vraie ouverture à la rétroaction influencerait positivement la culture de son équipe
   c) La réception de la rétroaction n'a aucun lien avec la culture d'équipe
   d) Il ne tenait pas à ajuster sa façon de communiquer

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La vraie ouverture d'un leader à la rétroaction donne un exemple puissant qui façonne la culture plus large de l'organisation en matière de rétroaction et de sécurité psychologique.
2. S'expliquer ou se justifier tout de suite au lieu de d'abord vraiment considérer la rétroaction est une réaction défensive courante qui nuit à sa réception.
3. Rejeter une rétroaction selon l'ancienneté de la personne, plutôt que selon son contenu, nuit à sa réception et décourage l'honnêteté future.
4. En résistant à la justification par réflexe, le leader a donné l'exemple, avec raison, de la vraie ouverture à la rétroaction qu'il espérait développer dans toute son équipe.

**7. Points clés à retenir**
- L'ouverture d'un leader à la rétroaction façonne la culture plus large de l'organisation en matière de rétroaction et de sécurité psychologique.
- Les réactions défensives courantes comprennent la justification par réflexe, le rejet selon le statut de la personne et le fait de ne pas agir visiblement à la suite de la rétroaction.
- Recevoir vraiment la rétroaction, surtout de personnes sans autorité officielle, donne l'exemple de la culture qu'un leader espère bâtir.
- Ça se relie directement à la discussion sur la confiance de la leçon 9 et annonce la discussion sur la gestion ascendante de la leçon 42.
