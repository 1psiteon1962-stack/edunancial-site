---
id: BLACK-L2-014
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 14
title: "Les conversations difficiles : pourquoi les éviter coûte plus cher"
summary: "Comprends pourquoi reporter une conversation difficile aggrave souvent le problème, et apprends à l'aborder avec préparation, curiosité et écoute."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-014
### Les conversations difficiles : pourquoi les éviter coûte plus cher

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi éviter une conversation difficile nécessaire coûte généralement plus cher que de l'avoir.
- Nommer les principes généraux pour aborder les conversations difficiles de façon constructive.
- Appliquer cette notion à une situation d'évitement hypothétique.

**2. Contenu principal**
En s'appuyant sur les leçons 9 à 13, cette leçon aborde un schéma d'évitement courant en leadership : reporter ou éviter complètement une conversation difficile nécessaire — sur un rendement insuffisant (leçon 26), une préoccupation de comportement ou un conflit interpersonnel (leçon 15) —, souvent parce que la conversation elle-même semble désagréable à court terme. Cet évitement coûte généralement plus cher, avec le temps, que la conversation elle-même : le problème sous-jacent continue habituellement ou s'aggrave, les autres membres de l'équipe remarquent souvent le problème non réglé (ce qui peut miner leur confiance dans le jugement ou l'équité du leader), et la conversation finale, encore plus retardée, devient souvent encore plus difficile à cause de la frustration accumulée ou de l'aggravation continue du problème.

Les principes généraux pour aborder les conversations difficiles de façon constructive comprennent préparer à l'avance des points précis et factuels (en écho à la discussion sur la précision de la leçon 12), aborder la conversation avec une vraie curiosité et une écoute active (leçon 11) plutôt qu'avec une attitude purement accusatrice, et se concentrer sur le comportement ou le problème précis plutôt que sur des jugements généraux sur le caractère de la personne.

**3. Exemple pratique**
Au courant depuis plusieurs semaines d'un problème de rendement chez un membre de son équipe, une leader reconnaît qu'elle évite la conversation nécessaire en espérant que le problème se règle de lui-même sans qu'elle intervienne directement. Reconnaissant ce schéma d'évitement et ses coûts probables — un rendement insuffisant qui continue, d'autres membres de l'équipe qui remarquent le problème non réglé, et une conversation éventuellement plus difficile une fois que la situation aura duré plus longtemps —, elle prépare des points précis et factuels et lance la conversation rapidement, en l'abordant avec une vraie curiosité sur la cause sous-jacente plutôt qu'avec une attitude accusatrice.

**4. Quiz de pratique**
1. Selon cette leçon, pourquoi éviter une conversation difficile nécessaire coûte-t-il généralement plus cher que de l'avoir?
   a) L'évitement n'a jamais de conséquences négatives
   b) Le problème sous-jacent continue habituellement ou s'aggrave, et la conversation finale retardée devient souvent encore plus difficile
   c) Les conversations difficiles se règlent toujours d'elles-mêmes sans intervention du leader
   d) Les autres membres de l'équipe ne remarquent jamais un problème non réglé
2. Selon cette leçon, quel est un principe général pour aborder une conversation difficile de façon constructive?
   a) L'aborder avec une attitude purement accusatrice, sans préparation
   b) Préparer des points précis et factuels et l'aborder avec une vraie curiosité et une écoute active
   c) Se concentrer sur des jugements généraux sur le caractère plutôt que sur le comportement précis
   d) Éviter toute préparation ou toute vraie écoute
3. Vrai ou faux : Reporter une conversation difficile nécessaire n'a généralement aucun effet sur la difficulté de la conversation finale.
4. Pourquoi la leader a-t-elle préparé des points précis et factuels avant de lancer la conversation?
   a) Elle voulait aborder la conversation avec une attitude purement accusatrice, sans préparation
   b) Cette préparation, en écho à la discussion sur la précision de la leçon 12, favorisait une conversation constructive et factuelle plutôt que vague ou accusatrice
   c) La préparation n'a aucun lien avec le caractère constructif d'une conversation difficile
   d) Elle n'avait aucun vrai problème de rendement à régler

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'évitement permet habituellement au problème sous-jacent de continuer ou de s'aggraver, et la conversation finale retardée devient souvent encore plus difficile.
2. Préparer des points précis et factuels et aborder la conversation avec une vraie curiosité et une écoute active sont des principes constructifs pour les conversations difficiles.
3. Reporter une conversation difficile la rend souvent plus difficile au final, à cause de la frustration accumulée ou de l'aggravation du problème.
4. La préparation précise et factuelle de la leader a favorisé, avec raison, une conversation constructive, en écho à la discussion sur la précision de la leçon 12.

**7. Points clés à retenir**
- Éviter une conversation difficile nécessaire coûte généralement plus cher, avec le temps, que de l'avoir rapidement.
- Les problèmes non réglés continuent habituellement ou s'aggravent, et les autres membres de l'équipe remarquent souvent l'évitement, ce qui mine la confiance.
- Les approches constructives comprennent une préparation précise, une vraie curiosité, l'écoute active et l'accent sur le comportement précis plutôt que sur le caractère.
- Ça s'appuie directement sur les discussions des leçons 9 à 13 sur la confiance, la communication et la rétroaction.
