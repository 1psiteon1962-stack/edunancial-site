---
id: BLACK-L2-015
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 15
title: "Résoudre les conflits : comprendre les sources de conflit au travail"
summary: "Nomme les sources courantes de conflit au travail et comprends pourquoi il faut régler la cause réelle plutôt que les symptômes visibles."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-015
### Résoudre les conflits : comprendre les sources de conflit au travail

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Nommer les sources courantes de conflit au travail.
- Expliquer pourquoi comprendre la source compte plus que de régler seulement les symptômes visibles.
- Appliquer cette notion à une situation de conflit hypothétique.

**2. Contenu principal**
Les sources courantes de conflit au travail comprennent des attentes floues ou contradictoires (en écho à la discussion sur la définition des attentes de la leçon 23), des styles de communication ou de travail différents (en écho à la discussion sur les différences individuelles dans le leadership situationnel de la leçon 7), la rareté des ressources ou de la reconnaissance (la concurrence pour des occasions ou une reconnaissance limitées) et de vraies différences de valeurs ou de priorités sur la façon d'aborder le travail.

Comprendre la vraie source d'un conflit compte plus que de régler seulement ses symptômes visibles, en écho à la reformulation des objections de ORANGE-L2-027 et à la discussion sur l'écoute active de la leçon 11 : deux membres de l'équipe qui semblent se disputer au sujet d'une tâche précise vivent peut-être en réalité un conflit sous-jacent lié à des rôles mal définis ou à un déséquilibre perçu dans la reconnaissance. Une solution qui règle seulement l'attribution de la tâche, sans s'attaquer à la source sous-jacente, risque donc de voir le conflit revenir plus tard sous une autre forme.

**3. Exemple pratique**
En servant de médiatrice dans un différend entre deux membres de son équipe qui semble, en apparence, porter sur une responsabilité précise dans un projet, une leader pratique l'écoute active (leçon 11) pour comprendre la vraie préoccupation de chaque personne. Elle découvre que la source réelle est un partage des responsabilités mal défini, qui laisse les deux personnes incertaines de leur rôle respectif, plutôt qu'un vrai désaccord sur la tâche elle-même. En réglant ce problème de clarté des rôles, au lieu de simplement attribuer la tâche contestée à l'une des deux personnes, elle règle le conflit de façon plus durable qu'une solution superficielle ne l'aurait fait.

**4. Quiz de pratique**
1. Selon cette leçon, quelle est une source courante de conflit au travail?
   a) Des attentes parfaitement claires et non contradictoires, sans aucune ambiguïté
   b) Des attentes floues ou contradictoires, des styles de travail différents ou la rareté des ressources ou de la reconnaissance
   c) Un type de crédit d'impôt
   d) Une source sans aucun lien avec la dynamique du travail
2. Pourquoi comprendre la source sous-jacente d'un conflit compte-t-il plus que de régler seulement les symptômes visibles?
   a) Les symptômes visibles reflètent toujours entièrement la cause sous-jacente, sans distinction
   b) Une solution qui règle seulement les symptômes visibles, sans la source sous-jacente, risque de voir le conflit revenir sous une autre forme
   c) Les sources sous-jacentes n'existent jamais réellement dans les conflits au travail
   d) L'écoute active n'a aucun lien avec la compréhension des sources de conflit
3. Vrai ou faux : Un différend qui semble porter sur l'attribution d'une tâche précise n'a jamais de source plus profonde qui vaut la peine d'être explorée.
4. Qu'est-ce que l'écoute active de la leader a révélé sur le différend apparent au sujet de la tâche?
   a) Le différend portait uniquement sur la tâche précise, sans problème sous-jacent plus profond
   b) La vraie source sous-jacente était un partage des responsabilités mal défini, et non la tâche elle-même
   c) L'écoute active n'a rien révélé d'utile sur la situation
   d) Les membres de l'équipe n'avaient aucune vraie préoccupation sous-jacente

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Des attentes floues ou contradictoires, des styles de travail différents et la rareté des ressources ou de la reconnaissance sont des sources courantes de conflit au travail.
2. Régler seulement les symptômes visibles sans la source sous-jacente risque de voir le conflit revenir plus tard sous une autre forme.
3. Un différend en apparence superficiel a souvent une source plus profonde qui vaut la peine d'être explorée par l'écoute active.
4. L'écoute active de la leader a révélé un problème sous-jacent de clarté des rôles, distinct du différend apparent sur la tâche.

**7. Points clés à retenir**
- Les sources courantes de conflit comprennent des attentes floues, des styles de travail différents et la rareté des ressources ou de la reconnaissance.
- Comprendre la vraie source sous-jacente compte plus que de régler seulement les symptômes visibles.
- Une solution superficielle qui ne règle pas la source sous-jacente voit souvent le conflit revenir sous une autre forme.
- Ça rejoint la reformulation des objections de ORANGE-L2-027 et la discussion sur l'écoute active de la leçon 11.
