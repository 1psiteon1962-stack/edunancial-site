---
id: BLACK-L2-016
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 16
title: "Servir de médiateur dans un conflit entre membres de l'équipe"
summary: "Applique les principes de la médiation à un conflit d'équipe et comprends pourquoi une solution trouvée par les personnes elles-mêmes dure plus longtemps qu'une décision imposée."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-016
### Servir de médiateur dans un conflit entre membres de l'équipe

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Renforcer, du point de vue du leadership, la discussion de PURPLE-L2-029 sur la médiation.
- Nommer les étapes générales d'une médiation menée par un leader dans un conflit d'équipe.
- Appliquer cette notion à une situation de médiation hypothétique.

**2. Contenu principal**
En revenant sur la discussion de PURPLE-L2-029 sur la médiation — une tierce personne neutre qui facilite un règlement plutôt que d'imposer une décision —, cette leçon applique le même principe à un leader qui sert de médiateur dans un conflit entre membres de l'équipe. Les étapes générales comprennent : rencontrer d'abord chaque personne séparément pour comprendre son vrai point de vue (en écho à la discussion sur la source sous-jacente de la leçon 15), puis animer une conversation commune centrée sur le vrai problème sous-jacent plutôt que sur les accusations, et aider les personnes elles-mêmes à trouver une solution acceptable pour les deux, plutôt que le leader impose seul une décision.

Ça reflète la distinction centrale de PURPLE-L2-029 entre la médiation et l'arbitrage : un leader qui impose simplement une décision (et qui agit donc plutôt comme un arbitre) peut régler le différend immédiat, mais ne s'attaque souvent pas à la dynamique relationnelle sous-jacente, alors qu'une vraie médiation — aider les personnes elles-mêmes à arriver à une compréhension et à un règlement — tend à produire des résultats plus durables et peut même améliorer la relation de travail par la suite, au lieu de simplement étouffer le conflit visible.

**3. Exemple pratique**
En servant de médiatrice entre deux membres de son équipe en conflit depuis un moment, une leader rencontre d'abord chaque personne séparément pour comprendre son vrai point de vue, en écho à l'approche de médiation de PURPLE-L2-029, puis anime une conversation commune centrée sur le partage des rôles sous-jacent qui était resté flou (en écho à l'exemple pratique de la leçon 15), plutôt que de revenir sur des incidents passés précis. Au lieu d'imposer sa propre décision sur la répartition des responsabilités, elle guide les deux personnes pour qu'elles trouvent elles-mêmes une solution acceptable pour les deux, ce qui donne un résultat que les deux appuient vraiment, plutôt qu'une décision simplement imposée.

**4. Quiz de pratique**
1. Sur quoi cette leçon revient-elle à partir de PURPLE-L2-029?
   a) Une notion sans aucun lien avec la résolution de conflits
   b) La discussion sur la médiation, appliquée cette fois à un leader qui sert de médiateur dans un conflit entre membres de l'équipe
   c) Uniquement une discussion sur l'arbitrage
   d) Uniquement une discussion sur les poursuites judiciaires
2. Qu'est-ce qui distingue une vraie médiation d'un leader qui impose simplement une décision?
   a) Ce sont des approches identiques, sans distinction importante
   b) La médiation aide les personnes elles-mêmes à arriver à une compréhension et à un règlement, ce qui tend à produire des résultats plus durables qu'une décision imposée
   c) Imposer une décision produit toujours des résultats plus durables que la médiation
   d) La médiation n'a aucun lien avec un règlement durable des conflits
3. Vrai ou faux : Un leader qui impose simplement une décision pour régler un conflit d'équipe agit exactement comme un vrai médiateur.
4. Pourquoi la leader a-t-elle guidé les membres de l'équipe pour qu'ils trouvent leur propre solution, au lieu d'en imposer une elle-même?
   a) Elle voulait plutôt revenir sur des incidents passés précis
   b) Une vraie médiation, en écho à PURPLE-L2-029, tend à produire des résultats plus durables et à améliorer la relation de travail
   c) Imposer une décision aurait été tout aussi efficace
   d) Elle ne tenait pas à régler le conflit sous-jacent

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Cette leçon revient sur la discussion de PURPLE-L2-029 sur la médiation, appliquée à un leader qui sert de médiateur dans un conflit entre membres de l'équipe.
2. Une vraie médiation aide les personnes elles-mêmes à arriver à une compréhension et à un règlement, ce qui tend à produire des résultats plus durables qu'une décision imposée.
3. Un leader qui impose une décision agit plutôt comme un arbitre, ce qui diffère de l'approche facilitante d'une vraie médiation.
4. L'approche de médiation de la leader visait, avec raison, un résultat plus durable et vraiment appuyé qu'une décision imposée.

**7. Points clés à retenir**
- Cette leçon revient sur la discussion de PURPLE-L2-029 sur la médiation, appliquée à un leader qui sert de médiateur dans un conflit d'équipe.
- Les étapes générales comprennent des rencontres individuelles d'abord, puis une conversation commune centrée sur le problème sous-jacent, et l'accompagnement vers une solution trouvée ensemble.
- Une vraie médiation tend à produire des résultats plus durables et à améliorer les relations, contrairement à une décision simplement imposée.
- Ça reflète la distinction centrale de PURPLE-L2-029 entre médiation et arbitrage, appliquée au leadership d'équipe.
