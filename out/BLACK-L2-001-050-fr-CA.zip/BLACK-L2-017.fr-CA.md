---
id: BLACK-L2-017
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 17
title: "Décider dans l'incertitude : une constante du leadership"
summary: "Apprends à décider avec une information incomplète en rassemblant le meilleur de l'information disponible, en expliquant ton raisonnement et en restant prêt à ajuster le tir."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-017
### Décider dans l'incertitude : une constante du leadership

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Renforcer, du point de vue du leadership, la discussion de GOLD-L2-030 sur l'évaluation des occasions dans l'incertitude.
- Expliquer pourquoi les décisions de leadership se prennent avec une information incomplète.
- Appliquer cette notion à une décision de leadership hypothétique.

**2. Contenu principal**
En revenant sur la discussion de GOLD-L2-030 sur les décisions de placement prises dans une vraie incertitude, cette leçon applique la même réalité à la prise de décisions en leadership de façon générale : les leaders doivent régulièrement décider avec une information incomplète, sous la pression du temps et sans le luxe d'être certains des résultats — une réalité différente de celle d'un rôle purement technique ou analytique, qui disposerait peut-être de plus de temps et d'une information complète avant de devoir prendre une décision.

Une prise de décision efficace dans l'incertitude, en écho à la distinction de GOLD-L2-030 entre risque calculé et spéculation imprudente, consiste à rassembler la meilleure information disponible dans un délai raisonnable, à expliquer clairement le raisonnement derrière la décision (ce qui soutient la confiance abordée à la leçon 9, même quand le résultat est incertain) et à rester prêt à ajuster le tir à mesure que de nouvelles informations apparaissent, plutôt que de rester figé indéfiniment en attendant une certitude complète qui n'arrivera peut-être jamais, ou de décider impulsivement sans vraiment tenir compte de l'information disponible.

**3. Exemple pratique**
Devant la décision d'aller de l'avant ou non avec une initiative stratégique importante sans être tout à fait certaine des conditions du marché, une leader rassemble la meilleure information disponible dans un délai raisonnable, explique clairement son raisonnement à son équipe tout en reconnaissant la vraie incertitude sur le résultat, et s'engage à suivre des indicateurs précis qui la pousseraient à ajuster le tir si ses hypothèses de départ se révélaient fausses. Cette approche, en écho à la discussion sur la prise de risques calculés de GOLD-L2-030, évite à la fois la paralysie indéfinie dans l'attente d'une certitude impossible et l'action impulsive sans vraie réflexion.

**4. Quiz de pratique**
1. Sur quoi cette leçon revient-elle à partir de GOLD-L2-030?
   a) Une notion sans aucun lien avec la prise de décisions dans l'incertitude
   b) La discussion sur les décisions de placement dans l'incertitude, appliquée cette fois de façon générale aux décisions de leadership
   c) Uniquement une discussion sur la fraude en placement
   d) Uniquement une discussion sur la répartition de l'actif
2. Selon cette leçon, en quoi consiste généralement une prise de décision efficace en leadership dans l'incertitude?
   a) Rester figé indéfiniment en attendant une certitude complète avant toute décision
   b) Rassembler la meilleure information disponible, expliquer clairement son raisonnement et rester prêt à ajuster le tir à mesure que de nouvelles informations apparaissent
   c) Décider impulsivement sans vraiment tenir compte de l'information disponible
   d) Éviter toute décision tant que chaque incertitude possible n'est pas réglée
3. Vrai ou faux : Les leaders devraient généralement attendre d'avoir une information complète et certaine avant de prendre une décision importante.
4. Pourquoi la leader s'est-elle engagée à suivre des indicateurs précis après sa décision stratégique?
   a) Elle était entièrement certaine du résultat et n'avait besoin d'aucun suivi
   b) Elle restait prête à ajuster le tir à mesure que de nouvelles informations apparaissaient, en écho à la discussion sur la prise de risques calculés de GOLD-L2-030
   c) Le suivi n'a aucun lien avec la prise de décisions dans l'incertitude
   d) Elle voulait éviter de réfléchir davantage au résultat de sa décision

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Cette leçon revient sur la discussion de GOLD-L2-030 sur les décisions de placement dans l'incertitude, appliquée de façon générale aux décisions de leadership.
2. Une prise de décision efficace consiste à rassembler la meilleure information disponible, à expliquer clairement son raisonnement et à rester prêt à ajuster le tir quand de nouvelles informations apparaissent.
3. Une certitude complète n'est généralement pas possible, et les leaders doivent décider avec la meilleure information disponible dans un délai raisonnable.
4. L'engagement de la leader à faire un suivi reflétait, avec raison, l'approche calculée et ajustable décrite dans GOLD-L2-030.

**7. Points clés à retenir**
- Cette leçon revient sur la discussion de GOLD-L2-030 sur la prise de décisions dans l'incertitude, appliquée de façon générale au leadership.
- Les leaders décident régulièrement avec une information incomplète, sous la pression du temps, sans certitude sur les résultats.
- Une prise de décision efficace consiste à rassembler l'information disponible, à raisonner clairement et à rester prêt à ajuster le tir.
- Ça évite à la fois la paralysie indéfinie et l'action impulsive sans vraie réflexion.
