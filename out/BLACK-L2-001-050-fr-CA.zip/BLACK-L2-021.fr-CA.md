---
id: BLACK-L2-021
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 21
title: "Embaucher selon l'adéquation : compétences ou valeurs"
summary: "Compare l'adéquation des compétences et l'adéquation des valeurs à l'embauche, et comprends pourquoi un écart de valeurs est plus difficile à corriger qu'un écart de compétences."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-021
### Embaucher selon l'adéquation : compétences ou valeurs

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Distinguer l'adéquation des compétences de l'adéquation des valeurs à l'embauche.
- Expliquer pourquoi les deux dimensions comptent, et pourquoi un écart de valeurs est souvent plus difficile à corriger par la suite.
- Appliquer cette notion à une situation d'embauche hypothétique.

**2. Contenu principal**
En s'appuyant sur la discussion sur l'embauche de BLUE-L2-021, cette leçon examine une dimension précise que les leaders devraient évaluer : l'adéquation des compétences (la personne candidate a-t-elle les capacités techniques ou fonctionnelles qu'exige le poste?) par rapport à l'adéquation des valeurs (le style de travail, l'éthique et l'approche générale de la personne candidate correspondent-ils à la culture de l'organisation, abordée brièvement ici et approfondie à la leçon 28?). Les deux dimensions comptent, mais elles n'ont pas les mêmes conséquences pratiques : les écarts de compétences peuvent souvent être comblés par la formation et le développement au fil du temps, alors qu'un écart de valeurs — des différences fondamentales d'éthique de travail, d'honnêteté ou d'esprit de collaboration — est généralement beaucoup plus difficile à corriger après l'embauche.

Ça ne veut pas dire que les compétences ne sont pas importantes, mais ça veut dire qu'un leader qui compare une personne candidate aux compétences solides mais dont les valeurs correspondent peu, à une personne candidate aux compétences moyennes mais dont les valeurs correspondent bien, devrait reconnaître qu'il s'agit d'un compromis d'un genre vraiment différent de celui de choisir entre deux personnes qui diffèrent surtout par leur niveau de compétence, puisqu'un des deux écarts se comble généralement plus facilement par la formation que l'autre.

**3. Exemple pratique**
En comparant les deux personnes finalistes pour un poste à pourvoir, une leader constate que l'une a de meilleures compétences techniques immédiates, mais a montré pendant le processus d'entrevue des signaux préoccupants quant à son esprit de collaboration et à son honnêteté, alors que l'autre a un peu moins de compétences techniques immédiates, mais démontre une forte adéquation avec les valeurs de collaboration et l'éthique de travail de l'équipe. Reconnaissant que les écarts de compétences se comblent généralement plus facilement par la formation qu'un écart de valeurs, elle choisit la personne dont les valeurs correspondent, en prévoyant investir dans la formation pour combler l'écart de compétences, plus facile à régler.

**4. Quiz de pratique**
1. Dans ce contexte d'embauche, à quoi l'adéquation des compétences fait-elle généralement référence?
   a) Au style de travail, à l'éthique et à l'approche culturelle générale de la personne candidate
   b) Au fait que la personne candidate a ou non les capacités techniques ou fonctionnelles qu'exige le poste
   c) À un type de crédit d'impôt
   d) À une notion identique à l'adéquation des valeurs, sans distinction
2. Pourquoi un écart de valeurs est-il généralement plus difficile à corriger qu'un écart de compétences?
   a) Les écarts de compétences sont impossibles à combler par la formation
   b) Des différences fondamentales d'éthique de travail, d'honnêteté ou d'esprit de collaboration sont généralement beaucoup plus difficiles à corriger après l'embauche que des écarts de compétences techniques
   c) Les valeurs et les compétences posent exactement les mêmes défis de correction
   d) Un écart de valeurs se règle toujours naturellement avec le temps
3. Vrai ou faux : L'adéquation des compétences et l'adéquation des valeurs posent des défis identiques, aussi faciles à combler par la formation, quand une personne candidate a des lacunes dans l'une ou l'autre.
4. Pourquoi la leader a-t-elle choisi la personne dont les valeurs correspondaient, plutôt que celle qui avait de meilleures compétences techniques immédiates?
   a) Les écarts de compétences sont généralement plus difficiles à corriger qu'un écart de valeurs
   b) Elle a reconnu qu'un écart de valeurs est généralement plus difficile à corriger, alors que l'écart de compétences pouvait plus facilement être comblé par la formation
   c) Elle n'avait aucune préoccupation quant aux valeurs de l'une ou l'autre des personnes candidates
   d) Les compétences techniques n'ont aucune importance dans les décisions d'embauche

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'adéquation des compétences fait généralement référence au fait que la personne candidate a ou non les capacités techniques ou fonctionnelles qu'exige le poste.
2. Des différences fondamentales d'éthique de travail, d'honnêteté ou d'esprit de collaboration sont généralement beaucoup plus difficiles à corriger après l'embauche que des écarts de compétences techniques.
3. Les compétences et les valeurs posent des défis de correction vraiment différents, un écart de valeurs étant généralement plus difficile à régler après l'embauche.
4. Le choix de la leader a pesé, avec raison, l'écart de valeurs, généralement plus difficile à corriger, par rapport à l'écart de compétences, plus facile à combler par la formation.

**7. Points clés à retenir**
- L'adéquation des compétences porte sur les capacités techniques ou fonctionnelles; l'adéquation des valeurs porte sur le style de travail, l'éthique et la correspondance avec la culture.
- Les écarts de compétences se comblent souvent plus facilement par la formation qu'un écart de valeurs, qui est généralement beaucoup plus difficile à corriger après l'embauche.
- Ça ne rend pas les compétences moins importantes, mais ça change le calcul quand on compare des compromis entre personnes candidates.
- Ça s'appuie directement sur la discussion sur l'embauche de BLUE-L2-021 et annonce la discussion sur la culture de la leçon 28.
