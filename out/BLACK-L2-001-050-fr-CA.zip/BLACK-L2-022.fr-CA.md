---
id: BLACK-L2-022
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 22
title: "L'intégration : les 90 premiers jours et pourquoi ils comptent"
summary: "Comprends pourquoi la période d'intégration influence l'engagement et la rétention à long terme, et ce qu'elle doit comprendre pour bien fonctionner."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-022
### L'intégration : les 90 premiers jours et pourquoi ils comptent

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi la période d'intégration initiale a une importance démesurée.
- Nommer les composantes générales d'une intégration efficace.
- Appliquer cette notion à une situation hypothétique d'arrivée d'une nouvelle personne.

**2. Contenu principal**
La période qui suit l'arrivée d'une nouvelle personne — qu'on appelle souvent les 90 premiers jours — a une importance démesurée pour l'évolution à long terme de la relation d'emploi : cette période façonne généralement la compréhension des attentes du nouveau membre de l'équipe (annoncée ici pour la leçon 23), son sentiment d'appartenance et d'adéquation avec la culture (annoncé pour la leçon 28), ainsi que ses premières impressions sur la compétence de l'organisation et sur le souci réel qu'elle a de sa réussite. Tous ces éléments peuvent influencer de façon importante son engagement, son rendement et même la probabilité qu'il reste dans l'organisation à long terme.

Une intégration efficace comprend généralement une communication claire des attentes du poste et des critères de réussite dès le départ (en écho à la leçon 23), une présentation proactive aux personnes et aux ressources clés dont la nouvelle personne aura besoin, et des suivis réguliers et structurés dès le début, plutôt que de la laisser découvrir seule comment réussir. Une période d'intégration mal gérée peut faire éprouver des difficultés inutiles même à une personne très qualifiée, ce qui mène parfois à des départs hâtifs qu'un processus d'intégration plus réfléchi aurait pu éviter.

**3. Exemple pratique**
À l'arrivée d'un nouveau membre dans son équipe, une leader structure volontairement un processus d'intégration complet au lieu de le laisser comprendre seul les attentes et les relations : elle communique clairement les critères de réussite précis du poste dès le premier jour, présente de façon proactive la nouvelle personne aux collègues et aux ressources clés, et prévoit des suivis structurés réguliers tout au long des 90 premiers jours, plutôt qu'un suivi improvisé et occasionnel. Cette approche réfléchie aide la nouvelle personne à gagner confiance et à vraiment comprendre son rôle plus rapidement qu'une période d'intégration non structurée ne l'aurait permis.

**4. Quiz de pratique**
1. Selon cette leçon, pourquoi la période d'intégration initiale a-t-elle une importance démesurée?
   a) Elle n'a aucun lien avec l'engagement ou le rendement à long terme d'une nouvelle personne
   b) Elle façonne fortement la compréhension des attentes, l'adéquation avec la culture et les premières impressions, ce qui influence l'engagement et la rétention à long terme
   c) L'intégration compte seulement pour la toute première journée, sans effet durable
   d) La période initiale n'a aucun lien avec les départs hâtifs évitables
2. Selon cette leçon, quelle est une composante générale d'une intégration efficace?
   a) Laisser la nouvelle personne découvrir seule les attentes, sans soutien structuré
   b) Une communication claire des attentes du poste, une présentation proactive aux personnes clés et des suivis structurés réguliers
   c) Un type de crédit d'impôt
   d) Éviter toute communication des critères de réussite
3. Vrai ou faux : Une période d'intégration mal gérée n'a aucun lien avec la probabilité qu'une personne très qualifiée éprouve des difficultés ou parte tôt.
4. Pourquoi la leader a-t-elle prévu des suivis structurés réguliers tout au long des 90 premiers jours de la nouvelle personne?
   a) Elle voulait laisser la nouvelle personne comprendre seule les attentes
   b) Des suivis structurés réguliers soutiennent la compréhension et la confiance d'une nouvelle personne plus efficacement qu'une approche non structurée
   c) Les suivis n'ont aucun lien avec l'efficacité de l'intégration
   d) Elle ne s'intéressait pas à la réussite initiale de la nouvelle personne

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La période d'intégration initiale façonne fortement la compréhension des attentes, l'adéquation avec la culture et les premières impressions d'une nouvelle personne, ce qui influence son engagement et sa rétention à long terme.
2. Une communication claire des attentes, une présentation proactive aux personnes clés et des suivis structurés réguliers sont des composantes générales d'une intégration efficace.
3. Une période d'intégration mal gérée peut faire éprouver des difficultés inutiles même à une personne très qualifiée, ce qui mène parfois à des départs hâtifs évitables.
4. Les suivis structurés de la leader ont soutenu, avec raison, la confiance et la compréhension de la nouvelle personne plus efficacement qu'une approche non structurée.

**7. Points clés à retenir**
- La période d'intégration initiale a une importance démesurée pour l'engagement, le rendement et la rétention à long terme.
- Une intégration efficace comprend une communication claire des attentes, une présentation proactive aux personnes clés et des suivis structurés réguliers.
- Une période d'intégration mal gérée peut mener à des départs hâtifs évitables, même chez des personnes très qualifiées.
- Ça annonce la discussion sur la définition des attentes de la leçon 23 et celle sur la culture de la leçon 28.
