---
id: BLACK-L2-023
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 23
title: "Définir les attentes : la racine de la plupart des problèmes de rendement"
summary: "Comprends pourquoi beaucoup de problèmes de rendement viennent d'attentes jamais clairement communiquées, et comment fixer des attentes précises et confirmées."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-023
### Définir les attentes : la racine de la plupart des problèmes de rendement

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi des attentes floues sont à la source de nombreux problèmes de rendement apparents.
- Nommer les caractéristiques générales d'attentes bien définies.
- Appliquer cette notion à une situation de rendement hypothétique.

**2. Contenu principal**
En s'appuyant directement sur la leçon 22, cette leçon aborde une cause profonde souvent négligée derrière de nombreux problèmes de rendement apparents : des attentes qui n'ont jamais été clairement communiquées ni comprises de la même façon par les deux parties au départ. Un membre de l'équipe qui semble avoir un rendement insuffisant peut, dans certains cas, avoir en réalité un rendement raisonnable par rapport à sa propre compréhension de ce qu'on attendait de lui — une compréhension différente des attentes réelles, mais jamais exprimées, du leader, en écho à la discussion sur la clarté de la communication de la leçon 10.

Des attentes bien définies sont généralement précises (elles définissent clairement à quoi ressemble la réussite, et non une vague idée générale), confirmées par les deux parties (le leader a vérifié que le membre de l'équipe comprend vraiment, au lieu de supposer qu'un message bien livré est forcément bien reçu, en écho à la leçon 10) et documentées de façon appropriée quand c'est utile pour s'y référer plus tard. Investir cet effort dès le départ évite généralement une part importante des problèmes de rendement qui exigeraient autrement une intervention plus difficile par la suite (leçon 26).

**3. Exemple pratique**
En examinant un problème de rendement apparent, une leader découvre, en regardant de plus près, que le membre de l'équipe n'avait jamais vraiment reçu un énoncé clair et précis de ce à quoi ressemblait la réussite dans son poste — la leader supposait que c'était compris, mais ne l'avait jamais communiqué explicitement et précisément, ni vérifié que la personne avait vraiment compris. Reconnaissant que cet échec dans la définition des attentes est la vraie cause, plutôt qu'un vrai problème de rendement ou d'effort, la leader comble l'écart directement en communiquant et en confirmant clairement des attentes précises pour la suite, ce qui règle une grande partie du problème apparent sans avoir besoin de l'intervention plus difficile pour rendement insuffisant décrite à la leçon 26.

**4. Quiz de pratique**
1. Quelle cause profonde souvent négligée cette leçon nomme-t-elle derrière de nombreux problèmes de rendement apparents?
   a) Des attentes trop claires et trop bien communiquées
   b) Des attentes qui n'ont jamais été clairement communiquées ni comprises de la même façon par les deux parties au départ
   c) Un type de crédit d'impôt
   d) Une cause sans aucun lien avec la communication
2. Selon cette leçon, qu'est-ce qui caractérise généralement des attentes bien définies?
   a) Elles sont vagues, non confirmées et non documentées
   b) Elles sont précises, confirmées par les deux parties et documentées de façon appropriée quand c'est utile
   c) Une notion identique à des attentes mal définies
   d) Des attentes qui ne sont jamais communiquées explicitement
3. Vrai ou faux : Le rendement insuffisant apparent d'un membre de l'équipe est toujours vraiment lié à son effort ou à sa capacité, jamais à des attentes floues.
4. Pourquoi l'examen de la leader a-t-il révélé un échec dans la définition des attentes plutôt qu'un vrai problème de rendement?
   a) Le membre de l'équipe avait reçu un énoncé clair, précis et confirmé des attentes
   b) La leader avait supposé que les attentes étaient comprises sans jamais les communiquer explicitement ni les confirmer
   c) La définition des attentes n'a aucun lien avec les résultats en matière de rendement
   d) Le membre de l'équipe n'avait aucune responsabilité dans son poste

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Des attentes qui n'ont jamais été clairement communiquées ni comprises par les deux parties sont une cause profonde souvent négligée des problèmes de rendement apparents.
2. Des attentes bien définies sont précises, confirmées par les deux parties et documentées de façon appropriée quand c'est utile.
3. Un rendement insuffisant apparent peut parfois refléter des attentes floues plutôt qu'un vrai problème d'effort ou de capacité.
4. L'examen de la leader a révélé qu'elle avait supposé la compréhension sans communication explicite ni confirmation, ce qui était la vraie cause.

**7. Points clés à retenir**
- Des attentes floues ou non confirmées sont à la source de nombreux problèmes de rendement apparents, distincts des vrais problèmes d'effort ou de capacité.
- Des attentes bien définies sont précises, confirmées par les deux parties et documentées de façon appropriée.
- Investir dès le départ dans une définition claire des attentes évite de nombreux problèmes de rendement qui exigeraient autrement une intervention plus difficile.
- Ça s'appuie directement sur la discussion sur la clarté de la communication de la leçon 10 et annonce la discussion sur le rendement insuffisant de la leçon 26.
