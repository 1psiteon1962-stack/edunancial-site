---
id: BLACK-L2-024
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 24
title: "La gestion du rendement : continue, et pas seulement annuelle"
summary: "Comprends pourquoi des suivis réguliers tout au long de l'année fonctionnent mieux qu'une seule évaluation annuelle, et quel rôle garde l'évaluation officielle."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-024
### La gestion du rendement : continue, et pas seulement annuelle

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi une gestion du rendement continue donne de meilleurs résultats qu'une approche limitée à l'évaluation annuelle.
- Relier directement cette notion à la discussion sur la rétroaction rapide de la leçon 12.
- Appliquer cette notion à une situation hypothétique de gestion du rendement.

**2. Contenu principal**
En s'appuyant directement sur la discussion sur la rétroaction rapide de la leçon 12, cette leçon présente la gestion du rendement comme une pratique de leadership continue, et non comme une activité limitée à une seule évaluation annuelle. Une approche limitée à l'évaluation annuelle souffre généralement du même problème de moment que celui relevé à la leçon 12 : une rétroaction sur des événements survenus plusieurs mois plus tôt a perdu une grande partie de sa pertinence et de son utilité, et un membre de l'équipe qui reçoit sa première vraie discussion sur son rendement de l'année pendant une seule évaluation officielle peut être, avec raison, surpris ou pris de court par des préoccupations qui auraient pu être abordées beaucoup plus tôt.

Une gestion du rendement continue comprend généralement des suivis réguliers et moins formels tout au long de l'année sur des observations précises et récentes (en écho à la leçon 12), l'évaluation officielle annuelle ou périodique servant alors de synthèse et de conversation de planification tournée vers l'avenir, plutôt que de seule occasion de donner une vraie rétroaction sur le rendement. Cette approche donne généralement moins de surprises, plus d'occasions de corriger le tir à temps et une relation continue plus solide qu'une approche purement annuelle.

**3. Exemple pratique**
En revoyant sa façon de gérer le rendement, une leader passe d'une seule évaluation annuelle à de brefs suivis mensuels réguliers sur des observations précises et récentes tout au long de l'année, en écho au principe de rétroaction rapide de la leçon 12. Quand son évaluation annuelle officielle arrive enfin, elle sert surtout de synthèse des thèmes déjà abordés pendant l'année et de conversation de planification tournée vers l'avenir, au lieu de surprendre le membre de son équipe avec de nouvelles préoccupations sur des événements survenus plusieurs mois plus tôt, qui auraient pu être réglées bien avant.

**4. Quiz de pratique**
1. Selon cette leçon, de quel problème souffre généralement une approche limitée à l'évaluation annuelle?
   a) D'aucun problème
   b) Du même problème de moment relevé à la leçon 12 — une rétroaction sur des événements vieux de plusieurs mois perd sa pertinence et son utilité
   c) Les évaluations annuelles sont toujours plus rapides et plus efficaces que les suivis continus
   d) Les évaluations annuelles n'ont aucun lien avec le moment où la rétroaction est donnée
2. Dans une approche de gestion du rendement continue, quel rôle joue généralement l'évaluation officielle annuelle?
   a) La seule occasion de donner une vraie rétroaction sur le rendement pendant l'année
   b) Une synthèse et une conversation de planification tournée vers l'avenir, qui s'appuie sur les thèmes déjà abordés lors des suivis réguliers
   c) Une notion sans lien avec la gestion du rendement continue
   d) Une occasion de surprendre le membre de l'équipe avec des préoccupations entièrement nouvelles
3. Vrai ou faux : Une gestion du rendement continue tout au long de l'année rend l'évaluation officielle annuelle complètement inutile et devrait la remplacer entièrement.
4. Pourquoi le membre de l'équipe de la leader a-t-il eu moins de surprises pendant l'évaluation annuelle officielle après ce changement?
   a) L'évaluation annuelle restait la seule occasion de discuter du rendement
   b) Les suivis mensuels réguliers pendant l'année avaient déjà abordé des observations précises et récentes, ce qui faisait de l'évaluation annuelle une synthèse plutôt qu'une surprise
   c) Les suivis continus n'ont aucun lien avec la réduction des surprises pendant les évaluations officielles
   d) La leader a évité toute discussion sur le rendement pendant l'année

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une approche limitée à l'évaluation annuelle souffre du même problème de moment relevé à la leçon 12, puisqu'une rétroaction vieille de plusieurs mois perd sa pertinence et son utilité.
2. Dans une approche continue, l'évaluation officielle annuelle sert de synthèse et de conversation de planification tournée vers l'avenir, en s'appuyant sur les suivis réguliers.
3. Une gestion du rendement continue complète la fonction de synthèse et de planification d'une évaluation officielle périodique, plutôt que de la remplacer entièrement.
4. Les suivis mensuels réguliers de la leader pendant l'année ont réduit, avec raison, les surprises lors de l'évaluation annuelle officielle.

**7. Points clés à retenir**
- Une gestion du rendement continue tout au long de l'année donne de meilleurs résultats que de compter seulement sur une évaluation annuelle.
- Ça s'appuie directement sur la discussion sur la rétroaction rapide de la leçon 12, appliquée à la structure plus large de la gestion du rendement.
- L'évaluation officielle annuelle fonctionne mieux comme synthèse et conversation de planification, et non comme seule occasion de vraie rétroaction.
- Cette approche continue donne moins de surprises, plus d'occasions de corriger le tir à temps et une relation plus solide.
