---
id: BLACK-L2-025
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 25
title: "Reconnaître et récompenser le rendement"
summary: "Apprends à reconnaître une contribution de façon précise et rapide, et comprends pourquoi la reconnaissance complète la rémunération comme source de motivation."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-025
### Reconnaître et récompenser le rendement

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le but général de reconnaître et de récompenser un bon rendement.
- Distinguer une reconnaissance sincère et précise d'éloges vagues et rares.
- Appliquer cette notion à une situation de reconnaissance hypothétique.

**2. Contenu principal**
En s'appuyant sur les principes de rétroaction de la leçon 12, reconnaître et récompenser un bon rendement suit généralement les mêmes normes de précision et de rapidité qu'exige une rétroaction constructive efficace — une reconnaissance sincère et précise (qui souligne une réalisation ou un comportement particulier, et non un vague compliment général) donnée rapidement tend à avoir plus de sens et plus de chances de renforcer le comportement reconnu que des éloges vagues et rares, déconnectés de réalisations précises.

Ça se relie directement à la discussion sur la rémunération de la leçon 46, plus loin : la rémunération et les récompenses officielles comptent vraiment, mais la recherche et l'expérience courante suggèrent aussi qu'une reconnaissance sincère et précise — un leader qui souligne authentiquement la contribution particulière d'un membre de l'équipe — a une vraie valeur de motivation, indépendante de la rémunération officielle et complémentaire à celle-ci. Un leader qui compte entièrement sur la rémunération en négligeant la reconnaissance sincère au quotidien se prive donc peut-être d'un outil de motivation important et peu coûteux.

**3. Exemple pratique**
Au lieu de se limiter à des éloges vagues et occasionnels comme « beau travail, l'équipe » pendant les grandes réunions, une leader prend l'habitude de reconnaître de façon précise et rapide les contributions individuelles — par exemple, en soulignant tout de suite après coup la façon précise et efficace dont un membre de l'équipe a géré une situation difficile avec un client, plutôt que de l'inclure dans un remerciement de groupe vague et tardif. Cette reconnaissance précise et rapide, distincte de sa structure de rémunération officielle, est un outil de motivation important et peu coûteux qui renforce le comportement précis qu'elle souhaite voir se poursuivre.

**4. Quiz de pratique**
1. Selon cette leçon, qu'est-ce qui distingue généralement une reconnaissance sincère et précise d'éloges vagues?
   a) Une reconnaissance sincère souligne une réalisation ou un comportement particulier, et non un vague compliment général
   b) Des éloges vagues ont toujours plus de sens qu'une reconnaissance précise
   c) Un type de crédit d'impôt
   d) Une reconnaissance sincère devrait toujours être tardive et générale
2. Comment cette leçon se relie-t-elle à la discussion sur la rémunération de la leçon 46, plus loin?
   a) La reconnaissance et la rémunération sont des notions identiques, sans distinction
   b) Une reconnaissance sincère et précise a une vraie valeur de motivation, indépendante de la rémunération officielle et complémentaire à celle-ci
   c) La reconnaissance n'a aucun lien avec la motivation
   d) La rémunération seule suffit toujours, sans besoin de vraie reconnaissance
3. Vrai ou faux : Un leader qui compte entièrement sur la rémunération officielle en négligeant la reconnaissance sincère au quotidien utilise toute la gamme des outils de motivation disponibles.
4. Pourquoi la leader a-t-elle reconnu de façon précise et rapide la façon dont le membre de l'équipe avait géré la situation avec le client?
   a) Elle voulait inclure la reconnaissance dans un commentaire de groupe vague et tardif
   b) Une reconnaissance précise et rapide, en écho aux principes de rétroaction de la leçon 12, est un outil de motivation important et peu coûteux
   c) La reconnaissance n'a aucun lien avec le renforcement des comportements souhaités
   d) Elle ne tenait pas à souligner les contributions individuelles

**5. Corrigé**
1. a  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une reconnaissance sincère souligne précisément une réalisation ou un comportement particulier, ce qui la distingue d'un vague compliment général.
2. Une reconnaissance sincère et précise a une vraie valeur de motivation, indépendante de la rémunération officielle et complémentaire à celle-ci.
3. Un leader qui compte entièrement sur la rémunération en négligeant la vraie reconnaissance se prive peut-être d'un outil de motivation important et peu coûteux.
4. La reconnaissance précise et rapide de la leader a renforcé, avec raison, le comportement souhaité, en écho aux principes de rétroaction de la leçon 12.

**7. Points clés à retenir**
- Une reconnaissance sincère et précise, donnée rapidement, tend à avoir plus de sens que des éloges vagues et rares.
- Ça applique à la reconnaissance positive les mêmes normes de précision et de rapidité que la discussion sur la rétroaction de la leçon 12.
- La reconnaissance a une valeur de motivation indépendante de la rémunération officielle et complémentaire à celle-ci, un thème annoncé ici pour la leçon 46.
- Négliger la reconnaissance sincère au quotidien peut laisser inutilisé un outil de motivation important et peu coûteux.
