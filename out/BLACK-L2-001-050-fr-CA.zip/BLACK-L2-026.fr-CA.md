---
id: BLACK-L2-026
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 26
title: "Régler un rendement insuffisant : la structure avant l'improvisation"
summary: "Apprends à suivre un processus structuré face à un rendement insuffisant, en commençant par vérifier que les attentes étaient claires, puis en fixant un plan, des jalons et un échéancier."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-026
### Régler un rendement insuffisant : la structure avant l'improvisation

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le but général d'un processus structuré face à un rendement insuffisant.
- Nommer les composantes générales qu'un tel processus pourrait comprendre.
- Appliquer cette notion à une situation de rendement insuffisant hypothétique.

**2. Contenu principal**
En s'appuyant sur les leçons 14 (conversations difficiles) et 23 (définition des attentes), cette leçon aborde la façon de régler un vrai rendement insuffisant — distinct des échecs dans la définition des attentes que la leçon 23 a nommés comme une cause fréquente — au moyen d'un processus structuré plutôt que d'une improvisation au cas par cas. Une approche structurée comprend généralement : d'abord confirmer que les attentes étaient vraiment claires et comprises (pour écarter la cause plus fréquente de la leçon 23), puis nommer clairement l'écart de rendement précis avec des exemples concrets (en écho à la norme de précision de la leçon 12), élaborer un plan d'amélioration précis avec des jalons clairs et mesurables, et fixer un échéancier défini pour réévaluer la situation.

Cette approche structurée protège à la fois l'organisation et le membre de l'équipe : elle donne au membre de l'équipe une vraie occasion, clairement définie, de s'améliorer avec une orientation précise plutôt qu'une critique vague, tout en offrant au leader et à l'organisation un processus documenté et équitable si le rendement insuffisant exige finalement la décision plus difficile abordée à la leçon 27, plutôt qu'une approche improvisée et incohérente qui pourrait sembler arbitraire ou injuste pour le membre de l'équipe concerné.

**3. Exemple pratique**
Devant une situation de vrai rendement insuffisant, après avoir d'abord confirmé (en écho à la leçon 23) que les attentes avaient bel et bien été clairement communiquées et comprises, une leader élabore un plan d'amélioration structuré avec le membre de l'équipe : elle nomme précisément l'écart de rendement avec des exemples concrets, fixe des jalons d'amélioration clairs et mesurables, et établit un échéancier défini pour la réévaluation. Cette approche structurée, plutôt qu'une conversation improvisée ou purement informelle, donne au membre de l'équipe une vraie clarté et une vraie occasion de s'améliorer, tout en établissant un processus équitable et documenté si d'autres mesures devenaient éventuellement nécessaires.

**4. Quiz de pratique**
1. Selon cette leçon, que faut-il confirmer d'abord avant de régler un rendement insuffisant apparent au moyen d'un processus structuré?
   a) Rien n'a besoin d'être confirmé avant d'aller de l'avant
   b) Si les attentes étaient vraiment claires et comprises, pour écarter la cause plus fréquente de la leçon 23
   c) Uniquement la situation personnelle du membre de l'équipe
   d) Le rendement financier global de l'organisation
2. Selon cette leçon, quelle est une composante générale d'un processus structuré face à un rendement insuffisant?
   a) Une critique vague et non documentée, sans exemple précis
   b) Nommer clairement l'écart de rendement précis avec des exemples concrets et élaborer un plan d'amélioration précis avec des jalons mesurables
   c) Un type de crédit d'impôt
   d) Une approche improvisée sans échéancier défini
3. Vrai ou faux : Un processus structuré face à un rendement insuffisant n'offre aucun vrai avantage par rapport à une approche improvisée au cas par cas.
4. Pourquoi la leader a-t-elle d'abord confirmé que les attentes avaient été clairement communiquées avant d'aller de l'avant avec son plan structuré?
   a) Elle voulait sauter cette étape et supposer un vrai rendement insuffisant de toute façon
   b) Elle a reconnu que cette étape écartait la cause fréquente d'attentes floues de la leçon 23 avant de régler un vrai rendement insuffisant
   c) La confirmation des attentes n'a aucun lien avec une bonne façon de régler un rendement insuffisant
   d) Elle ne tenait pas à un processus équitable et structuré

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Il faut d'abord confirmer si les attentes étaient vraiment claires et comprises, pour écarter la cause plus fréquente de la leçon 23.
2. Nommer clairement l'écart de rendement précis avec des exemples concrets et élaborer un plan d'amélioration précis avec des jalons mesurables sont des composantes générales.
3. Un processus structuré offre un vrai avantage par rapport à l'improvisation, en donnant de la clarté au membre de l'équipe et un processus équitable et documenté à l'organisation.
4. L'étape de confirmation de la leader a écarté, avec raison, la cause plus fréquente liée à la définition des attentes avant de passer à une intervention pour un vrai rendement insuffisant.

**7. Points clés à retenir**
- Pour régler un rendement insuffisant, il faut d'abord écarter la cause plus fréquente d'attentes floues de la leçon 23.
- Un processus structuré comprend la description précise de l'écart, un plan d'amélioration clair avec des jalons mesurables et un échéancier de réévaluation défini.
- Cette approche structurée protège à la fois le membre de l'équipe (une vraie occasion de s'améliorer) et l'organisation (un processus équitable et documenté).
- Ça s'appuie directement sur les discussions des leçons 14 et 23 sur les conversations difficiles et la définition des attentes.
