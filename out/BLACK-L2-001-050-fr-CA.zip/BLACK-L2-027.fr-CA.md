---
id: BLACK-L2-027
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 27
title: "Quand mettre fin à un emploi : une décision de leadership difficile"
summary: "Comprends ce qui doit guider une décision de cessation d'emploi : un processus juste et documenté, un vrai souci de la personne et le refus de reporter indéfiniment par malaise."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-027
### Quand mettre fin à un emploi : une décision de leadership difficile

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer les considérations générales qui guident une décision de cessation d'emploi.
- Renforcer, dans ce contexte précis et difficile, le thème de la responsabilité de l'employeur de BLUE-L2-020.
- Appliquer cette notion à une situation de cessation d'emploi hypothétique.

**2. Contenu principal**
En s'appuyant directement sur le processus structuré face à un rendement insuffisant de la leçon 26, cette leçon aborde la décision difficile de mettre fin à un emploi quand un processus d'amélioration structuré n'a pas donné une amélioration suffisante, ou quand un problème plus grave (une violation sérieuse d'une politique ou un manquement à l'éthique) justifie une action plus immédiate. Cette décision devrait généralement suivre le processus structuré et documenté décrit à la leçon 26, quand il s'applique, à la fois par équité envers la personne et pour les intérêts légitimes de l'organisation, et elle devrait être prise avec le vrai souci d'intendance sur lequel insistent la leçon 8 et BLUE-L2-020, en reconnaissant l'effet important sur le gagne-pain de la personne touchée.

Ça ne veut pas dire que les décisions de cessation d'emploi devraient être reportées indéfiniment par malaise — en écho à la discussion de la leçon 14 sur l'évitement des conversations difficiles, retarder une cessation d'emploi vraiment nécessaire ne sert souvent ni la personne (qui pourrait profiter d'une transition nette vers un poste qui lui convient mieux), ni l'équipe (qui peut être touchée par un rendement insuffisant persistant ou un comportement problématique), ni l'organisation. Il s'agit donc d'une décision qui exige à la fois un vrai souci de la personne et un moment approprié, et non un évitement indéfini.

**3. Exemple pratique**
Après qu'un processus d'amélioration structuré (leçon 26) n'a pas donné une amélioration suffisante malgré un vrai soutien et des attentes claires, une leader prend la décision difficile de mettre fin à l'emploi d'un membre de son équipe, après avoir documenté le processus de façon équitable et complète du début à la fin. Elle aborde la conversation de cessation d'emploi avec un vrai souci et du respect pour la dignité de la personne, en écho au thème de l'intendance de ce niveau, tout en reconnaissant que continuer de reporter cette décision nécessaire à cause de son propre malaise ne servirait vraiment ni la personne, ni son équipe, ni l'organisation.

**4. Quiz de pratique**
1. Selon cette leçon, qu'est-ce qui devrait généralement précéder une décision de cessation d'emploi, quand ça s'applique?
   a) Aucun processus, en procédant immédiatement sans aucune documentation
   b) Le processus structuré et documenté face à un rendement insuffisant décrit à la leçon 26, quand il s'applique
   c) Un processus sans lien avec l'équité ou les intérêts de l'organisation
   d) Un report indéfini, peu importe la gravité de la situation
2. Selon cette leçon, pourquoi les décisions de cessation d'emploi ne devraient-elles pas être reportées indéfiniment par malaise?
   a) Le report n'a jamais d'effet négatif sur la personne, l'équipe ou l'organisation
   b) Retarder une cessation d'emploi vraiment nécessaire ne sert souvent ni la personne, ni l'équipe, ni l'organisation
   c) Le report indéfini est toujours l'approche la plus fidèle à l'intendance
   d) Les décisions de cessation d'emploi n'ont aucun lien avec le moment choisi
3. Vrai ou faux : Une décision de cessation d'emploi devrait toujours être prise immédiatement, sans processus structuré ni documentation, peu importe la situation.
4. Conformément au thème de l'intendance de cette leçon, comment la leader a-t-elle abordé la conversation de cessation d'emploi?
   a) Sans vrai souci ni respect pour la dignité de la personne
   b) Avec un vrai souci et du respect pour la dignité de la personne, en écho au thème de l'intendance de ce niveau
   c) En reportant indéfiniment la conversation à cause de son propre malaise
   d) Sans aucun processus structuré et documenté au préalable

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Le processus structuré et documenté face à un rendement insuffisant de la leçon 26 devrait généralement précéder une décision de cessation d'emploi, quand il s'applique.
2. Retarder une cessation d'emploi vraiment nécessaire ne sert souvent bien ni la personne, ni l'équipe, ni l'organisation.
3. Une décision de cessation d'emploi devrait généralement suivre un processus structuré et documenté, et non être prise immédiatement sans processus, quand celui-ci s'applique.
4. Le vrai souci et le respect dont la leader a fait preuve pendant la conversation reflétaient, avec raison, le thème de l'intendance de ce niveau.

**7. Points clés à retenir**
- Les décisions de cessation d'emploi devraient généralement suivre le processus structuré et documenté de la leçon 26, quand il s'applique.
- Cette décision devrait être prise avec un vrai souci d'intendance, en reconnaissant l'effet important sur le gagne-pain de la personne.
- Un report indéfini par malaise ne sert souvent ni la personne, ni l'équipe, ni l'organisation.
- Ça exige à la fois un vrai souci de la personne et un moment approprié, en écho aux thèmes constants des leçons 8 et 14.
