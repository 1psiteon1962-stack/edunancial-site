---
id: BLACK-L2-028
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 28
title: "La culture organisationnelle : ce qu'elle est et qui la bâtit vraiment"
summary: "Comprends que la culture d'une organisation se bâtit par les comportements réels, surtout ceux des leaders, et non par les valeurs affichées."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-028
### La culture organisationnelle : ce qu'elle est et qui la bâtit vraiment

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle la culture organisationnelle.
- Expliquer pourquoi la culture se bâtit par des comportements constants, et non par des valeurs affichées seulement.
- Appliquer cette notion à une situation hypothétique où il faut bâtir une culture.

**2. Contenu principal**
La culture organisationnelle désigne généralement les valeurs, les normes et les comportements communs qui caractérisent vraiment la façon dont les gens d'une organisation agissent et interagissent — ce qui est distinct des valeurs affichées ou souhaitées d'une entreprise, qui reflètent ou non la culture réelle et vécue. La culture se bâtit surtout par des comportements constants et observés au fil du temps, en particulier ceux des leaders (en écho à la discussion sur la confiance de la leçon 9) : ce que les leaders font réellement, récompensent et tolèrent façonne la culture beaucoup plus fortement que ce qu'annonce l'énoncé de mission ou l'affiche des valeurs d'une organisation.

Ça veut dire qu'un leader qui affirme valoriser la collaboration tout en récompensant constamment la compétition individuelle, ou qui affirme valoriser l'honnêteté tout en punissant ceux qui donnent une rétroaction juste mais mal accueillie (en écho à la discussion sur la réception de la rétroaction de la leçon 13), bâtit en réalité une culture incohérente avec ses valeurs affichées, peu importe l'intention annoncée — la culture reflète ce qui est réellement montré en exemple et renforcé de façon constante, et non ce qui est simplement écrit ou annoncé.

**3. Exemple pratique**
Même si les valeurs affichées de son organisation mettent la collaboration bien en évidence, une leader constate que ses pratiques réelles de promotion et de reconnaissance ont constamment récompensé les réalisations individuelles plutôt que les comportements de collaboration, ce qui a, dans les faits, bâti une culture de compétition interne incohérente avec les valeurs de collaboration affichées. Reconnaissant que la culture reflète ce qui est réellement montré en exemple et récompensé, et non ce qui est simplement affiché, elle commence à ajuster volontairement son propre comportement et ses pratiques de reconnaissance pour vraiment renforcer la culture de collaboration qu'elle veut bâtir, au lieu de supposer que les valeurs affichées suffiraient à produire cette culture.

**4. Quiz de pratique**
1. Selon cette leçon, à quoi la culture organisationnelle fait-elle généralement référence?
   a) Aux seules valeurs affichées ou souhaitées d'une entreprise, peu importe les comportements réels
   b) Aux valeurs, aux normes et aux comportements communs qui caractérisent vraiment la façon dont les gens agissent et interagissent
   c) À un type de crédit d'impôt
   d) À une notion sans lien avec le comportement des leaders
2. Selon cette leçon, qu'est-ce qui bâtit surtout la culture?
   a) Un énoncé de mission écrit ou une affiche des valeurs, à eux seuls
   b) Des comportements constants et observés au fil du temps, en particulier ceux des leaders
   c) La culture n'a aucun lien avec les comportements réels
   d) Les valeurs affichées produisent toujours automatiquement une culture réelle qui y correspond
3. Vrai ou faux : Les valeurs affichées d'une organisation reflètent automatiquement et fidèlement sa culture réelle et vécue, peu importe le comportement des leaders.
4. Pourquoi la leader a-t-elle reconnu un écart entre les valeurs affichées de son organisation et sa culture réelle?
   a) Ses pratiques réelles de promotion et de reconnaissance correspondaient parfaitement aux valeurs de collaboration affichées
   b) Ses pratiques avaient constamment récompensé les réalisations individuelles, ce qui était incohérent avec les valeurs de collaboration affichées
   c) Les valeurs affichées et les pratiques réelles n'ont aucun lien entre elles
   d) Elle n'avait aucune pratique de promotion ou de reconnaissance à examiner

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La culture organisationnelle désigne les valeurs, les normes et les comportements communs qui caractérisent vraiment la façon dont les gens agissent et interagissent.
2. La culture se bâtit surtout par des comportements constants et observés au fil du temps, en particulier ceux des leaders.
3. Les valeurs affichées ne reflètent pas automatiquement la culture réelle, qui dépend de ce qui est montré en exemple et renforcé de façon constante.
4. En reconnaissant l'incohérence de ses pratiques de reconnaissance, la leader a mis au jour un vrai écart entre les valeurs affichées et la culture réelle et vécue.

**7. Points clés à retenir**
- La culture organisationnelle est l'ensemble des valeurs, des normes et des comportements communs qui caractérisent vraiment une organisation, distinct de ses intentions affichées.
- La culture se bâtit surtout par des comportements constants au fil du temps, en particulier par l'exemple que donnent les leaders.
- Ce que les leaders récompensent et tolèrent réellement façonne la culture bien plus qu'un énoncé de mission ou une affiche des valeurs.
- Ça prépare la distinction entre culture et avantages de la leçon 29 et la discussion sur la sécurité psychologique de la leçon 30.
