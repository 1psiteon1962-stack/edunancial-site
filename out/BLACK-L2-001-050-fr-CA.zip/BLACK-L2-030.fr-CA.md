---
id: BLACK-L2-030
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 30
title: "La sécurité psychologique : pourquoi les équipes doivent se sentir libres de parler"
summary: "Comprends ce qu'est la sécurité psychologique, pourquoi elle influence directement le rendement d'une équipe et comment un leader la bâtit par son ouverture."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-030
### La sécurité psychologique : pourquoi les équipes doivent se sentir libres de parler

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle la sécurité psychologique.
- Expliquer pourquoi la sécurité psychologique influence directement le rendement et l'innovation d'une équipe.
- Appliquer cette notion à une situation d'équipe hypothétique.

**2. Contenu principal**
En s'appuyant directement sur les leçons 13, 28 et 29, la sécurité psychologique désigne un climat d'équipe où les membres se sentent vraiment libres de prendre la parole — soulever des préoccupations, admettre des erreurs, exprimer une opinion divergente ou poser des questions — sans craindre d'être punis, ridiculisés ou de voir leur position ébranlée. Ça se relie directement à la discussion sur la réception de la rétroaction de la leçon 13 : un leader qui montre une vraie ouverture à la rétroaction, y compris à la critique, bâtit directement la sécurité psychologique que décrit cette leçon.

La recherche et l'expérience courante des organisations suggèrent que la sécurité psychologique influence directement le rendement d'une équipe : dans les équipes qui en manquent, les problèmes restent souvent non signalés jusqu'à ce qu'ils s'aggravent nettement, les idées novatrices ne sont pas partagées par peur de la critique, et le vrai engagement souffre parce que les membres de l'équipe gardent pour eux leur point de vue authentique. La sécurité psychologique n'est donc pas seulement une qualité agréable du milieu de travail, mais un vrai facteur de rendement et de gestion des risques que le cadre de leadership de ce niveau devrait cultiver activement.

**3. Exemple pratique**
Remarquant que son équipe soulève rarement des préoccupations ou admet rarement ses erreurs d'elle-même, une leader reconnaît un manque probable de sécurité psychologique, en écho à la discussion sur la réception de la rétroaction de la leçon 13. Elle travaille volontairement à montrer une vraie ouverture — en accueillant visiblement, sans réaction punitive, l'aveu d'un membre de l'équipe au sujet d'une erreur repérée tôt, et en sollicitant activement des opinions divergentes pendant les discussions d'équipe au lieu d'accueillir seulement l'accord. Avec le temps, elle remarque que son équipe commence à faire ressortir d'elle-même ses préoccupations et ses idées plus tôt qu'avant, ce qui illustre l'avantage direct de la sécurité psychologique sur le rendement.

**4. Quiz de pratique**
1. Selon cette leçon, qu'est-ce que la sécurité psychologique?
   a) Un climat d'équipe où les membres se sentent vraiment libres de prendre la parole sans craindre d'être punis ou ridiculisés
   b) Une notion qui exige que les membres de l'équipe soient toujours d'accord et évitent de soulever des préoccupations
   c) Un type de crédit d'impôt
   d) Une notion sans lien avec le rendement de l'équipe
2. Selon cette leçon, comment la sécurité psychologique influence-t-elle directement le rendement d'une équipe?
   a) Elle n'a aucun lien avec le rendement de l'équipe
   b) Dans les équipes qui en manquent, les problèmes restent souvent non signalés, les idées novatrices ne sont pas partagées et le vrai engagement souffre
   c) La sécurité psychologique réduit toujours le rendement de l'équipe
   d) Seules les équipes sans sécurité psychologique ont un bon rendement
3. Vrai ou faux : La sécurité psychologique est seulement une qualité agréable du milieu de travail, sans vrai lien avec le rendement ou la gestion des risques.
4. Pourquoi l'équipe de la leader a-t-elle commencé à faire ressortir ses préoccupations et ses idées plus tôt qu'avant?
   a) Elle a puni un membre de l'équipe qui avait admis une erreur
   b) En montrant une vraie ouverture et en sollicitant activement les opinions divergentes, elle a bâti la sécurité psychologique que décrit cette leçon
   c) La sécurité psychologique n'a aucun lien avec le fait de soulever des préoccupations de façon proactive
   d) Elle a découragé toute opinion divergente pendant les discussions d'équipe

**5. Corrigé**
1. a  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La sécurité psychologique est un climat d'équipe où les membres se sentent vraiment libres de prendre la parole sans craindre d'être punis ou ridiculisés.
2. Dans les équipes sans sécurité psychologique, les problèmes restent souvent non signalés, les idées ne sont pas partagées et le vrai engagement souffre.
3. La sécurité psychologique est un vrai facteur de rendement et de gestion des risques, et pas seulement une qualité agréable du milieu de travail.
4. L'ouverture sincère dont la leader a fait preuve a bâti, avec raison, la sécurité psychologique qui a mené à des préoccupations soulevées plus tôt et de façon plus proactive.

**7. Points clés à retenir**
- La sécurité psychologique est un climat d'équipe où les membres se sentent vraiment libres de prendre la parole sans craindre d'être punis ou ridiculisés.
- Ça se relie directement à la discussion sur la réception de la rétroaction de la leçon 13, puisque montrer de l'ouverture bâtit cette sécurité.
- Les équipes sans sécurité psychologique voient souvent des problèmes non signalés, des idées non partagées et un engagement réduit.
- La sécurité psychologique est un vrai facteur de rendement et de gestion des risques, et pas seulement une qualité agréable du milieu de travail.
