---
id: BLACK-L2-031
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 31
title: "La diversité et l'inclusion : une responsabilité de leadership"
summary: "Distingue la diversité, soit la présence de parcours variés, de l'inclusion, soit le fait que ces points de vue soient vraiment entendus, et vois pourquoi l'inclusion relève du leader."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-031
### La diversité et l'inclusion : une responsabilité de leadership

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer les arguments généraux, d'affaires et éthiques, en faveur de la diversité et de l'inclusion.
- Distinguer de façon conceptuelle la diversité de l'inclusion.
- Appliquer cette notion à une situation de leadership hypothétique.

**2. Contenu principal**
La diversité désigne généralement la présence de parcours, de points de vue et d'expériences variés dans une équipe ou une organisation; l'inclusion désigne généralement le fait que les personnes qui ont ces parcours variés se sentent vraiment accueillies, valorisées et capables de participer et de contribuer pleinement — en écho à la discussion sur la sécurité psychologique de la leçon 30, puisqu'une vraie inclusion exige le genre de sécurité qui permet aux points de vue variés d'être réellement exprimés et entendus, et non simplement présents mais silencieux.

La diversité sans vraie inclusion ne produit souvent pas ses avantages possibles : une équipe aux parcours variés, mais où certains points de vue sont constamment écartés ou mal accueillis, ne profite pas vraiment de cette diversité, puisque les perspectives distinctes qu'elle pourrait offrir ne sont pas réellement exprimées ni prises en compte. C'est pourquoi l'inclusion, et pas seulement la présence de la diversité, est la responsabilité de leadership sur laquelle insiste cette leçon : créer activement les conditions pour que des points de vue variés soient vraiment recherchés, entendus et valorisés, et non simplement tolérés pour des raisons de représentation.

**3. Exemple pratique**
Après avoir bâti une équipe aux parcours et aux points de vue vraiment variés, une leader constate que la diversité seule n'a pas automatiquement produit les avantages qu'elle espérait, puisque les points de vue de certains membres de l'équipe semblent constamment sous-représentés dans les discussions et les décisions réelles. Reconnaissant la distinction que décrit cette leçon, elle travaille précisément sur l'inclusion — en sollicitant activement l'avis des membres plus discrets, en s'assurant que les points de vue variés sont vraiment pris en compte dans les décisions et en corrigeant toute tendance où certaines voix sont constamment écartées —, en reconnaissant que c'est une vraie inclusion, et non la simple présence de la diversité, qui permet réellement aux points de vue variés d'apporter de la valeur.

**4. Quiz de pratique**
1. À quoi la diversité fait-elle généralement référence, par rapport à l'inclusion dans cette leçon?
   a) Au fait que les personnes aux parcours variés se sentent vraiment accueillies et capables de participer
   b) À la présence de parcours, de points de vue et d'expériences variés dans une équipe ou une organisation
   c) À un type de crédit d'impôt
   d) À une notion identique à l'inclusion, sans distinction
2. Pourquoi la diversité sans vraie inclusion peut-elle ne pas produire ses avantages possibles?
   a) La diversité produit toujours automatiquement tous ses avantages, peu importe l'inclusion
   b) Une équipe aux parcours variés, mais où certains points de vue sont écartés, ne profite pas vraiment de cette diversité
   c) L'inclusion n'a aucun lien avec le fait que des points de vue variés soient réellement exprimés
   d) La diversité et l'inclusion sont identiques et n'exigent pas d'attention distincte
3. Vrai ou faux : Bâtir une équipe aux parcours variés garantit automatiquement que ces points de vue variés sont vraiment entendus et valorisés dans les décisions.
4. Pourquoi la leader s'est-elle concentrée sur l'inclusion après avoir bâti une équipe diversifiée?
   a) La diversité seule avait déjà produit tous les avantages souhaités
   b) Elle a reconnu que certains points de vue restaient sous-représentés dans les discussions réelles, ce qui exigeait un effort volontaire d'inclusion
   c) L'inclusion n'a aucun lien avec la valeur qu'apportent des points de vue variés
   d) Elle ne tenait pas à s'occuper des points de vue sous-représentés

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La diversité désigne la présence de parcours, de points de vue et d'expériences variés dans une équipe ou une organisation.
2. Une équipe aux parcours variés, mais où certains points de vue sont écartés, ne profite pas vraiment du potentiel de cette diversité.
3. Bâtir une équipe diversifiée ne garantit pas automatiquement l'inclusion; une vraie inclusion exige un effort de leadership volontaire.
4. En se concentrant sur l'inclusion, la leader a réglé, avec raison, la sous-représentation de certains points de vue que la diversité seule n'avait pas réglée.

**7. Points clés à retenir**
- La diversité est la présence de parcours et de points de vue variés; l'inclusion est le fait que ces points de vue soient vraiment accueillis et entendus.
- La diversité sans vraie inclusion ne produit souvent pas ses avantages possibles, puisque certains points de vue peuvent rester inexprimés.
- Ça se relie directement à la discussion sur la sécurité psychologique de la leçon 30, puisqu'une vraie inclusion exige cette sécurité de fond.
- C'est l'inclusion, et non la simple présence de la diversité, qui constitue la responsabilité de leadership continue sur laquelle insiste cette leçon.
