---
id: BLACK-L2-032
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 32
title: "Bâtir et diriger une équipe : de personnes individuelles à une unité"
summary: "Distingue un groupe de personnes qui travaillent côte à côte d'une vraie équipe, et vois ce qu'un leader doit faire pour créer une unité soudée."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-032
### Bâtir et diriger une équipe : de personnes individuelles à une unité

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer la distinction générale entre un groupe de personnes et une vraie équipe.
- Nommer les facteurs qui aident à transformer des personnes en une unité soudée.
- Appliquer cette notion à une situation hypothétique de consolidation d'équipe.

**2. Contenu principal**
Un groupe de personnes qui travaillent les unes près des autres n'est pas automatiquement une vraie équipe; une équipe exige généralement une raison d'être commune (annoncée ici pour la discussion sur la vision de la leçon 37), une collaboration interdépendante (des membres qui comptent vraiment les uns sur les autres et se coordonnent, au lieu de simplement travailler chacun de leur côté en parallèle), ainsi que la confiance (leçon 9) et la sécurité psychologique (leçon 30) sur lesquelles ce niveau insiste, ce qui permet une vraie collaboration plutôt qu'une simple coexistence d'efforts individuels.

Transformer des personnes en une vraie équipe exige généralement un effort de leadership volontaire : énoncer clairement la raison d'être commune et la façon dont les contributions individuelles s'y rattachent, créer des occasions structurées de vraie collaboration plutôt que de supposer qu'elle apparaîtra d'elle-même, et montrer et renforcer constamment la confiance et la sécurité qui permettent aux membres de l'équipe de vraiment compter les uns sur les autres et de se soutenir, au lieu de traiter la consolidation d'équipe comme un événement ponctuel (une retraite ou une activité occasionnelle) déconnecté de la pratique quotidienne du leadership.

**3. Exemple pratique**
Constatant que les membres de son équipe travaillent surtout chacun de leur côté, en parallèle, avec peu de vraie collaboration ou de sentiment de raison d'être commune, une leader travaille volontairement à transformer ce groupe en une vraie équipe : elle énonce clairement comment le travail de chaque personne se rattache à une raison d'être commune, crée des occasions de collaboration structurées où les membres doivent vraiment se coordonner plutôt que travailler isolément, et montre constamment l'exemple de la confiance et de la sécurité psychologique qui permettent de vraiment compter les uns sur les autres. Elle reconnaît que cette transformation exige un effort soutenu et continu, et non un seul événement de consolidation d'équipe déconnecté de sa pratique quotidienne du leadership.

**4. Quiz de pratique**
1. Selon cette leçon, qu'est-ce qui distingue généralement une vraie équipe d'un groupe de personnes qui travaillent les unes près des autres?
   a) Rien ne les distingue; ce sont des notions identiques
   b) Une raison d'être commune, une collaboration interdépendante, ainsi que la confiance et la sécurité psychologique qui permettent une vraie collaboration
   c) Un type de crédit d'impôt
   d) La seule proximité physique, sans autre exigence
2. Selon cette leçon, qu'exige généralement la transformation de personnes en une vraie équipe?
   a) Un seul événement de consolidation d'équipe déconnecté de la pratique quotidienne
   b) Un effort de leadership volontaire, y compris une raison d'être commune claire, des occasions de collaboration structurées et un travail de confiance constant
   c) Supposer qu'une vraie collaboration apparaîtra d'elle-même, sans effort de leadership
   d) Une notion sans lien avec la pratique du leadership
3. Vrai ou faux : Un groupe de personnes qui travaillent les unes près des autres forme automatiquement une vraie équipe soudée, sans autre effort de leadership.
4. Pourquoi la leader a-t-elle reconnu que son groupe devait être volontairement transformé en une vraie équipe?
   a) Les membres de son équipe montraient déjà une forte collaboration interdépendante et une raison d'être commune
   b) Les membres de son équipe travaillaient surtout chacun de leur côté, en parallèle, sans vraie collaboration ni raison d'être commune
   c) La transformation d'une équipe n'a aucun lien avec l'effort de leadership
   d) Elle ne s'intéressait pas à la dynamique de collaboration de son équipe

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une vraie équipe exige une raison d'être commune, une collaboration interdépendante, ainsi que la confiance et la sécurité psychologique qui permettent une vraie collaboration.
2. Transformer des personnes en une vraie équipe exige un effort de leadership volontaire, et non un événement ponctuel ou une apparition spontanée.
3. La seule proximité physique ne forme pas automatiquement une vraie équipe soudée sans effort de leadership volontaire.
4. En reconnaissant que son groupe travaillait en parallèle sans coordination, la leader a, avec raison, entrepris un effort volontaire de transformation de l'équipe.

**7. Points clés à retenir**
- Une vraie équipe exige une raison d'être commune, une collaboration interdépendante, de la confiance et de la sécurité psychologique, au-delà de la simple proximité.
- Transformer des personnes en équipe exige un effort de leadership volontaire et continu, et non un seul événement.
- Ça annonce la discussion sur la vision de la leçon 37 et s'appuie sur les discussions sur la confiance et la sécurité des leçons 9 et 30.
- Une vraie cohésion d'équipe exige une pratique quotidienne et soutenue du leadership, et non une activité occasionnelle déconnectée.
