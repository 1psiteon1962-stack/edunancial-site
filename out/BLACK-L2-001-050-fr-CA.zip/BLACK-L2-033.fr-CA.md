---
id: BLACK-L2-033
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 33
title: "La dynamique d'équipe : les étapes du développement d'une équipe"
summary: "Découvre les étapes de formation, de turbulence, de normalisation et de performance, et comprends pourquoi les frictions font souvent partie normale du développement d'une équipe."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-033
### La dynamique d'équipe : les étapes du développement d'une équipe

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Nommer les étapes du développement d'une équipe souvent citées.
- Expliquer pourquoi les équipes vivent souvent des frictions avant d'atteindre une pleine cohésion.
- Appliquer ce cadre à une situation hypothétique de nouvelle équipe.

**2. Contenu principal**
Un modèle de développement d'équipe souvent cité décrit des étapes générales : la formation (les membres de l'équipe font d'abord connaissance, souvent avec des échanges polis et prudents), la turbulence (de vraies différences de style, d'opinion ou d'approche apparaissent, ce qui crée parfois des frictions, en écho à la discussion sur les conflits de la leçon 15), la normalisation (l'équipe établit des normes communes et des façons de travailler efficacement ensemble) et la performance (l'équipe fonctionne avec une vraie cohésion et une vraie efficacité, après avoir surmonté les frictions du début).

Reconnaître cette progression générale aide un leader à réagir de façon appropriée à chaque étape, plutôt que de s'alarmer outre mesure des frictions de l'étape de turbulence, qui font souvent partie normale du développement d'une équipe et ne sont pas forcément un signe d'échec. La compétence de leadership consiste à aider l'équipe à traverser l'étape de turbulence de façon constructive (en utilisant les principes de résolution de conflits des leçons 15 et 16) vers la normalisation et la performance, plutôt que d'éviter complètement les frictions nécessaires ou de les laisser faire dérailler le développement de l'équipe.

**3. Exemple pratique**
Observant que son équipe nouvellement formée commence à vivre des frictions et des désaccords après une première période polie et prudente, une leader reconnaît qu'il s'agit de l'étape de turbulence, une partie souvent normale du développement d'une équipe, et non d'un signe que ses efforts de consolidation ont échoué. En appliquant les principes de résolution de conflits des leçons 15 et 16, elle aide son équipe à traverser ces frictions de façon constructive. Elle observe peu à peu l'équipe établir des normes de travail communes (normalisation), puis fonctionner avec une vraie cohésion et une vraie efficacité (performance), au lieu de s'alarmer des frictions de l'étape de turbulence ou d'essayer de les étouffer complètement.

**4. Quiz de pratique**
1. Dans ce modèle de développement d'équipe souvent cité, qu'est-ce que l'étape de « turbulence »?
   a) L'étape où l'équipe fonctionne avec une pleine cohésion et une vraie efficacité
   b) L'étape où de vraies différences de style, d'opinion ou d'approche apparaissent, ce qui crée parfois des frictions
   c) Un type de crédit d'impôt
   d) La toute première étape, avant même que les membres de l'équipe se soient rencontrés
2. Pourquoi reconnaître cette progression générale aide-t-il un leader à réagir de façon appropriée?
   a) Elle laisse entendre que la turbulence indique toujours un échec d'équipe qui exige une intervention immédiate
   b) Elle aide le leader à voir la turbulence comme une étape de développement souvent normale, et pas forcément comme un signe d'échec
   c) Ce modèle n'a aucune application pratique dans le leadership d'équipe réel
   d) La turbulence devrait toujours être complètement évitée ou étouffée
3. Vrai ou faux : L'étape de turbulence indique toujours un échec de la consolidation d'équipe qui oblige le leader à abandonner la structure actuelle de l'équipe.
4. Selon le cadre de cette leçon, comment la leader a-t-elle réagi aux frictions de l'étape de turbulence de son équipe?
   a) Elle s'est alarmée et a conclu que ses efforts de consolidation d'équipe avaient échoué
   b) Elle a appliqué les principes de résolution de conflits pour aider l'équipe à traverser les frictions de façon constructive vers la normalisation et la performance
   c) Elle a complètement étouffé les frictions, ce qui a empêché tout vrai règlement
   d) Elle n'avait aucun cadre pour comprendre le développement de son équipe

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'étape de turbulence est celle où de vraies différences de style, d'opinion ou d'approche apparaissent, ce qui crée parfois des frictions.
2. Reconnaître cette progression aide le leader à voir la turbulence comme une étape de développement souvent normale, et pas forcément comme un échec de l'équipe.
3. La turbulence fait souvent partie normale du développement d'une équipe, et n'indique pas forcément un échec qui oblige à abandonner la structure.
4. En appliquant les principes de résolution de conflits, la leader a aidé, avec raison, son équipe à traverser la turbulence vers la normalisation et la performance.

**7. Points clés à retenir**
- Les étapes du développement d'une équipe souvent citées sont la formation, la turbulence, la normalisation et la performance.
- Les frictions de l'étape de turbulence font souvent partie normale du développement d'une équipe, et ne sont pas forcément un signe d'échec.
- La compétence de leadership consiste à aider l'équipe à traverser la turbulence de façon constructive, à l'aide des principes de résolution de conflits des leçons 15 et 16.
- Reconnaître cette progression aide le leader à réagir de façon appropriée plutôt que de s'alarmer outre mesure de frictions normales.
