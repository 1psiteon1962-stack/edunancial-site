---
id: BLACK-L2-035
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 35
title: "La gestion du changement : diriger pendant un changement organisationnel"
summary: "Apprends les principes pour mener une équipe à travers un changement, et comprends pourquoi la confiance bâtie au préalable influence la façon dont l'équipe réagit."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-035
### La gestion du changement : diriger pendant un changement organisationnel

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer les principes généraux pour mener une équipe à travers un changement organisationnel.
- Relier directement cette notion à la discussion sur la confiance de la leçon 9.
- Appliquer cette notion à une situation de changement hypothétique.

**2. Contenu principal**
Diriger pendant un changement organisationnel — une réorganisation, la mise en place d'un nouveau système, un virage stratégique — exige une attention de leadership précise, au-delà du leadership opérationnel courant. Les principes généraux comprennent une communication claire et honnête sur la raison d'être du changement et sur ses effets prévus (en écho à la discussion sur la clarté de la leçon 10, particulièrement importante vu l'incertitude qu'entraîne naturellement le changement), une vraie reconnaissance des préoccupations légitimes plutôt que leur rejet (en écho à la discussion sur l'écoute active de la leçon 11), et un suivi constant qui démontre que le changement est mis en œuvre de façon réfléchie, et non chaotique.

Ça se relie directement à la discussion sur la confiance de la leçon 9 : un leader qui a bâti une vraie confiance au fil du temps constate généralement que son équipe est plus disposée à lui accorder le bénéfice du doute pendant l'incertitude et l'inconfort propres au changement organisationnel, alors qu'un leader qui n'a pas cette base de confiance peut voir ses efforts de changement rencontrer beaucoup plus de résistance et de scepticisme, en écho à la discussion sur la résistance de la leçon 36, peu importe les mérites réels du changement.

**3. Exemple pratique**
En menant son équipe à travers une réorganisation importante, une leader communique de façon honnête et claire la raison d'être et les effets prévus du changement, reconnaît sincèrement les préoccupations légitimes de son équipe au lieu de les rejeter, et respecte constamment ses engagements tout au long de la mise en œuvre. Elle reconnaît que la réaction plutôt constructive de son équipe face à ce changement important reflète, en partie, la vraie confiance qu'elle a bâtie au fil du temps (en écho à la leçon 9), ce qui a permis à son équipe de lui accorder le bénéfice du doute pendant cette période naturellement incertaine.

**4. Quiz de pratique**
1. Selon cette leçon, quel est un principe général pour diriger pendant un changement organisationnel?
   a) Éviter toute communication sur la raison d'être du changement
   b) Une communication claire et honnête sur la raison d'être et les effets, et une vraie reconnaissance des préoccupations légitimes
   c) Un type de crédit d'impôt
   d) Rejeter complètement les préoccupations de l'équipe, peu importe leur légitimité
2. Comment cette leçon se relie-t-elle directement à la discussion sur la confiance de la leçon 9?
   a) Elle n'a aucun lien avec la confiance
   b) Un leader qui a bâti une vraie confiance au fil du temps constate généralement que son équipe est plus disposée à lui accorder le bénéfice du doute pendant le changement
   c) La confiance n'a aucun lien avec la façon dont une équipe réagit au changement organisationnel
   d) La gestion du changement n'exige aucune base de confiance
3. Vrai ou faux : La base de confiance d'un leader, bâtie par un comportement constant au préalable, n'a aucune influence sur la façon dont son équipe réagit au changement organisationnel.
4. Pourquoi l'équipe de la leader a-t-elle réagi de façon plutôt constructive à la réorganisation importante?
   a) Elle n'avait aucune base de confiance avec son équipe
   b) La vraie confiance qu'elle avait bâtie au fil du temps a permis à son équipe de lui accorder le bénéfice du doute pendant cette période naturellement incertaine
   c) La confiance n'a aucun lien avec les résultats de la gestion du changement
   d) Elle a complètement rejeté les préoccupations de son équipe pendant le processus

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une communication claire et honnête sur la raison d'être et les effets, et une vraie reconnaissance des préoccupations légitimes, sont des principes généraux pour diriger pendant un changement.
2. Un leader qui a bâti une vraie confiance au fil du temps constate généralement que son équipe est plus disposée à lui accorder le bénéfice du doute pendant le changement.
3. La base de confiance d'un leader influence fortement la façon dont son équipe réagit au changement organisationnel, que ce soit de façon constructive ou avec résistance.
4. La vraie confiance que la leader avait bâtie au préalable a soutenu, avec raison, la réaction plutôt constructive de son équipe face au changement important.

**7. Points clés à retenir**
- Diriger pendant un changement organisationnel exige une communication claire, une vraie reconnaissance des préoccupations et un suivi constant.
- Ça se relie directement à la discussion sur la confiance de la leçon 9, puisque la confiance bâtie au préalable influence la disposition de l'équipe à accorder le bénéfice du doute pendant le changement.
- Les efforts de changement menés sans base de confiance peuvent rencontrer beaucoup plus de résistance, un sujet annoncé pour la leçon 36.
- Ces principes appliquent les thèmes constants de ce niveau au contexte précis et à enjeux élevés du changement organisationnel.
