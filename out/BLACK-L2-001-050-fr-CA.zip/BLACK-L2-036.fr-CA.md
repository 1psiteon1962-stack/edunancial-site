---
id: BLACK-L2-036
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 36
title: "La résistance au changement : pourquoi elle survient et comment y répondre"
summary: "Nomme les sources courantes de résistance au changement et apprends à la traiter comme une information potentiellement utile plutôt que comme de l'entêtement."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-036
### La résistance au changement : pourquoi elle survient et comment y répondre

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Nommer les sources courantes de résistance au changement organisationnel.
- Expliquer pourquoi la résistance reflète souvent des préoccupations légitimes, et pas simplement de l'entêtement.
- Appliquer cette notion à une situation hypothétique de résistance au changement.

**2. Contenu principal**
En s'appuyant directement sur la leçon 35, cette leçon aborde précisément la résistance au changement : ses sources courantes comprennent une vraie incertitude sur la façon dont le changement touchera personnellement chaque personne (sécurité d'emploi, clarté du rôle ou pertinence de ses compétences), le sentiment de ne pas avoir eu d'occasion de donner son avis ou de s'exprimer sur la décision (en écho à la discussion sur l'inclusion de la leçon 31) et, dans certains cas, des préoccupations légitimes et bien fondées sur les mérites réels du changement, qui méritent d'être vraiment examinées plutôt que rejetées.

Une réponse efficace du leader face à la résistance consiste généralement à la traiter comme une information potentiellement légitime qui vaut la peine d'être comprise, en écho à la reformulation des objections de ORANGE-L2-027 et à la discussion sur l'écoute active de la leçon 11, plutôt que de classer immédiatement toute résistance comme de l'entêtement ou une opposition au changement pour le principe. Certaines résistances reflètent de vraies préoccupations valables qui, une fois prises en compte, peuvent même améliorer l'initiative de changement elle-même, alors que d'autres peuvent refléter une incertitude ou une crainte qu'une communication sincère et honnête (leçon 35) peut aider à apaiser.

**3. Exemple pratique**
Devant une résistance importante à un changement proposé, une leader résiste à la tentation de classer immédiatement cette résistance comme de l'entêtement et pratique plutôt l'écoute active (leçon 11) pour en comprendre les vraies sources. Elle découvre qu'une partie de la résistance reflète une vraie incertitude sur la sécurité des rôles, qu'une communication honnête peut apaiser, alors que d'autres commentaires révèlent une préoccupation légitime et valable sur la façon de mettre en œuvre le changement. Une fois intégrée, cette préoccupation améliore même l'initiative elle-même — ce qui montre pourquoi traiter la résistance comme une information potentiellement légitime, au lieu de la rejeter, a donné un meilleur résultat global.

**4. Quiz de pratique**
1. Selon cette leçon, quelle est une source courante de résistance au changement organisationnel?
   a) Un enthousiasme complet et universel, sans aucune vraie préoccupation
   b) Une vraie incertitude sur les effets personnels, le sentiment de ne pas avoir eu son mot à dire ou des préoccupations légitimes sur les mérites du changement
   c) Un type de crédit d'impôt
   d) Une source sans aucun lien avec une considération légitime
2. Selon cette leçon, pourquoi la résistance devrait-elle être traitée comme une information potentiellement légitime?
   a) Toute résistance reflète toujours un simple entêtement, sans fondement légitime
   b) Certaines résistances reflètent de vraies préoccupations valables qui, une fois prises en compte, peuvent même améliorer l'initiative de changement
   c) La résistance n'a aucun lien avec de vraies préoccupations ou de l'incertitude
   d) Rejeter toute résistance donne toujours le meilleur résultat
3. Vrai ou faux : Toute résistance au changement organisationnel devrait être immédiatement classée comme un simple entêtement et rejetée sans autre examen.
4. Qu'est-ce que l'écoute active de la leader a révélé sur la résistance de son équipe au changement proposé?
   a) Toute la résistance reflétait un pur entêtement, sans fondement légitime
   b) Une partie de la résistance reflétait une incertitude qu'on pouvait apaiser, alors que d'autres commentaires révélaient une préoccupation légitime qui a amélioré l'initiative
   c) Aucune vraie préoccupation n'existait dans son équipe
   d) Elle ne tenait pas à comprendre les sources de la résistance

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une vraie incertitude sur les effets personnels, le sentiment de ne pas avoir eu son mot à dire et des préoccupations légitimes sur les mérites du changement sont des sources courantes de résistance.
2. Certaines résistances reflètent de vraies préoccupations valables qui, une fois prises en compte, peuvent même améliorer l'initiative de changement elle-même.
3. La résistance devrait être comprise avant d'être rejetée, puisque certaines résistances reflètent des préoccupations légitimes qu'on peut régler.
4. L'écoute active de la leader a révélé, avec raison, à la fois une incertitude qu'on pouvait apaiser et une préoccupation légitime qui a amélioré son initiative.

**7. Points clés à retenir**
- Les sources courantes de résistance comprennent l'incertitude sur les effets personnels, le sentiment de ne pas avoir eu son mot à dire et des préoccupations légitimes sur le changement lui-même.
- La résistance devrait être traitée comme une information potentiellement légitime, en écho à la reformulation des objections de ORANGE-L2-027.
- Certaines résistances reflètent de vraies préoccupations valables qui peuvent même améliorer une initiative de changement une fois prises en compte.
- Ça s'appuie directement sur la discussion sur la gestion du changement de la leçon 35 et sur celle sur l'écoute active de la leçon 11.
