---
id: BLACK-L2-037
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 37
title: "La vision et la mission : donner à une équipe quelque chose autour de quoi s'aligner"
summary: "Distingue la mission, soit la raison d'être, de la vision, soit l'avenir souhaité, et vois comment elles donnent du sens au travail quotidien de l'équipe."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-037
### La vision et la mission : donner à une équipe quelque chose autour de quoi s'aligner

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Distinguer de façon conceptuelle la vision de la mission.
- Expliquer pourquoi une vision et une mission claires soutiennent l'alignement et la motivation de l'équipe.
- Appliquer cette notion à une situation d'équipe hypothétique.

**2. Contenu principal**
Une mission décrit généralement la raison d'être fondamentale d'une organisation ou d'une équipe — pourquoi elle existe et ce qu'elle fait essentiellement. Une vision décrit généralement un avenir souhaité — ce vers quoi l'organisation ou l'équipe travaille à plus long terme. Ensemble, elles fournissent la raison d'être commune que la leçon 32 a nommée comme essentielle pour transformer des personnes en une vraie équipe, en donnant aux membres de l'équipe quelque chose de plus grand que leurs tâches quotidiennes individuelles autour de quoi s'aligner et en quoi trouver du sens.

Une vision et une mission claires soutiennent la motivation et l'alignement, en particulier pendant les périodes difficiles (en écho à la discussion sur la gestion du changement de la leçon 35) ou quand les tâches individuelles semblent déconnectées d'un sens plus large — un membre de l'équipe qui comprend comment son travail quotidien précis se rattache à une raison d'être plus large et significative montre généralement plus d'engagement et de résilience qu'une personne qui voit son travail comme une simple série de tâches individuelles déconnectées, sans contexte ni sens plus large.

**3. Exemple pratique**
Constatant que les membres de son équipe ont parfois du mal à voir comment leurs tâches quotidiennes individuelles se rattachent à quelque chose de plus grand, une leader travaille à énoncer clairement et constamment la mission de l'équipe (sa raison d'être fondamentale) et sa vision (l'orientation future souhaitée), en reliant explicitement les contributions individuelles à ce contexte plus large dans ses communications régulières. Elle observe que des membres de l'équipe qui décrivaient auparavant leur travail comme routinier et déconnecté commencent à exprimer plus d'engagement et un plus grand sentiment de sens une fois ce lien plus large rendu clair et constamment renforcé.

**4. Quiz de pratique**
1. Que décrit généralement une mission?
   a) Un avenir souhaité vers lequel l'organisation travaille
   b) La raison d'être fondamentale d'une organisation ou d'une équipe — pourquoi elle existe et ce qu'elle fait essentiellement
   c) Un type de crédit d'impôt
   d) Une notion identique à la vision, sans distinction
2. Que décrit généralement une vision, par rapport à une mission?
   a) La raison d'être fondamentale et actuelle de l'organisation
   b) Un avenir souhaité vers lequel l'organisation ou l'équipe travaille à plus long terme
   c) Une notion sans lien avec une quelconque orientation future
   d) Uniquement les tâches quotidiennes individuelles
3. Vrai ou faux : Une vision et une mission claires n'ont aucun lien avec l'engagement ou la motivation des membres de l'équipe.
4. Pourquoi les membres de l'équipe de la leader ont-ils exprimé plus d'engagement après qu'elle a relié leur travail à une mission et à une vision plus larges?
   a) La vision et la mission n'ont aucun lien avec l'engagement individuel
   b) Comprendre comment le travail quotidien se rattache à une raison d'être plus large et significative augmente généralement l'engagement et la résilience
   c) Les tâches individuelles sont toujours plus motivantes quand elles sont déconnectées de tout contexte plus large
   d) Elle ne s'intéressait pas au sentiment de sens ou de raison d'être de son équipe

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une mission décrit la raison d'être fondamentale d'une organisation ou d'une équipe — pourquoi elle existe et ce qu'elle fait essentiellement.
2. Une vision décrit un avenir souhaité vers lequel l'organisation ou l'équipe travaille à plus long terme.
3. Une vision et une mission claires soutiennent généralement un plus grand engagement et une plus grande motivation des membres de l'équipe, en particulier pendant les périodes difficiles.
4. Comprendre comment leur travail se rattachait à une raison d'être plus large et significative a augmenté, avec raison, l'engagement et la résilience des membres de l'équipe.

**7. Points clés à retenir**
- Une mission décrit la raison d'être fondamentale d'une organisation; une vision décrit son orientation future souhaitée.
- Ensemble, elles fournissent la raison d'être commune que la leçon 32 a nommée comme essentielle à une vraie cohésion d'équipe.
- Une vision et une mission claires soutiennent la motivation et la résilience, en particulier pendant des périodes difficiles comme un changement organisationnel.
- Relier le travail quotidien individuel à ce contexte plus large augmente généralement l'engagement par rapport à un travail vu comme une série de tâches déconnectées.
