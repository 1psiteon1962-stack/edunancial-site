---
id: BLACK-L2-039
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 39
title: "La gestion du temps pour les leaders : les priorités avant l'urgence"
summary: "Distingue ce qui est urgent de ce qui est important, et apprends à protéger du temps pour la planification stratégique et l'accompagnement de ton équipe."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-039
### La gestion du temps pour les leaders : les priorités avant l'urgence

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Distinguer de façon conceptuelle les tâches urgentes des tâches importantes.
- Expliquer pourquoi les leaders devraient donner la priorité aux tâches importantes, plutôt que de seulement réagir à l'urgence.
- Appliquer cette notion à une situation hypothétique de gestion du temps.

**2. Contenu principal**
En s'appuyant sur les thèmes plus larges de ce niveau, une gestion du temps efficace en leadership distingue généralement les tâches urgentes (qui exigent une attention immédiate, peu importe leur importance réelle à long terme) des tâches importantes (vraiment significatives pour les objectifs et les priorités à long terme, comme la réflexion stratégique, le développement des relations et le développement de l'équipe sur lesquels ce niveau insiste, même si elles n'ont pas le même caractère pressant et immédiat).

Une erreur courante de gestion du temps en leadership consiste à laisser constamment les tâches urgentes prendre la place des activités importantes mais non urgentes — la planification stratégique, le vrai développement des relations (leçon 9), l'accompagnement et le développement (en écho à la discussion sur la délégation de la leçon 4) —, puisque les tâches urgentes créent une pression immédiate, alors que les coûts de la négligence des tâches importantes (le développement stagnant d'une équipe, une occasion stratégique ratée) s'accumulent plus graduellement et de façon moins visible. Donner volontairement la priorité aux activités importantes mais non urgentes est donc une vraie discipline de leadership, et pas quelque chose qui arrive automatiquement.

**3. Exemple pratique**
En examinant comment elle passe réellement son temps, une leader découvre qu'elle laisse constamment les demandes urgentes et immédiates — répondre aux courriels, régler des problèmes opérationnels immédiats — prendre la place d'activités importantes mais non urgentes, comme la planification stratégique et des conversations d'accompagnement réfléchies avec les membres de son équipe. Reconnaissant ce schéma comme une erreur courante de gestion du temps en leadership, elle bloque volontairement des plages de temps réservées à ces activités importantes mais non urgentes, et protège ce temps pour qu'il ne soit pas constamment remplacé par la demande urgente du jour.

**4. Quiz de pratique**
1. À quoi « urgent » fait-il généralement référence, par rapport à « important » dans cette leçon?
   a) À ce qui est vraiment significatif pour les objectifs et les priorités à long terme
   b) À ce qui exige une attention immédiate, peu importe son importance réelle à long terme
   c) À un type de crédit d'impôt
   d) À une notion identique à « important », sans distinction
2. Quelle erreur courante de gestion du temps en leadership cette leçon nomme-t-elle?
   a) Donner constamment la priorité aux activités importantes mais non urgentes plutôt qu'aux demandes urgentes
   b) Laisser constamment les tâches urgentes prendre la place d'activités importantes mais non urgentes, comme la planification stratégique et l'accompagnement
   c) Une erreur sans aucun lien avec la répartition du temps
   d) Ne consacrer aucun temps à quelque tâche urgente que ce soit
3. Vrai ou faux : Les activités importantes mais non urgentes, comme la planification stratégique et l'accompagnement, n'ont aucun vrai coût quand on les néglige constamment au profit des demandes urgentes.
4. Pourquoi la leader a-t-elle bloqué volontairement des plages de temps pour les activités importantes mais non urgentes?
   a) Elle voulait que les demandes urgentes continuent de prendre la place de ces activités
   b) Elle a reconnu ce schéma d'erreur courant en leadership et a protégé du temps pour des activités vraiment significatives
   c) Les activités importantes mais non urgentes n'ont aucun lien avec l'efficacité du leadership
   d) Elle ne s'intéressait pas à la planification stratégique ni à l'accompagnement

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. « Urgent » désigne les tâches qui exigent une attention immédiate, peu importe leur importance réelle à long terme.
2. Laisser constamment les tâches urgentes prendre la place des activités importantes mais non urgentes est une erreur courante de gestion du temps en leadership.
3. Négliger les activités importantes mais non urgentes entraîne de vrais coûts, même s'ils sont plus graduels et moins visibles, comme un développement stagnant de l'équipe.
4. En bloquant volontairement du temps, la leader a protégé, avec raison, des activités vraiment significatives contre leur remplacement constant par l'urgence.

**7. Points clés à retenir**
- Les tâches urgentes exigent une attention immédiate, peu importe leur importance; les tâches importantes sont vraiment significatives pour les objectifs à long terme.
- Une erreur courante en leadership consiste à laisser les tâches urgentes prendre constamment la place des activités importantes mais non urgentes.
- Négliger ce qui est important mais non urgent entraîne de vrais coûts qui s'accumulent plus graduellement et de façon moins visible que la pression des tâches urgentes.
- Protéger volontairement du temps pour les activités importantes est une vraie discipline de leadership, et non un résultat automatique.
