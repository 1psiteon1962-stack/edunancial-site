---
id: BLACK-L2-040
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 40
title: "La délégation et le temps : retrouver de la capacité grâce aux autres"
summary: "Comprends comment la délégation libère du temps pour les activités que seul le leader peut accomplir, comme la réflexion stratégique et l'accompagnement."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-040
### La délégation et le temps : retrouver de la capacité grâce aux autres

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Relier directement la discussion sur la gestion du temps de la leçon 39 à la délégation (leçons 4 et 20).
- Expliquer comment la délégation permet au leader de retrouver de la capacité pour les activités importantes mais non urgentes.
- Appliquer cette notion à une situation hypothétique de capacité.

**2. Contenu principal**
En s'appuyant directement sur la leçon 39, cette leçon relie explicitement la gestion du temps à la délégation (leçons 4 et 20) : un leader qui continue de s'occuper lui-même de tâches qui pourraient vraiment être déléguées à des membres compétents de l'équipe a moins de capacité pour les activités de leadership importantes mais non urgentes nommées à la leçon 39 — la réflexion stratégique, le développement des relations, l'accompagnement. La délégation n'est donc pas seulement un outil d'efficacité opérationnelle (comme BLUE-L2 la présentait), mais une vraie stratégie de gestion du temps en leadership pour retrouver de la capacité pour les activités que seul le leader peut accomplir.

Ça renforce, du point de vue de la capacité, la distinction entre délégation et abdication de la leçon 20 : une vraie délégation, avec responsabilité (et non une abdication), libère du temps de leadership pour des activités à plus grand effet de levier, alors que continuer de s'occuper soi-même de tâches qu'on pourrait déléguer — souvent à cause des mêmes obstacles psychologiques nommés dans BLUE-L2-026 — représente un vrai coût en capacité de leadership, et pas seulement une préférence personnelle sans conséquence plus large.

**3. Exemple pratique**
En examinant la façon dont elle répartit son temps (en écho à la leçon 39), une leader reconnaît qu'elle continue de s'occuper elle-même de plusieurs tâches que des membres compétents de son équipe pourraient vraiment prendre en charge, ce qui lui laisse trop peu de capacité pour la réflexion stratégique et l'accompagnement, qu'elle reconnaît comme importants mais non urgents. Reconnaissant la délégation comme une vraie stratégie de gestion du temps, et pas seulement comme un outil d'efficacité opérationnelle, elle délègue volontairement ces tâches (en gardant une responsabilité appropriée, en écho à la leçon 20), ce qui lui permet de retrouver de la capacité précisément pour les activités à plus grand effet de levier qu'elle seule peut accomplir.

**4. Quiz de pratique**
1. Comment cette leçon relie-t-elle la discussion de la leçon 39 à la délégation?
   a) Elle les traite comme des notions entièrement sans lien
   b) Un leader qui continue de s'occuper lui-même de tâches qu'on pourrait déléguer a moins de capacité pour les activités de leadership importantes mais non urgentes
   c) La délégation n'a aucun lien avec la gestion du temps du leader
   d) La gestion du temps et la délégation portent sur des préoccupations identiques et redondantes
2. Comment cette leçon présente-t-elle la délégation, au-delà de la présentation axée sur l'efficacité opérationnelle de BLUE-L2?
   a) Comme un simple outil d'efficacité opérationnelle, sans lien avec la gestion du temps du leader
   b) Comme une vraie stratégie de gestion du temps en leadership pour retrouver de la capacité pour des activités à plus grand effet de levier
   c) Comme une notion sans lien avec la capacité du leader
   d) Comme quelque chose qu'il ne faudrait jamais faire
3. Vrai ou faux : Continuer de s'occuper soi-même de tâches qu'on pourrait déléguer n'a aucun vrai coût sur la capacité du leader pour les activités importantes mais non urgentes.
4. Pourquoi la leader a-t-elle volontairement délégué des tâches dont elle continuait de s'occuper elle-même?
   a) Elle ne tenait pas à retrouver de la capacité pour la réflexion stratégique ou l'accompagnement
   b) Elle a reconnu la délégation comme une vraie stratégie de gestion du temps pour retrouver de la capacité pour des activités à plus grand effet de levier
   c) La délégation n'a aucun lien avec le temps disponible du leader
   d) Elle voulait continuer de s'occuper elle-même de chaque tâche, peu importe sa capacité

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Continuer de s'occuper soi-même de tâches qu'on pourrait déléguer laisse au leader moins de capacité pour les activités de leadership importantes mais non urgentes.
2. Cette leçon présente la délégation comme une vraie stratégie de gestion du temps en leadership, au-delà de sa présentation axée sur l'efficacité opérationnelle dans BLUE-L2.
3. Continuer de s'occuper soi-même de tâches qu'on pourrait déléguer entraîne un vrai coût en capacité pour les activités importantes mais non urgentes.
4. La délégation volontaire de la leader lui a permis, avec raison, de retrouver de la capacité pour les activités à plus grand effet de levier qu'elle seule pouvait accomplir.

**7. Points clés à retenir**
- Cette leçon relie directement la discussion sur la gestion du temps de la leçon 39 à la délégation des leçons 4 et 20.
- Continuer de s'occuper soi-même de tâches qu'on pourrait déléguer laisse moins de capacité pour les activités de leadership importantes mais non urgentes.
- La délégation sert de vraie stratégie de gestion du temps en leadership, et pas seulement d'outil d'efficacité opérationnelle.
- Une vraie délégation, avec responsabilité (et non une abdication, leçon 20), permet de retrouver de la capacité pour un travail de leadership à plus grand effet de levier.
