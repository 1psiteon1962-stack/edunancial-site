---
id: BLACK-L2-041
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 41
title: "L'intelligence émotionnelle : la conscience de soi comme base du leadership"
summary: "Comprends ce qu'est l'intelligence émotionnelle et pourquoi reconnaître tes propres émotions et déclencheurs t'aide à mieux diriger sous pression."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-041
### L'intelligence émotionnelle : la conscience de soi comme base du leadership

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle l'intelligence émotionnelle.
- Expliquer pourquoi la conscience de soi sert de composante de base.
- Appliquer cette notion à une situation hypothétique de conscience de soi.

**2. Contenu principal**
L'intelligence émotionnelle désigne généralement la capacité de reconnaître, de comprendre et de gérer ses propres émotions, ainsi que de reconnaître les émotions des autres et d'y répondre de façon appropriée — une capacité qui soutient plusieurs des compétences précises de ce niveau, dont l'écoute active (leçon 11), la réception de la rétroaction (leçon 13) et la résolution de conflits (leçons 15 et 16). La conscience de soi, généralement considérée comme une composante de base de l'intelligence émotionnelle, consiste à reconnaître vraiment ses propres états émotionnels, ses déclencheurs et leurs effets sur son propre comportement et ses propres décisions, en particulier sous le stress ou la pression.

Sans vraie conscience de soi, un leader peut, sans le savoir, laisser ses propres réactions émotionnelles — frustration, anxiété, attitude défensive — influencer de façon inappropriée son comportement de leader, en écho à la discussion sur les réactions défensives de la leçon 13 et à celle sur les conversations difficiles de la leçon 14, sans se rendre compte que cette influence se produit. La conscience de soi est donc une base nécessaire aux compétences d'intelligence émotionnelle plus tournées vers les autres (reconnaître les émotions des autres et bien y répondre) que ce niveau aborde tout au long.

**3. Exemple pratique**
Remarquant qu'il a tendance à répondre plus sèchement et avec moins de patience pendant les discussions d'équipe quand il subit lui-même une forte pression liée à une échéance, un leader développe une meilleure conscience de ce déclencheur émotionnel précis et de son effet sur son comportement. Cette conscience de soi lui permet de modérer consciemment ses réactions pendant les périodes de forte pression, plutôt que de laisser, sans le savoir, ses réactions liées au stress influencer de façon inappropriée ses échanges avec son équipe — ce qui montre comment la conscience de soi sert de capacité de leadership de base qui soutient son intelligence émotionnelle plus large.

**4. Quiz de pratique**
1. À quoi l'intelligence émotionnelle fait-elle généralement référence?
   a) À la capacité de reconnaître, de comprendre et de gérer ses propres émotions, et de répondre de façon appropriée aux émotions des autres
   b) À un type de crédit d'impôt
   c) À une notion sans lien avec des compétences de leadership comme l'écoute active ou la résolution de conflits
   d) Uniquement à la capacité de réprimer complètement toute expression émotionnelle
2. Selon cette leçon, pourquoi la conscience de soi est-elle considérée comme une composante de base de l'intelligence émotionnelle?
   a) La conscience de soi n'a aucun lien avec l'intelligence émotionnelle plus large
   b) Sans vraie conscience de soi, un leader peut, sans le savoir, laisser ses propres réactions émotionnelles influencer son comportement de façon inappropriée
   c) La conscience de soi n'a aucun lien avec le comportement d'un leader sous le stress
   d) Les composantes de base n'ont aucun effet sur les compétences d'intelligence émotionnelle tournées vers les autres
3. Vrai ou faux : Les réactions émotionnelles d'un leader n'influencent jamais son comportement de leader, ce qui rend la conscience de soi inutile.
4. Pourquoi la conscience qu'avait le leader de son déclencheur lié à la pression des échéances a-t-elle aidé son comportement de leader?
   a) Elle n'a eu aucun effet sur son comportement
   b) Elle lui a permis de modérer consciemment ses réactions, au lieu de laisser, sans le savoir, ses réactions liées au stress influencer ses échanges avec son équipe
   c) La conscience de soi n'a aucun lien avec la modération du comportement sous pression
   d) Il n'avait aucun déclencheur émotionnel précis à reconnaître

**5. Corrigé**
1. a  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'intelligence émotionnelle est la capacité de reconnaître, de comprendre et de gérer ses propres émotions, et de répondre de façon appropriée aux émotions des autres.
2. Sans vraie conscience de soi, un leader peut, sans le savoir, laisser ses propres réactions émotionnelles influencer son comportement de façon inappropriée.
3. Les réactions émotionnelles d'un leader peuvent influencer fortement son comportement, ce qui fait de la conscience de soi une capacité de leadership vraiment nécessaire.
4. La conscience de soi du leader lui a permis, avec raison, de modérer consciemment ses réactions liées au stress au lieu d'agir sous leur effet sans le savoir.

**7. Points clés à retenir**
- L'intelligence émotionnelle consiste à reconnaître et à gérer ses propres émotions, et à répondre de façon appropriée aux émotions des autres.
- La conscience de soi, une composante de base, consiste à reconnaître ses propres états émotionnels, ses déclencheurs et leurs effets sur son comportement.
- Sans conscience de soi, un leader peut, sans le savoir, laisser ses réactions émotionnelles influencer son comportement de leader de façon inappropriée.
- Ça soutient plusieurs compétences précises abordées dans ce niveau, dont l'écoute active, la réception de la rétroaction et la résolution de conflits.
