---
id: BLACK-L2-042
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 42
title: "La gestion ascendante : exercer du leadership même sans autorité officielle"
summary: "Apprends à gérer de façon proactive et constructive ta relation avec ton supérieur, en exerçant de l'influence sans aucune autorité officielle sur lui."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-042
### La gestion ascendante : exercer du leadership même sans autorité officielle

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle la « gestion ascendante ».
- Expliquer comment la distinction entre autorité et influence de la leçon 5 s'applique à ce contexte précis.
- Appliquer cette notion à une situation hypothétique de gestion ascendante.

**2. Contenu principal**
En s'appuyant directement sur la distinction entre autorité et influence de la leçon 5, la « gestion ascendante » désigne généralement le fait de gérer de façon proactive et constructive sa relation avec un supérieur ou un leader de niveau plus élevé — anticiper ses besoins et ses préférences de communication, lui fournir de façon proactive une information pertinente et bien organisée, et soulever de façon constructive des préoccupations ou des désaccords par les voies appropriées. Il s'agit d'une forme de leadership et d'influence exercée sans aucune autorité officielle sur la personne qu'on « gère ».

Ça applique directement l'idée centrale de la leçon 5 : une personne qui n'a aucune autorité officielle sur son supérieur peut quand même exercer une vraie influence grâce aux mêmes mécanismes sur lesquels ce niveau insiste — bâtir la confiance (leçon 9), communiquer clairement (leçon 10) et comprendre les besoins et le point de vue précis de l'autre personne (en écho à la discussion sur l'écoute active de la leçon 11). Ça montre que les compétences de leadership sont utiles dans toutes les directions de l'organisation, et pas seulement vers le bas, envers les personnes sur lesquelles on a une autorité officielle.

**3. Exemple pratique**
Constatant que son supérieur préfère constamment des mises à jour concises et axées sur les données plutôt que de longues explications narratives, un membre de l'équipe adapte sa propre façon de communiquer en conséquence, en lui fournissant de façon proactive une information pertinente et bien organisée dans le format qu'il préfère, au lieu de s'attendre à ce que son supérieur s'adapte à son propre style de communication habituel. Il apprend aussi à soulever ses désaccords de façon constructive, en choisissant le bon moment et la bonne formulation, et reconnaît qu'il s'agit d'une vraie application des mêmes principes d'influence sur lesquels ce niveau insiste, appliqués vers le haut de l'organisation même s'il n'a aucune autorité officielle sur son supérieur.

**4. Quiz de pratique**
1. Selon cette leçon, à quoi la « gestion ascendante » fait-elle généralement référence?
   a) Au fait d'avoir une autorité officielle sur un supérieur ou un leader de niveau plus élevé
   b) Au fait de gérer de façon proactive et constructive sa relation avec un supérieur, en exerçant de l'influence sans autorité officielle sur lui
   c) À un type de crédit d'impôt
   d) À une notion sans lien avec les compétences de leadership
2. Comment cette leçon applique-t-elle la distinction entre autorité et influence de la leçon 5?
   a) Elle n'a aucun lien avec cette distinction
   b) Elle montre qu'une vraie influence, et non l'autorité officielle, peut s'exercer même vers le haut de l'organisation
   c) L'influence s'applique seulement vers le bas de l'organisation, jamais vers le haut
   d) La gestion ascendante exige une autorité officielle pour être efficace
3. Vrai ou faux : Les compétences de leadership comme bâtir la confiance et communiquer clairement n'ont aucune utilité quand elles visent un supérieur plutôt qu'un subordonné.
4. Pourquoi le membre de l'équipe a-t-il adapté son style de communication aux préférences de son supérieur?
   a) Il voulait plutôt que son supérieur s'adapte entièrement à son propre style habituel
   b) Cette adaptation reflétait un vrai travail d'influence, qui applique les principes de ce niveau vers le haut de l'organisation
   c) L'adaptation de la communication n'a aucun lien avec une gestion ascendante efficace
   d) Il avait une autorité officielle sur son supérieur, ce qui n'exigeait aucune adaptation

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La gestion ascendante consiste à gérer de façon proactive et constructive sa relation avec un supérieur, en exerçant de l'influence sans autorité officielle sur lui.
2. Cette leçon montre qu'une vraie influence, et non l'autorité officielle, peut s'exercer même vers le haut de l'organisation.
3. Bâtir la confiance et communiquer clairement sont utiles dans toutes les directions de l'organisation, y compris vers un supérieur.
4. L'adaptation du membre de l'équipe reflétait, avec raison, un vrai travail d'influence exercé vers le haut, même sans autorité officielle sur son supérieur.

**7. Points clés à retenir**
- La « gestion ascendante » consiste à gérer de façon proactive et constructive sa relation avec un supérieur, en exerçant de l'influence sans autorité officielle.
- Ça applique directement la distinction entre autorité et influence de la leçon 5 à la direction ascendante de l'organisation.
- Ça s'appuie sur la confiance, la communication claire et la compréhension des besoins de l'autre, en écho aux leçons 9 à 11.
- Les compétences de leadership sont utiles dans toutes les directions de l'organisation, et pas seulement vers le bas, envers des subordonnés officiels.
