---
id: BLACK-L2-043
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 43
title: "Le leadership transversal : diriger au-delà de sa propre équipe"
summary: "Apprends à collaborer avec d'autres équipes qui ne relèvent pas de toi, en comprenant leurs priorités et en présentant tes demandes en fonction d'un avantage mutuel."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-043
### Le leadership transversal : diriger au-delà de sa propre équipe

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer les défis généraux du leadership entre différents services.
- Relier directement cette notion à la discussion sur l'influence de la leçon 5.
- Appliquer cette notion à une situation transversale hypothétique.

**2. Contenu principal**
En s'appuyant sur la discussion de la leçon 5 sur l'autorité et l'influence, et sur celle de la leçon 42 sur la gestion ascendante, le leadership transversal aborde un défi apparenté : diriger ou coordonner des personnes d'autres équipes ou d'autres services qui ne relèvent pas du leader et qui peuvent avoir des priorités, des incitatifs ou des normes de travail différents de ceux de sa propre équipe. Ça exige de compter presque entièrement sur l'influence plutôt que sur l'autorité officielle, puisque le leadership transversal n'offre généralement pas l'autorité directe qu'un leader a sur sa propre équipe.

Un leadership transversal efficace consiste généralement à comprendre vraiment les priorités et les contraintes précises de l'autre équipe (en écho à la discussion sur l'écoute active de la leçon 11), à présenter ses demandes ou ses propositions en fonction d'un vrai avantage mutuel plutôt que de supposer que l'autre équipe devrait simplement faire passer les besoins du leader qui fait la demande en premier, et à bâtir, au-delà des frontières entre services, le même genre de confiance (leçon 9) que ce niveau a mis de l'avant au sein d'une même équipe.

**3. Exemple pratique**
Ayant besoin de la collaboration d'un autre service, qui a des priorités différentes et aucun lien hiérarchique avec elle, une leader prend le temps de comprendre vraiment les contraintes et les priorités précises de ce service, et présente sa demande en fonction d'un vrai avantage mutuel plutôt que de supposer qu'il devrait simplement faire passer les besoins de son équipe avant ses propres priorités légitimes. Cette approche, qui compte sur l'influence plutôt que sur une autorité officielle qu'elle n'a pas sur ce service, reprend l'idée centrale de la leçon 5, appliquée précisément à ce contexte transversal.

**4. Quiz de pratique**
1. Selon cette leçon, quel vrai défi le leadership transversal comporte-t-il généralement?
   a) Diriger des personnes qui relèvent directement du leader, avec une pleine autorité officielle
   b) Diriger ou coordonner des personnes d'autres équipes qui ne relèvent pas du leader et qui peuvent avoir des priorités différentes
   c) Un type de crédit d'impôt
   d) Une notion sans lien avec l'influence ou l'autorité
2. Selon cette leçon, qu'exige généralement un leadership transversal efficace?
   a) Supposer que les autres équipes devraient simplement faire passer les besoins du leader avant les leurs
   b) Comprendre vraiment les priorités des autres équipes et présenter ses demandes en fonction d'un avantage mutuel
   c) Avoir une autorité officielle sur chaque équipe concernée
   d) Ignorer complètement les contraintes des autres équipes
3. Vrai ou faux : Le leadership transversal repose généralement surtout sur l'autorité officielle, puisque le leader a un lien hiérarchique direct avec chaque équipe concernée.
4. Pourquoi la leader a-t-elle présenté sa demande transversale en fonction d'un avantage mutuel plutôt que de supposer qu'elle avait priorité?
   a) Elle avait une autorité officielle sur l'autre service, ce qui n'exigeait pas une telle présentation
   b) Elle a reconnu que le leadership transversal repose sur l'influence, et non sur l'autorité officielle, en écho à l'idée centrale de la leçon 5
   c) Présenter une demande en fonction d'un avantage mutuel n'a aucun lien avec la collaboration transversale
   d) Elle ne s'intéressait pas aux priorités ni aux contraintes de l'autre service

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Le leadership transversal consiste à diriger ou à coordonner des personnes d'autres équipes qui ne relèvent pas du leader et qui peuvent avoir des priorités différentes.
2. Un leadership transversal efficace exige de comprendre vraiment les priorités des autres équipes et de présenter ses demandes en fonction d'un avantage mutuel.
3. Le leadership transversal repose généralement sur l'influence plutôt que sur l'autorité officielle, puisque le leader n'a pas de lien hiérarchique direct au-delà de son service.
4. En présentant sa demande en fonction d'un avantage mutuel, la leader comptait, avec raison, sur l'influence plutôt que sur une autorité officielle qu'elle n'avait pas.

**7. Points clés à retenir**
- Le leadership transversal consiste à diriger ou à coordonner des personnes d'autres équipes, sans lien hiérarchique officiel.
- Il repose presque entièrement sur l'influence plutôt que sur l'autorité officielle, en écho à la distinction centrale de la leçon 5.
- Un leadership transversal efficace exige de comprendre vraiment les priorités des autres équipes et de présenter ses demandes en fonction d'un avantage mutuel.
- Ça bâtit la confiance au-delà des frontières entre services, en appliquant plus largement dans l'organisation les principes d'équipe de ce niveau.
