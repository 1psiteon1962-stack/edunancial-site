---
id: BLACK-L2-044
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 44
title: "Retour sur le leadership et le devoir fiduciaire (BLACK rencontre PURPLE)"
summary: "Vois comment le principe éthique derrière le devoir fiduciaire s'applique à tout leader, même sans obligation juridique officielle, par exemple pour reconnaître le travail de l'équipe."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-044
### Retour sur le leadership et le devoir fiduciaire (BLACK rencontre PURPLE)

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Renforcer, du point de vue du leadership, la discussion de PURPLE-L2-043 sur le devoir fiduciaire.
- Expliquer comment le devoir fiduciaire s'applique aux leaders au-delà des administrateurs officiels de sociétés.
- Appliquer cette notion à une décision de leadership hypothétique.

**2. Contenu principal**
En revenant sur la discussion de PURPLE-L2-043 sur le devoir fiduciaire — une obligation juridique renforcée qui exige qu'une partie agisse dans le meilleur intérêt d'une autre —, cette leçon examine comment cette notion, et le principe éthique plus large qui la soutient, s'applique au leadership de façon plus générale, au-delà des administrateurs officiels de sociétés dont traitait précisément PURPLE-L2-043. Même si chaque poste de leadership ne comporte pas un devoir fiduciaire officiel et juridiquement exécutoire, le principe éthique sous-jacent — faire passer les intérêts des personnes qu'on dirige et qu'on représente avant son propre intérêt étroit — se retrouve directement dans le thème de l'intendance (leçon 8) et dans la discussion sur la confiance (leçon 9) de ce niveau.

Un leader qui prend des décisions qui l'avantagent personnellement au détriment réel de son équipe ou de son organisation — s'attribuer le mérite du travail des membres de son équipe, prendre des décisions surtout pour faire avancer sa propre position plutôt que pour le vrai bien de l'organisation ou de l'équipe — viole ce principe éthique plus large, même dans des contextes sans devoir fiduciaire officiel et juridiquement exécutoire. Ça rejoint le thème constant de ce niveau : le leadership comporte une vraie responsabilité, et pas seulement une obligation juridique officielle là où elle s'applique techniquement.

**3. Exemple pratique**
Alors qu'il se demande s'il devrait s'attribuer personnellement le mérite d'un projet que son équipe a élaboré collectivement, un leader reconnaît que ça violerait le principe éthique plus large qui soutient le devoir fiduciaire (en écho à PURPLE-L2-043), même si son poste ne comporte peut-être pas d'obligation fiduciaire officielle et juridiquement exécutoire. Reconnaissant que ça se relie directement au thème de l'intendance (leçon 8) et à la discussion sur la confiance (leçon 9) de ce niveau, il s'assure que son équipe reçoive une reconnaissance réelle et visible pour son travail collectif, en faisant passer les intérêts réels de son équipe avant son propre intérêt étroit à être reconnu personnellement.

**4. Quiz de pratique**
1. Sur quoi cette leçon revient-elle à partir de PURPLE-L2-043?
   a) Une notion sans aucun lien avec l'éthique du leadership
   b) La discussion sur le devoir fiduciaire, appliquée cette fois au principe éthique plus large qui soutient le leadership en général
   c) Uniquement une discussion sur les structures de gouvernance d'entreprise
   d) Uniquement une discussion sur le droit des marques de commerce
2. Selon cette leçon, chaque poste de leadership comporte-t-il un devoir fiduciaire officiel et juridiquement exécutoire?
   a) Oui, chaque poste de leadership comporte un devoir fiduciaire officiel identique
   b) Pas forcément, mais le principe éthique sous-jacent s'applique plus largement, peu importe le statut juridique officiel
   c) Aucun poste de leadership ne comporte jamais d'obligation éthique
   d) Le devoir fiduciaire et l'éthique du leadership sont des notions entièrement sans lien
3. Vrai ou faux : Un leader qui s'attribue personnellement le mérite du travail collectif de son équipe, au détriment réel de celle-ci, agit de façon tout à fait conforme au cadre éthique de cette leçon, pourvu qu'aucun devoir fiduciaire officiel ne s'applique techniquement.
4. Pourquoi le leader s'est-il assuré que son équipe reçoive une reconnaissance visible plutôt que de se l'attribuer personnellement?
   a) Il n'avait aucune obligation éthique, peu importe son statut fiduciaire officiel
   b) Il a reconnu que le principe éthique plus large qui soutient le devoir fiduciaire s'appliquait, peu importe le statut juridique officiel de son poste
   c) Les principes éthiques s'appliquent seulement quand un devoir fiduciaire officiel est juridiquement exécutoire
   d) Il n'avait aucune équipe dont il pouvait reconnaître le travail

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Cette leçon revient sur la discussion de PURPLE-L2-043 sur le devoir fiduciaire, appliquée au principe éthique plus large qui soutient le leadership en général.
2. Chaque poste de leadership ne comporte pas un devoir fiduciaire officiel et juridiquement exécutoire, mais le principe éthique sous-jacent s'applique plus largement.
3. S'attribuer le mérite au détriment réel de son équipe viole le principe éthique plus large que décrit cette leçon, peu importe le statut fiduciaire officiel.
4. La décision du leader de reconnaître le travail de son équipe reflétait, avec raison, le principe éthique plus large qui s'applique peu importe le statut juridique officiel de son poste.

**7. Points clés à retenir**
- Cette leçon revient sur la discussion de PURPLE-L2-043 sur le devoir fiduciaire, appliquée au principe éthique plus large qui soutient le leadership en général.
- Chaque poste de leadership ne comporte pas un devoir fiduciaire officiel et juridiquement exécutoire, mais le principe éthique s'applique plus largement.
- Ça rejoint le thème de l'intendance (leçon 8) et la discussion sur la confiance (leçon 9) de ce niveau.
- Le leadership comporte une vraie responsabilité éthique, au-delà de l'obligation juridique officielle là où elle s'applique techniquement.
