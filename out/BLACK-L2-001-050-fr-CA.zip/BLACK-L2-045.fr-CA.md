---
id: BLACK-L2-045
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 45
title: "Diriger une équipe de vente : motivation et indicateurs (BLACK rencontre ORANGE)"
summary: "Vois comment les indicateurs de vente très visibles peuvent motiver une équipe, mais aussi créer une compétition malsaine ou des tactiques douteuses si le leader ne trouve pas le bon équilibre."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-045
### Diriger une équipe de vente : motivation et indicateurs (BLACK rencontre ORANGE)

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Renforcer, du point de vue du leadership, la discussion sur la vente de ORANGE-L2.
- Expliquer les considérations générales propres à la direction d'une équipe axée sur la vente.
- Appliquer cette notion à une situation hypothétique de leadership en vente.

**2. Contenu principal**
En s'appuyant sur la discussion sur le processus de vente de ORANGE-L2, cette leçon examine les considérations de leadership propres aux équipes de vente : les rôles en vente comportent souvent des indicateurs individuels très visibles et quantifiables (en écho à la discussion sur la mesure de ORANGE-L2-038), ce qui peut créer à la fois des occasions de motivation (une reconnaissance claire et objective d'un bon rendement, en écho à la leçon 25) et de vrais risques (une compétition interne malsaine qui mine la cohésion d'équipe abordée à la leçon 32, ou une pression vers les tactiques de vente manipulatrices contre lesquelles ORANGE-L2-028 mettait en garde, si on poursuit les indicateurs sans balises éthiques).

Un leadership efficace en vente exige généralement de trouver un équilibre entre la responsabilité individuelle des résultats et la cohésion d'équipe ainsi que les normes éthiques sur lesquelles ce niveau insiste — reconnaître et récompenser un bon rendement (leçon 25) tout en s'assurant que la culture plus large de l'équipe (leçons 28 et 29) n'encourage pas le genre de tactiques éthiquement douteuses contre lesquelles ORANGE-L2-028 mettait en garde. Ça exige un vrai jugement de leadership, au-delà de simplement fixer des cibles ambitieuses et de laisser libre cours à la compétition interne.

**3. Exemple pratique**
À la tête d'une équipe de vente dont les indicateurs de rendement individuels sont très visibles, une leader reconnaît la vraie valeur de motivation de ces indicateurs, en écho à la discussion sur la reconnaissance de la leçon 25, tout en surveillant activement les signes que ce milieu axé sur les indicateurs pourrait encourager le genre de tactiques manipulatrices contre lesquelles ORANGE-L2-028 mettait en garde, ou une compétition malsaine qui mine la cohésion d'équipe (leçon 32). Elle équilibre volontairement la reconnaissance individuelle fondée sur les indicateurs avec des incitatifs à la collaboration à l'échelle de l'équipe et des normes éthiques claires, pour que la poursuite de bons résultats par son équipe ne se fasse pas au détriment de la pratique éthique et de la cohésion sur lesquelles ce niveau insiste.

**4. Quiz de pratique**
1. Selon cette leçon, quel vrai risque des indicateurs de vente très visibles peuvent-ils créer?
   a) Aucun risque, puisque les indicateurs ont toujours des effets entièrement positifs
   b) Une compétition interne malsaine qui mine la cohésion d'équipe, ou une pression vers des tactiques manipulatrices
   c) Les indicateurs n'ont aucun lien avec la dynamique d'équipe ou la pratique éthique
   d) Les indicateurs de vente empêchent toujours automatiquement une compétition malsaine
2. Selon cette leçon, entre quoi un leadership efficace en vente doit-il généralement trouver un équilibre?
   a) Uniquement la responsabilité individuelle, sans tenir compte de la cohésion d'équipe ni de l'éthique
   b) La responsabilité individuelle des résultats, d'une part, et la cohésion d'équipe et les normes éthiques sur lesquelles ce niveau insiste, d'autre part
   c) Une notion sans lien avec les discussions précédentes de ORANGE-L2
   d) Une compétition interne sans limite et sans balises éthiques
3. Vrai ou faux : Fixer des cibles ambitieuses et laisser libre cours à la compétition interne est décrit comme suffisant pour un leadership en vente efficace et éthique.
4. Pourquoi la leader a-t-elle surveillé activement les signes de tactiques manipulatrices ou de compétition malsaine dans son équipe de vente?
   a) Elle ne s'inquiétait pas de la pratique éthique ni de la cohésion de son équipe
   b) Elle a reconnu que les milieux axés sur les indicateurs comportent de vrais risques qui exigent un équilibre volontaire de la part du leader, en écho à ORANGE-L2-028 et à la discussion sur la cohésion de ce niveau
   c) Les indicateurs ne créent jamais de risque qui exige l'attention du leader
   d) Elle voulait encourager des tactiques manipulatrices pour obtenir de meilleurs résultats

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Des indicateurs de vente très visibles peuvent créer une compétition interne malsaine ou une pression vers des tactiques manipulatrices s'ils ne sont pas équilibrés par un vrai jugement de leadership.
2. Un leadership efficace en vente exige un équilibre entre la responsabilité individuelle, la cohésion d'équipe et les normes éthiques de ce niveau.
3. Des cibles ambitieuses et une compétition sans limite ne suffisent pas; un équilibre volontaire du leader entre éthique et cohésion est nécessaire.
4. La surveillance active de la leader a répondu, avec raison, aux vrais risques que les milieux axés sur les indicateurs peuvent créer pour l'éthique et la cohésion.

**7. Points clés à retenir**
- Cette leçon revient sur la discussion sur la vente de ORANGE-L2, du point de vue du leadership qui gère la dynamique propre aux équipes de vente.
- Des indicateurs très visibles créent des occasions de motivation, mais aussi des risques de compétition malsaine ou de tactiques éthiquement douteuses.
- Un leadership efficace en vente équilibre la responsabilité individuelle avec la cohésion d'équipe et les normes éthiques.
- Ça se relie directement à la discussion sur l'éthique de ORANGE-L2-028 et à celle sur la cohésion d'équipe de la leçon 32.
