---
id: BLACK-L2-046
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 46
title: "Rémunération et motivation : ce qui stimule vraiment le rendement (BLACK rencontre GREEN)"
summary: "Comprends pourquoi une rémunération insuffisante nuit à la motivation, mais qu'au-delà d'un seuil, la reconnaissance, le sens du travail et l'autonomie comptent souvent autant ou plus."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-046
### Rémunération et motivation : ce qui stimule vraiment le rendement (BLACK rencontre GREEN)

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Renforcer la discussion sur la reconnaissance de la leçon 25, en lien avec les notions de rémunération de GREEN-L2.
- Expliquer des constats généraux, appuyés par la recherche, sur la rémunération et la motivation.
- Appliquer cette notion à une situation de motivation hypothétique.

**2. Contenu principal**
En s'appuyant directement sur la discussion sur la reconnaissance de la leçon 25, cette leçon examine le rôle de la rémunération dans la motivation, en lien avec les notions financières du parcours GREEN (la paie, l'impôt sur la rémunération) vues plus tôt dans ce programme. Des recherches souvent citées suggèrent que la rémunération fonctionne autrement qu'on le suppose parfois : sous un certain seuil, une rémunération insuffisante peut vraiment miner la motivation et l'engagement (une préoccupation légitime, en écho au thème de la responsabilité de l'employeur de BLUE-L2-020), mais au-delà de ce seuil, les hausses de rémunération supplémentaires produisent souvent des gains de motivation décroissants par rapport à des facteurs non monétaires comme une vraie reconnaissance (leçon 25), un travail qui a du sens (discussion sur la vision de la leçon 37) et l'autonomie (en écho à la discussion sur la délégation de la leçon 4).

Ça ne veut pas dire que la rémunération n'est pas importante — une rémunération vraiment équitable et suffisante reste une vraie responsabilité, en écho au thème de l'intendance de ce niveau —, mais ça veut dire qu'un leader qui compte entièrement sur les hausses de rémunération en négligeant la vraie reconnaissance, le lien avec un travail qui a du sens et une autonomie appropriée se prive peut-être de facteurs de motivation importants et complémentaires, que ces constats appuyés par la recherche décrivent comme souvent aussi importants, sinon plus, une fois que la rémunération de base est suffisante.

**3. Exemple pratique**
En réfléchissant à la façon d'améliorer la motivation et l'engagement de son équipe, une leader s'assure d'abord que la rémunération de son équipe est vraiment équitable et suffisante, en écho à sa responsabilité d'intendance, mais reconnaît que des hausses de rémunération supplémentaires ne sont peut-être pas, à elles seules, le levier le plus efficace pour accroître la motivation une fois ce seuil de suffisance atteint. Elle accorde une attention supplémentaire à une vraie reconnaissance (leçon 25), s'assure que les membres de l'équipe comprennent comment leur travail se rattache à une raison d'être qui a du sens (leçon 37), et leur donne une autonomie appropriée (en écho à la discussion sur la délégation de la leçon 4), en reconnaissant que ces facteurs complémentaires sont vraiment importants en plus d'une rémunération équitable, et non à sa place.

**4. Quiz de pratique**
1. Selon cette leçon, que suggèrent des recherches souvent citées au sujet d'une rémunération sous un certain seuil de suffisance?
   a) Une rémunération insuffisante sous ce seuil n'a aucun effet sur la motivation
   b) Une rémunération insuffisante peut vraiment miner la motivation et l'engagement
   c) Une rémunération sous n'importe quel seuil maximise toujours la motivation
   d) Ce seuil n'a aucun lien avec la responsabilité de l'employeur
2. Que suggèrent ces recherches au sujet des hausses de rémunération au-delà du seuil de suffisance?
   a) Elles produisent toujours des gains de motivation proportionnels, sans effet décroissant
   b) Elles produisent souvent des gains de motivation décroissants par rapport à des facteurs non monétaires comme la reconnaissance, un travail qui a du sens et l'autonomie
   c) Une rémunération au-delà de ce seuil n'a aucun lien avec la motivation
   d) Seules les hausses de rémunération comptent, peu importe tout autre facteur
3. Vrai ou faux : Cette leçon conclut que la rémunération n'a aucune importance et qu'il faut l'écarter au profit des seuls facteurs non monétaires.
4. Pourquoi la leader a-t-elle investi dans la reconnaissance, le lien avec un travail qui a du sens et l'autonomie, en plus d'une rémunération équitable?
   a) Elle croyait que la rémunération n'avait aucune importance pour la motivation
   b) Elle a reconnu que ces facteurs complémentaires sont vraiment importants une fois la rémunération de base suffisante assurée
   c) La rémunération et les facteurs non monétaires n'ont aucun lien entre eux
   d) Elle ne s'intéressait pas à la motivation globale de son équipe

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une rémunération insuffisante sous un certain seuil de suffisance peut vraiment miner la motivation et l'engagement.
2. Au-delà de ce seuil, les hausses de rémunération produisent souvent des gains de motivation décroissants par rapport à des facteurs non monétaires comme la reconnaissance, un travail qui a du sens et l'autonomie.
3. Cette leçon ne nie pas l'importance de la rémunération, mais nomme des facteurs complémentaires importants une fois la suffisance de base atteinte.
4. En investissant dans des facteurs complémentaires, la leader a reconnu, avec raison, leur importance en plus d'une rémunération équitable, et non à sa place.

**7. Points clés à retenir**
- Une rémunération insuffisante sous un seuil de suffisance peut vraiment miner la motivation, en écho au thème de l'intendance de ce niveau.
- Au-delà de ce seuil, une rémunération supplémentaire produit souvent des gains de motivation décroissants par rapport aux facteurs non monétaires.
- Une vraie reconnaissance (leçon 25), un travail qui a du sens (leçon 37) et l'autonomie (leçon 4) sont des facteurs de motivation complémentaires importants.
- Ça relie directement les thèmes de leadership de ce niveau aux notions de rémunération et de finances du parcours GREEN vues plus tôt dans le programme.
