---
id: BLACK-L2-047
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 47
title: "Les erreurs de leadership courantes et pourquoi elles arrivent"
summary: "Passe en revue les erreurs de leadership les plus fréquentes, relie chacune à une leçon de ce niveau et découvre la cause commune qui les explique presque toutes."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-047
### Les erreurs de leadership courantes et pourquoi elles arrivent

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Nommer plusieurs erreurs de leadership courantes.
- Relier chaque erreur à des leçons précises vues plus tôt dans ce niveau.
- Renforcer la structure cumulative de ce niveau, en écho aux leçons sur les erreurs des autres couleurs.

**2. Contenu principal**
En écho aux leçons sur les erreurs de chaque couleur précédente, cette leçon passe en revue des erreurs de leadership courantes, chacune reliée à des notions déjà vues. Continuer de s'occuper soi-même de tâches qu'on pourrait déléguer (leçons 4, 20 et 40) vient souvent d'obstacles de confiance ou de malaise émotionnel non réglés, plutôt que de vraies contraintes de capacité. Éviter les conversations difficiles nécessaires (leçon 14) vient souvent du fait de privilégier le confort à court terme au détriment des coûts à plus long terme pour la relation et le rendement. Compter entièrement sur l'autorité officielle sans bâtir une vraie influence (leçon 5) vient souvent de la supposition qu'un titre suffit à produire l'engagement que génèrent en réalité la confiance et la relation. Laisser les tâches urgentes prendre constamment la place des activités de leadership importantes (leçon 39) vient souvent de la pression immédiate de l'urgence, qui masque les coûts plus graduels et moins visibles de la négligence des activités importantes.

Comme dans les autres couleurs, un schéma plus large explique la plupart de ces erreurs : privilégier le confort, le contrôle ou l'efficacité apparente à court terme au détriment de la discipline volontaire, axée sur les relations et à plus long terme, que tout ce niveau a bâtie — précisément la discipline que les dernières leçons de ce niveau (48 et 49) rassembleront dans un cadre final et pratique.

**3. Exemple pratique**
En réfléchissant à ses propres erreurs de leadership du début, un leader reconnaît qu'il a déjà continué de s'occuper lui-même de tâches qu'il aurait dû déléguer, qu'il a évité pendant des mois une conversation difficile nécessaire et qu'il a beaucoup compté sur son titre officiel plutôt que de bâtir une vraie influence auprès de son équipe. En reliant chaque erreur à la notion précise de ce niveau qui l'aurait évitée, il s'engage à appliquer désormais le cadre rassemblé dans les dernières leçons de ce niveau, plutôt que de continuer à répéter ces schémas courants et bien connus.

**4. Quiz de pratique**
1. Selon cette leçon, d'où vient souvent le fait de « continuer de s'occuper soi-même de tâches qu'on pourrait déléguer »?
   a) De vraies contraintes de capacité, sans lien avec la confiance ou le malaise émotionnel
   b) D'obstacles de confiance ou de malaise émotionnel non réglés, en écho aux leçons 4, 20 et 40
   c) D'une absence complète de membres compétents dans l'équipe
   d) D'une délégation excessive et d'une implication personnelle insuffisante dans les tâches
2. Qu'est-ce qui cause souvent le fait de compter entièrement sur l'autorité officielle sans bâtir une vraie influence?
   a) Une vraie influence se bâtit toujours automatiquement en même temps que l'autorité officielle
   b) La supposition qu'un titre suffit à produire l'engagement que génèrent en réalité la confiance et la relation
   c) L'autorité officielle n'a aucun lien avec une vraie influence
   d) Bâtir de l'influence n'exige aucun effort volontaire
3. Vrai ou faux : Cette leçon présente des notions entièrement nouvelles, sans lien avec le reste de BLACK-L2.
4. Quel schéma plus large explique la plupart des erreurs courantes abordées dans cette leçon?
   a) Une discipline volontaire, axée sur les relations et à plus long terme
   b) Privilégier le confort, le contrôle ou l'efficacité apparente à court terme au détriment d'une discipline volontaire, axée sur les relations et à plus long terme
   c) Une prudence excessive et un refus de prendre toute mesure de leadership
   d) Une application parfaite de chaque cadre abordé dans ce niveau

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Continuer de s'occuper soi-même de tâches qu'on pourrait déléguer vient souvent d'obstacles de confiance ou de malaise émotionnel non réglés, en écho aux leçons 4, 20 et 40.
2. Compter entièrement sur l'autorité officielle vient souvent de la supposition qu'un titre suffit à produire un vrai engagement, plutôt que la confiance et la relation.
3. Cette leçon relie volontairement des notions déjà vues tout au long de BLACK-L2, ce qui renforce la structure du niveau.
4. La plupart des erreurs viennent du fait de privilégier le confort, le contrôle ou l'efficacité apparente à court terme au détriment d'une discipline volontaire à plus long terme.

**7. Points clés à retenir**
- Les erreurs de leadership courantes comprennent continuer de s'occuper soi-même de tâches qu'on pourrait déléguer, éviter les conversations difficiles et compter sur l'autorité plutôt que sur l'influence.
- Chaque erreur se rattache à une notion précise déjà vue plus tôt dans ce niveau.
- Cette leçon fait écho aux leçons sur les erreurs de chaque autre couleur, ce qui renforce une structure constante dans tout le programme.
- La plupart des erreurs ont une cause commune : privilégier le confort ou le contrôle à court terme au détriment d'une discipline volontaire axée sur les relations.
