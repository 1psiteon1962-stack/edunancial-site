---
id: BLACK-L2-048
track: BLACK
officialTrackName: "Leadership"
level: 2
lessonNumber: 48
title: "La relève et le fait de se rendre remplaçable : former des leaders qui te survivront"
summary: "Comprends pourquoi former de futurs leaders est une responsabilité de leadership en soi, et comment le faire avec la délégation, la rétroaction et un leadership situationnel."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## BLACK-L2-048
### La relève et le fait de se rendre remplaçable : former des leaders qui te survivront

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Renforcer, du point de vue du développement du leadership, la discussion sur la planification de la relève de BLUE-L2-042.
- Expliquer pourquoi former de futurs leaders est en soi une responsabilité de leadership.
- Appliquer cette notion à une situation hypothétique de développement du leadership.

**2. Contenu principal**
En revenant sur la discussion sur la planification de la relève de BLUE-L2-042, cette leçon examine la responsabilité précise d'un leader de former de futurs leaders, et pas seulement de gérer les activités courantes. Un leader qui ne développe jamais volontairement la capacité de leadership des autres — en écho à la discussion sur le maintien des systèmes de la leçon 3 et à celle sur la délégation comme compétence de leadership de la leçon 4 — crée une vraie vulnérabilité pour l'organisation, puisque la capacité de leadership de celle-ci reste concentrée sur une seule personne, ce qui l'empêche de grandir ou de continuer efficacement si ce leader n'est plus disponible.

Former volontairement de futurs leaders repose généralement sur les mêmes principes que ce niveau a abordés tout au long : une vraie délégation avec une responsabilité appropriée (leçons 4 et 20), une rétroaction constructive qui soutient la croissance (leçons 12 et 13) et un ajustement du leadership situationnel (leçon 7) qui augmente peu à peu les responsabilités et l'autonomie à mesure que la compétence et la confiance du leader en devenir grandissent. Il s'agit de traiter le développement du leadership comme une pratique continue et volontaire, et non comme quelque chose qui arrive automatiquement ou qui devient une préoccupation seulement quand la relève devient soudainement urgente.

**3. Exemple pratique**
Reconnaissant qu'elle n'a jamais développé volontairement la capacité de leadership d'un membre de son équipe, et qu'elle compte entièrement sur sa propre présence de leader, une leader commence à repérer et à former intentionnellement de futurs leaders potentiels dans son équipe : elle leur délègue de vraies responsabilités de leadership avec une responsabilité appropriée (leçons 4 et 20), leur donne une rétroaction constructive qui soutient leur croissance (leçons 12 et 13) et augmente peu à peu leur autonomie à mesure que leur compétence et leur confiance se développent (en écho au leadership situationnel de la leçon 7). Elle reconnaît que c'est ce développement volontaire, et non une course de dernière minute quand la relève devient urgente, qui permettra vraiment à son organisation de lui survivre comme leader.

**4. Quiz de pratique**
1. Sur quoi cette leçon revient-elle à partir de BLUE-L2-042?
   a) Une notion sans aucun lien avec le développement du leadership
   b) La discussion sur la planification de la relève, examinée cette fois du point de vue du développement du leadership
   c) Uniquement une discussion sur l'évaluation d'entreprise
   d) Uniquement une discussion sur les stratégies de sortie d'entreprise
2. Selon cette leçon, quelle vraie vulnérabilité un leader qui ne forme jamais de futurs leaders crée-t-il pour l'organisation?
   a) Aucune vulnérabilité
   b) La capacité de leadership de l'organisation reste concentrée sur une seule personne, ce qui l'empêche de grandir ou de continuer si ce leader n'est plus disponible
   c) Le développement du leadership n'a aucun lien avec la continuité de l'organisation
   d) Cette vulnérabilité existe seulement dans les très petites organisations
3. Vrai ou faux : Le développement du leadership se fait automatiquement, sans effort volontaire, et devient une préoccupation seulement quand la relève devient soudainement urgente.
4. Pourquoi la leader a-t-elle commencé à former intentionnellement de futurs leaders potentiels dans son équipe?
   a) Elle ne s'inquiétait pas de la capacité de leadership de son organisation au-delà de sa propre présence
   b) Elle a reconnu que la capacité de leadership de son organisation était concentrée sur elle, ce qui créait une vraie vulnérabilité qui exigeait un développement volontaire
   c) Le développement du leadership n'exige aucun effort volontaire ni aucune délégation
   d) Elle voulait empêcher les membres de son équipe de développer leur capacité de leadership

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Cette leçon revient sur la discussion sur la planification de la relève de BLUE-L2-042, examinée du point de vue du développement du leadership.
2. Un leader qui ne forme jamais de futurs leaders crée une vraie vulnérabilité, en concentrant la capacité de leadership de l'organisation sur une seule personne.
3. Le développement du leadership exige un effort volontaire et continu, et non une apparition automatique ou une course de dernière minute dictée par l'urgence.
4. Le développement intentionnel de la leader a réglé, avec raison, la vraie vulnérabilité qu'avait créée le fait qu'elle soit la seule leader.

**7. Points clés à retenir**
- Cette leçon revient sur la discussion sur la planification de la relève de BLUE-L2-042, du point de vue du développement du leadership.
- Un leader qui ne forme jamais de futurs leaders crée une vraie vulnérabilité pour l'organisation, en concentrant tout sur lui-même.
- Un développement volontaire s'appuie sur les principes de ce niveau : une vraie délégation, une rétroaction constructive et un ajustement situationnel.
- C'est une pratique continue et volontaire, et non quelque chose qui arrive automatiquement ou qui compte seulement quand la relève devient urgente.
