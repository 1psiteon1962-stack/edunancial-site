---
id: BLACK-L4-019
track: BLACK
officialTrackName: "Leadership & Executive Management"
level: 4
lessonNumber: 19
locale: es-Caribbean
title: "Análisis de las teorías de la motivación: por qué la motivación intrínseca dura más que los incentivos extrínsecos"
summary: "Aprenda la distinción entre motivación intrínseca y extrínseca, los factores de autonomía, maestría y propósito, por qué los incentivos extrínsecos pueden socavar la motivación intrínseca en el trabajo complejo y por qué un líder debe darle prioridad a la motivación intrínseca."
version: "1.0"
author: "Edunancial Faculty"
date: "2026-10-19"
---
Filename: BLACK-L4-019.es-Caribbean.md
Folder: BLACK/L4
Title: Análisis de las teorías de la motivación: por qué la motivación intrínseca dura más que los incentivos extrínsecos
Lesson ID: BLACK-L4-019
Author: Waldemar M. Caban, JD MA
Meta Description: Aprenda la distinción entre motivación intrínseca y extrínseca, los factores de autonomía, maestría y propósito, por qué los incentivos extrínsecos pueden socavar la motivación intrínseca en el trabajo complejo y por qué un líder debe darle prioridad a la motivación intrínseca.
SEO Keywords: motivación intrínseca, motivación extrínseca, autonomía, maestría y propósito, sostenibilidad de la motivación
Slug: motivation-theory-analysis-why-intrinsic-motivation-outlasts-extrinsic-incentives

# Análisis de las teorías de la motivación: por qué la motivación intrínseca dura más que los incentivos extrínsecos

## Escenario inicial
SUPUESTO/OPINIÓN (escenario hipotético solo con fines educativos): Imagine una crisis de salud pública generalizada que paraliza el transporte marítimo y la manufactura a nivel mundial durante un período prolongado, enredando a la vez las cadenas de suministro de muchas industrias. Mientras una disrupción generalizada elimina muchas de las estructuras externas y de la supervisión directa que antes reforzaban la motivación extrínseca, los líderes descubren que los miembros del equipo verdaderamente comprometidos de forma intrínseca con su trabajo siguen desempeñándose con eficacia, mientras que los miembros del equipo motivados principalmente por una recompensa externa o por la supervisión muestran un compromiso sostenido considerablemente más débil.

## Objetivos de aprendizaje
- Explicar la distinción entre la motivación intrínseca (un compromiso interno genuino con el trabajo en sí) y la motivación extrínseca (una motivación impulsada por recompensas o consecuencias externas).
- Explicar los factores que se citan comúnmente — autonomía, maestría y propósito — y que, según la investigación, fomentan una motivación intrínseca genuina.
- Explicar por qué los incentivos extrínsecos, aunque verdaderamente útiles para ciertos tipos de tareas sencillas y repetitivas, a veces pueden en realidad socavar la motivación intrínseca en un trabajo más complejo y creativo.
- Explicar por qué un líder que busca un compromiso sostenido y de alta calidad, sobre todo en un trabajo complejo o creativo, por lo general debe darle prioridad a fomentar la motivación intrínseca en lugar de depender principalmente de los incentivos extrínsecos por sí solos.

## Contenido principal
DATO VERIFICADO: la motivación intrínseca se refiere a un compromiso interno genuino con el trabajo en sí — hacer una actividad porque uno la encuentra de verdad interesante, significativa o satisfactoria por sí misma — mientras que la motivación extrínseca se refiere a una motivación impulsada principalmente por una recompensa o una consecuencia externa (la compensación, un bono específico o el miedo a una consecuencia negativa por un bajo desempeño) y no por un compromiso interno genuino con las cualidades propias del trabajo.

Este es el porqué de que la autonomía, la maestría y el propósito se citen comúnmente como factores que, según la investigación, fomentan una motivación intrínseca genuina: OPINIÓN y marco motivacional ampliamente citado en la investigación sobre psicología organizativa, la autonomía (tener un control genuino sobre cómo se hace realmente el propio trabajo, en eco con la discusión de la Lección 6 de este nivel sobre la delegación por resultados), la maestría (la oportunidad genuina de desarrollar y demostrar una destreza y una competencia crecientes con el tiempo) y el propósito (una conexión genuina y sentida entre el propio trabajo específico y alguna meta más amplia y significativa) se identifican comúnmente como los factores específicos que fomentan una motivación intrínseca genuina, de modo que un líder que busca específicamente fomentar este tipo de compromiso interno genuino debe prestar atención a si los miembros de su propio equipo viven de verdad estos tres factores específicos en su trabajo diario real.

Por eso los incentivos extrínsecos, aunque verdaderamente útiles para ciertos tipos de tareas sencillas y repetitivas, a veces pueden en realidad socavar la motivación intrínseca en un trabajo más complejo y creativo: OPINIÓN y hallazgo verdaderamente debatido, aunque ampliamente discutido, en la investigación sobre la motivación, algunas investigaciones han sugerido que introducir una recompensa extrínseca fuerte por una tarea que una persona ya estaba verdaderamente motivada de forma intrínseca a hacer puede, en ciertas circunstancias, en realidad reducir la motivación intrínseca posterior de esa persona por la tarea, ya que la recompensa externa introducida puede desplazar la razón percibida de la persona para hacer la actividad, del interés interno genuino hacia la propia recompensa externa — esta preocupación específica por lo general se considera más relevante para un trabajo complejo y creativo que se beneficia de verdad de un compromiso interno profundo que para tareas sencillas y repetitivas, para las cuales los incentivos extrínsecos por lo general siguen siendo verdaderamente útiles y eficaces sin este mismo riesgo específico de socavamiento. Por eso un líder que busca un compromiso sostenido y de alta calidad, sobre todo en un trabajo complejo o creativo, por lo general debe darle prioridad a fomentar la motivación intrínseca en lugar de depender principalmente de los incentivos extrínsecos por sí solos: como la motivación intrínseca tiende a producir un compromiso más sostenido y de mayor calidad con el tiempo, sobre todo una vez que la supervisión directa o un incentivo extrínseco específico ya no está presente de inmediato ni lo refuerza, un líder que de verdad busca un desempeño duradero y de alta calidad en un trabajo complejo o creativo por lo general debe invertir una atención deliberada en fomentar una autonomía genuina, oportunidades de maestría y un propósito sentido, en lugar de depender principalmente de los incentivos extrínsecos por sí solos, que, según la discusión anterior de esta lección, podrían resultar considerablemente menos duraderos e, incluso, en ciertas circunstancias específicas, contraproducentes para este tipo particular de trabajo.

## Ejemplo práctico
EJEMPLO ILUSTRATIVO: Mientras una disrupción generalizada elimina gran parte de la estructura de supervisión directa bajo la que antes funcionaba un equipo, los miembros del equipo que habían vivido de verdad una autonomía significativa, oportunidades para desarrollar sus destrezas y una conexión sentida entre su trabajo y un propósito más amplio siguen desempeñándose a un nivel alto, verdaderamente comprometidos de forma intrínseca con su trabajo a pesar de una supervisión directa reducida. Otro equipo, cuyo compromiso había dependido principalmente de una supervisión cercana y de incentivos extrínsecos específicos, ahora considerablemente más difíciles de reforzar en las condiciones de la disrupción, muestra un desempeño sostenido considerablemente más débil. Esto ilustra precisamente por qué la motivación intrínseca, fomentada mediante la autonomía, la maestría y el propósito, tiende a producir un compromiso más duradero que los incentivos extrínsecos por sí solos, sobre todo una vez que la supervisión cercana se vuelve verdaderamente impráctica.

## Prueba práctica
**Q1. ¿Cuál es la distinción entre la motivación intrínseca y la extrínseca?**
A) Estas dos formas de motivación son idénticas, sin distinción significativa entre ellas
B) La motivación intrínseca es un compromiso interno genuino con el trabajo en sí, mientras que la motivación extrínseca está impulsada principalmente por una recompensa o una consecuencia externa y no por un compromiso interno genuino
C) La motivación extrínseca siempre está impulsada por un compromiso interno genuino con el trabajo en sí
D) La motivación intrínseca siempre requiere una recompensa o una consecuencia externa para funcionar realmente

**Q2. ¿Qué tres factores cita comúnmente la investigación como los que fomentan una motivación intrínseca genuina?**
A) Solo la compensación y el título del puesto, sin ningún otro factor relevante
B) La autonomía (control sobre cómo se hace el trabajo), la maestría (oportunidad de desarrollar una destreza creciente) y el propósito (una conexión sentida con una meta más amplia y significativa)
C) Solo una supervisión directa cercana y un seguimiento estricto del desempeño
D) La motivación intrínseca no tiene factores específicos identificables que la fomenten

**Q3. ¿Por qué los incentivos extrínsecos a veces pueden en realidad socavar la motivación intrínseca en un trabajo complejo y creativo?**
A) Los incentivos extrínsecos siempre fortalecen, y nunca socavan, la motivación intrínseca sin importar el tipo de trabajo de que se trate
B) Introducir una recompensa extrínseca fuerte por una tarea que una persona ya estaba motivada de forma intrínseca a hacer puede, según algunas investigaciones, desplazar la razón percibida de la persona para hacerla, del interés interno genuino hacia la propia recompensa externa, una preocupación más relevante para un trabajo complejo y creativo

**Q4. ¿Por qué un líder que busca un compromiso sostenido y de alta calidad en un trabajo complejo por lo general debe darle prioridad a fomentar la motivación intrínseca?**
A) Los incentivos extrínsecos por sí solos siempre producen un compromiso más sostenido y duradero que fomentar la motivación intrínseca, sin importar el tipo de trabajo de que se trate
B) La motivación intrínseca tiende a producir un compromiso más sostenido y de mayor calidad con el tiempo, sobre todo una vez que la supervisión directa o un incentivo extrínseco específico ya no está presente de inmediato, de modo que fomentar la autonomía, la maestría y el propósito por lo general produce resultados más duraderos en un trabajo complejo o creativo

**Q5. En el ejemplo, ¿por qué el primer equipo siguió desempeñándose a un nivel alto a pesar de una supervisión directa reducida, a diferencia del segundo equipo?**
A) Ambos equipos en realidad se desempeñaron con una eficacia idéntica, sin importar el efecto de la disrupción en las estructuras de supervisión e incentivos
B) El primer equipo había vivido de verdad la autonomía, las oportunidades de maestría y un propósito sentido, lo que fomentó una motivación intrínseca genuina que persistió a pesar de una supervisión reducida, mientras que el compromiso del segundo equipo había dependido principalmente de una supervisión cercana y de incentivos extrínsecos que se volvieron más difíciles de reforzar en las condiciones de la disrupción

## Clave de respuestas
Q1: B
Q2: B
Q3: B
Q4: B
Q5: B

## Respuestas y explicaciones
**Q1.** Esta distinción entre un compromiso interno genuino y una búsqueda de recompensas impulsada desde afuera es precisamente lo que separa la motivación intrínseca de la extrínseca.
**Q2.** Estos tres factores — autonomía, maestría y propósito — son precisamente lo que este marco motivacional citado comúnmente identifica como los que fomentan una motivación intrínseca genuina.
**Q3.** Este desplazamiento de la motivación percibida, del interés interno genuino hacia la recompensa externa, es precisamente el mecanismo que, según algunas investigaciones, puede socavar la motivación intrínseca específicamente en un trabajo complejo y creativo.
**Q4.** Esta mayor durabilidad de la motivación intrínseca, sobre todo cuando faltan la supervisión directa continua o el refuerzo de los incentivos, es precisamente la razón por la que se anima a los líderes a darle prioridad a fomentarla en un trabajo complejo y creativo.
**Q5.** Este contraste directo entre un compromiso duradero motivado de forma intrínseca y un compromiso dependiente de la supervisión y motivado de forma extrínseca demuestra precisamente por qué esta lección destaca la importancia de fomentar la motivación intrínseca para un desempeño sostenido.

## Puntos clave
- La motivación intrínseca es un compromiso interno genuino con el trabajo en sí, mientras que la motivación extrínseca está impulsada por una recompensa o una consecuencia externa.
- La autonomía, la maestría y el propósito son factores citados comúnmente que fomentan una motivación intrínseca genuina.
- Los incentivos extrínsecos a veces pueden socavar la motivación intrínseca en un trabajo complejo y creativo al desplazar la motivación percibida hacia la propia recompensa externa.
- Los líderes que buscan un compromiso sostenido y de alta calidad en un trabajo complejo por lo general deben darle prioridad a fomentar la motivación intrínseca, ya que tiende a persistir de forma más duradera que los incentivos extrínsecos por sí solos.
