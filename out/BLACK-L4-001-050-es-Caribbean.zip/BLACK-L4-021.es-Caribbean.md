---
id: BLACK-L4-021
track: BLACK
officialTrackName: "Leadership & Executive Management"
level: 4
lessonNumber: 21
locale: es-Caribbean
title: "Análisis de la estructura organizacional: por qué la estructura debe seguir a la estrategia, y no al revés"
summary: "Aprenda por qué la estructura debe diseñarse para apoyar la estrategia escogida, por qué la estructura existente crea inercia, por qué cambiar de estrategia sin revisar la estructura perjudica la ejecución y por qué una reestructuración debe estar justificada."
version: "1.0"
author: "Edunancial Faculty"
date: "2026-10-19"
---
Filename: BLACK-L4-021.es-Caribbean.md
Folder: BLACK/L4
Title: Análisis de la estructura organizacional: por qué la estructura debe seguir a la estrategia, y no al revés
Lesson ID: BLACK-L4-021
Author: Waldemar M. Caban, JD MA
Meta Description: Aprenda por qué la estructura debe diseñarse para apoyar la estrategia escogida, por qué la estructura existente crea inercia, por qué cambiar de estrategia sin revisar la estructura perjudica la ejecución y por qué una reestructuración debe estar justificada.
SEO Keywords: estructura organizacional, la estructura sigue a la estrategia, inercia estructural, diseño estructural deliberado
Slug: organizational-structure-analysis-why-structure-should-follow-strategy-not-the-reverse

# Análisis de la estructura organizacional: por qué la estructura debe seguir a la estrategia, y no al revés

## Escenario inicial
SUPUESTO/OPINIÓN (escenario hipotético solo con fines educativos): Imagine dos grandes potencias económicas que intensifican los controles de exportación entre sí sobre una categoría de componentes tecnológicos avanzados que se usan en muchas industrias. Mientras dos grandes potencias económicas intensifican las restricciones tecnológicas, lo que obliga a muchas empresas a reconsiderar su dirección estratégica, las organizaciones cuya estructura existente nunca se diseñó pensando en esta nueva dirección descubren que esa estructura limita silenciosamente lo que la organización puede lograr en realidad, sin importar lo que la gerencia de verdad prefiera perseguir.

## Objetivos de aprendizaje
- Explicar el principio de que la estructura organizacional debe diseñarse deliberadamente para apoyar una estrategia escogida, en lugar de que la estrategia quede determinada implícitamente por lo que la estructura existente haga conveniente.
- Explicar por qué la estructura existente de una organización puede crear una inercia real que inclina silenciosamente las decisiones estratégicas hacia lo que la estructura actual ya apoya bien.
- Explicar por qué cambiar de estrategia sin reconsiderar también la estructura subyacente suele producir una estrategia que la organización no está equipada estructuralmente para ejecutar con eficacia.
- Explicar por qué una reestructuración conlleva costos de transición reales, de modo que un líder debe confirmar que un cambio estructural es verdaderamente necesario para la estrategia escogida en lugar de reestructurar por reflejo.

## Contenido principal
DATO VERIFICADO: un principio fundamental del diseño organizacional sostiene que la estructura de una organización —cómo reparte las responsabilidades, agrupa a las personas en equipos o departamentos y establece las líneas de reporte— debe diseñarse deliberadamente para apoyar la estrategia específica que la organización ha decidido de verdad perseguir, en lugar de que sus decisiones estratégicas reales queden determinadas o limitadas implícitamente por lo que su estructura existente haga conveniente o familiar.

Este es el «porqué» de que la estructura existente de una organización pueda crear una inercia real que inclina silenciosamente las decisiones estratégicas hacia lo que la estructura actual ya apoya bien: la estructura existente de una organización por lo general se diseñó, en algún momento anterior, para apoyar una dirección estratégica anterior específica, de modo que esa estructura hace naturalmente que ciertos tipos de decisiones estratégicas sean considerablemente más fáciles de ejecutar (porque ya las apoya) y que otras decisiones verdaderamente distintas sean considerablemente más difíciles (porque nunca se diseñó para apoyarlas), y esta diferencia de facilidad puede inclinar silenciosamente a la gerencia a seguir persiguiendo la dirección que la estructura existente ya apoya bien, aun cuando una dirección verdaderamente distinta podría ser más apropiada dadas las circunstancias reales y actuales de la organización.

Por eso cambiar de estrategia sin reconsiderar también la estructura subyacente suele producir una estrategia que la organización no está equipada estructuralmente para ejecutar con eficacia: un equipo gerencial que decide perseguir una dirección estratégica verdaderamente nueva, sin reconsiderar deliberadamente si la estructura existente de verdad apoya esa nueva dirección, con frecuencia descubre que la estructura existente crea fricción e ineficiencia reales al ejecutar la nueva estrategia, ya que las líneas de reporte, las agrupaciones de equipos y las asignaciones de recursos existentes nunca se diseñaron pensando en esta nueva dirección; precisamente por eso un cambio estratégico sólido por lo general requiere reconsiderar deliberadamente también la estructura organizacional subyacente, en lugar de suponer que una estructura existente, sin importar para qué se diseñó originalmente, acomodará adecuadamente cualquier dirección verdaderamente nueva que la organización decida perseguir después. Por eso una reestructuración conlleva costos de transición reales, de modo que un líder debe confirmar que un cambio estructural es verdaderamente necesario para la estrategia escogida en lugar de reestructurar por reflejo: OPINIÓN y consideración de equilibrio importante, reorganizar una estructura existente por lo general conlleva costos de transición reales —relaciones de trabajo alteradas, un período de ajuste real y el costo directo del propio proceso de reorganización—, de modo que un líder debe confirmar específicamente que existe un desajuste estructural real con la estrategia escogida y que este justifica esos costos reales, en lugar de reestructurar por reflejo o por razones ajenas al verdadero ajuste estratégico, ya que la reestructuración no es gratuita y debe justificarse deliberadamente por una necesidad estratégica real e identificada, en lugar de convertirse en la respuesta rutinaria y por defecto ante cualquier reto organizacional.

## Ejemplo práctico
EJEMPLO ILUSTRATIVO: Una empresa, en respuesta a la intensificación de las restricciones tecnológicas, decide perseguir una dirección estratégica verdaderamente nueva centrada en la colaboración rápida e interfuncional entre equipos que antes operaban en departamentos mayormente separados y aislados bajo su estructura existente. Al reconocer que esta estructura departamental, diseñada originalmente para apoyar una estrategia anterior distinta y más secuencial, crearía fricción real para la nueva dirección más colaborativa, la empresa se reorganiza deliberadamente en equipos interfuncionales diseñados específicamente para apoyar la nueva estrategia, en lugar de intentar ejecutar la nueva estrategia mediante su organización departamental existente, estructuralmente desajustada; esto ilustra precisamente por qué la estructura debe diseñarse deliberadamente para apoyar una estrategia escogida, en lugar de que la estrategia quede limitada implícitamente por lo que la estructura existente haga conveniente.

## Prueba práctica
**Q1. ¿Qué principio fundamental sostiene el diseño organizacional sobre la relación entre estructura y estrategia?**
A) La estructura existente de una organización siempre debe determinar su estrategia, y no al revés
B) La estructura de una organización debe diseñarse deliberadamente para apoyar la estrategia específica que la organización ha decidido de verdad perseguir, en lugar de que las decisiones estratégicas queden determinadas implícitamente por lo que la estructura existente haga conveniente

**Q2. ¿Por qué la estructura existente de una organización puede crear una inercia real que inclina las decisiones estratégicas?**
A) La estructura existente de una organización no tiene relación real con qué decisiones estratégicas resultan más fáciles o más difíciles de ejecutar
B) Una estructura existente por lo general se diseñó para apoyar una dirección estratégica anterior, lo que hace ciertas decisiones considerablemente más fáciles de ejecutar y otras verdaderamente distintas más difíciles, inclinando silenciosamente a la gerencia a continuar la dirección que la estructura existente ya apoya bien

**Q3. ¿Por qué cambiar de estrategia sin reconsiderar la estructura subyacente suele producir una estrategia mal ejecutada?**
A) Una estructura organizacional existente siempre se adapta automáticamente para apoyar cualquier nueva dirección estratégica que escoja la gerencia
B) Un equipo gerencial que persigue una nueva estrategia sin reconsiderar si la estructura existente de verdad la apoya con frecuencia descubre fricción e ineficiencia reales, ya que las líneas de reporte y las asignaciones de recursos existentes nunca se diseñaron pensando en la nueva dirección

**Q4. ¿Por qué un líder debe confirmar que existe un desajuste estructural real antes de reestructurar, en lugar de reestructurar por reflejo?**
A) La reestructuración siempre es gratuita y debe ser la respuesta refleja por defecto ante cualquier reto organizacional
B) Reorganizar conlleva costos de transición reales —relaciones alteradas, un período de ajuste y costos directos de reorganización—, de modo que un líder debe confirmar que un desajuste estructural real con la estrategia escogida justifica esos costos, en lugar de reestructurar sin esa justificación específica

**Q5. En el ejemplo, ¿por qué la empresa se reorganizó deliberadamente en equipos interfuncionales en lugar de intentar ejecutar su nueva estrategia mediante la estructura departamental existente?**
A) La estructura departamental existente de la empresa en realidad ya estaba bien adaptada para apoyar la nueva dirección más colaborativa
B) La empresa reconoció que su estructura departamental existente y aislada, diseñada para una estrategia anterior más secuencial, crearía fricción real para su nueva dirección más colaborativa, lo que justificaba la reorganización estructural deliberada

## Clave de respuestas
Q1: B
Q2: B
Q3: B
Q4: B
Q5: B

## Respuestas y explicaciones
**Q1.** Este principio de que la estructura debe diseñarse deliberadamente para servir a la estrategia escogida, y no al revés, es precisamente el principio fundamental de diseño organizacional que describe esta lección.
**Q2.** Esta diferencia en la facilidad de ejecución, que inclina las decisiones hacia lo que la estructura existente ya apoya, es precisamente la forma en que la estructura organizacional puede crear este tipo de inercia estratégica real.
**Q3.** Esta fricción real causada por una estructura desajustada y no reconsiderada es precisamente la razón por la que un cambio estratégico por lo general requiere reconsiderar deliberadamente también la estructura organizacional subyacente.
**Q4.** Este reconocimiento de costos de transición reales, que requieren una justificación deliberada antes de reestructurar, es precisamente la razón por la que esta lección advierte contra la reestructuración refleja e injustificada.
**Q5.** Esta ilustración directa de reconsiderar deliberadamente la estructura para apoyar de verdad una nueva estrategia escogida ejemplifica precisamente el principio que describe esta lección: la estructura sigue a la estrategia.

## Puntos clave
- La estructura organizacional debe diseñarse deliberadamente para apoyar una estrategia escogida, en lugar de que la estrategia quede limitada implícitamente por la estructura existente.
- La estructura existente de una organización puede crear una inercia real que inclina las decisiones estratégicas hacia lo que la estructura actual ya apoya bien.
- Cambiar de estrategia sin reconsiderar la estructura suele producir fricción real, ya que la estructura existente nunca se diseñó para apoyar la nueva dirección.
- La reestructuración conlleva costos de transición reales, de modo que un líder debe confirmar que un desajuste estructural real justifica esos costos en lugar de reestructurar por reflejo.
