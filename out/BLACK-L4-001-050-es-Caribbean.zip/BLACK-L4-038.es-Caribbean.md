---
id: BLACK-L4-038
track: BLACK
officialTrackName: "Leadership & Executive Management"
level: 4
lessonNumber: 38
locale: es-Caribbean
title: "Análisis de la creación de coaliciones: por qué el cambio organizacional requiere un compromiso genuino y no solo autoridad"
summary: "Aprenda por qué un cambio significativo requiere una coalición de partidarios comprometidos, por qué los campeones del cambio influyen en sus pares mejor que la gerencia, por qué involucrar a las personas influyentes más allá de los puestos altos y por qué construir una coalición toma tiempo."
version: "1.0"
author: "Edunancial Faculty"
date: "2026-10-19"
---
Filename: BLACK-L4-038.es-Caribbean.md
Folder: BLACK/L4
Title: Análisis de la creación de coaliciones: por qué el cambio organizacional requiere un compromiso genuino y no solo autoridad
Lesson ID: BLACK-L4-038
Author: Waldemar M. Caban, JD MA
Meta Description: Aprenda por qué un cambio significativo requiere una coalición de partidarios comprometidos, por qué los campeones del cambio influyen en sus pares mejor que la gerencia, por qué involucrar a las personas influyentes más allá de los puestos altos y por qué construir una coalición toma tiempo.
SEO Keywords: creación de coaliciones, compromiso genuino, red de campeones del cambio, autoridad frente a persuasión
Slug: coalition-building-analysis-why-organizational-change-requires-genuine-buy-in-not-authority-alone

# Análisis de la creación de coaliciones: por qué el cambio organizacional requiere un compromiso genuino y no solo autoridad

## Escenario inicial
SUPUESTO/OPINIÓN (escenario hipotético solo con fines educativos): Imagine una perturbación de salud pública generalizada que detiene el transporte marítimo y la manufactura a nivel mundial durante un período prolongado, lo que enreda las cadenas de suministro de muchas industrias a la vez. Mientras una perturbación generalizada obliga a las organizaciones a implementar con rapidez cambios significativos, y a veces difíciles, los líderes que dependen solo de su propia autoridad formal del puesto para imponer estos cambios encuentran una adopción real considerablemente más débil que los líderes que construyen deliberadamente una coalición genuina de partidarios comprometidos en toda la organización.

## Objetivos de aprendizaje
- Explicar por qué implementar con éxito un cambio organizacional significativo por lo general requiere construir deliberadamente una coalición genuina de partidarios comprometidos, en conexión directa con la discusión de la Lección 9 de este nivel sobre la gestión del cambio y la de la Lección 18 sobre la autoridad ganada.
- Explicar por qué los primeros partidarios dentro de una coalición, a veces llamados campeones del cambio, pueden influir en sus propios pares de forma considerablemente más eficaz que la sola comunicación directa, de arriba hacia abajo, del líder.
- Explicar por qué identificar e involucrar deliberadamente a las personas influyentes en toda la organización, y no solo a quienes ocupan puestos formales altos, importa para construir una coalición verdaderamente eficaz.
- Explicar por qué la creación de coaliciones toma un tiempo real y no puede simplemente comprimirse en un solo anuncio o una sola presentación persuasiva, por convincente que sea esa presentación.

## Contenido principal
En conexión directa con la discusión de la Lección 9 de este nivel sobre la gestión del cambio y la de la Lección 18 sobre la autoridad ganada, DATO VERIFICADO, implementar con éxito un cambio organizacional significativo por lo general requiere construir deliberadamente una coalición genuina de partidarios comprometidos en toda la organización, en lugar de depender solo de la autoridad formal del puesto para simplemente imponer el cambio, ya que la Lección 9 estableció que la adopción genuina, y no el mero cumplimiento formal, es lo que de verdad determina si una iniciativa de cambio tiene éxito, y la Lección 18 estableció que la autoridad del puesto por sí sola tiende a producir un cumplimiento limitado y dependiente de la supervisión, en lugar del compromiso genuino y voluntario que un esfuerzo de cambio exitoso de verdad requiere de las personas que deben adoptarlo de verdad.

Este es el «porqué» de que los primeros partidarios dentro de una coalición, a veces llamados campeones del cambio, puedan influir en sus propios pares de forma considerablemente más eficaz que la sola comunicación directa, de arriba hacia abajo, del líder: un par que ha abrazado de verdad y de forma voluntaria un cambio específico, y que puede hablar del valor práctico genuino de ese cambio desde su propia perspectiva directa y creíble de par, por lo general tiene una influencia persuasiva considerablemente mayor sobre sus propios compañeros que el mismo mensaje entregado directamente por la gerencia de la organización, ya que los pares con frecuencia confían considerablemente más en la perspectiva genuina y creíble de un compañero que en un mensaje de arriba hacia abajo de la gerencia, del que los pares pueden sospechar razonablemente que conlleva cierto grado de interés institucional en promover el cambio específico; precisamente por eso cultivar y apoyar deliberadamente una red de campeones del cambio genuinos y creíbles entre los pares en toda la organización puede acelerar de forma significativa la creación de una coalición genuina más allá de lo que podría lograr la sola comunicación directa de la gerencia.

Por eso identificar e involucrar deliberadamente a las personas influyentes en toda la organización, y no solo a quienes ocupan puestos formales altos, importa para construir una coalición verdaderamente eficaz: haciendo eco de la discusión de la Lección 18 de este nivel sobre la autoridad ganada que persiste independientemente de la autoridad formal del puesto, una organización con frecuencia tiene personas con una influencia genuina considerable sobre sus pares a pesar de no ocupar ningún puesto formal particularmente alto, de modo que un líder que construye una coalición genuina para el cambio debe identificar específicamente e involucrar deliberadamente a estas personas verdaderamente influyentes, sin importar su puesto formal, en lugar de suponer que involucrar solo a quienes tienen títulos formales altos basta para construir el tipo de coalición genuina y amplia que de verdad requiere un cambio organizacional significativo. Por eso la creación de coaliciones toma un tiempo real y no puede simplemente comprimirse en un solo anuncio: como la creación de una coalición genuina requiere fundamentalmente construir confianza genuina y persuasión genuina entre las personas reales cuyo compromiso voluntario requiere el esfuerzo de cambio, en lugar de simplemente informarles una decisión que ya se tomó, este proceso requiere de forma inherente un tiempo genuino para construir relaciones reales, sostener un diálogo genuino y permitir el tipo de influencia gradual y creíble entre pares que describió la discusión anterior de esta lección, de modo que un líder que intenta comprimir la creación de una coalición genuina en un solo anuncio o una sola presentación persuasiva, por verdaderamente convincente que sea esa presentación específica, por lo general subestima el tiempo genuino que este proceso de verdad requiere para construir el tipo de compromiso amplio y voluntario del que de verdad depende un cambio organizacional exitoso.

## Ejemplo práctico
EJEMPLO ILUSTRATIVO: Una líder que implementa un cambio organizacional significativo identifica deliberadamente a varias personas verdaderamente influyentes en toda la organización, incluidas algunas sin títulos formales particularmente altos, e invierte un tiempo genuino en construir comprensión y apoyo auténticos en este grupo antes de anunciar el cambio de forma amplia. Estos primeros partidarios, convencidos de verdad del valor práctico del cambio desde su propia perspectiva creíble de pares, ayudan luego a persuadir a sus propios compañeros de forma considerablemente más eficaz de lo que habría logrado la sola comunicación directa, de arriba hacia abajo, de la líder, y este proceso deliberado y paciente de creación de coaliciones, aunque toma verdaderamente más tiempo que simplemente anunciar e imponer el cambio mediante la autoridad formal, produce una adopción genuina considerablemente más sólida en toda la organización.

## Prueba práctica
**Q1. ¿Por qué implementar con éxito un cambio organizacional significativo por lo general requiere construir una coalición genuina, en conexión con las Lecciones 9 y 18?**
A) La autoridad formal del puesto por sí sola siempre produce una adopción genuina suficiente para implementar con éxito un cambio organizacional significativo
B) La adopción genuina, y no el mero cumplimiento formal, es lo que de verdad determina si una iniciativa de cambio tiene éxito, y la autoridad del puesto por sí sola tiende a producir solo un cumplimiento limitado y dependiente de la supervisión, en lugar del compromiso genuino y voluntario que de verdad requiere un esfuerzo de cambio exitoso
C) La creación de coaliciones no tiene relación real con que un esfuerzo de cambio organizacional significativo tenga éxito finalmente
D) La adopción genuina del cambio organizacional siempre ocurre de forma automática, sin importar el enfoque específico de un líder

**Q2. ¿Por qué los primeros partidarios dentro de una coalición pueden influir en sus propios pares de forma más eficaz que la comunicación directa, de arriba hacia abajo, de un líder?**
A) La comunicación directa, de arriba hacia abajo, de un líder siempre es más persuasiva para los pares que la perspectiva genuina de un compañero creíble
B) Un par que ha abrazado de verdad y de forma voluntaria un cambio y puede hablar de su valor práctico genuino desde una perspectiva creíble de par por lo general tiene más influencia persuasiva sobre sus compañeros, ya que los pares pueden sospechar razonablemente que el mensaje de arriba hacia abajo de la gerencia conlleva un interés institucional
C) Los pares nunca confían en realidad más en la perspectiva de un compañero que en un mensaje entregado directamente por la gerencia de la organización
D) Los campeones del cambio no tienen ninguna influencia real en cómo sus compañeros perciben un cambio organizacional específico

**Q3. ¿Por qué construir una coalición genuina requiere identificar a personas influyentes más allá de quienes ocupan puestos formales altos, en conexión con la Lección 18?**
A) Solo las personas que ocupan puestos formales altos tienen alguna influencia genuina sobre sus pares dentro de una organización
B) Haciendo eco de la discusión anterior sobre la autoridad ganada que persiste independientemente de la autoridad formal del puesto, una organización con frecuencia tiene personas con una influencia genuina considerable sobre sus pares a pesar de no ocupar puestos formales altos, de modo que una coalición verdaderamente eficaz requiere involucrar también a estas personas
C) La autoridad formal del puesto y la influencia genuina sobre los pares siempre están perfectamente correlacionadas en cualquier organización
D) Involucrar a personas influyentes sin títulos formales altos siempre debilita, en lugar de fortalecer, una coalición genuina para el cambio

**Q4. ¿Por qué la creación de una coalición genuina toma un tiempo real y no puede comprimirse en un solo anuncio?**
A) La creación de una coalición genuina siempre puede lograrse por completo mediante un solo anuncio o una sola presentación lo suficientemente convincente
B) La creación de una coalición genuina requiere fundamentalmente construir confianza y persuasión genuinas entre las personas reales cuyo compromiso voluntario se requiere, un proceso que de forma inherente requiere un tiempo genuino para construir relaciones y permitir una influencia gradual y creíble entre pares, en lugar de simplemente informar a las personas de una decisión ya tomada
C) La cantidad específica de tiempo invertido en la creación de coaliciones no tiene relación real con el éxito con que finalmente se adopta un cambio organizacional
D) Una sola presentación lo suficientemente persuasiva siempre produce resultados idénticos a los de un proceso sostenido y paciente de creación de coaliciones

**Q5. En el ejemplo, ¿por qué el enfoque de la líder produjo una adopción genuina más sólida de la que habría logrado simplemente anunciar e imponer el cambio?**
A) La líder en realidad había anunciado el cambio solo mediante la autoridad formal, sin ningún esfuerzo deliberado de creación de coaliciones
B) La líder identificó e involucró deliberadamente a personas verdaderamente influyentes en toda la organización, invirtió un tiempo real en construir un apoyo auténtico en este grupo y permitió que estos campeones creíbles ayudaran a persuadir a sus propios compañeros, lo que produjo una adopción genuina más sólida de la que habría logrado un mandato directo de arriba hacia abajo
C) La líder dependió por completo de quienes ocupaban puestos formales altos, e ignoró a cualquier persona verdaderamente influyente sin títulos altos
D) Ambos enfoques para implementar el cambio organizacional en realidad produjeron niveles idénticos de adopción genuina

## Clave de respuestas
Q1: B
Q2: B
Q3: B
Q4: B
Q5: B

## Respuestas y explicaciones
**Q1.** Esta conexión directa con las discusiones anteriores sobre la gestión del cambio y la autoridad ganada es precisamente la razón por la que construir una coalición genuina de partidarios comprometidos importa más que la sola autoridad del puesto para un cambio organizacional exitoso.
**Q2.** Esta mayor credibilidad de la perspectiva genuina de un par, frente a un mensaje de arriba hacia abajo potencialmente interesado, es precisamente la razón por la que los campeones del cambio pueden influir en sus pares de forma más eficaz que la sola comunicación directa de la gerencia.
**Q3.** Esta conexión directa con la discusión anterior sobre la autoridad ganada, en cuanto a la influencia independiente del puesto formal, es precisamente la razón por la que la creación de coaliciones requiere identificar a personas verdaderamente influyentes más allá de los títulos formales altos.
**Q4.** Este requisito inherente de tiempo para construir confianza genuina e influencia creíble entre pares, en lugar de la mera entrega de información, es precisamente la razón por la que la creación de coaliciones no puede comprimirse en un solo anuncio.
**Q5.** Esta ilustración directa de una creación de coaliciones deliberada y paciente que produce una adopción genuina más sólida ejemplifica precisamente por qué esta lección enfatiza la construcción de un compromiso genuino por encima de depender solo de la autoridad formal.

## Puntos clave
- Implementar con éxito un cambio organizacional significativo por lo general requiere construir una coalición genuina de partidarios comprometidos, en lugar de depender solo de la autoridad formal del puesto.
- Los campeones del cambio, partidarios genuinos entre los pares, pueden influir en sus compañeros de forma más eficaz que la comunicación directa, de arriba hacia abajo, del líder.
- Construir una coalición genuina requiere identificar e involucrar a las personas influyentes en toda la organización, y no solo a quienes ocupan puestos formales altos.
- La creación de una coalición genuina toma un tiempo real y no puede comprimirse en un solo anuncio, ya que requiere construir confianza genuina e influencia creíble entre pares.
