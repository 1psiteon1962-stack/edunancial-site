---
id: BLACK-L4-044
track: BLACK
officialTrackName: "Leadership & Executive Management"
level: 4
lessonNumber: 44
locale: es-Caribbean
title: "Análisis de la asignación de recursos: por qué decirles que no a las buenas oportunidades protege a las excelentes"
summary: "Aprenda por qué rechazar buenas oportunidades protege los recursos de las prioridades más importantes, por qué es psicológicamente difícil, por qué perseguir demasiadas oportunidades da resultados mediocres y por qué evaluar cada oportunidad frente a las prioridades actuales."
version: "1.0"
author: "Edunancial Faculty"
date: "2026-10-19"
---
Filename: BLACK-L4-044.es-Caribbean.md
Folder: BLACK/L4
Title: Análisis de la asignación de recursos: por qué decirles que no a las buenas oportunidades protege a las excelentes
Lesson ID: BLACK-L4-044
Author: Waldemar M. Caban, JD MA
Meta Description: Aprenda por qué rechazar buenas oportunidades protege los recursos de las prioridades más importantes, por qué es psicológicamente difícil, por qué perseguir demasiadas oportunidades da resultados mediocres y por qué evaluar cada oportunidad frente a las prioridades actuales.
SEO Keywords: asignación de recursos, disciplina del costo de oportunidad, decir que no de forma estratégica, protección de las prioridades
Slug: resource-allocation-analysis-why-saying-no-to-good-opportunities-protects-great-ones

# Análisis de la asignación de recursos: por qué decirles que no a las buenas oportunidades protege a las excelentes

## Escenario inicial
SUPUESTO/OPINIÓN (escenario hipotético solo con fines educativos): Imagine una importante región agrícola que sufre una sequía severa durante varias temporadas, lo que reduce marcadamente la oferta mundial de un producto alimentario clave. Mientras una sequía agrícola severa crea a la vez nuevas oportunidades y presiones reales, las organizaciones que mantienen la disciplina de rechazar oportunidades verdaderamente buenas, pero que no son sus prioridades verdaderamente más altas, protegen los recursos necesarios para perseguir con eficacia sus prioridades más importantes, mientras que las organizaciones que persiguen cada oportunidad que parece razonable encuentran sus recursos demasiado repartidos entre demasiadas prioridades.

## Objetivos de aprendizaje
- Explicar por qué la disposición de un líder a rechazar oportunidades verdaderamente buenas, pero no verdaderamente excelentes, es esencial para proteger los recursos finitos de una organización para sus prioridades de mayor valor, en conexión con la discusión de la Lección 32 de este nivel sobre la estrategia.
- Explicar la presión psicológica u organizacional específica que hace difícil rechazar una oportunidad verdaderamente buena, aun cuando hacerlo es en realidad la decisión estratégica acertada.
- Explicar por qué perseguir demasiadas buenas oportunidades a la vez, en lugar de concentrar los recursos en las verdaderamente mejores, tiende a producir resultados mediocres en todas en lugar de resultados excelentes en las de mayor prioridad.
- Explicar por qué un líder debe evaluar una nueva oportunidad específicamente frente a los compromisos actuales de mayor prioridad de la organización, en lugar de evaluarla de forma aislada solo por sus propios méritos aparentes.

## Contenido principal
En conexión directa con la discusión de la Lección 32 de este nivel de que una estrategia genuina requiere sacrificios explícitos, DATO VERIFICADO, la disposición de un líder a rechazar oportunidades verdaderamente buenas, pero no verdaderamente excelentes, es esencial para proteger los recursos finitos de una organización para perseguir con eficacia sus prioridades verdaderamente de mayor valor, ya que la Lección 32 estableció que una estrategia genuina requiere sacrificios explícitos sobre lo que una organización no perseguirá, y rechazar una buena oportunidad específica representa precisamente este tipo de decisión de sacrificio concreta y específica en la práctica real, lo que convierte el principio estratégico abstracto que describió la Lección 32 en una decisión real y específica de asignación de recursos.

Este es el «porqué» de que rechazar una oportunidad verdaderamente buena, aun cuando hacerlo es en realidad la decisión estratégica acertada, sea difícil: una oportunidad específica que se presenta de forma directa e inmediata por lo general tiene un atractivo genuino y tangible y un beneficio potencial específico y visible, mientras que el costo genuino de perseguir esa oportunidad específica —los recursos que desviaría de los compromisos verdaderamente de mayor prioridad de la organización— es considerablemente menos visible y tangible de inmediato, ya que este costo se manifiesta como menos recursos y menos atención para otras prioridades y no como una consecuencia negativa única, visible e inmediata, de modo que un líder enfrenta una presión psicológica genuina y comprensible a aceptar una buena oportunidad inmediatamente visible y tangible, aun cuando hacerlo de verdad resta recursos que estarían mejor asignados a las prioridades reales más altas de la organización.

Por eso perseguir demasiadas buenas oportunidades a la vez tiende a producir resultados mediocres en todas en lugar de resultados excelentes en las de mayor prioridad: los recursos reales de una organización —su capital disponible, la atención disponible de su liderazgo y su talento disponible— siguen siendo verdaderamente finitos sin importar cuántas oportunidades distintas decida perseguir a la vez, de modo que repartir estos recursos finitos entre un número mayor de oportunidades distintas, incluidas algunas buenas pero no verdaderamente de mayor prioridad, por lo general reduce los recursos realmente disponibles para los compromisos verdaderamente de mayor prioridad de la organización, lo que produce resultados mediocres en un número mayor de oportunidades perseguidas en lugar de resultados verdaderamente excelentes concentrados en sus compromisos reales de mayor prioridad. Por eso un líder debe evaluar una nueva oportunidad específicamente frente a los compromisos actuales de mayor prioridad de la organización, en lugar de evaluarla de forma aislada: OPINIÓN y principio práctico de evaluación importante, una nueva oportunidad debe evaluarse específicamente preguntando si de verdad representa un mejor uso de los recursos finitos de la organización que seguir invirtiendo plenamente en sus compromisos actuales verdaderamente de mayor prioridad, en lugar de evaluar esa nueva oportunidad de forma puramente aislada por sus propios méritos aparentes, ya que incluso una oportunidad verdaderamente buena, evaluada solo por sus propios méritos aislados, aún puede representar un peor uso de los recursos finitos de la organización que seguir dotando plenamente sus compromisos existentes verdaderamente de mayor prioridad, de modo que una buena disciplina de asignación de recursos requiere este tipo de evaluación comparativa basada en el costo de oportunidad, en lugar de una valoración aislada de los méritos aparentes de cada nueva oportunidad.

## Ejemplo práctico
EJEMPLO ILUSTRATIVO: Una organización que enfrenta varias nuevas oportunidades verdaderamente buenas creadas por los efectos de mercado de una sequía agrícola severa mantiene la disciplina de evaluar específicamente cada oportunidad frente a sus compromisos actuales de mayor prioridad, y rechaza varias oportunidades verdaderamente buenas, pero no verdaderamente de mayor prioridad, para proteger los recursos necesarios para sus prioridades principales reales. Otra organización persigue cada oportunidad que parece razonable, reparte sus recursos finitos entre un número considerablemente mayor de iniciativas y finalmente obtiene resultados mediocres en todas, en lugar de los resultados verdaderamente excelentes que logra la primera organización al concentrar sus recursos específicamente en sus propios compromisos de mayor prioridad.

## Prueba práctica
**Q1. ¿Por qué rechazar oportunidades verdaderamente buenas es esencial para proteger los recursos para las prioridades de mayor valor de una organización, en conexión con la Lección 32?**
A) Perseguir cada oportunidad verdaderamente buena que se presente siempre es la estrategia de asignación de recursos más acertada posible para cualquier organización
B) Una estrategia genuina requiere sacrificios explícitos sobre lo que una organización no perseguirá, y rechazar una buena oportunidad específica representa precisamente este tipo de decisión de sacrificio concreta que convierte el principio estratégico abstracto en una decisión real de asignación de recursos
C) La estrategia genuina no tiene relación real con que una organización rechace o persiga una buena oportunidad específica
D) Rechazar buenas oportunidades siempre socava la disciplina genuina de sacrificio estratégico de una organización

**Q2. ¿Por qué rechazar una oportunidad verdaderamente buena es difícil, aun cuando hacerlo es en realidad la decisión estratégica acertada?**
A) Rechazar una oportunidad verdaderamente buena siempre es fácil y no le exige ningún esfuerzo psicológico a ningún líder
B) Una oportunidad específica que se presenta tiene un atractivo genuino, tangible e inmediatamente visible, mientras que el costo genuino de perseguirla —los recursos desviados de compromisos de mayor prioridad— es considerablemente menos visible de inmediato, lo que crea una presión psicológica genuina a aceptar la oportunidad tangible y visible
C) El costo genuino de perseguir una buena oportunidad siempre es más visible de inmediato que el atractivo tangible de esa oportunidad
D) La presión psicológica no tiene relación real con por qué a un líder podría costarle rechazar una oportunidad verdaderamente buena

**Q3. ¿Por qué perseguir demasiadas buenas oportunidades a la vez tiende a producir resultados mediocres en todas?**
A) Los recursos realmente disponibles de una organización siempre se expanden automáticamente para acomodar cuantas oportunidades distintas decida perseguir a la vez
B) Los recursos reales de una organización siguen siendo verdaderamente finitos sin importar cuántas oportunidades persiga a la vez, de modo que repartir estos recursos finitos entre más oportunidades reduce los recursos disponibles para los compromisos de mayor prioridad, lo que produce resultados mediocres en un número mayor de oportunidades perseguidas
C) Perseguir más oportunidades a la vez siempre produce resultados proporcionalmente mejores, y no peores, en todas
D) El número de oportunidades que persigue una organización no tiene relación real con la calidad de los resultados que logra en cada una

**Q4. ¿Por qué un líder debe evaluar una nueva oportunidad frente a los compromisos actuales de mayor prioridad, en lugar de forma aislada?**
A) Una nueva oportunidad siempre debe evaluarse de forma puramente aislada, solo por sus propios méritos aparentes, sin compararla con las prioridades existentes
B) Una nueva oportunidad debe evaluarse preguntando si de verdad representa un mejor uso de los recursos finitos que seguir invirtiendo plenamente en los compromisos actuales de mayor prioridad, ya que incluso una oportunidad verdaderamente buena aún puede representar un peor uso de los recursos que dotar plenamente las prioridades principales existentes
C) La evaluación comparativa basada en el costo de oportunidad siempre produce peores decisiones de asignación de recursos que la valoración aislada de los méritos de una nueva oportunidad
D) Los compromisos actuales de mayor prioridad de una organización no tienen ninguna pertinencia real para evaluar una oportunidad verdaderamente nueva

**Q5. En el ejemplo, ¿por qué la primera organización logró resultados verdaderamente excelentes mientras que la segunda logró solo resultados mediocres en un número mayor de iniciativas?**
A) Ambas organizaciones en realidad persiguieron un número idéntico de oportunidades, con una asignación de recursos y unos resultados idénticos
B) La primera organización mantuvo la disciplina de rechazar varias oportunidades verdaderamente buenas, pero no verdaderamente de mayor prioridad, para proteger los recursos de sus prioridades principales reales, mientras que la segunda persiguió cada oportunidad que parecía razonable y repartió demasiado sus recursos finitos entre demasiadas iniciativas
C) La segunda organización en realidad había logrado resultados más excelentes al perseguir un número mayor de oportunidades a la vez
D) El enfoque de ninguna de las dos organizaciones respecto de la asignación de recursos tuvo ninguna incidencia real en la calidad de los resultados que finalmente logró cada una

## Clave de respuestas
Q1: B
Q2: B
Q3: B
Q4: B
Q5: B

## Respuestas y explicaciones
**Q1.** Esta conexión directa con la discusión anterior sobre los sacrificios estratégicos es precisamente la razón por la que rechazar oportunidades verdaderamente buenas es esencial para proteger los recursos necesarios para las prioridades verdaderamente de mayor valor de una organización.
**Q2.** Esta asimetría entre el atractivo inmediato y visible de una oportunidad y su costo genuino menos visible es precisamente la razón por la que rechazar una oportunidad verdaderamente buena resulta difícil, aun cuando la decisión estratégica acertada es en realidad rechazarla.
**Q3.** Esta finitud genuina de los recursos organizacionales, sin importar cuántas oportunidades se persigan, es precisamente la razón por la que repartir demasiado los recursos tiende a producir resultados mediocres en todas las oportunidades perseguidas en lugar de resultados excelentes en las de mayor prioridad.
**Q4.** Este enfoque de evaluación comparativa basado en el costo de oportunidad, en lugar de una valoración aislada, es precisamente la razón por la que los líderes deben evaluar las nuevas oportunidades específicamente frente a los compromisos actuales de mayor prioridad.
**Q5.** Este contraste directo entre una priorización disciplinada y la búsqueda indisciplinada de cada buena oportunidad ejemplifica precisamente por qué esta lección enfatiza decirles que no a las buenas oportunidades para proteger las oportunidades verdaderamente excelentes de la organización.

## Puntos clave
- Rechazar oportunidades verdaderamente buenas, pero no de mayor prioridad, es esencial para proteger los recursos para las prioridades verdaderamente de mayor valor de una organización, lo que convierte los sacrificios estratégicos abstractos en decisiones concretas.
- Rechazar una oportunidad verdaderamente buena es difícil, ya que su atractivo inmediato y tangible pesa más que el costo menos visible de los recursos desviados de prioridades más altas.
- Perseguir demasiadas buenas oportunidades a la vez reparte demasiado los recursos verdaderamente finitos de una organización, lo que produce resultados mediocres en todas.
- Una nueva oportunidad debe evaluarse frente a los compromisos actuales de mayor prioridad de una organización, en lugar de valorarse de forma puramente aislada por sus propios méritos aparentes.
