---
id: BLUE-L1-028
track: BLUE
officialTrackName: Business
level: 1
lessonNumber: 28
locale: fr-CA
title: "Qu’est-ce qu’une quantité minimale de commande (MOQ), et comment peut-elle bloquer une bonne idée?"
summary: "Explique ce qu’est une quantité minimale de commande et pourquoi elle peut bloquer une bonne idée d’entreprise pour des raisons de capital plutôt que de mérite."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# BLUE-L1-028 : Qu’est-ce qu’une quantité minimale de commande (MOQ), et comment peut-elle bloquer une bonne idée?

**Volet :** BLUE (Entreprise)
**Niveau :** 1 — Sensibilisation et littératie
**ID de la leçon :** BLUE-L1-028
**Auteur :** Waldemar M. Caban, JD MA
**Durée estimée :** 15 à 20 minutes
**Difficulté :** Débutant

---

## Résumé
`BLUE-L1-028-MAIN`
Une idée d’entreprise vraiment bonne peut quand même être complètement bloquée par un mur de capital qui n’a rien à voir avec la qualité de l’idée — la quantité minimale de commande. Cette leçon explique ce qu’est une MOQ et pourquoi elle compte autant pour les nouvelles entreprises qui disposent de peu de capital.

## Objectifs d’apprentissage
- Définir la quantité minimale de commande (MOQ)
- Expliquer pourquoi les fournisseurs fixent des MOQ
- Comprendre comment une MOQ peut bloquer une bonne idée pour des raisons qui n’ont rien à voir avec son mérite

## Préalables
BLUE-L1-017, BLUE-L1-027

## Durée estimée
15 à 20 minutes

## Difficulté
Débutant (niveau 1)

---

## Contenu principal

### Thème 1 : Ce qu’est une MOQ
Une quantité minimale de commande (MOQ, de l’anglais *minimum order quantity*) est la plus petite quantité de produits qu’un fournisseur ou un fabricant accepte de produire ou de vendre en une seule commande, peu importe la quantité que l’acheteur souhaite réellement.

### Thème 2 : Pourquoi les fournisseurs fixent des MOQ
[ESTIMATION] Les fournisseurs fixent habituellement des MOQ parce que les petites commandes ne sont souvent pas rentables à produire pour eux — les coûts de mise en route de la production, la taille minimale des lots de matières et les frais administratifs liés à chaque commande rendent les très petites séries disproportionnellement coûteuses par rapport au prix qu’ils pourraient demander.

### Thème 3 : Comment cela peut bloquer une bonne idée
[EXEMPLE ILLUSTRATIF] Une entrepreneure veut lancer une gamme de nourriture pour animaux sous sa propre marque, mais découvre que la MOQ du fabricant est de 5 000 unités — ce qui exige des dizaines de milliers de dollars dès le départ, bien au-delà du capital disponible, même si l’idée du produit, l’étude de marché et le plan d’affaires sont tous réellement solides.

### Thème 4 : Ce n’est pas un échec de l’idée
[OPINION] Se heurter au mur d’une MOQ est un obstacle de capital et de chaîne d’approvisionnement, et non la preuve que l’idée elle-même était mauvaise. Reconnaître cette distinction est important — renoncer à une idée bloquée par une MOQ, ou en modifier l’approche, est souvent une décision judicieuse plutôt qu’un signe d’échec.

---

## Définitions clés
- **Quantité minimale de commande (MOQ) :** La plus petite quantité de produits qu’un fournisseur ou un fabricant accepte de produire ou de vendre en une seule commande.
- **Mur de capital :** Un obstacle au lancement ou à la croissance d’une entreprise causé par le besoin de plus d’argent au départ que ce qui est disponible, indépendamment du mérite de l’idée.

## Exemples pratiques
[EXEMPLE ILLUSTRATIF] Deux entrepreneurs ont des idées de produits tout aussi solides. L’un trouve un fournisseur dont la MOQ est faible et lance son entreprise avec un capital modeste. Le fabricant choisi par l’autre exige une MOQ de 5 000 unités, ce qui crée un mur de capital qui empêche une idée de même qualité d’être lancée de la même façon.

## Erreurs courantes
- Supposer qu’une idée bloquée signifie que l’idée elle-même était mauvaise
- Ne pas se renseigner sur les MOQ avant de consacrer beaucoup de temps à un plan d’affaires
- Supposer que tous les fournisseurs ou fabricants ont des MOQ aussi élevées

## FAQ
**Q : Tous les fournisseurs ont-ils des MOQ élevées?**
R : [ESTIMATION] Non — les MOQ varient beaucoup selon l’industrie, le type de produit et le fournisseur; certaines sont assez faibles, voire négociables, surtout pour des produits moins complexes.

**Q : Que peut-on faire si une MOQ bloque une idée d’entreprise?**
R : [ESTIMATION] Les options peuvent comprendre de trouver un autre fournisseur dont la MOQ est plus faible, d’adapter le modèle d’affaires (par exemple une solution qui exige moins de capital) ou de repenser entièrement l’approche — des leçons ultérieures et des niveaux supérieurs abordent ces réorientations plus en profondeur.

## Points clés
- Une MOQ est la plus petite commande qu’un fournisseur accepte, peu importe la demande de l’acheteur
- Les fournisseurs fixent des MOQ surtout en raison de l’efficacité de leurs propres coûts de production
- Une MOQ élevée peut bloquer une idée vraiment bonne uniquement en raison des besoins en capital
- Être bloqué par une MOQ n’est pas la preuve que l’idée de départ était mauvaise

## Exercice pratique
Expliquez dans vos propres mots pourquoi se heurter au mur d’une MOQ est différent d’une idée qui n’est tout simplement « pas assez bonne ».

---

## Guide d’enseignement socratique
`BLUE-L1-028-SOCRATIC` (niveau 1 — « Quoi »)

1. **Question d’ouverture :** Une excellente idée d’entreprise pourrait-elle quand même ne pas voir le jour, même si l’idée elle-même est réellement solide?
2. **Notion 1 — Définition :** Que signifie MOQ, et qu’est-ce que cela exige?
3. **Suivi :** Qui fixe ce chiffre — l’acheteur ou le fournisseur?
4. **Notion 2 — Raison d’être :** Pourquoi les fournisseurs fixent-ils des quantités minimales de commande?
5. **Suivi :** Qu’est-ce qui rend les très petites commandes moins rentables pour les fournisseurs?
6. **Notion 3 — Bloquer une bonne idée :** Comment une MOQ élevée pourrait-elle bloquer un plan d’affaires par ailleurs solide?
7. **Suivi :** Cela signifie-t-il que le plan ou l’étude de marché étaient mauvais?
8. **Notion 4 — Recadrer le revers :** Pourquoi la leçon distingue-t-elle un « mur de capital » d’une « mauvaise idée »?
9. **Synthèse :** Quelles options existent si une idée d’entreprise se heurte au mur d’une MOQ?
10. **Réflexion :** Pourquoi est-il utile de se renseigner tôt sur les MOQ possibles, avant d’investir beaucoup dans la planification?

## Évaluation des compétences
`BLUE-L1-028-ASSESSMENT`

1. (Choix multiple) MOQ signifie : A) Quantité maximale de commande B) Quantité minimale de commande C) Quota mensuel de commandes D) Qualité propre au fabricant
2. (Choix multiple) Une MOQ est fixée par : A) L’acheteur B) Le fournisseur ou le fabricant C) Le gouvernement D) Toujours une association professionnelle
3. (Vrai ou faux) Une MOQ élevée qui bloque une idée d’entreprise signifie que l’idée elle-même était mauvaise.
4. (Réponse courte) Expliquez pourquoi les fournisseurs fixent habituellement des quantités minimales de commande.
5. (Mise en situation) L’idée de produit d’une entrepreneure est solide, mais la MOQ du fabricant exige bien plus de capital que ce dont elle dispose. Qu’est-ce qui bloque réellement cette idée?
6. (Choix multiple) Qu’est-ce qu’un « mur de capital »? A) Une stratégie de marketing B) Un obstacle causé par un capital de départ insuffisant, indépendamment de la qualité de l’idée C) Un type de prêt D) Une exigence légale
7. (Vrai ou faux) Tous les fournisseurs ont des MOQ aussi élevées, peu importe l’industrie ou le produit.
8. (Réponse courte) Nommez une option possible si une idée d’entreprise se heurte au mur d’une MOQ.
9. (Choix multiple) Quand est-il le plus utile de se renseigner sur les MOQ possibles? A) Après le lancement B) Tôt, avant d’investir beaucoup dans la planification C) Ce n’est jamais nécessaire D) Seulement après avoir obtenu du financement
10. (Réflexion) Pourquoi la leçon insiste-t-elle sur le fait que se heurter au mur d’une MOQ n’est pas un échec personnel ni un échec de l’idée?

## Corrigé
`BLUE-L1-028-ANSWER-KEY`

1. **Bonne réponse :** B. **Explication :** Énoncé directement au thème 1. **Compétence évaluée :** Rappel.
2. **Bonne réponse :** B. **Explication :** Énoncé au thème 1. **Compétence évaluée :** Rappel.
3. **Bonne réponse :** Faux. **Explication :** Le thème 4 distingue explicitement les obstacles de capital des défauts de l’idée. **Compétence évaluée :** Correction d’une idée fausse.
4. **Bonne réponse :** Les petites commandes ne sont souvent pas rentables en raison des coûts de mise en route et des frais administratifs par rapport au prix, selon le thème 2. **Compétence évaluée :** Synthèse.
5. **Bonne réponse :** Un mur de capital ou l’exigence de MOQ, et non le mérite de l’idée. **Compétence évaluée :** Raisonnement appliqué.
6. **Bonne réponse :** B. **Explication :** Défini dans les définitions clés. **Compétence évaluée :** Rappel.
7. **Bonne réponse :** Faux. **Explication :** La FAQ précise que les MOQ varient beaucoup. **Compétence évaluée :** Correction d’une idée fausse.
8. **Bonne réponse :** Au choix : trouver un fournisseur dont la MOQ est plus faible, adapter le modèle d’affaires, repenser l’approche. **Compétence évaluée :** Rappel.
9. **Bonne réponse :** B. **Explication :** Découle des erreurs courantes et de la FAQ. **Compétence évaluée :** Rappel.
10. **Bonne réponse :** Les réponses devraient mentionner que confondre un obstacle de capital avec une mauvaise idée pourrait amener quelqu’un à abandonner à tort un concept vraiment bon, au lieu de chercher un autre chemin pour contourner l’obstacle. **Compétence évaluée :** Synthèse approfondie.

## Norme de compétence
`BLUE-L1-028-COMPETENCY`

COMPÉTENCES ENSEIGNÉES : Définition de la MOQ; raison d’être des minimums fixés par les fournisseurs; distinction entre obstacles de capital et qualité de l’idée.
COMPÉTENCES MESURÉES : Rappel des définitions; raisonnement appliqué; correction d’idées fausses.
SEUIL DE MAÎTRISE MINIMAL : 80 %
TÂCHE PRATIQUE OBLIGATOIRE : Réalisation de l’exercice pratique.
SUJETS DE RATTRAPAGE : Revoir le thème 4 en cas d’erreur aux questions 3, 5 ou 10.
LEÇON SUIVANTE DÉBLOQUÉE : BLUE-L1-029
VOLETS CONNEXES : Aucun encore publié.

## Lectures complémentaires
- BLUE-L1-027 — Qu’est-ce qu’un fournisseur?
- BLUE-L1-029 — Qu’est-ce que la livraison directe (drop shipping)?

## Parcours de la leçon
`BLUE-L1-028-LOCALIZATION` (bloc de parcours)
LEÇON PRÉCÉDENTE : BLUE-L1-027
LEÇON SUIVANTE : BLUE-L1-029
PRÉALABLES OBLIGATOIRES : BLUE-L1-017, BLUE-L1-027
LEÇONS DE RÉVISION FACULTATIVES : BLUE-L1-017, BLUE-L1-027
LEÇONS DE RATTRAPAGE : BLUE-L1-017
LEÇONS CONNEXES D’AUTRES VOLETS : Aucune encore publiée
CONDITION D’ACHÈVEMENT DU NIVEAU : Terminer toutes les leçons BLUE-L1 (001 à 050) et réussir l’évaluation des compétences du niveau 1.

## Bloc SEO
`BLUE-L1-028-SEO`
Titre SEO : Qu’est-ce qu’une quantité minimale de commande (MOQ)? | Edunancial
Méta-description : Découvrez ce qu’est une MOQ, pourquoi les fournisseurs en fixent et comment un mur de capital — et non une mauvaise idée — peut bloquer un bon concept d’entreprise.
Adresse URL suggérée : /courses/business/level-1/what-is-moq
Mot-clé principal : qu’est-ce qu’une quantité minimale de commande
Mots-clés secondaires : MOQ obstacle d’entreprise, mur de capital idée d’entreprise
Liens internes suggérés : BLUE-L1-027, BLUE-L1-029
Références externes suggérées : Ressources générales sur l’approvisionnement et la fabrication pour les petites entreprises
Schéma recommandé : Schéma Course + LearningResource
Intention de recherche : Informative, niveau débutant
Possibilité d’extrait optimisé : « Qu’est-ce qu’une quantité minimale de commande (MOQ)? »
Questions pour le schéma FAQ : « Tous les fournisseurs ont-ils des MOQ élevées? »; « Que faire si une MOQ bloque mon idée? »

## Bloc de soutien IA
`BLUE-L1-028-AI`
Résumé IA : Définit la MOQ comme la plus petite commande qu’un fournisseur accepte, explique pourquoi les fournisseurs en fixent et recadre les revers liés aux MOQ comme des obstacles de capital et de chaîne d’approvisionnement plutôt que comme la preuve d’une mauvaise idée.
Notes d’enseignement IA : Cette leçon se rattache à l’étude de cas réelle du volet BLUE (entreprise de nourriture pour chiens, contraintes de capital) mentionnée dans l’orientation du programme de Waldemar — garder un cadrage cohérent avec « une décision judicieuse de renoncer, et non un échec ».

## Bloc de localisation
`BLUE-L1-028-LOCALIZATION`
État de la traduction : Version française (fr-CA) fidèle à la source anglaise.

## Bloc de références et de vérification
`BLUE-L1-028-REFERENCES`
Aucune statistique ni citation externe utilisée. La raison d’être des MOQ et les options pour y remédier portent la mention ESTIMATION.
