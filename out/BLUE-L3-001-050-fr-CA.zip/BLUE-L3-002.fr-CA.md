---
id: BLUE-L3-002
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 2
title: "Pourquoi évaluer une entreprise n'est pas la même chose qu'évaluer ses actifs"
summary: "Découvre pourquoi une entreprise vaut souvent plus (ou moins) que la somme de ses actifs physiques, et pourquoi c'est la capacité bénéficiaire qui détermine la plupart des évaluations."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-002 : Pourquoi évaluer une entreprise n'est pas la même chose qu'évaluer ses actifs

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer la différence entre la valeur des actifs et la valeur de l'entreprise (en exploitation)
- Expliquer pourquoi une entreprise rentable vaut habituellement plus que la somme de ses actifs physiques
- Expliquer pourquoi une entreprise non rentable pourrait ne valoir à peu près que la valeur de ses actifs

## Contenu principal

Il est tentant de croire que la valeur d'une entreprise est simplement la somme de ce qu'elle possède : équipement, stocks, encaisse, immeubles. On appelle ça la **valeur des actifs**, et c'est un chiffre réel et calculable — mais pour la plupart des entreprises en exploitation, ce n'est pas le principal facteur de ce qu'un acheteur paierait réellement.

Voici « pourquoi » on évalue habituellement une entreprise autrement : une entreprise rentable et en exploitation (une « entreprise en activité ») a une capacité bénéficiaire — la capacité de générer des profits continus dans l'avenir — qui a une valeur bien supérieure à ce que rapporteraient ses seuls actifs physiques s'ils étaient vendus un par un. Un acheteur achète habituellement cette capacité bénéficiaire future, et non principalement l'équipement physique.

[VERIFIED FACT] Cette relation peut aussi jouer dans l'autre sens : une entreprise qui n'est pas rentable, ou dont l'avenir est incertain, peut être évaluée près de sa seule valeur de liquidation ou de ses actifs, puisqu'un acheteur n'est pas prêt à payer beaucoup pour une capacité bénéficiaire future incertaine ou négative — dans certains cas, les actifs d'une entreprise non rentable pourraient même valoir plus s'ils étaient vendus séparément que l'entreprise comme exploitation continue.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] L'entreprise A possède 200 000 $ d'équipement et de stocks, mais génère un profit annuel solide et constant. Un acheteur pourrait raisonnablement payer beaucoup plus que 200 000 $, parce qu'il achète surtout la capacité bénéficiaire continue que l'entreprise démontre, et pas seulement les biens physiques. L'entreprise B possède les mêmes 200 000 $ d'équipement et de stocks, mais perd de l'argent sans chemin clair vers la rentabilité. [ASSUMPTION] Un acheteur de l'entreprise B pourrait n'être prêt à payer qu'à peu près la valeur des actifs de 200 000 $, voire moins une fois les dettes prises en compte, puisque l'exploitation continue ne démontre pas une capacité bénéficiaire qui justifierait de payer une prime supplémentaire.

## Quiz de pratique

1. Selon la définition de cette leçon, qu'est-ce que la valeur des actifs?
2. Pourquoi une entreprise rentable vaut-elle habituellement plus que la somme de ses actifs physiques?
3. Pourquoi une entreprise non rentable pourrait-elle être évaluée à peu près à la seule valeur de ses actifs?

## Corrigé

1. La valeur de ce qu'une entreprise possède — équipement, stocks, encaisse, immeubles — calculée indépendamment de son exploitation continue.
2. Parce qu'un acheteur achète surtout la capacité bénéficiaire future de l'entreprise, qui a une valeur supérieure à celle des actifs physiques utilisés pour la générer.
3. Parce qu'une capacité bénéficiaire future incertaine ou négative donne peu de raisons à un acheteur de payer une prime au-delà de ce que vaudraient les actifs physiques eux-mêmes.

## Réponses et explications

1. C'est la définition de base, comparée à la valeur de l'entreprise en activité.
2. C'est le « pourquoi » central qui explique la plupart des évaluations d'entreprises.
3. Ça montre la notion dans le sens inverse, en renforçant l'idée que c'est la capacité bénéficiaire — et non la propriété d'actifs — qui est habituellement le principal facteur.

## Points clés à retenir
- La valeur des actifs reflète ce qu'une entreprise possède; la valeur de l'entreprise en activité reflète sa capacité bénéficiaire comme entreprise en exploitation.
- Une entreprise rentable est habituellement évaluée bien au-delà de la valeur de ses actifs, puisque les acheteurs paient pour la capacité bénéficiaire future.
- Une entreprise non rentable ou incertaine peut être évaluée près de la seule valeur de ses actifs, voire en dessous.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel autorisé avant de prendre des décisions d'évaluation d'entreprise.
