---
id: BLUE-L3-004
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 4
title: "Pourquoi l'achat d'actifs et l'achat d'actions sont des transactions fondamentalement différentes"
summary: "Découvre la différence entre acheter les actifs d'une entreprise et acheter ses actions, et pourquoi les acheteurs et les vendeurs préfèrent souvent des structures opposées."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-004 : Pourquoi l'achat d'actifs et l'achat d'actions sont des transactions fondamentalement différentes

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer la différence structurelle entre un achat d'actifs et un achat d'actions
- Expliquer pourquoi les acheteurs préfèrent souvent un achat d'actifs
- Expliquer pourquoi les vendeurs préfèrent souvent un achat d'actions

## Contenu principal

Quand on acquiert une entreprise constituée en société par actions ou sous une forme semblable, il existe généralement deux approches structurelles : un **achat d'actifs**, où l'acheteur acquiert directement des actifs précis (et parfois des dettes précises) de l'entreprise, ou un **achat d'actions**, où l'acheteur acquiert les actions de la société elle-même et prend en charge toute l'entité — actifs, dettes, contrats et historique — telle qu'elle existe.

Voici « pourquoi » les acheteurs et les vendeurs préfèrent souvent des structures opposées : dans un achat d'actifs, l'acheteur peut habituellement choisir les actifs et les dettes précis qu'il acquiert, ce qui lui permet généralement d'éviter les dettes inconnues ou non désirées qui pourraient exister au sein de la société elle-même (des poursuites non divulguées, par exemple) — c'est une raison importante pour laquelle les acheteurs préfèrent souvent cette structure. Dans un achat d'actions, le vendeur transfère toute l'entité, y compris toutes ses dettes, connues ou inconnues, ce qui explique pourquoi les vendeurs préfèrent souvent cette structure : elle leur procure une sortie plus nette et plus complète de tous les aspects de l'entreprise, connus et inconnus.

[VERIFIED FACT] Le traitement fiscal diffère aussi souvent de façon importante entre les deux structures, pour l'acheteur comme pour le vendeur, et peut être un facteur majeur dans la structure finalement négociée — les conséquences fiscales précises dépendent de règles propres à chaque territoire et doivent être évaluées avec l'aide d'un professionnel pour toute transaction réelle.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un acheteur veut acquérir une entreprise manufacturière, mais s'inquiète de la possibilité de dettes environnementales non divulguées liées à l'historique de la société. Structurer la transaction comme un achat d'actifs lui permettrait d'acquérir précisément l'équipement, les stocks et les contrats avec les clients qu'il veut, sans hériter automatiquement des dettes inconnues liées à l'entité elle-même. Le vendeur, par contre, pourrait préférer un achat d'actions précisément pour obtenir une sortie complète et nette de l'entreprise, y compris des dettes que la structure d'achat d'actifs de l'acheteur laisserait autrement à sa charge.

## Quiz de pratique

1. Quelle est la différence structurelle entre un achat d'actifs et un achat d'actions?
2. Pourquoi les acheteurs préfèrent-ils souvent une structure d'achat d'actifs?
3. Pourquoi les vendeurs préfèrent-ils souvent une structure d'achat d'actions?

## Corrigé

1. Un achat d'actifs acquiert directement des actifs précis (et parfois des dettes); un achat d'actions acquiert la propriété de toute l'entité, y compris l'ensemble de ses actifs, de ses dettes, de ses contrats et de son historique.
2. Parce qu'elle leur permet généralement de choisir les actifs et les dettes précis qu'ils acquièrent, en évitant les dettes inconnues ou non désirées qui pourraient exister au sein de la société elle-même.
3. Parce qu'elle procure une sortie plus nette et plus complète de toute l'entreprise, y compris des dettes, au lieu de laisser des dettes non désirées à la charge du vendeur.

## Réponses et explications

1. C'est la distinction structurelle de base de la leçon.
2. Ça explique l'incitatif habituel de l'acheteur, lié au risque de responsabilité.
3. Ça explique l'incitatif habituel, opposé, du vendeur.

## Points clés à retenir
- Un achat d'actifs acquiert directement des actifs précis; un achat d'actions acquiert toute l'entité, y compris toutes ses dettes.
- Les acheteurs préfèrent souvent l'achat d'actifs pour éviter les dettes inconnues ou non désirées.
- Les vendeurs préfèrent souvent l'achat d'actions pour une sortie plus nette et plus complète, dettes comprises.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un avocat et un fiscaliste autorisés avant de structurer toute acquisition d'entreprise.
