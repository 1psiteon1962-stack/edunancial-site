---
id: BLUE-L3-005
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 5
title: "Pourquoi l'achalandage représente ce qu'on ne peut pas toucher"
summary: "Découvre ce que veut dire l'achalandage dans l'acquisition d'une entreprise, pourquoi il reflète une valeur qui n'apparaît pas dans une simple liste d'actifs, et comment on le calcule."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-005 : Pourquoi l'achalandage représente ce qu'on ne peut pas toucher

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Définir l'achalandage dans le contexte de l'acquisition d'une entreprise
- Expliquer comment on calcule généralement l'achalandage
- Nommer des exemples de ce que l'achalandage vise à refléter

## Contenu principal

La leçon 2 a distingué la valeur des actifs de la valeur globale d'une entreprise en activité, déterminée par sa capacité bénéficiaire. L'**achalandage** (ou écart d'acquisition; en anglais, *goodwill*) est la notion comptable précise qui sert à mesurer cet écart : on le calcule généralement en soustrayant du prix payé pour une entreprise la juste valeur de ses actifs nets identifiables (actifs moins dettes).

Voici « pourquoi » ce chiffre compte : l'achalandage représente la valeur de tout ce qui est intangible et contribue à la capacité bénéficiaire d'une entreprise sans être un actif précis et identifiable séparément — la réputation de la marque, les relations avec les clients, un emplacement établi, des employés formés, ou des systèmes d'exploitation qu'un concurrent aurait de la difficulté à reproduire rapidement et à faible coût. [ILLUSTRATIVE EXAMPLE] Une entreprise locale bien connue, avec une clientèle fidèle, pourrait se vendre bien au-delà de la valeur de ses actifs physiques, et cet écart serait comptabilisé comme de l'achalandage, ce qui reflète la valeur réelle, quoique intangible, de cette réputation et de cette fidélité de la clientèle.

[VERIFIED FACT] L'achalandage est comptabilisé comme un actif dans les livres de l'acheteur après l'acquisition, et son traitement fiscal et comptable (y compris la façon dont il est passé en charges au fil du temps, s'il l'est) suit des règles comptables et fiscales précises qui varient et doivent être évaluées avec l'aide d'un professionnel pour une transaction donnée.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un acheteur paie 500 000 $ pour une entreprise dont les actifs nets identifiables (équipement, stocks, encaisse, moins les dettes) sont évalués à 300 000 $. Les 200 000 $ restants du prix d'achat sont comptabilisés comme achalandage — ce qui représente la valeur que l'acheteur paie pour la réputation de l'entreprise, ses relations établies avec la clientèle et d'autres facteurs intangibles qui contribuent à sa capacité bénéficiaire, au-delà de ce que les seuls actifs physiques expliqueraient.

## Quiz de pratique

1. Qu'est-ce que l'achalandage, et comment le calcule-t-on généralement?
2. Quels types de facteurs intangibles l'achalandage vise-t-il à refléter?
3. Comment cette notion se relie-t-elle à la distinction de la leçon 2 entre la valeur des actifs et la valeur de l'entreprise en activité?

## Corrigé

1. Le prix d'achat d'une entreprise moins la juste valeur de ses actifs nets identifiables; il représente une valeur intangible qui n'est pas reflétée par un actif précis et identifiable séparément.
2. La réputation de la marque, les relations avec les clients, un emplacement établi, des employés formés, ou des systèmes d'exploitation qu'un concurrent aurait de la difficulté à reproduire rapidement.
3. L'achalandage est le chiffre comptable précis qui mesure l'écart décrit à la leçon 2 — la différence entre la valeur des actifs d'une entreprise et sa valeur plus élevée en tant qu'entreprise en activité, déterminée par sa capacité bénéficiaire.

## Réponses et explications

1. C'est la définition et le calcul de base de la leçon.
2. Ça ancre la notion abstraite dans des exemples concrets et faciles à reconnaître.
3. Ça relie explicitement la leçon à la leçon 2, ce qui renforce la structure intégrée du parcours.

## Points clés à retenir
- L'achalandage se calcule en soustrayant du prix d'achat la juste valeur des actifs nets identifiables.
- Il reflète une valeur intangible — réputation, relations avec la clientèle et facteurs semblables — qui contribue à la capacité bénéficiaire d'une entreprise.
- L'achalandage mesure précisément l'écart entre la valeur des actifs et la valeur de l'entreprise en activité présenté à la leçon 2.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un comptable autorisé avant de prendre des décisions d'évaluation ou d'acquisition d'entreprise.
