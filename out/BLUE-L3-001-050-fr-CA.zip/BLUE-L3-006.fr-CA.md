---
id: BLUE-L3-006
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 6
title: "Pourquoi une lettre d'intention n'est pas une convention d'achat qui lie les parties"
summary: "Découvre ce à quoi une lettre d'intention t'engage ou ne t'engage pas, et pourquoi la traiter comme un contrat final peut créer de la confusion ou des risques."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-006 : Pourquoi une lettre d'intention n'est pas une convention d'achat qui lie les parties

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer le but général d'une lettre d'intention dans l'acquisition d'une entreprise
- Expliquer quelles parties d'une lettre d'intention lient habituellement les parties et lesquelles ne les lient pas
- Expliquer pourquoi une lettre d'intention est une étape utile même si la plus grande partie n'est pas juridiquement exécutoire

## Contenu principal

Une **lettre d'intention** est un document qui présente les modalités préliminaires sur lesquelles les deux parties se sont entendues en principe, avant la rédaction et la signature d'une convention d'achat complète et officielle. Elle couvre habituellement le prix proposé, la structure générale de la transaction et les principales modalités que les deux parties s'attendent à inclure dans la convention finale.

Voici « pourquoi » elle compte, même si elle n'est généralement pas un engagement de vente qui lie les parties : [VERIFIED FACT] la plupart des modalités de fond d'une lettre d'intention — le prix, la structure et d'autres modalités d'affaires semblables — ne lient habituellement pas les parties, ce qui veut dire que chacune peut encore se retirer avant de signer une convention finale, alors que certaines dispositions précises (comme les obligations de confidentialité ou une période d'exclusivité convenue, pendant laquelle le vendeur s'engage à ne pas négocier avec d'autres acheteurs) sont couramment structurées pour lier les parties, même à l'intérieur d'une lettre d'intention qui, autrement, ne les lie pas.

Cette structure a un vrai but : elle permet aux deux parties de s'entendre sur les grandes modalités et de consacrer beaucoup de temps et de ressources à la vérification diligente (leçon 7) et à la rédaction d'une convention finale, sans qu'aucune des deux soit juridiquement liée à une transaction qui pourrait plus tard échouer selon ce que révélera ce processus.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un acheteur et un vendeur signent une lettre d'intention qui précise un prix convenu et la structure générale de la transaction, ainsi qu'une période d'exclusivité de 60 jours qui lie les parties, pendant laquelle le vendeur s'engage à ne pas négocier avec d'autres acheteurs potentiels. [ASSUMPTION] Pendant ces 60 jours, la vérification diligente de l'acheteur révèle un problème important, non divulgué auparavant, dans les finances de l'entreprise. Comme les modalités de fond de la lettre d'intention sur le prix et la structure ne liaient pas les parties, l'acheteur peut renégocier le prix ou se retirer complètement — alors que la clause d'exclusivité, elle, reste exécutoire et a déjà rempli son rôle en protégeant le temps investi par l'acheteur pendant la période de vérification.

## Quiz de pratique

1. Quel est le but général d'une lettre d'intention?
2. Quelles parties d'une lettre d'intention ne lient habituellement pas les parties, et lesquelles les lient couramment?
3. Pourquoi cette structure est-elle utile pour les deux parties, même si la plus grande partie de la lettre d'intention n'est pas juridiquement exécutoire?

## Corrigé

1. Présenter les modalités préliminaires sur lesquelles les deux parties se sont entendues en principe, avant de rédiger une convention d'achat complète et officielle.
2. Les modalités d'affaires de fond comme le prix et la structure de la transaction ne lient habituellement pas les parties; des dispositions comme la confidentialité et les périodes d'exclusivité sont couramment structurées pour les lier.
3. Parce qu'elle permet aux deux parties de s'entendre sur les grandes modalités et d'investir dans la vérification diligente et la rédaction du contrat sans être juridiquement liées à une transaction qui pourrait changer selon ce que révélera la vérification.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. Ça clarifie la distinction importante, à l'intérieur d'un même document, entre ce qui lie et ce qui ne lie pas les parties.
3. Ça explique la valeur pratique de la structure de la lettre d'intention, malgré son caractère en grande partie non exécutoire.

## Points clés à retenir
- Une lettre d'intention présente des modalités préliminaires convenues avant la rédaction d'une convention d'achat complète.
- Les modalités de fond comme le prix ne lient habituellement pas les parties; des dispositions précises comme la confidentialité et l'exclusivité les lient couramment.
- Cette structure permet aux deux parties d'investir dans la vérification diligente et la rédaction sans être juridiquement liées aux modalités finales de la transaction.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un avocat autorisé avant de signer toute lettre d'intention ou convention d'acquisition.
