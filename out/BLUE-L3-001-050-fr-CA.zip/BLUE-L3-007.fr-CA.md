---
id: BLUE-L3-007
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 7
title: "Pourquoi la vérification diligente existe pour trouver ce que le vendeur ne t'a pas dit"
summary: "Découvre pourquoi la vérification diligente est un processus d'enquête structuré, et pas seulement une formalité, et pourquoi elle sert à trouver des risques qui ne feraient pas surface autrement."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-007 : Pourquoi la vérification diligente existe pour trouver ce que le vendeur ne t'a pas dit

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer le but général de la vérification diligente dans l'acquisition d'une entreprise
- Nommer les grandes catégories d'information que couvre habituellement la vérification diligente
- Expliquer pourquoi la vérification diligente a lieu après la lettre d'intention, mais avant la convention d'achat finale

## Contenu principal

La **vérification diligente** est le processus structuré, qui suit la signature d'une lettre d'intention (leçon 6), pendant lequel un acheteur examine à fond les registres financiers, la situation juridique, les contrats, l'exploitation et d'autres détails pertinents d'une entreprise avant de conclure l'achat.

Voici « pourquoi » ce processus existe comme étape distincte et volontaire : un vendeur présente, et c'est compréhensible, son entreprise sous son meilleur jour pendant les premières négociations — ça ne veut pas forcément dire qu'il y a tromperie, mais les vendeurs ne sont pas obligés de révéler d'eux-mêmes chaque élément défavorable, à moins qu'on le leur demande précisément ou que la loi l'exige. La vérification diligente sert à vérifier de façon indépendante les affirmations faites pendant les négociations et à mettre activement au jour des problèmes — dettes non divulguées, litiges en cours, risque de concentration de la clientèle (une leçon plus loin) ou incohérences dans les registres financiers — qui ne feraient pas forcément surface par la seule conversation.

[VERIFIED FACT] La vérification diligente couvre couramment les registres financiers (pour vérifier les revenus et les dépenses déclarés), les questions juridiques (contrats, litiges en cours, conformité réglementaire), les détails d'exploitation (dépendance envers des employés clés, relations avec les fournisseurs) et tout autre domaine particulièrement pertinent pour l'entreprise acquise.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un acheteur qui négocie l'achat d'une entreprise se fait dire que la société a des revenus solides et stables, sans problème juridique important. Pendant la vérification diligente, un examen attentif des registres financiers révèle qu'une part importante des revenus récents provient d'un seul gros contrat avec un client, qui arrive bientôt à échéance et ne sera probablement pas renouvelé — une information qui n'avait pas été révélée d'elle-même pendant les premières conversations, mais qui touche de façon importante les vraies perspectives futures de l'entreprise. [ASSUMPTION] Ce constat, mis au jour précisément grâce au processus de vérification diligente, donne à l'acheteur une base pour renégocier le prix ou reconsidérer complètement la transaction, ce qui se relie à la discussion de la leçon 6 sur la façon dont les modalités non exécutoires d'une lettre d'intention permettent ce genre d'ajustement.

## Quiz de pratique

1. Qu'est-ce que la vérification diligente, et à quel moment a-t-elle habituellement lieu dans le processus d'acquisition?
2. Pourquoi la vérification diligente existe-t-elle comme étape distincte et volontaire, plutôt que de se fier aux déclarations du vendeur?
3. Nomme trois catégories d'information que couvre couramment la vérification diligente.

## Corrigé

1. Un examen structuré des détails financiers, juridiques et d'exploitation d'une entreprise, qui a lieu après la signature d'une lettre d'intention, mais avant la convention d'achat finale.
2. Parce que les vendeurs présentent leur entreprise sous un jour favorable et ne sont pas forcément obligés de révéler chaque détail défavorable; la vérification diligente vérifie donc les affirmations de façon indépendante et met activement au jour des problèmes qui ne feraient pas surface autrement.
3. Trois parmi les suivantes : les registres financiers, les questions juridiques (contrats, litiges, conformité), les détails d'exploitation (employés clés, relations avec les fournisseurs), ou d'autres facteurs propres à l'entreprise.

## Réponses et explications

1. C'est la définition de base et le moment de la leçon.
2. C'est le « pourquoi » central qui explique la nécessité du processus.
3. Ça vérifie la compréhension de la portée pratique d'une vérification diligente.

## Points clés à retenir
- La vérification diligente est un examen structuré qui a lieu après la lettre d'intention, avant la convention d'achat finale.
- Elle sert à vérifier les affirmations de façon indépendante et à mettre au jour des problèmes qui ne feraient pas forcément surface pendant les négociations.
- Elle couvre couramment les détails financiers, juridiques et d'exploitation propres à l'entreprise acquise.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte des professionnels autorisés en comptabilité et en droit avant de conclure toute acquisition d'entreprise.
