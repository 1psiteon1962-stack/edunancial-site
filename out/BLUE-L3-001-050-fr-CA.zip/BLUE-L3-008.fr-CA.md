---
id: BLUE-L3-008
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 8
title: "Pourquoi une clause d'indexation sur les résultats lie une partie du prix au rendement futur"
summary: "Découvre comment fonctionne une clause d'indexation sur les résultats (*earnout*) dans la vente d'une entreprise, et pourquoi elle peut aider l'acheteur et le vendeur à s'entendre sur le prix quand ils ne voient pas l'avenir de la même façon."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-008 : Pourquoi une clause d'indexation sur les résultats lie une partie du prix au rendement futur

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce qu'est une clause d'indexation sur les résultats
- Expliquer pourquoi une telle clause peut régler un type précis de désaccord sur l'évaluation
- Expliquer un risque que cette clause crée pour le vendeur

## Contenu principal

Une **clause d'indexation sur les résultats** (en anglais, *earnout*) est une structure de transaction où une partie du prix d'achat total dépend de l'atteinte, par l'entreprise, de cibles de rendement précises après la conclusion de la vente, au lieu d'être payée entièrement d'avance. On l'utilise souvent avec d'autres méthodes de financement, dont le financement par le vendeur (leçon 1).

Voici « pourquoi » ces clauses existent : l'acheteur et le vendeur ne s'entendent souvent pas sur le rendement futur probable d'une entreprise — le vendeur peut être optimiste au sujet de perspectives de croissance dont l'acheteur doute davantage, surtout si cette croissance dépend de plans que le vendeur n'a pas encore réalisés. Une clause d'indexation règle ce désaccord précis en prévoyant qu'une partie du prix ne sera payée que si les projections optimistes se concrétisent réellement, ce qui permet aux deux parties de conclure une transaction sans qu'aucune ait à accepter entièrement, d'avance, la vision de l'avenir de l'autre.

[VERIFIED FACT] Ces clauses créent toutefois un vrai risque pour le vendeur : comme le rendement de l'entreprise pendant la période d'indexation est habituellement contrôlé par l'acheteur (le nouveau propriétaire), le vendeur dépend des décisions et de la gestion de l'acheteur pour atteindre réellement les cibles qui déterminent son paiement final — une dynamique qu'il vaut la peine de régler avec soin dans la façon de structurer les modalités de la clause et toute participation ou surveillance pertinente du vendeur.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une vendeuse croit que son entreprise est sur le point de connaître une forte croissance grâce à un nouveau produit qu'elle développe, et elle veut un prix qui reflète cette croissance attendue. L'acheteur est plus prudent et préfère payer selon le rendement actuel et éprouvé de l'entreprise. Ils s'entendent sur une clause d'indexation : un prix de base qui reflète le rendement actuel, plus un paiement supplémentaire conditionnel à l'atteinte par l'entreprise de cibles de revenus précises au cours des deux prochaines années. [ASSUMPTION] Si le nouveau produit réussit comme la vendeuse le prévoyait, elle reçoit le paiement supplémentaire; sinon, l'acheteur ne se retrouve pas à avoir trop payé en se fiant à des projections qui ne se sont pas concrétisées — mais la vendeuse dépend maintenant de la façon dont l'acheteur exécutera et soutiendra ce nouveau produit après en être devenu propriétaire.

## Quiz de pratique

1. Qu'est-ce qu'une clause d'indexation sur les résultats?
2. Quel type précis de désaccord une telle clause aide-t-elle à régler?
3. Quel risque cette clause crée-t-elle précisément pour le vendeur?

## Corrigé

1. Une structure de transaction où une partie du prix d'achat dépend de l'atteinte, par l'entreprise, de cibles de rendement précises après la conclusion de la vente.
2. Un désaccord entre l'acheteur et le vendeur sur le rendement futur probable de l'entreprise, surtout quand cet avenir dépend de plans qui n'ont pas encore été réalisés.
3. Le paiement final du vendeur dépend des décisions et de la gestion de l'acheteur une fois propriétaire, puisque c'est maintenant l'acheteur qui contrôle le rendement de l'entreprise pendant la période d'indexation.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. C'est le « pourquoi » central qui explique le but de cette structure.
3. C'est une mise en garde pratique et importante sur la perte de contrôle du vendeur pendant la période d'indexation.

## Points clés à retenir
- Une clause d'indexation sur les résultats lie une partie du prix d'achat d'une entreprise à des cibles de rendement futures précises après la conclusion de la vente.
- Elle aide à régler les désaccords entre l'acheteur et le vendeur sur le rendement futur probable de l'entreprise.
- Elle crée un vrai risque pour le vendeur, dont le paiement dépend des décisions et de la gestion de l'acheteur après la vente.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un avocat autorisé avant de structurer ou d'accepter une clause d'indexation sur les résultats.
