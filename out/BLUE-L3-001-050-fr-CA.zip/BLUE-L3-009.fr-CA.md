---
id: BLUE-L3-009
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 9
title: "Pourquoi une clause de non-concurrence protège la valeur que tu achètes réellement"
summary: "Découvre pourquoi une entente de non-concurrence est souvent essentielle dans l'acquisition d'une entreprise, et pourquoi la valeur achetée en dépend."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-009 : Pourquoi une clause de non-concurrence protège la valeur que tu achètes réellement

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer le but général d'une clause de non-concurrence dans l'acquisition d'une entreprise
- Expliquer pourquoi elle protège directement la valeur d'achalandage abordée à la leçon 5
- Expliquer pourquoi le caractère exécutoire des clauses de non-concurrence varie et exige une rédaction attentive

## Contenu principal

Dans le contexte de l'acquisition d'une entreprise, une **clause de non-concurrence** empêche habituellement le vendeur de lancer une entreprise concurrente, ou de s'y joindre, dans une zone géographique donnée et pendant une période donnée après la conclusion de la vente.

Voici « pourquoi » cette clause est souvent essentielle, en lien direct avec la discussion sur l'achalandage de la leçon 5 : une grande partie de ce que l'acheteur paie — les relations avec les clients, la réputation, les relations avec des employés formés — est étroitement liée à la personne du vendeur, surtout dans une petite entreprise à capital fermé. Sans clause de non-concurrence, le vendeur pourrait, en théorie, empocher le produit de la vente puis ouvrir immédiatement une nouvelle entreprise concurrente tout près, en emportant avec lui une grande partie des mêmes clients et des mêmes relations — ce qui minerait en fait la valeur d'achalandage même que l'acheteur vient de payer.

[VERIFIED FACT] Le caractère exécutoire des clauses de non-concurrence varie beaucoup d'un territoire à l'autre : certains imposent des limites strictes à leur portée, à leur durée ou même à leur caractère exécutoire, et les règles peuvent différer pour les clauses liées à la vente d'une entreprise par rapport à celles du contexte de l'emploi — c'est un domaine qui exige une rédaction juridique attentive et propre au territoire, plutôt qu'un modèle générique.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un acheteur acquiert une entreprise de services locale en payant une prime qui reflète la solide réputation du vendeur et sa clientèle fidèle — autrement dit, une valeur d'achalandage importante, selon la leçon 5. Sans clause de non-concurrence bien rédigée et exécutoire, le vendeur pourrait ouvrir une nouvelle entreprise semblable à quelques coins de rue peu après la vente, et attirer probablement une grande partie des mêmes clients grâce aux relations personnelles et à la réputation pour lesquelles l'acheteur a précisément payé. [ASSUMPTION] Une clause de non-concurrence bien rédigée, d'une portée et d'une durée raisonnables pour le territoire concerné, protège l'investissement de l'acheteur dans cet achalandage en empêchant ce scénario précis.

## Quiz de pratique

1. Qu'est-ce qu'une clause de non-concurrence dans l'acquisition d'une entreprise empêche habituellement?
2. Pourquoi une clause de non-concurrence est-elle souvent jugée essentielle, en lien avec la notion d'achalandage de la leçon 5?
3. Pourquoi le caractère exécutoire des clauses de non-concurrence exige-t-il une rédaction juridique attentive et propre au territoire plutôt qu'un modèle générique?

## Corrigé

1. Que le vendeur lance une entreprise concurrente, ou s'y joigne, dans une zone géographique donnée et pendant une période donnée après la vente.
2. Parce qu'une grande partie de la valeur d'achalandage que paie l'acheteur est liée à la personne du vendeur, et que sans clause de non-concurrence, le vendeur pourrait miner cette valeur en lançant une entreprise concurrente et en attirant les mêmes clients.
3. Parce que le caractère exécutoire varie beaucoup d'un territoire à l'autre, avec des limites différentes quant à la portée, à la durée et au caractère exécutoire, et que les règles peuvent différer de celles qui s'appliquent aux clauses de non-concurrence en emploi.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. Ça relie directement la clause de non-concurrence à la notion d'achalandage de la leçon 5, ce qui renforce la structure intégrée du parcours.
3. Ça renforce la prudence appropriée, compte tenu des importantes différences juridiques.

## Points clés à retenir
- Une clause de non-concurrence empêche un vendeur de faire concurrence à l'entreprise que l'acheteur vient d'acquérir, pendant une durée et dans une zone données.
- Elle protège directement la valeur d'achalandage que paie l'acheteur, surtout dans les entreprises étroitement liées à la personne du vendeur.
- Le caractère exécutoire des clauses de non-concurrence varie beaucoup d'un territoire à l'autre, ce qui exige une rédaction juridique attentive et professionnelle.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un avocat autorisé avant de rédiger ou d'accepter toute clause de non-concurrence.
