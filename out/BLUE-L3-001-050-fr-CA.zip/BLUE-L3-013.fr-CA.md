---
id: BLUE-L3-013
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 13
title: "Pourquoi les flux de trésorerie et le profit ne sont pas le même chiffre"
summary: "Découvre pourquoi une entreprise rentable peut quand même manquer d'argent, et pourquoi les flux de trésorerie et le profit mesurent deux choses vraiment différentes."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-013 : Pourquoi les flux de trésorerie et le profit ne sont pas le même chiffre

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer la différence entre le profit et les flux de trésorerie
- Expliquer pourquoi les décalages dans le temps entre les deux peuvent créer un vrai risque pour l'entreprise
- Donner un exemple d'une cause courante de l'écart entre les deux

## Contenu principal

Le **profit** (ou bénéfice net) est une mesure comptable des revenus moins les dépenses sur une période, souvent comptabilisée au moment où une vente est faite ou une dépense engagée (selon la comptabilité d'exercice), peu importe le moment exact où l'argent change réellement de mains. Les **flux de trésorerie** mesurent les mouvements réels d'argent qui entrent dans l'entreprise et en sortent pendant cette même période — un chiffre vraiment différent.

Voici « pourquoi » cet écart compte autant en pratique : une entreprise peut être rentable sur papier — en comptabilisant une vente comme revenu dès qu'elle est faite — alors que le paiement réel de cette vente n'est pas encore arrivé, peut-être parce qu'on a accordé au client 60 jours pour payer (un sujet lié au cycle de conversion de la trésorerie de la leçon 14). Pendant ce temps, l'entreprise doit quand même payer ses propres employés et fournisseurs en argent réel, selon leurs propres échéanciers, que ses clients aient payé ou non.

[VERIFIED FACT] Cet écart est une cause importante et bien documentée de faillite des petites entreprises — une entreprise peut afficher un profit dans son état des résultats tout en manquant réellement de l'argent nécessaire pour respecter ses obligations immédiates, une situation souvent décrite comme être « rentable, mais à court de liquidités ».

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une entreprise termine un gros projet et comptabilise 100 000 $ de revenus et 70 000 $ de profit pour le mois, puisque ses dépenses pour le projet étaient de 30 000 $. Toutefois, le client n'est pas tenu de payer avant 60 jours selon les modalités du contrat. [ASSUMPTION] Entre-temps, l'entreprise doit quand même payer immédiatement ses employés et ses fournisseurs en argent — si elle n'a pas assez de réserves de trésorerie ni d'autre financement pour combler cet écart de 60 jours, elle pourrait manquer réellement de liquidités même si elle affiche, sur papier, un profit solide et réel pour la même période.

## Quiz de pratique

1. Quelle est la principale différence entre le profit et les flux de trésorerie?
2. Pourquoi une entreprise rentable peut-elle quand même manquer réellement de liquidités?
3. Que décrit l'expression « rentable, mais à court de liquidités »?

## Corrigé

1. Le profit est une mesure comptable des revenus moins les dépenses, souvent comptabilisée indépendamment du moment exact des paiements; les flux de trésorerie mesurent les mouvements réels d'argent qui entrent dans l'entreprise et en sortent.
2. Parce que les revenus peuvent être comptabilisés avant l'arrivée du paiement réel (par exemple, quand on accorde aux clients des délais de paiement prolongés), alors que l'entreprise doit quand même payer ses propres obligations en argent réel selon un échéancier différent.
3. Une situation où une entreprise affiche un vrai profit dans son état des résultats, mais manque quand même de l'argent réel nécessaire pour respecter ses obligations immédiates.

## Réponses et explications

1. C'est la distinction de base sur laquelle toute la leçon est construite.
2. C'est le mécanisme central qui explique le risque pratique de l'écart entre le profit et les flux de trésorerie.
3. Ça nomme et renforce le scénario précis et courant que décrit la leçon.

## Points clés à retenir
- Le profit et les flux de trésorerie mesurent des choses différentes — le profit est un chiffre comptable, les flux de trésorerie suivent les mouvements réels d'argent.
- Les décalages entre la comptabilisation des revenus et la réception du paiement réel peuvent créer un vrai manque de liquidités, même dans une entreprise rentable.
- Être « rentable, mais à court de liquidités » est une cause importante et bien documentée de faillite des petites entreprises.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un comptable autorisé pour obtenir des conseils adaptés à ton entreprise.
