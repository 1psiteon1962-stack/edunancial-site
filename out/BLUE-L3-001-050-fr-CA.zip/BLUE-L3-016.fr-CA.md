---
id: BLUE-L3-016
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 16
title: "Pourquoi la marge brute en dit plus long que les revenus seuls"
summary: "Découvre ce que mesure la marge brute, pourquoi deux entreprises aux revenus identiques peuvent avoir une réalité économique très différente, et pourquoi la marge compte pour la croissance."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-016 : Pourquoi la marge brute en dit plus long que les revenus seuls

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Définir la marge brute et la façon de la calculer
- Expliquer pourquoi deux entreprises aux revenus identiques peuvent avoir une réalité économique sous-jacente très différente
- Expliquer pourquoi la marge brute compte pour la capacité d'une entreprise à croître de façon rentable

## Contenu principal

La **marge brute** est le pourcentage des revenus qui reste après avoir soustrait le coût direct de production ou de livraison d'un produit ou d'un service (le coût des ventes), avant de tenir compte des autres dépenses d'exploitation comme le marketing, le loyer ou les frais administratifs.

Voici « pourquoi » les revenus seuls peuvent être un chiffre trompeur : deux entreprises pourraient chacune générer 1 million de dollars de revenus annuels, mais si l'une a une marge brute de 70 % et l'autre de 20 %, il leur reste des montants très différents pour couvrir leurs autres dépenses et finir par dégager un profit — l'entreprise à marge plus élevée conserve une bien plus grande part de chaque dollar de revenu avant même de tenir compte des autres coûts.

[VERIFIED FACT] La marge brute compte aussi beaucoup pour la capacité d'une entreprise à croître : une entreprise à forte marge brute peut généralement augmenter ses revenus en faisant en sorte que chaque vente supplémentaire contribue davantage à couvrir les coûts fixes et à dégager un profit, alors qu'une entreprise à faible marge a besoin d'un volume de ventes nettement plus élevé pour obtenir le même effet en dollars, puisqu'une si grande partie de chaque vente est absorbée par les coûts directs.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] L'entreprise A vend un logiciel dont les coûts de livraison directs sont minimes, ce qui lui donne une marge brute de 75 % — pour chaque tranche de 100 $ de revenus, il reste 75 $ après les coûts directs pour couvrir les autres dépenses et dégager un profit. L'entreprise B vend des produits physiques qui ont des coûts de matériaux et de fabrication importants, ce qui lui donne une marge brute de seulement 25 % — pour chaque tranche de 100 $ de revenus, il ne reste que 25 $ après les coûts directs. [ASSUMPTION] Même si les deux entreprises déclarent les mêmes revenus annuels totaux, l'entreprise A dispose de beaucoup plus de ressources pour investir dans sa croissance, couvrir ses frais généraux ou dégager un profit, ce qui montre pourquoi les revenus seuls, sans tenir compte de la marge brute, peuvent être une mesure trompeuse de la solidité économique sous-jacente d'une entreprise.

## Quiz de pratique

1. Que mesure la marge brute?
2. Pourquoi deux entreprises aux revenus identiques peuvent-elles avoir une réalité économique sous-jacente très différente?
3. Pourquoi la marge brute compte-t-elle pour la capacité d'une entreprise à croître?

## Corrigé

1. Le pourcentage des revenus qui reste après avoir soustrait le coût direct de production ou de livraison d'un produit ou d'un service, avant les autres dépenses d'exploitation.
2. Parce que des marges brutes différentes veulent dire que des montants très différents de revenus restent après les coûts directs, ce qui influe sur ce qui est disponible pour couvrir les autres dépenses et dégager un profit.
3. Parce qu'une entreprise à marge plus élevée conserve une plus grande part de chaque vente supplémentaire pour couvrir les coûts fixes et dégager un profit, alors qu'une entreprise à marge plus faible a besoin d'un volume nettement plus élevé pour obtenir le même effet en dollars.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. C'est l'idée centrale qui explique pourquoi les revenus seuls sont une mesure incomplète.
3. Ça relie directement la marge brute aux perspectives pratiques de croissance d'une entreprise.

## Points clés à retenir
- La marge brute mesure le pourcentage des revenus qui reste après les coûts directs de production ou de livraison.
- Des entreprises aux revenus identiques peuvent avoir une réalité économique sous-jacente très différente selon leur marge brute.
- Des marges brutes plus élevées favorisent généralement une croissance plus facile et plus rentable que des marges plus faibles.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel autorisé avant de prendre des décisions de planification d'entreprise.
