---
id: BLUE-L3-017
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 17
title: "Pourquoi l'économie unitaire détermine si la croissance t'aide ou te nuit"
summary: "Découvre ce que mesure l'économie unitaire, et pourquoi faire croître une entreprise dont l'économie unitaire est mauvaise peut en fait aggraver ses problèmes financiers au lieu de les régler."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-017 : Pourquoi l'économie unitaire détermine si la croissance t'aide ou te nuit

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce que mesure l'économie unitaire
- Expliquer pourquoi la croissance peut aggraver la situation financière d'une entreprise si son économie unitaire est négative
- Relier cette notion à la discussion sur la marge brute de la leçon 16

## Contenu principal

L'**économie unitaire** examine les revenus et les coûts directs associés à une seule unité de l'activité principale d'une entreprise — souvent un seul client, une seule transaction ou un seul produit vendu. Elle répond à une question précise : chaque unité, à elle seule, génère-t-elle un profit ou une perte, avant de tenir compte des coûts fixes et des frais généraux plus larges de l'entreprise?

Voici « pourquoi » ça compte, dans certains cas, plus que les revenus globaux ou même la marge brute totale (leçon 16) : si l'économie unitaire liée à l'acquisition et au service d'un seul client est en fait négative — c'est-à-dire qu'il coûte plus cher d'acquérir et de servir ce client que ce que l'entreprise en tire —, alors faire croître la clientèle ne règle pas le problème de fond de l'entreprise. Ça l'accélère. Plus de clients, qui font chacun perdre de l'argent, veut dire des pertes totales plus grandes, et non un chemin vers la rentabilité.

[VERIFIED FACT] C'est une notion distincte de la marge brute globale : une entreprise peut afficher une marge brute globale positive sur papier tout en ayant une économie unitaire négative pour un segment de clientèle ou un canal de croissance précis, si les coûts réels d'acquisition et de service de ce segment ne sont pas entièrement pris en compte dans un simple calcul de marge.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une entreprise d'abonnements dépense 150 $ en publicité pour acquérir un nouveau client type, et ce client ne génère que 100 $ de revenus au total pendant sa période d'abonnement avant d'annuler. Sur le plan de l'économie unitaire, chaque client représente une perte de 50 $ pour l'entreprise. [ASSUMPTION] Si l'entreprise réagit au ralentissement de sa croissance en augmentant énergiquement ses dépenses de marketing pour acquérir encore plus de clients, sans d'abord régler ce problème d'économie unitaire, elle ne fera qu'accélérer ses pertes — chaque nouveau client continue de faire perdre 50 $, ce qui veut dire que la « croissance », dans ce cas précis, aggrave la situation financière de l'entreprise au lieu de l'améliorer.

## Quiz de pratique

1. Qu'examine l'économie unitaire?
2. Pourquoi faire croître la clientèle d'une entreprise peut-il aggraver sa situation financière si son économie unitaire est négative?
3. En quoi l'économie unitaire diffère-t-elle de la marge brute globale abordée à la leçon 16?

## Corrigé

1. Les revenus et les coûts directs associés à une seule unité de l'activité principale d'une entreprise, comme un client, une transaction ou un produit.
2. Parce que, si chaque client coûte plus cher à acquérir et à servir que ce qu'il rapporte, ajouter des clients ne fait que multiplier la perte au lieu de rapprocher l'entreprise de la rentabilité.
3. L'économie unitaire examine précisément le coût réel et le revenu d'une seule unité, ce qui peut révéler une perte même quand la marge brute globale semble acceptable, puisque la marge brute peut ne pas tenir compte entièrement des coûts réels d'acquisition et de service d'un segment précis.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. C'est l'idée centrale, contre-intuitive, autour de laquelle la leçon est construite — la croissance n'est pas automatiquement bonne.
3. Ça distingue l'économie unitaire de la notion apparentée, mais différente, abordée dans la leçon précédente.

## Points clés à retenir
- L'économie unitaire examine si un seul client, une seule transaction ou un seul produit est rentable à lui seul.
- Si l'économie unitaire est négative, faire croître la clientèle accélère les pertes au lieu de les régler.
- L'économie unitaire peut révéler des problèmes qu'un calcul de marge brute globale pourrait ne pas entièrement refléter.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel autorisé avant de prendre des décisions de croissance d'entreprise.
