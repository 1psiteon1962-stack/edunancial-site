---
id: BLUE-L3-018
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 18
title: "Pourquoi le coût d'acquisition d'un client et sa valeur à vie doivent être comparés ensemble"
summary: "Découvre pourquoi le CAC et la VVC n'ont aucun sens pris isolément, et pourquoi le ratio entre les deux révèle si une stratégie de croissance fonctionne réellement."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-018 : Pourquoi le coût d'acquisition d'un client et sa valeur à vie doivent être comparés ensemble

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Définir le coût d'acquisition d'un client (CAC) et la valeur à vie d'un client (VVC)
- Expliquer pourquoi ces deux chiffres doivent être comparés ensemble, et non évalués séparément
- Relier directement cette notion à la discussion sur l'économie unitaire de la leçon 17

## Contenu principal

Le **coût d'acquisition d'un client (CAC)** est le coût moyen pour acquérir un nouveau client, habituellement calculé en divisant les dépenses totales de ventes et de marketing par le nombre de nouveaux clients acquis pendant une période. La **valeur à vie d'un client (VVC**; en anglais, *LTV*) estime le total des revenus (ou des profits) qu'une entreprise s'attend à tirer d'un client type pendant toute la durée de sa relation avec elle.

Voici « pourquoi » ces deux chiffres n'ont essentiellement aucun sens pris isolément, en prolongement direct de la notion d'économie unitaire de la leçon 17 : un CAC élevé n'est pas automatiquement mauvais si la VVC est proportionnellement encore plus élevée, et un CAC bas n'est pas automatiquement bon si la VVC est encore plus basse. Ce qui compte, c'est la relation entre les deux — souvent exprimée sous forme de ratio VVC/CAC —, qui révèle si le coût d'acquisition d'un client est justifié par ce que ce client devrait valoir avec le temps.

[VERIFIED FACT] Même si les ratios cibles précis peuvent varier selon le secteur et le modèle d'affaires, une entreprise veut généralement que sa VVC dépasse nettement son CAC — un ratio trop proche de 1:1 (ou inférieur) laisse entrevoir le problème d'économie unitaire décrit à la leçon 17 : les clients pourraient ne pas générer assez de valeur pour justifier ce qu'il en coûte de les acquérir, surtout une fois pris en compte les autres coûts d'exploitation au-delà de l'acquisition.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une entreprise dépense 200 $ pour acquérir un nouveau client moyen (CAC) et estime que ce client générera 800 $ de profit pendant toute sa relation avec elle (VVC) — un ratio de 4:1, qui laisse croire à une relation raisonnablement saine entre le coût d'acquisition et la valeur du client. Une autre entreprise dépense le même CAC de 200 $, mais n'estime qu'une valeur à vie de 220 $ — un ratio à peine supérieur à 1:1. [ASSUMPTION] Même si les deux entreprises ont exactement le même CAC, le ratio malsain de la deuxième signale le même problème fragile d'économie unitaire que décrit la leçon 17, alors que le ratio plus sain de la première laisse croire que ses dépenses de croissance sont probablement justifiées par la valeur qu'apporte chaque client.

## Quiz de pratique

1. Que mesurent respectivement le CAC et la VVC?
2. Pourquoi le CAC et la VVC n'ont-ils essentiellement aucun sens évalués séparément plutôt qu'ensemble?
3. Qu'est-ce qu'un ratio VVC/CAC proche de 1:1 (ou inférieur) laisse généralement entrevoir?

## Corrigé

1. Le CAC mesure le coût moyen d'acquisition d'un nouveau client; la VVC estime le total des revenus ou des profits qu'une entreprise attend d'un client type pendant toute sa relation avec elle.
2. Parce qu'un chiffre de CAC ou de VVC à lui seul ne révèle pas si les dépenses d'acquisition sont justifiées — seule la relation entre les deux montre si la valeur attendue d'un client dépasse réellement ce qu'il en coûte de l'acquérir.
3. Il laisse entrevoir le même problème fragile d'économie unitaire que décrit la leçon 17 — les clients pourraient ne pas générer assez de valeur pour justifier leur coût d'acquisition, surtout une fois les autres coûts d'exploitation pris en compte.

## Réponses et explications

1. C'est la définition de base des deux indicateurs.
2. C'est le « pourquoi » central de la leçon — c'est le ratio, et non l'un ou l'autre chiffre seul, qui compte.
3. Ça relie directement la notion à la discussion sur l'économie unitaire de la leçon 17.

## Points clés à retenir
- Le CAC mesure le coût d'acquisition d'un client; la VVC estime la valeur totale attendue de ce client avec le temps.
- Ces chiffres doivent être comparés ensemble — c'est le ratio entre les deux, et non l'un ou l'autre seul, qui révèle si une stratégie de croissance est financièrement saine.
- Un ratio trop proche de 1:1 signale le même risque fragile d'économie unitaire abordé à la leçon 17.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel autorisé avant de prendre des décisions de croissance d'entreprise.
