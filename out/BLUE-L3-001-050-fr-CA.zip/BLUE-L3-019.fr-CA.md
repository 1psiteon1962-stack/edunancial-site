---
id: BLUE-L3-019
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 19
title: "Pourquoi le taux d'épuisement et la marge de manœuvre déterminent combien de temps il te reste vraiment"
summary: "Découvre ce que mesurent le taux d'épuisement de la trésorerie et la marge de manœuvre, et pourquoi connaître ta marge de manœuvre t'indique précisément combien de temps il te reste avant d'avoir besoin de plus de financement."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-019 : Pourquoi le taux d'épuisement et la marge de manœuvre déterminent combien de temps il te reste vraiment

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Définir le taux d'épuisement de la trésorerie et la marge de manœuvre
- Calculer une estimation simple de la marge de manœuvre
- Expliquer pourquoi comprendre sa marge de manœuvre guide le moment de la recherche de financement ou d'autres décisions financières

## Contenu principal

Le **taux d'épuisement de la trésorerie** (*burn rate*) est le rythme auquel une entreprise (souvent une entreprise pas encore rentable, comme une jeune entreprise) dépense la trésorerie dont elle dispose, habituellement mesuré par mois. La **marge de manœuvre** (*runway*) est le temps qu'il reste avant que cette trésorerie soit complètement épuisée, au taux d'épuisement actuel — calculée simplement en divisant la trésorerie disponible par le taux d'épuisement mensuel.

Voici « pourquoi » il est si important de suivre précisément ces chiffres : la marge de manœuvre indique exactement à un propriétaire ou à une fondatrice combien de temps il reste pour devenir rentable, obtenir du financement supplémentaire ou changer de cap autrement, avant que l'entreprise manque complètement d'argent. [VERIFIED FACT] Comme obtenir du financement supplémentaire (auprès d'investisseurs, par des prêts ou autrement) prend lui-même habituellement beaucoup de temps — souvent des mois —, de nombreux fondateurs et conseillers expérimentés recommandent d'amorcer ce processus bien avant que la marge de manœuvre soit presque épuisée, plutôt que d'attendre qu'une crise de liquidités soit déjà en cours, puisqu'une entreprise qui cherche du financement dans l'urgence a habituellement beaucoup moins de pouvoir de négociation qu'une entreprise qui le fait avec une marge de manœuvre confortable.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une entreprise dispose de 300 000 $ de trésorerie et dépense 50 000 $ de plus qu'elle ne fait entrer chaque mois (son taux d'épuisement) — ce qui lui donne une marge de manœuvre de 6 mois (300 000 $ divisés par 50 000 $). [ASSUMPTION] Si obtenir du financement supplémentaire prend habituellement de 3 à 4 mois du début à la fin, attendre qu'il ne reste plus que 2 mois de marge de manœuvre pour amorcer le processus mettrait l'entreprise en sérieux danger — amorcer le processus avec 6 mois complets de marge de manœuvre lui donne plutôt amplement de temps pour obtenir du financement à de meilleures conditions, et non par désespoir.

## Quiz de pratique

1. Que mesurent respectivement le taux d'épuisement et la marge de manœuvre?
2. Comment calcule-t-on généralement la marge de manœuvre?
3. Pourquoi recommande-t-on généralement d'amorcer la recherche de financement bien avant que la marge de manœuvre soit presque épuisée?

## Corrigé

1. Le taux d'épuisement est le rythme auquel une entreprise dépense sa trésorerie disponible, habituellement par mois; la marge de manœuvre est le temps qu'il reste avant que cette trésorerie s'épuise, au taux d'épuisement actuel.
2. On divise la trésorerie disponible par le taux d'épuisement mensuel.
3. Parce qu'obtenir du financement supplémentaire prend lui-même habituellement beaucoup de temps, et qu'une entreprise qui cherche du financement dans l'urgence a généralement beaucoup moins de pouvoir de négociation qu'une entreprise qui a encore une marge de manœuvre confortable.

## Réponses et explications

1. C'est la définition de base des deux notions.
2. C'est le calcul précis dont dépend la leçon.
3. C'est la leçon pratique centrale sur le moment de la recherche de financement par rapport à la marge de manœuvre réelle.

## Points clés à retenir
- Le taux d'épuisement mesure la vitesse à laquelle une entreprise dépense sa trésorerie disponible; la marge de manœuvre mesure le temps qu'il reste avant que cette trésorerie s'épuise.
- La marge de manœuvre se calcule en divisant la trésorerie disponible par le taux d'épuisement mensuel.
- La recherche de financement ou d'autres décisions financières importantes devraient généralement commencer bien avant que la marge de manœuvre soit presque épuisée, puisque l'urgence réduit le pouvoir de négociation.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel autorisé avant de prendre des décisions de planification financière d'entreprise.
