---
id: BLUE-L3-021
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 21
title: "Pourquoi le financement par capitaux propres coûte plus cher que la dette à long terme (si l'entreprise réussit)"
summary: "Découvre pourquoi céder des capitaux propres, contrairement au remboursement d'un prêt, veut dire partager indéfiniment tout le potentiel futur — et pourquoi ça peut faire des capitaux propres le choix le plus coûteux si l'entreprise réussit."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-021 : Pourquoi le financement par capitaux propres coûte plus cher que la dette à long terme (si l'entreprise réussit)

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer la différence structurelle fondamentale entre le financement par emprunt et le financement par capitaux propres
- Expliquer pourquoi le financement par capitaux propres peut devenir plus coûteux que la dette si une entreprise réussit très bien
- Expliquer pourquoi le financement par emprunt comporte un type de risque différent de celui des capitaux propres

## Contenu principal

Le **financement par emprunt** consiste à emprunter de l'argent qui doit être remboursé, habituellement avec intérêts, sur une période définie — une fois le prêt remboursé, le prêteur n'a plus aucun droit sur les profits futurs ni sur la propriété de l'entreprise. Le **financement par capitaux propres** consiste à vendre un pourcentage de la propriété de l'entreprise à des investisseurs en échange de capitaux — cette participation, et le droit de l'investisseur sur les profits et la valeur futurs, se poursuit indéfiniment, aussi longtemps que l'investisseur détient ses actions.

Voici « pourquoi » les capitaux propres peuvent finir par être la forme de financement la plus coûteuse, précisément quand une entreprise réussit très bien : le rendement d'un prêteur est plafonné — il récupère son capital plus l'intérêt convenu, peu importe le succès de l'entreprise. Le rendement d'un investisseur en capitaux propres n'est pas plafonné de la même façon — si l'entreprise devient très prospère et précieuse, la valeur de son pourcentage de propriété augmente avec elle, ce qui peut lui procurer un rendement bien plus important que ce qu'aurait jamais coûté le remboursement plafonné d'une dette.

[VERIFIED FACT] Ça ne veut pas dire que la dette est automatiquement le meilleur choix — la dette comporte son propre risque distinct (une obligation fixe de rembourser, peu importe le rendement réel de l'entreprise, ce qui peut être grave si l'entreprise éprouve des difficultés) que le financement par capitaux propres ne comporte pas de la même façon, puisque les investisseurs en capitaux propres partagent généralement le risque de perte avec la fondatrice au lieu d'exiger un remboursement fixe peu importe le rendement.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une fondatrice a besoin de 200 000 $ pour faire croître son entreprise. Option A : emprunter 200 000 $ et les rembourser sur cinq ans, avec un coût total d'intérêts fixe de, disons, 50 000 $ — un coût connu et plafonné, peu importe le succès de l'entreprise. Option B : vendre 20 % de l'entreprise à un investisseur pour les mêmes 200 000 $. [ASSUMPTION] Si l'entreprise en vient à valoir 10 millions de dollars en quelques années, cette participation de 20 % vaut maintenant 2 millions de dollars — un « coût » de ces 200 000 $ de capitaux de départ beaucoup plus élevé que le coût d'intérêts fixe de 50 000 $ de l'option d'emprunt, même si l'option d'emprunt comportait son propre risque de remboursement, peu importe le succès de l'entreprise en cours de route.

## Quiz de pratique

1. Quelle est la différence structurelle fondamentale entre le financement par emprunt et le financement par capitaux propres?
2. Pourquoi le financement par capitaux propres peut-il finir par coûter plus cher que le financement par emprunt si une entreprise réussit très bien?
3. Quel risque distinct le financement par emprunt comporte-t-il, que le financement par capitaux propres ne comporte généralement pas?

## Corrigé

1. La dette doit être remboursée, habituellement avec intérêts, après quoi le prêteur n'a plus aucun droit; les capitaux propres consistent à vendre une participation continue dans la propriété, et le droit de l'investisseur sur la valeur et les profits se poursuit indéfiniment.
2. Parce que le rendement d'un prêteur est plafonné au capital plus les intérêts, alors que le rendement d'un investisseur en capitaux propres augmente proportionnellement au succès de l'entreprise, sans plafond semblable.
3. Une obligation fixe de rembourser la dette, peu importe le rendement réel de l'entreprise — un risque que les investisseurs en capitaux propres n'imposent généralement pas, puisqu'ils partagent habituellement le risque de perte avec la fondatrice.

## Réponses et explications

1. C'est la distinction structurelle de base de la leçon.
2. C'est l'idée centrale, plutôt contre-intuitive, autour de laquelle la leçon est construite.
3. Ça apporte un équilibre, en montrant le risque distinct de la dette plutôt que de présenter les capitaux propres comme simplement « pires ».

## Points clés à retenir
- La dette doit être remboursée à un coût plafonné (capital plus intérêts); les capitaux propres accordent une participation continue dans la propriété, sans plafond semblable au rendement de l'investisseur.
- Si une entreprise réussit très bien, le financement par capitaux propres peut finir par coûter beaucoup plus cher, en valeur totale cédée, que la dette ne l'aurait fait.
- La dette comporte son propre risque distinct — une obligation de remboursement fixe peu importe le rendement de l'entreprise — que le financement par capitaux propres n'impose généralement pas de la même façon.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel autorisé avant de prendre des décisions de financement d'entreprise.
