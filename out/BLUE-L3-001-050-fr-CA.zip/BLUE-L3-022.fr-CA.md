---
id: BLUE-L3-022
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 22
title: "Pourquoi une table de capitalisation suit plus que la simple répartition de la propriété"
summary: "Découvre ce qu'est une table de capitalisation, pourquoi elle doit tenir compte de plus que les simples pourcentages de propriété actuels, et pourquoi il est important de la tenir à jour."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-022 : Pourquoi une table de capitalisation suit plus que la simple répartition de la propriété

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Définir une table de capitalisation
- Expliquer pourquoi une table de capitalisation doit tenir compte de plus que les simples pourcentages de propriété actuels
- Expliquer pourquoi tenir une table de capitalisation exacte et à jour compte pour les futures rondes de financement

## Contenu principal

Une **table de capitalisation** (*cap table*) est un registre de la structure de propriété d'une société — qui détient quel pourcentage de l'entreprise, et sous quelle forme (actions ordinaires, actions privilégiées, options et instruments semblables).

Voici « pourquoi » elle doit être plus élaborée qu'une simple liste des pourcentages actuels : une table de capitalisation doit habituellement tenir compte de changements futurs possibles à la propriété qui ne se sont pas encore produits, mais qui sont déjà convenus ou raisonnablement prévus — les options d'achat d'actions que les employés n'ont pas encore exercées, les billets convertibles qui seront convertis en capitaux propres dans des conditions futures précises, et les actions réservées, mais non émises, mises de côté pour de futurs employés ou investisseurs. On parle souvent de présenter l'entreprise sur une base « entièrement diluée » — c'est-à-dire montrer à quoi ressembleraient les pourcentages de propriété si toutes ces conversions et tous ces exercices futurs possibles avaient réellement lieu.

[VERIFIED FACT] Tenir une table de capitalisation exacte et à jour compte beaucoup pour les futures rondes de financement (un sujet abordé dans des leçons plus loin) : les investisseurs qui évaluent un placement possible ont besoin d'un portrait clair et exact de la structure de propriété complète de la société, y compris ces éléments sur une base entièrement diluée, pour comprendre exactement quel pourcentage de la société leur placement représenterait réellement.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] La simple liste de propriété actuelle d'une jeune pousse montre que les fondateurs détiennent 100 % des actions émises. Toutefois, la société a aussi accordé à plusieurs employés des options d'achat d'actions (pas encore exercées) qui représenteraient 10 % de propriété supplémentaire si elles étaient toutes exercées, et elle a un billet convertible d'un investisseur de la première heure qui sera converti en un autre 5 % de propriété dans des conditions futures précises. [ASSUMPTION] Une table de capitalisation tenue sur une base entièrement diluée montrerait que la propriété effective des fondateurs est plutôt d'environ 85 %, et non de 100 % — un portrait plus exact et plus complet qu'un futur investisseur qui évalue la société aurait besoin de comprendre avant de prendre une décision de placement.

## Quiz de pratique

1. Qu'est-ce qu'une table de capitalisation?
2. Pourquoi une table de capitalisation doit-elle tenir compte de plus que les simples pourcentages de propriété actuels?
3. Pourquoi tenir une table de capitalisation exacte compte-t-il beaucoup pour les futures rondes de financement?

## Corrigé

1. Un registre de la structure de propriété d'une société — qui détient quel pourcentage, et sous quelle forme (actions ordinaires, actions privilégiées, options et instruments semblables).
2. Parce que les options d'achat d'actions en circulation, les billets convertibles et les actions réservées représentent des changements futurs possibles à la propriété dont il faut tenir compte pour donner un portrait exact, sur une base entièrement diluée.
3. Parce que les futurs investisseurs ont besoin de comprendre clairement et exactement la structure de propriété complète pour savoir exactement quel pourcentage de la société leur placement représenterait.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. C'est le « pourquoi » central qui explique le besoin d'une présentation sur une base entièrement diluée.
3. Ça relie la notion à son importance pratique pour les futures rondes de financement, ce qui annonce des leçons plus loin dans ce parcours.

## Points clés à retenir
- Une table de capitalisation consigne la structure de propriété complète d'une société, y compris les différents types d'instruments de capitaux propres.
- Elle doit tenir compte des changements futurs possibles — options, billets convertibles, actions réservées — sur une base entièrement diluée, et pas seulement des simples pourcentages actuels.
- Tenir une table de capitalisation exacte est essentiel pour donner aux futurs investisseurs un portrait clair et juste de la structure de propriété de la société.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un professionnel autorisé avant de prendre des décisions de structuration du capital.
