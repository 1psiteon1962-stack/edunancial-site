---
id: BLUE-L3-023
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 23
title: "Pourquoi les calendriers d'acquisition des droits protègent une société contre un départ hâtif"
summary: "Découvre comment fonctionnent les calendriers d'acquisition des droits, pourquoi ils existent, et pourquoi les fondateurs et les employés acquièrent habituellement leurs actions au fil du temps plutôt que d'un seul coup."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-023 : Pourquoi les calendriers d'acquisition des droits protègent une société contre un départ hâtif

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce qu'est un calendrier d'acquisition des droits
- Expliquer pourquoi l'acquisition graduelle des droits protège une société si un fondateur ou un employé part tôt
- Expliquer ce que désigne une « période d'acquisition initiale » (*cliff*) dans un calendrier d'acquisition typique

## Contenu principal

Un **calendrier d'acquisition des droits** (*vesting schedule*) détermine à quel moment une personne qui s'est vu attribuer des actions (un fondateur, un employé ou parfois un conseiller) en acquiert réellement la pleine propriété au fil du temps, au lieu d'en obtenir la pleine propriété dès l'attribution initiale.

Voici « pourquoi » cette structure existe, en lien avec la discussion sur la table de capitalisation de la leçon 22 : sans acquisition graduelle des droits, une personne pourrait recevoir une attribution d'actions importante, puis quitter la société presque immédiatement en repartant avec une part de propriété importante, même si elle n'a presque pas contribué au succès réel de la société. L'acquisition graduelle des droits protège contre ce scénario précis en faisant en sorte que la propriété s'accumule progressivement, habituellement sur plusieurs années, en fonction de la participation continue à la société.

[VERIFIED FACT] Une structure d'acquisition courante comprend une **période d'acquisition initiale** (*cliff*) — souvent d'un an — pendant laquelle aucune action n'est acquise; si la personne part avant la fin de cette période, elle ne reçoit aucune action, même si du temps s'est écoulé depuis l'attribution. Après cette période, les actions restantes s'acquièrent souvent graduellement, parfois chaque mois ou chaque trimestre, pendant le reste de la période d'acquisition (qui totalise couramment quatre ans, même si les structures précises varient selon la société et l'entente).

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une jeune pousse attribue des actions à une nouvelle cofondatrice, assujetties à un calendrier d'acquisition de quatre ans avec une période d'acquisition initiale d'un an. Si cette cofondatrice quitte la société après seulement huit mois — avant la fin de la période d'acquisition initiale d'un an —, elle ne reçoit aucune action en vertu du calendrier, même si des actions lui avaient été attribuées au départ. [ASSUMPTION] Si elle était plutôt restée deux années complètes avant de partir, elle aurait acquis environ la moitié du total des actions qui lui avaient été attribuées, ce qui refléterait sa période réelle de contribution, alors que la moitié restante, non acquise, retournerait habituellement à la société au lieu de rester entre ses mains.

## Quiz de pratique

1. Que détermine un calendrier d'acquisition des droits?
2. Pourquoi l'acquisition graduelle des droits protège-t-elle une société si un fondateur ou un employé part tôt?
3. Qu'est-ce qu'une « période d'acquisition initiale » dans un calendrier d'acquisition typique?

## Corrigé

1. Le moment où une personne qui s'est vu attribuer des actions en acquiert réellement la pleine propriété au fil du temps, plutôt qu'immédiatement à l'attribution.
2. Parce que sans acquisition graduelle des droits, une personne pourrait partir presque immédiatement après avoir reçu une attribution tout en gardant une part de propriété importante, malgré une contribution réelle minime à la société.
3. Une période, souvent d'un an, pendant laquelle aucune action n'est acquise — si la personne part avant la fin de cette période, elle ne reçoit aucune action, même si du temps s'est écoulé depuis l'attribution.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. C'est le « pourquoi » central qui explique le rôle protecteur de l'acquisition graduelle des droits.
3. Ça explique une caractéristique précise et courante des structures d'acquisition typiques.

## Points clés à retenir
- Les calendriers d'acquisition des droits font en sorte que la propriété des actions s'accumule graduellement au fil du temps, au lieu d'être complète dès l'attribution.
- Ça protège une société contre le départ hâtif d'une personne qui garderait une part de propriété importante, en grande partie non méritée.
- Une structure courante comprend une période d'acquisition initiale d'un an, suivie d'une acquisition graduelle, souvent sur une période totale de quatre ans.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un professionnel autorisé avant de structurer toute entente de rémunération en actions.
