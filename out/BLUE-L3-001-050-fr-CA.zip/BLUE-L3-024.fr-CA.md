---
id: BLUE-L3-024
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 24
title: "Pourquoi la dilution est le prix à payer pour lever des capitaux externes"
summary: "Découvre pourquoi lever de l'argent en vendant des actions réduit le pourcentage de participation des propriétaires existants, et pourquoi la dilution n'est pas automatiquement une mauvaise chose."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-024 : Pourquoi la dilution est le prix à payer pour lever des capitaux externes

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce que veut dire la dilution quand une société lève de nouveaux capitaux propres
- Expliquer pourquoi la dilution réduit le pourcentage de participation des propriétaires existants, mais pas forcément la valeur de cette participation
- Expliquer pourquoi la dilution est une conséquence naturelle et attendue de la levée de capitaux externes, et non une erreur en soi

## Contenu principal

La **dilution** se produit quand une société émet de nouvelles actions — habituellement pour lever des capitaux auprès de nouveaux investisseurs —, ce qui réduit le pourcentage de propriété des actionnaires existants, puisque le nombre total d'actions en circulation augmente alors que le nombre d'actions de chaque actionnaire existant reste le même.

Voici « pourquoi » cette réduction du pourcentage ne veut pas forcément dire que les propriétaires existants s'en tirent moins bien : si les capitaux levés sont utilisés efficacement pour faire croître la valeur globale de la société, les actionnaires existants peuvent finir par détenir un plus petit pourcentage d'une société beaucoup plus grande et plus précieuse — ce qui peut donner à leur participation réduite une valeur totale plus élevée que celle qu'aurait eue un plus grand pourcentage d'une société plus petite et moins capitalisée.

[VERIFIED FACT] Ça se relie directement à la discussion de la leçon 20 sur l'autofinancement et la levée de capitaux : la dilution est le mécanisme direct et mesurable par lequel le côté « céder une partie de la propriété » de ce compromis se concrétise réellement — c'est une conséquence attendue et naturelle de la levée de capitaux propres externes, et non la preuve que quelque chose a mal tourné, même si une dilution excessive ou mal négociée sur plusieurs rondes de financement est une préoccupation légitime qu'il vaut la peine de gérer avec soin.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une fondatrice détient 100 % de sa société quand celle-ci est évaluée à 1 million de dollars. Elle lève des capitaux auprès d'investisseurs en émettant de nouvelles actions qui diluent sa participation à 70 % de la société. [ASSUMPTION] Si ces capitaux sont utilisés efficacement et que la valeur de la société grimpe à 10 millions de dollars grâce à eux, sa participation de 70 % (7 millions de dollars) vaut beaucoup plus que sa participation initiale de 100 % dans la société de 1 million de dollars — ce qui montre pourquoi la dilution, dans ce cas précis, n'a pas été une perte pour elle, même si son pourcentage de propriété a diminué.

## Quiz de pratique

1. Que veut dire la dilution quand une société émet de nouvelles actions?
2. Pourquoi une réduction du pourcentage de propriété ne veut-elle pas forcément dire que les propriétaires existants s'en tirent moins bien?
3. Comment cette leçon se relie-t-elle à la discussion de la leçon 20 sur l'autofinancement et la levée de capitaux?

## Corrigé

1. Le pourcentage de propriété des actionnaires existants diminue parce que de nouvelles actions sont émises, ce qui augmente le nombre total d'actions en circulation alors que le nombre d'actions de chaque actionnaire existant reste le même.
2. Parce que, si les capitaux levés sont utilisés efficacement pour faire croître la valeur globale de la société, un plus petit pourcentage d'une société beaucoup plus grande et plus précieuse peut valoir plus qu'un plus grand pourcentage d'une société plus petite.
3. La dilution est le mécanisme précis et mesurable par lequel le compromis de propriété décrit à la leçon 20 se concrétise réellement quand une société choisit de lever des capitaux externes plutôt que de s'autofinancer.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. C'est l'idée centrale, rassurante, selon laquelle la dilution n'est pas automatiquement nuisible.
3. Ça relie explicitement la leçon au compromis de financement plus large présenté plus tôt dans le parcours.

## Points clés à retenir
- La dilution réduit le pourcentage de propriété des actionnaires existants quand de nouvelles actions sont émises pour lever des capitaux.
- Un plus petit pourcentage d'une société dont la valeur augmente fortement peut quand même donner une valeur totale plus élevée qu'un plus grand pourcentage d'une société plus petite.
- La dilution est le mécanisme direct derrière le compromis de propriété lié à la levée de capitaux externes; elle est attendue et n'est pas une erreur en soi — même s'il faut quand même la gérer avec soin d'une ronde de financement à l'autre.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel autorisé avant de prendre des décisions de levée de capitaux propres.
