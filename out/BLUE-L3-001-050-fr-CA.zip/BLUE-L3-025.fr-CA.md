---
id: BLUE-L3-025
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 25
title: "Pourquoi une feuille de modalités fixe les conditions avant la rédaction du vrai contrat"
summary: "Découvre à quoi sert une feuille de modalités dans le contexte d'une levée de capitaux propres, et pourquoi elle fonctionne comme une lettre d'intention dans l'acquisition d'une entreprise."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-025 : Pourquoi une feuille de modalités fixe les conditions avant la rédaction du vrai contrat

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce qu'est une feuille de modalités dans le contexte d'une levée de capitaux propres
- Expliquer comment une feuille de modalités fonctionne de façon semblable à la lettre d'intention de la leçon 6
- Nommer les principales modalités que comprend habituellement une feuille de modalités

## Contenu principal

Dans le contexte d'une levée de capitaux propres, une **feuille de modalités** (*term sheet*) présente les principales conditions proposées d'un investissement — évaluation, montant levé, type d'actions émises, droits des investisseurs et autres dispositions importantes — avant la rédaction des ententes d'investissement juridiques complètes et détaillées.

Voici « pourquoi » elle ressemble beaucoup à la lettre d'intention abordée à la leçon 6 pour l'acquisition d'une entreprise : comme une lettre d'intention, une feuille de modalités ne lie généralement pas les parties pour l'essentiel de ses modalités de fond, ce qui permet à la société et à l'investisseur de s'entendre sur les grands points de la transaction et de passer à la vérification diligente et à la documentation juridique détaillée, sans qu'aucune des deux parties soit entièrement liée avant la signature des ententes finales — alors que, de la même façon, certaines dispositions (comme la confidentialité ou une période d'exclusivité limitée) sont couramment structurées pour lier les parties, même à l'intérieur d'une feuille de modalités qui, autrement, ne les lie pas.

[VERIFIED FACT] Les modalités courantes d'une feuille de modalités pour une levée de capitaux propres comprennent l'évaluation de la société (souvent en distinguant l'évaluation « avant financement » et « après financement »), le montant des capitaux levés, le type d'actions émises (souvent des actions privilégiées assorties de droits précis), ainsi que diverses protections des investisseurs et divers droits de gouvernance — chacun étant un point de négociation important avant la préparation des documents juridiques finaux.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une jeune pousse et un investisseur potentiel négocient et signent une feuille de modalités qui précise un montant d'investissement proposé, une évaluation convenue et le type d'actions privilégiées à émettre, ainsi qu'une période d'exclusivité de 45 jours qui lie les parties. [ASSUMPTION] Pendant cette période, les deux parties procèdent à la vérification diligente juridique et rédigent les ententes d'investissement complètes. Si un problème important survient pendant ce processus, les modalités de fond de la feuille de modalités qui ne lient pas les parties — évaluation, montant, structure — peuvent encore être renégociées, ou l'une ou l'autre partie peut se retirer, exactement comme la souplesse non contraignante décrite pour une lettre d'intention à la leçon 6, appliquée ici à un investissement en capitaux propres plutôt qu'à l'acquisition d'une entreprise.

## Quiz de pratique

1. Que présente une feuille de modalités dans le contexte d'une levée de capitaux propres?
2. En quoi la structure d'une feuille de modalités, qui lie ou non les parties selon les dispositions, ressemble-t-elle à la lettre d'intention de la leçon 6?
3. Nomme deux modalités courantes que comprend habituellement une feuille de modalités pour une levée de capitaux propres.

## Corrigé

1. Les principales conditions proposées d'un investissement — évaluation, montant levé, type d'actions, droits des investisseurs et autres dispositions importantes — avant la rédaction des ententes juridiques complètes.
2. Comme une lettre d'intention, ses modalités de fond ne lient généralement pas les parties, ce qui laisse de la souplesse avant la signature des documents finaux, alors que des dispositions précises comme la confidentialité ou l'exclusivité sont couramment structurées pour lier les parties.
3. Deux parmi les suivantes : l'évaluation de la société (avant et après financement), le montant des capitaux levés, le type d'actions émises, les protections des investisseurs et les droits de gouvernance.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. Ça relie explicitement la notion à la discussion semblable sur la lettre d'intention plus tôt dans ce parcours, ce qui renforce la structure intégrée.
3. Ça vérifie la compréhension du contenu pratique habituellement négocié dans une feuille de modalités.

## Points clés à retenir
- Une feuille de modalités présente les principales conditions proposées d'un investissement avant la rédaction des ententes juridiques complètes.
- Elle fonctionne comme la lettre d'intention d'une acquisition d'entreprise : ses modalités de fond ne lient généralement pas les parties, mais certaines dispositions comme l'exclusivité les lient couramment.
- Les modalités courantes comprennent l'évaluation, le montant des capitaux, le type d'actions et les droits des investisseurs, chacune pouvant être négociée avant les documents finaux.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un avocat autorisé avant de signer toute feuille de modalités ou entente d'investissement.
