---
id: BLUE-L3-027
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 27
title: "Pourquoi le financement fondé sur les revenus se situe à mi-chemin entre la dette et les capitaux propres"
summary: "Découvre comment fonctionne le financement fondé sur les revenus, et pourquoi il offre une voie intermédiaire entre la dette traditionnelle et la cession d'une participation au capital."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-027 : Pourquoi le financement fondé sur les revenus se situe à mi-chemin entre la dette et les capitaux propres

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer comment fonctionne le financement fondé sur les revenus
- Expliquer pourquoi on le décrit souvent comme une voie intermédiaire entre la dette et les capitaux propres
- Expliquer pourquoi on le qualifie souvent de financement « non dilutif » et ce que ça veut dire

## Contenu principal

Le **financement fondé sur les revenus** (en anglais, *revenue-based financing* ou RBF) fournit des capitaux à une entreprise en échange d'un pourcentage de ses revenus futurs, habituellement versé jusqu'à ce qu'un multiple établi d'avance du placement initial soit remboursé, plutôt que par des paiements mensuels fixes (comme une dette traditionnelle) ou par une participation continue au capital (comme le capital de risque, leçon 26).

Voici « pourquoi » on le décrit souvent comme une voie intermédiaire entre les deux, en lien avec la discussion de la leçon 21 sur la dette et les capitaux propres : comme la dette, le financement fondé sur les revenus a un montant total de remboursement défini (habituellement le montant investi multiplié par un multiple fixé) plutôt qu'une participation ouverte à toute la valeur future de l'entreprise. Mais contrairement à la dette traditionnelle, le montant réel des paiements varie selon les revenus de l'entreprise — pendant une période de revenus plus lente, le paiement est plus petit; pendant une période plus forte, il est plus grand —, ce qui réduit le risque de remboursement mensuel fixe que comporte le financement purement par emprunt.

[VERIFIED FACT] On qualifie souvent ce type de financement de capital **non dilutif**, puisqu'il n'exige de céder aucune participation au capital de l'entreprise, contrairement au capital de risque ou à d'autres formes de financement par capitaux propres — c'est une part importante de son attrait pour les fondateurs qui veulent lever des capitaux de croissance sans diluer leur participation (leçon 24) ni céder le contrôle de la gouvernance.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une entreprise en croissance reçoit 200 000 $ en financement fondé sur les revenus et accepte de rembourser un total de 260 000 $ (un multiple de 1,3) au moyen d'un pourcentage de ses revenus mensuels, jusqu'au remboursement de ce total. [ASSUMPTION] Pendant un mois de ventes fortes, l'entreprise paie un montant plus important vers ce total de remboursement; pendant un mois plus lent, le paiement diminue automatiquement avec les revenus, ce qui réduit la pression sur les flux de trésorerie par rapport à un paiement de dette mensuel fixe qui ne s'ajusterait pas, peu importe les ventes. Tout au long du processus, la fondatrice garde la pleine propriété de l'entreprise, contrairement à une entente de financement par capitaux propres.

## Quiz de pratique

1. Comment fonctionne le financement fondé sur les revenus?
2. Pourquoi décrit-on souvent ce type de financement comme une voie intermédiaire entre la dette et les capitaux propres?
3. Pourquoi qualifie-t-on souvent ce type de financement de capital « non dilutif »?

## Corrigé

1. Une entreprise reçoit des capitaux en échange d'un pourcentage de ses revenus futurs, habituellement versé jusqu'à ce qu'un multiple établi d'avance du placement initial soit remboursé.
2. Parce que, comme la dette, il a un montant total de remboursement défini plutôt qu'une participation ouverte au capital, mais que, comme une entente souple, le montant réel des paiements s'ajuste selon les revenus de l'entreprise au lieu d'être une obligation mensuelle fixe.
3. Parce qu'il n'exige de céder aucune participation au capital de l'entreprise, contrairement au capital de risque ou à d'autres ententes de financement par capitaux propres.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. C'est le « pourquoi » central qui explique la position de ce financement entre les deux types de financement abordés plus tôt dans le parcours.
3. Ça explique la terminologie précise et son lien avec la notion de dilution de la leçon 24.

## Points clés à retenir
- Le financement fondé sur les revenus fournit des capitaux en échange d'un pourcentage des revenus futurs, jusqu'à un multiple de remboursement établi d'avance.
- Il combine le total de remboursement défini de la dette et une structure de paiement souple, liée aux revenus, contrairement à un paiement de dette mensuel fixe.
- Il est non dilutif, ce qui veut dire qu'il n'exige de céder aucune participation au capital de l'entreprise.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel autorisé avant de prendre des décisions de financement d'entreprise.
