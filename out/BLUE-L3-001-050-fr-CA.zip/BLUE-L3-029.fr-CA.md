---
id: BLUE-L3-029
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 29
title: "Pourquoi l'affacturage transforme les comptes clients en argent immédiat (à un certain coût)"
summary: "Découvre comment fonctionne l'affacturage, pourquoi il comble directement l'écart de trésorerie de la leçon 13, et pourquoi il comporte un vrai coût qu'il vaut la peine de comprendre."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-029 : Pourquoi l'affacturage transforme les comptes clients en argent immédiat (à un certain coût)

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer comment fonctionne l'affacturage
- Expliquer pourquoi l'affacturage comble directement l'écart de trésorerie abordé à la leçon 13
- Expliquer pourquoi l'affacturage est souvent une forme de financement plus coûteuse

## Contenu principal

L'**affacturage** consiste à vendre les factures clients impayées d'une entreprise (ses comptes clients) à une société d'affacturage, en échange d'argent immédiat — habituellement une grande majorité de la valeur de la facture d'avance, le reste (moins les frais) étant versé une fois que la société d'affacturage a encaissé le paiement du client d'origine.

Voici « pourquoi » ça comble directement l'écart précis décrit à la leçon 13 : au lieu d'attendre tout le délai de paiement (30, 60 ou 90 jours) avant qu'un client paie une facture, une entreprise peut obtenir la majeure partie de cet argent presque immédiatement grâce à l'affacturage — ce qui comble directement l'écart entre la comptabilisation du revenu et la réception réelle de l'argent correspondant.

[VERIFIED FACT] Cette rapidité et cet accès immédiat à l'argent ont un vrai coût : les sociétés d'affacturage facturent des frais, souvent calculés en pourcentage de la valeur de la facture, ce qui peut donner un coût effectif du capital nettement plus élevé que les solutions de financement traditionnelles, surtout si les factures sont affacturées régulièrement sur une longue période — c'est donc un outil qu'il vaut mieux évaluer selon son coût réel, et pas seulement selon sa commodité.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une entreprise a une facture de 50 000 $ auprès d'un client qui ne paiera pas avant 60 jours, et elle a besoin d'argent plus tôt pour couvrir la paie et les paiements aux fournisseurs. Elle vend la facture à une société d'affacturage et reçoit 45 000 $ d'avance (90 % de la valeur de la facture), la société d'affacturage encaissant directement le paiement du client et remettant le solde restant, moins ses frais, une fois le paiement reçu. [ASSUMPTION] Ça règle le problème de trésorerie immédiat décrit à la leçon 13, mais le coût effectif pour obtenir cet argent 60 jours plus tôt — reflété dans les frais d'affacturage — pourrait être nettement plus élevé que le taux d'intérêt d'un prêt bancaire traditionnel, si l'entreprise avait été admissible à un tel prêt et avait eu le temps de l'obtenir.

## Quiz de pratique

1. Comment fonctionne l'affacturage?
2. Comment l'affacturage comble-t-il directement l'écart de trésorerie abordé à la leçon 13?
3. Pourquoi considère-t-on souvent l'affacturage comme une forme de financement plus coûteuse?

## Corrigé

1. Une entreprise vend ses factures clients impayées à une société d'affacturage en échange d'argent immédiat, habituellement une grande majorité de la valeur de la facture d'avance.
2. En donnant accès à l'argent immédiatement au lieu d'attendre tout le délai de paiement du client, ce qui comble directement l'écart entre la comptabilisation du revenu et la réception de l'argent réel.
3. Parce que les sociétés d'affacturage facturent des frais, souvent en pourcentage de la valeur de la facture, ce qui peut donner un coût effectif du capital nettement plus élevé que les solutions de financement traditionnelles.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. Ça relie explicitement l'affacturage au problème précis d'écart de trésorerie présenté à la leçon 13.
3. C'est la mise en garde importante sur le coût par laquelle se termine la leçon.

## Points clés à retenir
- L'affacturage procure de l'argent immédiat en vendant les factures clients impayées à une société tierce.
- Il règle directement le décalage entre le profit et les flux de trésorerie décrit à la leçon 13.
- Les frais d'affacturage peuvent en faire une forme de financement relativement coûteuse, qu'il vaut la peine d'évaluer attentivement selon son coût réel.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel autorisé avant de conclure une entente d'affacturage.
