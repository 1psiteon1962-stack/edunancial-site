---
id: BLUE-L3-032
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 32
title: "Pourquoi un document d'information sur la franchise existe avant que tu signes quoi que ce soit"
summary: "Découvre ce que contient un document d'information sur la franchise, et pourquoi il existe précisément pour protéger les futurs franchisés contre une information incomplète."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-032 : Pourquoi un document d'information sur la franchise existe avant que tu signes quoi que ce soit

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer le but général d'un document d'information sur la franchise
- Nommer les catégories d'information qu'un document d'information typique doit contenir
- Expliquer pourquoi l'examen attentif de ce document se relie à la notion de vérification diligente de la leçon 7

## Contenu principal

Aux États-Unis, un **document d'information sur la franchise** (en anglais, *Franchise Disclosure Document* ou FDD) est un document exigé par la loi que les franchiseurs doivent remettre aux futurs franchisés avant que toute vente de franchise soit conclue, et qui contient de l'information détaillée et normalisée sur l'occasion de franchise. (Au Canada, plusieurs provinces, dont l'Ontario, l'Alberta, la Colombie-Britannique, le Manitoba, le Nouveau-Brunswick et l'Île-du-Prince-Édouard, ont aussi des lois sur la divulgation en matière de franchise.) [VERIFIED FACT] Les exigences précises du document sont fixées par la réglementation fédérale et, dans certains cas, par des règlements d'États supplémentaires, et les catégories d'information à divulguer sont mises à jour périodiquement — il faut vérifier directement les exigences actuelles plutôt que de les supposer.

Voici « pourquoi » ce document existe : les futurs franchisés, qui n'ont pas d'accès indépendant à l'information interne du franchiseur, devraient autrement se fier presque entièrement au discours de vente du franchiseur pour évaluer l'occasion. Le document d'information est conçu précisément pour contrer ce déséquilibre en exigeant la divulgation normalisée de renseignements, dont l'historique des litiges du franchiseur, les droits initiaux et continus, les fourchettes d'investissement total et — dans certains cas — des déclarations précises sur le rendement financier, si le franchiseur choisit d'en faire.

Ça se relie directement à la notion de vérification diligente de la leçon 7 : examiner attentivement un document d'information sur la franchise est, en fait, une forme de vérification diligente propre aux franchises, qui donne au futur franchisé une information exigée de façon indépendante à évaluer avant de s'engager, plutôt que de se fier uniquement à ce que le franchiseur choisit de révéler en conversation.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une future franchisée est enthousiasmée par une occasion de franchise après une présentation de vente enthousiaste du franchiseur. Avant de signer toute entente, elle examine attentivement le document d'information exigé par la loi, qui révèle l'historique des litiges du franchiseur avec d'anciens franchisés et la fourchette réelle des coûts d'investissement total déclarés pour les établissements existants — de l'information qui n'avait pas forcément été mise de l'avant pendant la conversation de vente elle-même. [ASSUMPTION] Cet examen attentif du document d'information, semblable dans son esprit au processus de vérification diligente décrit à la leçon 7, lui donne un portrait plus complet, exigé de façon indépendante, avant de prendre un engagement financier important.

## Quiz de pratique

1. Qu'est-ce qu'un document d'information sur la franchise?
2. Pourquoi ce document d'information obligatoire existe-t-il?
3. Comment l'examen d'un document d'information sur la franchise se relie-t-il à la notion de vérification diligente présentée à la leçon 7?

## Corrigé

1. Un document exigé par la loi que les franchiseurs doivent remettre aux futurs franchisés, qui contient de l'information détaillée et normalisée sur l'occasion de franchise avant que toute vente soit conclue.
2. Pour contrer le déséquilibre d'information entre le franchiseur et les futurs franchisés, qui devraient autrement se fier surtout au discours de vente du franchiseur pour évaluer l'occasion.
3. Examiner attentivement ce document est une forme de vérification diligente propre aux franchises, qui fournit une information exigée de façon indépendante, au-delà de ce que le franchiseur pourrait choisir de révéler.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. C'est le « pourquoi » central qui explique le but réglementaire du document.
3. Ça relie explicitement la leçon à la notion de vérification diligente vue plus tôt, ce qui renforce la structure intégrée du parcours.

## Points clés à retenir
- Un document d'information sur la franchise est un document normalisé, exigé par la loi, que les franchiseurs doivent remettre avant de conclure la vente d'une franchise.
- Il existe pour contrer le déséquilibre naturel d'information entre le franchiseur et le futur franchisé.
- Examiner attentivement ce document est une forme de vérification diligente propre aux franchises.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un avocat autorisé avant de signer tout contrat de franchise.
