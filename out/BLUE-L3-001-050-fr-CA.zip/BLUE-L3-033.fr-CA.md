---
id: BLUE-L3-033
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 33
title: "Pourquoi le MTA, le MAS et le MOS ne sont pas le même chiffre"
summary: "Découvre ce que mesurent le marché total adressable, le marché adressable servi et le marché obtenable servi, et pourquoi les confondre surestime une occasion d'affaires."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-033 : Pourquoi le MTA, le MAS et le MOS ne sont pas le même chiffre

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Définir le MTA, le MAS et le MOS
- Expliquer pourquoi ces trois chiffres représentent des estimations de marché de plus en plus étroites et réalistes
- Expliquer pourquoi citer seulement le MTA peut donner un portrait trompeusement optimiste d'une occasion

## Contenu principal

Le **MTA (marché total adressable**; en anglais, *TAM*) représente le revenu total possible si un produit ou un service s'emparait de 100 % de son marché pertinent, à l'échelle mondiale ou dans sa catégorie la plus large. Le **MAS (marché adressable servi**; en anglais, *SAM*) réduit ce chiffre à la partie du MTA qu'une entreprise précise pourrait réalistement servir, compte tenu de son produit, de sa géographie et de son modèle d'affaires réels. Le **MOS (marché obtenable servi**; en anglais, *SOM*) le réduit encore davantage, à la partie du MAS qu'une entreprise pourrait réalistement conquérir compte tenu de la concurrence, des ressources et des contraintes de mise en marché réelles, habituellement dans un délai précis.

Voici « pourquoi » confondre ces trois chiffres — surtout citer seulement le MTA, impressionnant par sa taille — peut donner un portrait trompeusement optimiste d'une occasion d'affaires : un grand MTA ne dit rien de la part de ce marché qu'une entreprise précise pourrait réellement et réalistement atteindre et conquérir. Un plan d'affaires construit autour de « il suffit de conquérir 1 % de cet énorme MTA pour réussir » saute souvent le travail beaucoup plus difficile et plus honnête qui consiste à estimer précisément le MAS et le MOS, qui révèle habituellement une occasion réaliste bien plus modeste, même si elle peut quand même être viable.

[VERIFIED FACT] Les investisseurs et les évaluateurs d'entreprises expérimentés accordent généralement beaucoup plus de poids à une estimation crédible du MOS — fondée sur des hypothèses réalistes quant à la concurrence, à la capacité de distribution et à l'exécution de la mise en marché — qu'à un chiffre de MTA impressionnant à lui seul, puisque le MTA seul donne très peu d'information sur les perspectives réalistes d'une entreprise précise.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une jeune pousse présente son occasion en citant un MTA mondial de 50 milliards de dollars pour sa grande catégorie de produits. Une analyse plus attentive révèle que, compte tenu de son produit précis, de sa géographie cible et de son modèle d'affaires, son MAS réel se rapproche plutôt de 2 milliards de dollars — et que, compte tenu de la concurrence réaliste et de sa propre capacité de mise en marché, un MOS crédible pour ses premières années pourrait se rapprocher de 20 millions de dollars. [ASSUMPTION] Le chiffre de 50 milliards de dollars du MTA, même s'il est techniquement exact, donnerait à un investisseur une idée largement gonflée de l'occasion réaliste à court terme, par rapport à l'estimation du MOS, beaucoup plus fondée et plus utile.

## Quiz de pratique

1. Que mesurent respectivement le MTA, le MAS et le MOS?
2. Pourquoi citer seulement le MTA peut-il donner un portrait trompeusement optimiste d'une occasion d'affaires?
3. Pourquoi les investisseurs accordent-ils généralement plus de poids à une estimation crédible du MOS qu'au MTA seul?

## Corrigé

1. Le MTA est le revenu total possible si un produit s'emparait de 100 % de son marché pertinent; le MAS réduit ce chiffre à la partie qu'une entreprise précise pourrait réalistement servir; le MOS le réduit encore à ce que cette entreprise pourrait réalistement conquérir compte tenu de la concurrence et des contraintes réelles.
2. Parce qu'un grand MTA ne dit rien de la part de ce marché qu'une entreprise précise pourrait réellement et réalistement atteindre et conquérir, ce qui masque souvent une occasion réaliste bien plus modeste.
3. Parce que le MOS repose sur des hypothèses réalistes quant à la concurrence, à la distribution et à l'exécution, ce qui donne une information beaucoup plus utile sur les perspectives réelles à court terme d'une entreprise précise qu'un chiffre de MTA abstrait et général.

## Réponses et explications

1. C'est la définition de base, en trois parties, de la leçon.
2. C'est la mise en garde centrale autour de laquelle la leçon est construite.
3. Ça renforce pourquoi les évaluateurs expérimentés accordent moins de valeur aux présentations fondées uniquement sur le MTA, au profit d'une analyse du MOS plus fondée.

## Points clés à retenir
- Le MTA, le MAS et le MOS représentent des estimations de plus en plus étroites et réalistes de la taille réelle d'une occasion d'affaires.
- Citer seulement un MTA impressionnant peut donner un portrait trompeusement optimiste, en sautant le travail plus difficile d'une analyse réaliste du MAS et du MOS.
- Une estimation crédible du MOS, fondée sur des hypothèses réalistes de concurrence et d'exécution, a beaucoup plus de poids que le MTA seul.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel autorisé avant de prendre des décisions de planification d'entreprise.
