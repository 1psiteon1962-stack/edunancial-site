---
id: BLUE-L3-035
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 35
title: "Pourquoi savoir quand pivoter est une décision financière, et pas seulement stratégique"
summary: "Découvre pourquoi la décision de réorienter un modèle d'affaires devrait reposer sur des signaux financiers précis, et non seulement sur l'instinct ou une frustration générale."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-035 : Pourquoi savoir quand pivoter est une décision financière, et pas seulement stratégique

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce que veut généralement dire un « pivot » en affaires
- Expliquer pourquoi la décision de pivoter devrait reposer sur des signaux financiers précis
- Relier cette notion à la discussion sur la marge de manœuvre de la leçon 19

## Contenu principal

Un **pivot** désigne généralement un changement important qu'une entreprise apporte à sa stratégie de base, à son produit ou à son marché cible, habituellement en réponse à des preuves que l'approche initiale ne fonctionne pas comme prévu. On en parle souvent en termes surtout stratégiques ou émotionnels — « le marché n'était pas prêt » ou « on a trouvé une meilleure occasion » —, mais voici « pourquoi » c'est fondamentalement une décision financière autant que stratégique : une entreprise n'a qu'une marge de manœuvre (leçon 19) et un capital limités pour vérifier ses hypothèses avant de manquer complètement de ressources.

[VERIFIED FACT] Décider s'il faut pivoter, et à quel moment, devrait généralement reposer sur des indicateurs précis et mesurables — l'économie unitaire (leçon 17), les ratios VVC/CAC (leçon 18) et la marge de manœuvre restante — plutôt que seulement sur une frustration générale ou une intuition non vérifiée selon laquelle « autre chose » pourrait mieux fonctionner. Une fondatrice à qui il reste trois mois de marge de manœuvre fait face à une décision de pivot très différente, avec beaucoup moins de place pour d'autres expériences, que celle à qui il en reste dix-huit.

C'est pourquoi les fondateurs et les investisseurs expérimentés s'attendent souvent à ce qu'une décision de pivot repose sur une raison précise et énoncée, liée à des preuves concrètes tirées de l'approche actuelle — en écho à la discussion du parcours RED de ce programme selon laquelle le levier négatif exige une raison précise et énoncée plutôt qu'un vague espoir —, et non simplement sur la frustration ou la lassitude envers la voie actuelle.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une fondatrice teste une approche de produit précise depuis huit mois; l'analyse de l'économie unitaire (leçon 17) montre clairement que le coût d'acquisition des clients est insoutenable par rapport à leur valeur à vie, et il lui reste six mois de marge de manœuvre. En se fondant sur ces preuves précises et mesurables, elle pivote vers un autre segment de clientèle où les premières données laissent entrevoir une relation VVC/CAC beaucoup plus saine. [ASSUMPTION] Cette décision de pivot, fondée sur des preuves financières précises et prise alors qu'il reste une marge de manœuvre importante pour tester la nouvelle approche, est très différente de celle d'un fondateur qui pivote simplement par frustration face à la lenteur des premiers progrès, sans d'abord cerner des preuves concrètes de ce qui ne fonctionne pas précisément et sans marge de manœuvre suffisante pour tester une autre approche.

## Quiz de pratique

1. Que désigne généralement un « pivot » en affaires?
2. Pourquoi décider de pivoter est-il fondamentalement une décision financière, en lien avec la discussion sur la marge de manœuvre de la leçon 19?
3. Sur quoi une décision de pivot devrait-elle généralement reposer, plutôt que sur une simple frustration générale?

## Corrigé

1. Un changement important à la stratégie de base, au produit ou au marché cible d'une entreprise, habituellement en réponse à des preuves que l'approche initiale ne fonctionne pas.
2. Parce qu'une entreprise n'a qu'une marge de manœuvre et un capital limités pour vérifier ses hypothèses, et que la marge de manœuvre restante détermine directement l'espace disponible pour d'autres expériences avant qu'une décision de pivot doive être prise.
3. Sur des indicateurs précis et mesurables comme l'économie unitaire, les ratios VVC/CAC et la marge de manœuvre restante, plutôt que sur une frustration générale ou une intuition non vérifiée.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. Ça relie directement la notion stratégique de pivot à la notion financière de marge de manœuvre de la leçon 19.
3. Ça renforce l'approche fondée sur les preuves, plutôt que sur les émotions, que recommande la leçon pour cette décision.

## Points clés à retenir
- Un pivot est un changement stratégique important apporté en réponse à des preuves que l'approche initiale ne fonctionne pas.
- Cette décision est fondamentalement financière, puisque la marge de manœuvre restante détermine directement l'espace disponible pour d'autres expériences.
- Les décisions de pivot devraient reposer sur des preuves précises et mesurables — économie unitaire, VVC/CAC, marge de manœuvre —, et non sur la seule frustration générale.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un professionnel autorisé avant de prendre des décisions importantes de stratégie d'entreprise.
