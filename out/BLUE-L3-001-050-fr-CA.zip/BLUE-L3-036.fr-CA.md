---
id: BLUE-L3-036
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 36
title: "Pourquoi la protection de la propriété intellectuelle fait partie de la vraie valeur d'une entreprise"
summary: "Découvre pourquoi les brevets, les marques de commerce et les droits d'auteur ne sont pas de simples formalités juridiques, et pourquoi ils contribuent directement à l'achalandage et à l'évaluation d'une entreprise."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-036 : Pourquoi la protection de la propriété intellectuelle fait partie de la vraie valeur d'une entreprise

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Distinguer de façon générale les brevets, les marques de commerce et les droits d'auteur
- Expliquer pourquoi la protection de la propriété intellectuelle contribue directement à l'évaluation d'une entreprise
- Relier cette notion à la discussion sur l'achalandage de la leçon 5

## Contenu principal

La **propriété intellectuelle (PI)** désigne de façon générale les protections juridiques accordées aux créations de l'esprit — un **brevet** protège généralement une invention ou un procédé précis, une **marque de commerce** protège généralement des éléments d'identification de marque comme les noms et les logos, et un **droit d'auteur** protège généralement des œuvres originales comme des textes, des œuvres d'art ou du code logiciel. [VERIFIED FACT] La portée, les exigences et la durée précises de la protection de chaque type varient selon le territoire et sont régies par des lois précises sur la propriété intellectuelle.

Voici « pourquoi » ça se relie directement à la notion d'achalandage de la leçon 5 : la notoriété d'une marque (protégée par une marque de commerce), des inventions ou des procédés uniques (protégés par un brevet) et des œuvres créatives ou techniques exclusives (protégées par le droit d'auteur) contribuent souvent de façon importante, quoique intangible, à la valeur globale et à l'avantage concurrentiel d'une entreprise — une valeur qu'un acheteur lors d'une acquisition, ou un investisseur lors d'une ronde de financement, voudra précisément confirmer comme étant juridiquement protégée et réellement détenue (et non simplement utilisée sous licence) par l'entreprise elle-même.

C'est pourquoi l'examen de la propriété intellectuelle est couramment une composante précise de la vérification diligente (leçon 7), autant lors d'acquisitions d'entreprises que de levées de capitaux : un élément clé de propriété intellectuelle non protégé ou mal détenu représente un vrai risque pour la valeur acquise ou dans laquelle on investit.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un acheteur évalue une entreprise dont l'avantage concurrentiel repose en grande partie sur un procédé de fabrication unique et une marque bien connue. Pendant la vérification diligente, l'acheteur confirme précisément que le procédé de fabrication est protégé par un brevet existant, et que le nom et le logo de la marque sont des marques de commerce enregistrées réellement détenues par l'entreprise elle-même, et non simplement utilisées en vertu d'une entente informelle ou floue. [ASSUMPTION] Si la vérification diligente avait plutôt révélé que le procédé « unique » n'était pas réellement protégé par un brevet, ou que la marque de commerce appartenait personnellement à un fondateur sur le départ plutôt qu'à l'entreprise, l'acheteur devrait sérieusement revoir l'évaluation, puisqu'une part importante de la valeur d'achalandage présumée pourrait être à risque.

## Quiz de pratique

1. Que protègent généralement les brevets, les marques de commerce et les droits d'auteur?
2. Pourquoi la protection de la propriété intellectuelle se relie-t-elle directement à la notion d'achalandage de la leçon 5?
3. Pourquoi l'examen de la propriété intellectuelle est-il couramment une composante précise de la vérification diligente?

## Corrigé

1. Un brevet protège une invention ou un procédé précis; une marque de commerce protège des éléments d'identification de marque comme les noms et les logos; un droit d'auteur protège des œuvres originales comme des textes, des œuvres d'art ou du code logiciel.
2. Parce que la notoriété d'une marque, les procédés exclusifs et les œuvres créatives ou techniques contribuent souvent de façon importante, et intangible, à la valeur globale et à l'avantage concurrentiel d'une entreprise — le même genre de valeur que l'achalandage vise à refléter.
3. Parce qu'un élément clé de propriété intellectuelle non protégé ou mal détenu représente un vrai risque pour la valeur acquise ou dans laquelle on investit, qu'il vaut la peine de confirmer précisément avant d'engager des capitaux.

## Réponses et explications

1. C'est la définition de base, en trois parties, de la leçon.
2. Ça relie explicitement la leçon à la notion d'achalandage présentée à la leçon 5.
3. Ça relie l'examen de la propriété intellectuelle à la notion plus large de vérification diligente présentée à la leçon 7.

## Points clés à retenir
- Les brevets, les marques de commerce et les droits d'auteur protègent chacun un type différent de propriété intellectuelle.
- Cette protection contribue directement à l'achalandage et à l'évaluation globale d'une entreprise, comme d'autres facteurs de valeur intangibles.
- La propriété et la protection de la propriété intellectuelle sont couramment et précisément examinées pendant la vérification diligente lors d'acquisitions et de levées de capitaux.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un avocat autorisé en propriété intellectuelle pour obtenir des conseils adaptés à ta situation.
