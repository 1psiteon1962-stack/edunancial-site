---
id: BLUE-L3-038
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 38
title: "Pourquoi une convention de rachat entre associés devrait exister avant qu'on en ait besoin"
summary: "Découvre ce qu'une convention de rachat (*buy-sell*) apporte aux associés d'une entreprise, et pourquoi attendre qu'un événement déclencheur survienne pour la négocier est beaucoup trop tard."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-038 : Pourquoi une convention de rachat entre associés devrait exister avant qu'on en ait besoin

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce qu'une convention de rachat vise à régler
- Nommer les événements déclencheurs courants qu'une convention de rachat devrait prévoir
- Expliquer pourquoi négocier cette convention à l'avance est plus efficace que de la négocier après un événement déclencheur

## Contenu principal

Une **convention de rachat** (en anglais, *buy-sell agreement*; au Québec et au Canada, souvent intégrée à une convention entre actionnaires ou associés) est un contrat entre associés ou copropriétaires d'une entreprise qui établit à l'avance ce qu'il advient de la part d'un propriétaire si un événement déclencheur précis survient — un associé qui veut partir volontairement, le décès ou l'invalidité d'un associé, un divorce, ou un différend grave et impossible à régler entre associés.

Voici « pourquoi » ça fait étroitement écho à une notion abordée dans le parcours RED de ce programme au sujet des structures de dette des sociétés de personnes et des coentreprises : les associés démarrent souvent une entreprise avec une grande confiance et des objectifs harmonisés, mais les circonstances changent avec le temps, et sans convention établie d'avance, un événement déclencheur peut créer un grave conflit — un désaccord sur la valeur réelle de la part de l'associé qui part, sur la personne qui a le droit (ou l'obligation) de l'acheter, et à quelles conditions.

[VERIFIED FACT] Une convention de rachat bien rédigée porte habituellement sur la méthode d'évaluation (comment l'entreprise, ou la part de l'associé qui part, sera évaluée quand un événement déclencheur survient), sur les mécanismes de financement (comment le rachat sera réellement payé, parfois au moyen d'une assurance vie prévue précisément pour un rachat déclenché par un décès) et sur le processus précis à suivre — le tout négocié calmement, à l'avance, avant qu'un véritable événement déclencheur crée une pression émotionnelle ou financière qui rend une négociation équitable beaucoup plus difficile.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Deux associés fondent une entreprise ensemble, unis par une solide amitié, sans aucune convention de rachat officielle. Des années plus tard, l'un d'eux veut, de façon inattendue, quitter l'entreprise pour des raisons personnelles. Sans convention établie d'avance, ils se retrouvent dans une négociation difficile et chargée d'émotion sur la valeur réelle de la part de l'associé qui part et sur la façon dont l'associé qui reste financera le rachat — un différend qu'ils auraient pu éviter complètement s'ils avaient établi des modalités claires d'évaluation et de financement dans une convention de rachat des années plus tôt, avant que la situation ou les intérêts précis de l'un ou l'autre soient en jeu dans cette négociation particulière.

## Quiz de pratique

1. Qu'est-ce qu'une convention de rachat vise à régler?
2. Nomme deux événements déclencheurs courants qu'une convention de rachat devrait prévoir.
3. Pourquoi négocier cette convention à l'avance est-il plus efficace que de la négocier après qu'un événement déclencheur est survenu?

## Corrigé

1. Ce qu'il advient de la part d'un propriétaire dans une entreprise si un événement déclencheur précis survient, ce qui est établi à l'avance entre associés ou copropriétaires.
2. Deux parmi les suivants : un associé qui part volontairement, le décès ou l'invalidité d'un associé, un divorce, ou un différend grave et impossible à régler entre associés.
3. Parce qu'une négociation à l'avance se fait calmement, avant qu'un véritable événement déclencheur crée une pression émotionnelle ou financière qui rend une négociation équitable beaucoup plus difficile pour toutes les personnes concernées.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. Ça vérifie la compréhension de la portée pratique des situations que cette convention devrait couvrir.
3. C'est le raisonnement pratique central derrière le fait d'établir cette convention de façon proactive plutôt que réactive.

## Points clés à retenir
- Une convention de rachat établit à l'avance ce qu'il advient de la part d'un associé dans une entreprise si un événement déclencheur précis survient.
- Les événements déclencheurs courants comprennent le départ volontaire d'un associé, un décès, une invalidité, un divorce ou un différend impossible à régler.
- Négocier cette convention calmement à l'avance évite les négociations difficiles et sous pression qui surviennent si un événement déclencheur se produit sans plan établi.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un avocat autorisé avant de rédiger toute convention entre associés.
