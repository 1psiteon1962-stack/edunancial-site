---
id: BLUE-L3-045
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 45
title: "Pourquoi les multiples d'évaluation varient énormément d'un secteur à l'autre"
summary: "Découvre pourquoi un même BAIIA peut être évalué très différemment selon le secteur dans lequel une entreprise évolue, et ce qui explique cette différence."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-045 : Pourquoi les multiples d'évaluation varient énormément d'un secteur à l'autre

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce qu'est un multiple d'évaluation et comment on l'applique généralement
- Expliquer pourquoi un même BAIIA peut donner des évaluations très différentes d'un secteur à l'autre
- Nommer les facteurs qui entraînent généralement des multiples plus élevés ou plus bas

## Contenu principal

Un **multiple d'évaluation** applique un facteur précis à un indicateur financier — souvent le BAIIA (leçon 3) — pour estimer la valeur globale d'une entreprise; par exemple, une entreprise évaluée à « 4 fois son BAIIA » avec un BAIIA de 500 000 $ serait évaluée à environ 2 millions de dollars.

Voici « pourquoi » ce multiple varie autant d'un secteur à l'autre, même pour des entreprises qui ont un BAIIA identique : les multiples reflètent généralement l'opinion collective du marché sur le potentiel de croissance futur d'une entreprise, son niveau de risque et l'attrait général de ce type précis d'entreprise comme placement. [VERIFIED FACT] Les secteurs perçus comme ayant de meilleures perspectives de croissance, des revenus plus prévisibles et récurrents (un sujet abordé dans la prochaine leçon) ou un risque global plus faible obtiennent généralement des multiples d'évaluation plus élevés que les secteurs perçus comme à croissance plus lente, cycliques ou plus risqués — ce qui veut dire qu'un dollar de BAIIA dans un secteur n'est pas traité comme l'équivalent d'un dollar de BAIIA dans un autre.

C'est pourquoi comparer l'évaluation d'une entreprise précise à un multiple générique, qui ne tient pas compte du secteur, peut être sérieusement trompeur — les comparaisons utiles devraient se faire par rapport aux multiples typiques de ce secteur et de ce type d'entreprise précis, à partir de transactions comparables récentes lorsqu'il y en a.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] L'entreprise A, dans un secteur perçu comme à forte croissance avec de solides revenus récurrents, pourrait obtenir un multiple d'évaluation de 8 fois son BAIIA. L'entreprise B, qui a un BAIIA identique de 500 000 $, mais évolue dans un secteur à croissance plus lente et plus cyclique, pourrait n'obtenir qu'un multiple de 3. [ASSUMPTION] Ça veut dire que l'entreprise A pourrait être évaluée à environ 4 millions de dollars, alors que l'entreprise B, malgré exactement le même BAIIA sous-jacent, pourrait l'être à environ 1,5 million de dollars — ce qui montre pourquoi le BAIIA seul, sans tenir compte du multiple approprié au secteur, donne un portrait incomplet de la valeur de vente probable d'une entreprise.

## Quiz de pratique

1. Qu'est-ce qu'un multiple d'évaluation, et comment l'applique-t-on généralement?
2. Pourquoi un même BAIIA peut-il donner des évaluations très différentes d'un secteur à l'autre?
3. Pourquoi comparer l'évaluation d'une entreprise à un multiple générique, qui ne tient pas compte du secteur, peut-il être trompeur?

## Corrigé

1. Un facteur précis appliqué à un indicateur financier comme le BAIIA pour estimer la valeur globale d'une entreprise.
2. Parce que les multiples reflètent l'opinion du marché sur le potentiel de croissance, la prévisibilité des revenus et le niveau de risque de ce type précis d'entreprise, qui varient beaucoup d'un secteur à l'autre.
3. Parce que les comparaisons utiles devraient se faire par rapport aux multiples typiques de ce secteur et de ce type d'entreprise précis, et non à un chiffre générique qui ne tient pas compte des différences de croissance et de risque propres au secteur.

## Réponses et explications

1. C'est la définition et la mécanique de base de la leçon.
2. C'est le « pourquoi » central qui explique la variation des multiples selon le secteur.
3. C'est la mise en garde pratique par laquelle se termine la leçon, au sujet des comparaisons utiles.

## Points clés à retenir
- Un multiple d'évaluation applique un facteur à un indicateur comme le BAIIA pour estimer la valeur globale d'une entreprise.
- Un même BAIIA peut donner des évaluations très différentes selon la croissance, la prévisibilité des revenus et le risque perçus du secteur.
- Les comparaisons d'évaluation devraient se faire par rapport à des multiples propres au secteur, et non à un chiffre générique qui ne tient pas compte du secteur.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel autorisé avant de prendre des décisions d'évaluation d'entreprise.
