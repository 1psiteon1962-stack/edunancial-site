---
id: BLUE-L3-047
track: BLUE
officialTrackName: "Business"
level: 3
lessonNumber: 47
title: "Pourquoi la dépendance d'une entreprise envers un seul client est un signal d'alarme dans toute vente"
summary: "Découvre pourquoi le risque de concentration de la clientèle réduit directement la valeur d'une entreprise, même si la relation avec ce gros client semble stable aujourd'hui."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# BLUE-L3-047 : Pourquoi la dépendance d'une entreprise envers un seul client est un signal d'alarme dans toute vente

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce que veut dire le risque de concentration de la clientèle
- Expliquer pourquoi un acheteur vérifie précisément ce risque pendant la vérification diligente
- Relier cette notion aux idées de diversification et de corrélation abordées dans le parcours WHITE de ce programme

## Contenu principal

Le **risque de concentration de la clientèle** décrit une situation où un grand pourcentage des revenus totaux d'une entreprise provient d'un seul client, ou d'une petite poignée de clients, plutôt que d'être réparti sur une clientèle large et diversifiée.

Voici « pourquoi » on le traite comme un signal d'alarme sérieux pendant la vérification diligente (leçon 7) : ça reflète, à l'échelle d'une seule entreprise, les notions de diversification et de corrélation abordées dans le parcours WHITE de ce programme — tout comme un portefeuille de placements concentré dans un seul titre comporte un risque démesuré si ce titre éprouve des difficultés, une entreprise trop dépendante d'un seul client comporte un risque démesuré si ce client part, renégocie des conditions défavorables ou connaît lui-même des difficultés financières. [VERIFIED FACT] La perte d'un seul gros client peut ravager les revenus et la rentabilité d'une entreprise par ailleurs en bonne santé bien plus gravement que la perte de n'importe quel client ne toucherait une entreprise à la clientèle large et diversifiée.

C'est pourquoi un acheteur qui évalue une acquisition examine précisément la concentration de la clientèle pendant la vérification diligente, et pourquoi une entreprise qui dépend beaucoup d'un ou de quelques clients sera généralement évaluée à un multiple (leçon 45) nettement plus bas qu'une entreprise par ailleurs comparable dont la clientèle est diversifiée, ce qui reflète ce risque précis et mesurable.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une entreprise tire 60 % de ses revenus totaux d'une seule relation client de longue date. Pendant la vérification diligente, un acheteur potentiel considère qu'il s'agit d'un risque important : si ce client partait, était acquis par un concurrent ou décidait simplement de changer de fournisseur, les revenus et la rentabilité de l'entreprise pourraient être ravagés presque du jour au lendemain. [ASSUMPTION] Même si la relation est stable depuis des années et que le vendeur se dit confiant qu'elle se poursuivra, l'acheteur intégrera probablement directement ce risque de concentration dans une offre fondée sur un multiple d'évaluation plus bas, ou demandera des protections contractuelles précises, ce qui reflète le risque réel et mesurable que crée cette dépendance, peu importe la stabilité passée de la relation.

## Quiz de pratique

1. Que décrit le risque de concentration de la clientèle?
2. Pourquoi ce risque est-il démesuré, selon le parallèle avec la diversification du parcours WHITE?
3. Comment le risque de concentration de la clientèle influe-t-il habituellement sur l'évaluation d'une entreprise?

## Corrigé

1. Un grand pourcentage des revenus totaux d'une entreprise qui provient d'un seul client ou d'une petite poignée de clients, plutôt que d'une clientèle diversifiée.
2. Parce que, comme pour un portefeuille de placements concentré, la perte de ce seul gros client peut ravager les revenus et la rentabilité de l'entreprise bien plus gravement que la perte de n'importe quel client ne toucherait une entreprise largement diversifiée.
3. Il donne généralement un multiple d'évaluation nettement plus bas que celui d'une entreprise par ailleurs comparable dont la clientèle est diversifiée, ce qui reflète le risque précis et mesurable qu'il crée.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. Ça relie explicitement la notion aux idées de diversification et de corrélation du parcours WHITE, ce qui renforce l'apprentissage entre les parcours.
3. Ça relie directement le risque à la notion de multiple d'évaluation de la leçon 45.

## Points clés à retenir
- Le risque de concentration de la clientèle existe quand une grande part des revenus dépend d'un ou de quelques clients.
- Ça reflète la notion de risque de diversification en placement — la concentration crée une vulnérabilité démesurée à un point de défaillance unique.
- Les acheteurs vérifient précisément ce risque pendant la vérification diligente, et il donne habituellement un multiple d'évaluation plus bas pour l'entreprise touchée.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un professionnel autorisé avant de prendre des décisions d'évaluation ou d'acquisition d'entreprise.
