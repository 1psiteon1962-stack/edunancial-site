---
id: GREEN-L1-007
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 7
locale: en-GB
title: "Payroll Tax: National Insurance and Similar Contributions"
summary: "Introduces payroll tax as a category tied specifically to employment wages, often funding pensions and health or welfare programmes."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Payroll Tax: National Insurance and Similar Contributions

## Learning Objectives

- Define payroll tax and how it differs from general income tax.
- Explain that payroll tax is often split between employer and employee.
- Identify common programmes funded by payroll tax.

## Core Content

Payroll tax is a tax specifically tied to employment wages. It's related to income tax but distinct from it — while income tax funds general government spending, payroll tax is frequently linked to specific programmes, most commonly state pensions and health or welfare benefits. (In the UK, for example, the main payroll tax is National Insurance contributions, which help build entitlement to the State Pension and certain benefits.)

In many systems, payroll tax is split: part is deducted from the employee's pay, and part is paid directly by the employer on top of the wage, meaning the true cost of an employee to a business is higher than just the take-home amount. This split matters later when we look at self-employment, because a self-employed person often ends up responsible for their own contributions, sometimes at different rates. (In the UK, employees pay employee National Insurance through payroll, employers pay employer National Insurance on top, and the self-employed pay their own classes through Self Assessment; check HMRC for current rates.)

## Worked Example

**Question:** An employer pays a worker a wage, and separately sends an additional payroll tax payment to the government. Is the employer's payroll tax cost part of the worker's pay packet?

**Student:** I'd assume it's separate since the worker never sees that money.

**Guide:** Right, but is it still a cost of employing that worker?

**Student:** Yes — it's an extra cost on top of wages, even though it doesn't show up on the payslip.

**Guide:** Exactly, which is why 'cost of an employee' is usually higher than the wage alone.

## Practice Quiz

**Question 1.** Payroll tax is specifically tied to:

A) Property
B) Employment wages
C) Retail purchases
D) Inheritance

**Question 2.** Payroll tax commonly funds:

A) Pensions and health or welfare programmes
B) Only road construction
C) Only national defence
D) Nothing specific

**Question 3.** In many systems, payroll tax is:

A) Paid only by the employer
B) Paid only by the employee
C) Split between employer and employee
D) Never actually paid

**Question 4.** The true cost of employing a worker is often:

A) Exactly the amount on their payslip
B) Higher than their pay due to employer-side payroll tax
C) Lower than their pay
D) Unrelated to payroll tax

## Answer Key

1. B, 2. A, 3. C, 4. B

## Answers and Explanations

**1.** Payroll tax is distinct from general income tax because it's specifically linked to wages from employment.

**2.** Pension systems and health or welfare programmes are commonly funded or supported through dedicated payroll tax revenue.

**3.** Splitting the tax between employer and employee is a common structural choice in many systems.

**4.** Because employers pay a share on top of wages, the full cost of an employee exceeds their pay.

## Key Takeaways

- Payroll tax is tied specifically to employment wages, distinct from general income tax.
- It commonly funds pensions and health or welfare programmes.
- Many systems split payroll tax between employer and employee.
- This split becomes especially relevant for self-employed people, covered in a later lesson.
