---
id: GREEN-L1-046
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 46
locale: en-GB
title: "Tax Enquiries and Audits: What They Are and Why They Happen"
summary: "Demystifies tax audits and enquiries, framing them as a verification procedure rather than an automatic accusation of wrongdoing."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Tax Enquiries and Audits: What They Are and Why They Happen

## Learning Objectives

- Define what an audit or tax enquiry is.
- Identify common, non-accusatory reasons an audit might occur.
- Explain how good record-keeping directly protects someone during an audit.

## Core Content

An audit — in the UK usually called a compliance check or an enquiry into your return — is a review process where a tax authority examines a filed return more closely to verify that the reported information is accurate. It's worth separating the fact of being checked from an assumption of guilt — audits happen for many reasons, including random selection, statistical anomalies (numbers that look unusual compared to similar taxpayers), or simply because a particular claim or income type draws more routine scrutiny. (In the UK, for example, HMRC can open an enquiry into a Self Assessment return within a set time limit after it's filed, and it publishes guidance on what to expect and on your rights during a compliance check.)

This is where the earlier record-keeping lesson pays off most directly. Someone who has kept clean, organised documentation throughout the year can typically respond to an audit calmly and efficiently, producing support for whatever is being questioned. Someone without records may struggle to substantiate claims even if those claims were entirely legitimate — meaning good record-keeping isn't just about avoiding evasion, it's active protection for honest taxpayers whose returns simply get selected for review.

## Worked Example

**Question:** Someone receives a letter saying their return is being checked and immediately assumes they must have done something illegal. Is that assumption accurate?

**Student:** Based on this lesson, not necessarily — audits can happen for reasons unrelated to wrongdoing, like random selection or an unusual-looking number.

**Guide:** What determines how smoothly this person gets through the check?

**Student:** Whether they kept good records — if they have documentation for what they claimed, they can substantiate it calmly, even if they did nothing wrong.

**Guide:** Exactly — an audit notice is a request for verification, not automatically an accusation.

## Practice Quiz

**Question 1.** An audit is best described as:

A) An automatic accusation of a crime
B) A review process to verify that reported information is accurate
C) A type of tax credit
D) A penalty that always applies

**Question 2.** Audits can be triggered by:

A) Only clear wrongdoing
B) Random selection, statistical anomalies, or routine scrutiny of certain claims
C) Nothing — audits are entirely random with no other cause
D) Only self-employed people

**Question 3.** Good record-keeping helps most directly during an audit by:

A) Having no effect
B) Allowing claims to be substantiated calmly and efficiently
C) Guaranteeing no audit ever happens
D) Only mattering for businesses

**Question 4.** Is receiving an audit notice automatically proof of wrongdoing?

A) Yes, always
B) No — it's a verification request, not an automatic accusation
C) Only for companies
D) Only if a refund was received

## Answer Key

1. B, 2. B, 3. B, 4. B

## Answers and Explanations

**1.** An audit's function is verification, not an automatic finding or accusation of guilt.

**2.** Multiple non-accusatory triggers exist, including simple random selection.

**3.** Documentation is exactly what lets an honest taxpayer respond to questions efficiently instead of scrambling.

**4.** The notice itself signals a request to verify, not a predetermined conclusion.

## Key Takeaways

- An audit or enquiry is a verification review, not an automatic accusation of wrongdoing.
- Audits can be triggered by random selection, statistical anomalies, or routine scrutiny.
- Good record-keeping is direct, practical protection during an audit.
- Being audited and being guilty of something are two entirely different things.
