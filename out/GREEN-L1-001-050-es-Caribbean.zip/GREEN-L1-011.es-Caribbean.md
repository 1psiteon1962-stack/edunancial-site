---
id: GREEN-L1-011
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 11
locale: es-Caribbean
title: "Ingreso bruto e ingreso neto"
summary: "Aclara la diferencia entre el ingreso bruto y el ingreso neto, una distinción fundamental para leer talonarios de pago, hacer presupuestos y entender las finanzas de un negocio."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Ingreso bruto e ingreso neto

## Objetivos de aprendizaje

- Definir el ingreso bruto y el ingreso neto.
- Explicar qué suele causar la diferencia entre ambos.
- Aplicar la distinción a un caso de cheque de pago.

## Contenido principal

El ingreso bruto es la cantidad total ganada antes de restar cualquier cosa. El ingreso neto es lo que queda después de las restas: los impuestos y, a menudo, otras deducciones como las aportaciones al retiro o las primas del seguro de salud. La diferencia entre el bruto y el neto es donde la mayoría de las personas se sorprende la primera vez que ve un cheque de pago real.

Esta distinción importa mucho más allá de los cheques de pago. Las empresas hablan de ingresos brutos y de ganancia neta con la misma lógica de fondo: el bruto es el total de la línea superior y el neto es lo que queda después de restar los costos y las obligaciones. Siempre que escuche que una cifra se describe como «bruta», la primera pregunta que vale la pena hacerse es: ¿bruta de qué exactamente, y cuánto más pequeña será la neta?

## Ejemplo práctico

**Pregunta:** Una oferta de empleo dice que el salario es de $60,000. ¿Es esa la cantidad que realmente llegará a la cuenta bancaria cada año?

**Estudiante:** Supongo que no, porque primero se descuentan los impuestos y otras deducciones.

**Guía:** Correcto. ¿Cómo llamaría a la cifra de $60,000, y cómo llamaría a la cantidad que realmente llega a la cuenta?

**Estudiante:** Los $60,000 son el ingreso bruto, y lo que queda después de impuestos y deducciones es el ingreso neto.

**Guía:** Exactamente. Siempre haga su presupuesto con el neto, no con el bruto.

## Prueba práctica

**Pregunta 1.** El ingreso bruto es:

A) La cantidad después de todas las deducciones
B) La cantidad total ganada antes de cualquier deducción
C) Solo el ingreso de inversiones
D) Siempre igual al ingreso neto

**Pregunta 2.** El ingreso neto es:

A) La cantidad antes de las deducciones
B) Lo que queda después de restar los impuestos y otras deducciones
C) Algo ajeno al ingreso bruto
D) Siempre mayor que el ingreso bruto

**Pregunta 3.** ¿Por qué importa la diferencia entre el bruto y el neto al hacer un presupuesto?

A) No importa
B) Hacer el presupuesto con el bruto en lugar del neto puede llevar a sobrestimar el dinero disponible
C) El neto siempre es mayor que el bruto
D) El bruto no tiene importancia para las empresas

**Pregunta 4.** Las empresas usan una distinción similar entre bruto y neto para:

A) Los ingresos frente a la ganancia
B) Nada: es solo un concepto de finanzas personales
C) Solo la cantidad de empleados
D) Solo el gasto en mercadeo

## Clave de respuestas

1. B, 2. B, 3. B, 4. A

## Respuestas y explicaciones

**1.** El bruto es el total de la línea superior, antes de deducciones: la cifra principal.

**2.** El neto es la cantidad real que queda después de los impuestos y otras restas, y es lo que realmente llega a su cuenta.

**3.** Planificar con la cifra bruta implica el riesgo de suponer que tiene más dinero disponible para gastar del que realmente tendrá.

**4.** Las empresas aplican la misma lógica a los ingresos (bruto) frente a la ganancia (neto).

## Puntos clave

- El ingreso bruto es el total antes de deducciones; el ingreso neto es lo que queda después de ellas.
- La diferencia suele corresponder a los impuestos más otras retenciones, como el retiro o los seguros.
- Siempre haga su presupuesto con el ingreso neto, no con el bruto.
- La misma lógica de bruto frente a neto se aplica a los ingresos y la ganancia de un negocio.
