---
id: GREEN-L1-014
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 14
locale: es-Caribbean
title: "Formulario W-2 o Formulario 1099: ¿empleado o contratista?"
summary: "Presenta los dos documentos de informe de ingresos más comunes en los sistemas que los utilizan, en conexión directa con la distinción entre empleado y trabajador por cuenta propia de cursos anteriores."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Formulario W-2 o Formulario 1099: ¿empleado o contratista?

## Objetivos de aprendizaje

- Explicar la diferencia general entre un documento de ingresos de tipo empleado y uno de tipo contratista.
- Conectar esta distinción con el concepto de trabajo por cuenta propia frente a dueño de negocio de cursos anteriores.
- Reconocer por qué esta clasificación afecta a quién le corresponde la retención.

## Contenido principal

En algunos sistemas tributarios, particularmente el de los Estados Unidos, se usan formularios distintos para informar diferentes tipos de ingreso: uno para los empleados (comúnmente el W-2), en el que el patrono retiene impuestos durante el año, y otro para los contratistas independientes (comúnmente el 1099), en el que no se retiene impuesto y el trabajador es responsable de hacer sus propios pagos estimados. Otros países usan nombres distintos, pero la distinción de fondo —empleado frente a contratista independiente— aparece casi en todas partes. (En Puerto Rico, por ejemplo, los equivalentes locales son el Formulario 499R-2/W-2PR para empleados y los formularios de la serie 480.6 para ciertos pagos por servicios.)

Esto corresponde directamente al concepto de trabajo por cuenta propia visto antes en su currículo: a un empleado alguien más le retiene los impuestos automáticamente, mientras que un contratista independiente funciona más como una persona que trabaja por cuenta propia y debe reservar y pagar sus propios impuestos de forma proactiva. No entender en qué categoría está usted es uno de los errores tributarios más comunes y costosos: un contratista que gasta todo su pago sin reservar nada para impuestos puede llevarse una sorpresa dolorosa al momento de presentar su planilla.

## Ejemplo práctico

**Pregunta:** Una joven diseñadora web trabaja para varios clientes distintos, fija su propio horario y usa su propio equipo. ¿Es más probable que sea empleada o contratista independiente?

**Estudiante:** Como fija su propio horario y trabaja para varios clientes, parece más una contratista independiente.

**Guía:** Si eso es así, ¿quién es responsable de reservar sus pagos de impuestos durante el año?

**Estudiante:** Ella misma: como ningún patrono le retiene impuestos, tiene que hacerlo por su cuenta.

**Guía:** Exactamente. Por eso los contratistas necesitan planificar activamente sus impuestos en lugar de suponer que se manejan solos.

## Prueba práctica

**Pregunta 1.** Un documento de ingresos de tipo empleado normalmente refleja:

A) Ningún impuesto retenido
B) Impuestos retenidos durante el año por el patrono
C) Solo la ganancia de un negocio
D) Solo el ingreso de inversiones

**Pregunta 2.** Un contratista independiente, en general, es responsable de:

A) Nada: los impuestos son automáticos
B) Reservar y pagar sus propios impuestos estimados
C) Solo el impuesto sobre las ventas
D) No presentar nunca ningún documento

**Pregunta 3.** ¿Con qué concepto anterior se conecta más directamente esta distinción entre empleado y contratista?

A) Los bienes públicos
B) El trabajo por cuenta propia frente a ser dueño de negocio
C) Los tramos impositivos marginales
D) El impuesto sobre la propiedad

**Pregunta 4.** Un error costoso común de los nuevos contratistas es:

A) Presentar la planilla demasiado temprano
B) Gastar todo el ingreso sin reservar dinero para los impuestos
C) Retener demasiados impuestos
D) Tener demasiadas propiedades

## Clave de respuestas

1. B, 2. B, 3. B, 4. B

## Respuestas y explicaciones

**1.** Los informes de tipo empleado suelen ir acompañados de una retención automática a cargo del patrono.

**2.** Sin un patrono que retenga en su nombre, los contratistas deben manejar de forma proactiva sus propios pagos de impuestos.

**3.** Esta es la expresión, dentro del sistema tributario, del concepto de trabajo por cuenta propia visto antes en el currículo.

**4.** Gastar el 100 % del ingreso como contratista sin reservar una parte para impuestos es uno de los errores tempranos más comunes.

## Puntos clave

- El ingreso de tipo empleado generalmente tiene impuestos retenidos automáticamente; el de tipo contratista generalmente no.
- Esta distinción refleja el concepto de trabajo por cuenta propia frente a empleo de lecciones anteriores.
- Los contratistas deben reservar dinero para impuestos de forma proactiva a lo largo del año.
- Clasificarse mal, o no planificar para la diferencia, es un error común y costoso.
