---
id: GREEN-L1-024
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 24
locale: es-Caribbean
title: "Lo básico para llevar registros: recibos, estados de cuenta y documentación"
summary: "Presenta el hábito y la lógica de llevar registros tributarios como una protección, no solo como papeleo."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Lo básico para llevar registros: recibos, estados de cuenta y documentación

## Objetivos de aprendizaje

- Explicar por qué llevar registros importa para los impuestos.
- Identificar categorías comunes de documentos que vale la pena guardar.
- Describir un hábito sencillo para mantenerse organizado durante el año.

## Contenido principal

Llevar buenos registros es la base silenciosa de casi todos los demás temas tributarios de este curso: las deducciones, los créditos y las reclamaciones por trabajo por cuenta propia solo se sostienen si usted puede respaldarlos con documentación. Entre las categorías comunes que vale la pena guardar están los recibos de compras deducibles, los estados de cuenta bancarios y de inversiones, los talonarios de pago, las facturas (para quienes trabajan por cuenta propia) y las planillas de años anteriores.

El hábito que separa a quienes manejan esto sin problemas de quienes corren cada año es sencillo: recopile y organice la documentación a medida que ocurre, no meses después, al momento de presentar la planilla. Una sola carpeta (física o digital) que se abra al comienzo del año, en la que se vayan echando los documentos a medida que surgen, es mejor que tratar de reconstruir de memoria y con prisa un año de actividad financiera antes de una fecha límite. Los buenos registros no solo le ayudan a presentar con exactitud: son su protección si alguna vez se cuestiona una reclamación.

## Ejemplo práctico

**Pregunta:** El dueño de un pequeño negocio echa todos sus recibos en una caja de zapatos durante el año, sin ningún orden. ¿Es eso mejor que nada, y podría mejorarse?

**Estudiante:** Es mejor que perder los recibos por completo, pero igual suena desordenado para trabajar con ellos después.

**Guía:** ¿Cómo sería una pequeña mejora, sin necesidad de un sistema completamente pulido?

**Estudiante:** Tal vez solo separar los recibos en unas cuantas categorías básicas a medida que llegan, en lugar de tener una sola pila grande que ordenar de una vez.

**Guía:** Correcto. La meta no es la perfección, sino facilitarle el trabajo a su yo del futuro.

## Prueba práctica

**Pregunta 1.** Llevar registros importa sobre todo porque:

A) Se exige sin ninguna razón
B) Respalda las deducciones, los créditos y las reclamaciones si alguna vez se cuestionan
C) No tiene nada que ver con los impuestos
D) Solo las empresas lo necesitan

**Pregunta 2.** Entre los documentos comunes que vale la pena guardar están:

A) Recibos, estados de cuenta, talonarios de pago, facturas
B) Solo publicaciones en redes sociales
C) Nada: los registros digitales no cuentan
D) Solo las contraseñas del banco

**Pregunta 3.** El hábito recomendado es:

A) Reconstruirlo todo de memoria al momento de presentar la planilla
B) Recopilar y organizar la documentación a medida que ocurre durante el año
C) Botar todos los documentos de inmediato
D) Guardar registros solo en el caso de las personas ricas

**Pregunta 4.** Los buenos registros sirven como:

A) Decoración
B) Protección si alguna vez se cuestiona una reclamación
C) Un sustituto de la planilla
D) Nada útil

## Clave de respuestas

1. B, 2. A, 3. B, 4. B

## Respuestas y explicaciones

**1.** Toda deducción, crédito o reclamación necesita, en última instancia, estar respaldada por documentación real si alguna vez se revisa.

**2.** Los recibos, los estados de cuenta, los talonarios de pago y las facturas forman la columna vertebral de un sistema sólido de registros.

**3.** Recopilar de forma continua y con poco esfuerzo es mejor que una carrera estresante de fin de año para reconstruir el historial financiero.

**4.** La documentación es lo que respalda una reclamación si una autoridad tributaria alguna vez hace preguntas sobre ella.

## Puntos clave

- Llevar registros respalda cada deducción, crédito y reclamación que usted haga.
- Guarde los recibos, los estados de cuenta, los talonarios de pago y las facturas a medida que surgen.
- La organización continua es mejor que la reconstrucción de último minuto.
- Los buenos registros son su protección si alguna vez se cuestiona una reclamación.
