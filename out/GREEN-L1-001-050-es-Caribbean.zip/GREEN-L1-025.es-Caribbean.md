---
id: GREEN-L1-025
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 25
locale: es-Caribbean
title: "Gastos de negocio comúnmente deducibles"
summary: "Repasa las categorías generales de gastos de negocio que comúnmente son deducibles, a nivel conceptual, dada la variación entre jurisdicciones."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Gastos de negocio comúnmente deducibles

## Objetivos de aprendizaje

- Explicar el principio general detrás de los gastos de negocio deducibles.
- Identificar categorías comunes de gastos deducibles.
- Reconocer por qué los gastos personales generalmente no cualifican.

## Contenido principal

La mayoría de los sistemas tributarios permite a los negocios deducir los gastos que son «ordinarios y necesarios» para operar el negocio, es decir, normales para ese tipo de negocio y realmente necesarios para operar, no lujosos ni puramente personales. Entre las categorías comunes, descritas de forma general, están los suministros y materiales, el alquiler del local del negocio, los viajes relacionados con el negocio, el mercadeo y la publicidad, los servicios profesionales (como un abogado o un contador) y el equipo.

Una prueba útil que conviene recordar: ¿existiría este gasto si el negocio no existiera? Una computadora portátil comprada específicamente para trabajos de clientes pasa esa prueba con más claridad que unas vacaciones justificadas vagamente como «networking». Mezclar gastos personales y de negocio sin una línea clara es uno de los errores más comunes de los nuevos dueños de negocio, y precisamente por eso la lección anterior sobre llevar registros importa tanto aquí: una documentación limpia hace defendible la línea entre lo personal y lo del negocio.

## Ejemplo práctico

**Pregunta:** El dueño de un negocio compra una computadora portátil que usa exclusivamente para trabajos de diseño para clientes. Más tarde, también registra como gasto unas vacaciones familiares y las llama «networking». ¿Se tratan ambas cosas de la misma manera?

**Estudiante:** No lo creo: la computadora está claramente vinculada al trabajo real del negocio.

**Guía:** ¿Qué prueba aplicaría usted a las vacaciones?

**Estudiante:** ¿Existiría ese gasto si el negocio no existiera? La computadora probablemente no se habría comprado sin el negocio; las vacaciones probablemente se habrían hecho de todos modos.

**Guía:** Exactamente. Ese es el tipo de razonamiento que separa un gasto de negocio legítimo de un gasto personal disfrazado de gasto de negocio.

## Prueba práctica

**Pregunta 1.** Un criterio general común para los gastos de negocio deducibles es:

A) Cualquier gasto, sea personal o no
B) Que sea ordinario y necesario para el negocio
C) Solo los gastos de más de $10,000
D) Solo los gastos pagados en efectivo

**Pregunta 2.** Entre las categorías comunes de gastos de negocio deducibles están:

A) Suministros, alquiler, viajes, mercadeo, servicios profesionales y equipo
B) Solo la compra de comida para la casa
C) Solo las vacaciones
D) Solo la ropa personal

**Pregunta 3.** Una prueba útil para saber si un gasto está relacionado con el negocio es:

A) ¿Existiría este gasto si el negocio no existiera?
B) ¿Es caro?
C) ¿Se pagó en efectivo?
D) ¿Ocurrió en un día de semana?

**Pregunta 4.** Mezclar gastos personales y de negocio sin una línea clara:

A) Se recomienda
B) Es un error común y arriesgado de los nuevos dueños de negocio
C) No tiene consecuencias
D) Solo importa para las grandes corporaciones

## Clave de respuestas

1. B, 2. A, 3. A, 4. B

## Respuestas y explicaciones

**1.** «Ordinario y necesario» es un criterio general de uso amplio, aunque las reglas exactas varían según la jurisdicción.

**2.** Estas categorías representan los costos operativos típicos de la mayoría de los tipos de negocio.

**3.** Esta prueba ayuda a separar los gastos realmente vinculados al negocio de los gastos personales que se reetiquetan vagamente.

**4.** Desdibujar la línea entre lo personal y lo del negocio sin documentación es una trampa común que llevar registros ayuda a evitar.

## Puntos clave

- Los gastos de negocio deducibles son, en general, los que son ordinarios y necesarios para el negocio.
- Entre las categorías comunes están los suministros, el alquiler, los viajes, el mercadeo, los servicios profesionales y el equipo.
- Una prueba útil: ¿existiría el gasto sin el negocio?
- Mezclar gastos personales y de negocio sin una línea clara es un error común y arriesgado.
