---
id: GREEN-L1-026
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 26
locale: es-Caribbean
title: "Lo básico de la deducción por oficina en el hogar"
summary: "Presenta el concepto de deducir una parte de los gastos del hogar cuando una parte de la casa se usa para el negocio, con énfasis en la lógica básica de elegibilidad."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Lo básico de la deducción por oficina en el hogar

## Objetivos de aprendizaje

- Explicar la lógica general de una deducción por oficina en el hogar.
- Identificar el principio de elegibilidad común (uso regular y exclusivo).
- Reconocer por qué esta deducción requiere una documentación cuidadosa.

## Contenido principal

Cuando una parte de la casa se usa de forma regular y exclusiva para el negocio, muchos sistemas permiten deducir una parte de los costos relacionados con el hogar —como el alquiler, los servicios públicos o una parte de los intereses de la hipoteca—, en proporción a cuánto de la casa se usa para el negocio. La idea de elegibilidad básica en la mayoría de los sistemas es el «uso regular y exclusivo»: el espacio debe usarse de forma constante para el negocio y, en general, solo para el negocio, no como un cuarto de visitas que de vez en cuando sirve de oficina.

Esta deducción es valiosa, pero históricamente ha sido un área de escrutinio adicional en algunos sistemas tributarios, precisamente porque la línea entre el uso personal y el uso de negocio de una casa puede volverse borrosa. Eso la convierte en un buen ejemplo práctico de por qué importa la lección anterior sobre llevar registros: una documentación clara del uso exclusivo para el negocio del espacio, y de cómo se calculó la proporción deducible, es lo que hace defendible esta deducción.

## Ejemplo práctico

**Pregunta:** Un trabajador independiente trabaja desde un cuarto adicional que también se usa para visitas dos veces al año. ¿Cumple claramente ese cuarto con un criterio de «uso regular y exclusivo»?

**Estudiante:** Parece dudoso, porque no se usa solo para el negocio.

**Guía:** ¿Qué haría el caso más claro, en un sentido o en otro?

**Estudiante:** Si el cuarto se usara solo para trabajar, con un escritorio dedicado y ningún otro uso, cualificaría claramente. El uso ocasional para visitas lo enturbia.

**Guía:** Correcto. Esta es exactamente la clase de zona gris donde más importan la documentación y una organización clara y constante.

## Prueba práctica

**Pregunta 1.** La deducción por oficina en el hogar generalmente aplica cuando un espacio:

A) Se usa de vez en cuando para cualquier cosa
B) Se usa de forma regular y exclusiva para el negocio
C) Se usa solo los fines de semana
D) Es propio y no alquilado

**Pregunta 2.** ¿Qué se puede deducir normalmente, de forma proporcional, bajo esta regla?

A) Todos los gastos de la casa, sin importar el uso para el negocio
B) Una parte de costos como el alquiler, los servicios públicos o los intereses de la hipoteca, según la proporción de uso para el negocio
C) Nada relacionado con la vivienda
D) Solo la compra de muebles

**Pregunta 3.** ¿Por qué esta deducción ha atraído históricamente un escrutinio adicional en algunos sistemas?

A) Casi nunca se usa
B) La línea entre el uso personal y el de negocio puede ser borrosa
C) En realidad no existe
D) Solo aplica a las grandes corporaciones

**Pregunta 4.** ¿Qué lección anterior es especialmente relevante para defender esta deducción?

A) Los bienes públicos
B) Llevar registros
C) El impuesto sobre las ventas
D) El estado civil para la planilla

## Clave de respuestas

1. B, 2. B, 3. B, 4. B

## Respuestas y explicaciones

**1.** El «uso regular y exclusivo» es el principio de elegibilidad común en muchos de los sistemas que ofrecen esta deducción.

**2.** La deducción es generalmente proporcional: está vinculada a cuánto de la casa se usa realmente para el negocio.

**3.** Como en una casa el uso personal y el de negocio pueden superponerse, esta área suele recibir una revisión más cuidadosa.

**4.** Una documentación sólida es exactamente lo que hace defendible una deducción por oficina en el hogar si alguna vez se cuestiona.

## Puntos clave

- Las deducciones por oficina en el hogar generalmente requieren un uso regular y exclusivo del espacio para el negocio.
- La deducción es proporcional a cuánto de la casa se usa para el negocio.
- Esta área suele recibir un escrutinio adicional porque el uso personal y el de negocio pueden confundirse.
- Una documentación cuidadosa es esencial para defender esta deducción.
