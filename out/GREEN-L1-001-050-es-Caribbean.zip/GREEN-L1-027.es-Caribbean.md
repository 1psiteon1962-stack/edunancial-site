---
id: GREEN-L1-027
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 27
locale: es-Caribbean
title: "La depreciación: repartir un costo a lo largo del tiempo"
summary: "Presenta la depreciación como el concepto de repartir el costo de un bien duradero del negocio a lo largo de varios años, en lugar de deducirlo todo de una vez."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# La depreciación: repartir un costo a lo largo del tiempo

## Objetivos de aprendizaje

- Definir la depreciación en términos sencillos.
- Explicar por qué existe la depreciación como concepto.
- Distinguir los bienes que probablemente se deprecien de los que normalmente se registran como gasto de inmediato.

## Contenido principal

Cuando un negocio compra algo que usará durante años —un vehículo, maquinaria, un edificio—, normalmente no tiene sentido deducir todo el costo en el año de la compra. En cambio, muchos sistemas tributarios exigen o permiten que ese costo se reparta, o se deprecie, a lo largo de la vida útil del bien, de modo que la deducción coincida con los años en que el bien realmente ayuda a generar ingresos.

La lógica refleja el sentido contable básico: si un equipo se usará durante diez años, tratar todo su costo como un gasto de un solo año subestimaría la ganancia del primer año y la sobrestimaría en cada uno de los años siguientes. La depreciación suaviza eso. En cambio, los gastos de negocio de consumo cotidiano —los materiales de oficina, por ejemplo— normalmente se registran como gasto completo de inmediato, porque no aportan valor durante varios años como lo hace el equipo duradero.

## Ejemplo práctico

**Pregunta:** Una panadería compra un horno comercial que se espera dure diez años. ¿Debe deducirse todo el costo de inmediato o repartirse?

**Estudiante:** Según esta lección, parece que debe repartirse, porque el horno se usará durante muchos años.

**Guía:** ¿Por qué repartirlo da una imagen más exacta que deducirlo todo de una vez?

**Estudiante:** Porque el horno ayuda a generar ingresos durante los diez años, no solo el año en que se compró, así que asignar el costo a esos años es más exacto.

**Guía:** Exactamente. Esa es la lógica central de la depreciación.

## Prueba práctica

**Pregunta 1.** La depreciación se describe mejor como:

A) Deducir de inmediato todo el costo de un bien
B) Repartir el costo de un bien a lo largo de su vida útil
C) Ignorar por completo el costo de los bienes del negocio
D) Un tipo de impuesto sobre las ventas

**Pregunta 2.** La depreciación normalmente se aplica a:

A) Bienes duraderos como equipo, vehículos o edificios
B) Los materiales de oficina de uso diario
C) Los pagos del impuesto sobre las ventas
D) La retención de la nómina

**Pregunta 3.** ¿Por qué no deducir en el primer año todo el costo de un bien que dura diez años?

A) Es ilegal comprar equipo
B) Distorsionaría la ganancia de los años en que el bien realmente ayuda a generar ingresos
C) No hay razón; es arbitrario
D) La depreciación no aplica a los negocios

**Pregunta 4.** Los materiales de consumo cotidiano normalmente:

A) Se deprecian a lo largo de diez años
B) Se registran como gasto completo de inmediato
C) Nunca son deducibles
D) Se tratan igual que los bienes raíces

## Clave de respuestas

1. B, 2. A, 3. B, 4. B

## Respuestas y explicaciones

**1.** La depreciación hace coincidir el costo de un bien con los años en que realmente aporta valor, en lugar de concentrarlo en un solo año.

**2.** Los bienes duraderos son los candidatos típicos a la depreciación, a diferencia de los materiales de consumo de corta duración.

**3.** Repartir el costo evita distorsionar la imagen de la ganancia en el año de la compra frente a los años posteriores.

**4.** Los materiales se consumen rápido, así que registrarlos como gasto de inmediato refleja mejor su valor a corto plazo.

## Puntos clave

- La depreciación reparte el costo de un bien a lo largo de su vida útil en lugar de deducirlo todo de una vez.
- Se aplica a bienes duraderos como equipo, vehículos y edificios.
- Esto produce una imagen más exacta, año por año, de la ganancia del negocio.
- Los gastos de consumo cotidiano normalmente se deducen de inmediato.
