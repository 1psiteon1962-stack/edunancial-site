---
id: GREEN-L1-028
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 28
locale: es-Caribbean
title: "El cobro del impuesto sobre las ventas en los pequeños negocios"
summary: "Explica la responsabilidad práctica que asume un pequeño negocio cuando se convierte en recaudador del impuesto sobre las ventas, a partir de la lección anterior sobre este impuesto desde el punto de vista del consumidor."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# El cobro del impuesto sobre las ventas en los pequeños negocios

## Objetivos de aprendizaje

- Explicar el papel del negocio como recaudador del impuesto sobre las ventas.
- Describir por qué el impuesto sobre las ventas cobrado no es ingreso del negocio.
- Reconocer el riesgo de tratar el impuesto cobrado como ingreso disponible para gastar.

## Contenido principal

Antes, este curso abordó el impuesto sobre las ventas desde el punto de vista del comprador. Ahora considérelo desde el lado del negocio: cuando un negocio cobra el impuesto sobre las ventas a sus clientes, está guardando temporalmente dinero que le pertenece al gobierno, no dinero que ganó. Esa distinción importa muchísimo para la forma en que un negocio debe manejar su efectivo. (En Puerto Rico, por ejemplo, los comerciantes cobran y remiten el IVU a Hacienda; en la República Dominicana, los contribuyentes cobran y declaran el ITBIS ante la DGII.)

Un error común y serio de los nuevos dueños de pequeños negocios es tratar todo el efectivo que entra —incluida la parte del impuesto sobre las ventas— como disponible para gastar, y luego descubrir, al momento de declarar o remitir, que el dinero del impuesto ya se gastó en otras cosas. Como el negocio está obligado por ley a remitir ese impuesto sin importar su propia situación de efectivo, los negocios disciplinados suelen separar de inmediato el impuesto cobrado, a veces en una cuenta dedicada, en lugar de mezclarlo con los fondos generales de operación.

## Ejemplo práctico

**Pregunta:** El dueño de una tienda nueva deposita todas las ventas del día, incluido el impuesto cobrado, en una sola cuenta general y gasta libremente de ella. ¿Qué riesgo crea eso?

**Estudiante:** Según esta lección, podría gastar sin darse cuenta el dinero del impuesto que en realidad le pertenece al gobierno.

**Guía:** ¿Cómo sería un enfoque más disciplinado?

**Estudiante:** Separar de inmediato el impuesto cobrado en su propia cuenta, para que nunca se confunda con ingreso del negocio disponible para gastar.

**Guía:** Exactamente. Tratarlo desde el primer día como dinero ya comprometido evita la trampa.

## Prueba práctica

**Pregunta 1.** Cuando un negocio cobra el impuesto sobre las ventas, ese dinero es:

A) Ingreso propio ganado por el negocio
B) Dinero que guarda temporalmente en nombre del gobierno
C) Un regalo de los clientes
D) Automáticamente libre de impuestos

**Pregunta 2.** Un error común de los nuevos pequeños negocios es:

A) Separar de inmediato el impuesto sobre las ventas
B) Gastar el impuesto cobrado como si fuera ingreso general de operación
C) Cobrar muy poco impuesto sobre las ventas
D) No cobrar nunca el impuesto sobre las ventas

**Pregunta 3.** ¿Por qué es serio este error?

A) No es serio
B) El negocio sigue obligado por ley a remitir el impuesto, aunque ya lo haya gastado
C) El impuesto sobre las ventas es opcional
D) Los clientes son los responsables

**Pregunta 4.** Una práctica disciplinada para evitar este error es:

A) Ignorar el impuesto sobre las ventas hasta fin de año
B) Separar de inmediato el impuesto cobrado, a veces en una cuenta dedicada
C) Gastarlo primero y preocuparse después
D) Negarse a cobrar el impuesto sobre las ventas

## Clave de respuestas

1. B, 2. B, 3. B, 4. B

## Respuestas y explicaciones

**1.** El negocio es un recaudador en nombre del gobierno, no el dueño final de ese dinero.

**2.** Mezclar el impuesto cobrado con los ingresos generales es uno de los errores de manejo de efectivo más comunes de los nuevos dueños de negocio.

**3.** La obligación de remitir no desaparece solo porque el efectivo se haya gastado en otra cosa.

**4.** La separación inmediata es una disciplina sencilla y eficaz que evita exactamente este problema.

## Puntos clave

- El impuesto sobre las ventas cobrado le pertenece al gobierno, no al negocio.
- Tratarlo como ingreso disponible para gastar es un error común y arriesgado.
- El negocio sigue obligado a remitirlo sin importar su propia situación de efectivo.
- Separar de inmediato el impuesto cobrado es una buena práctica disciplinada.
