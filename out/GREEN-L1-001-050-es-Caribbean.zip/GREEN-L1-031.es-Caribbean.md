---
id: GREEN-L1-031
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 31
locale: es-Caribbean
title: "Las ganancias de capital: impuestos sobre la ganancia de las inversiones"
summary: "Presenta el concepto de ganancia de capital —la ganancia que se obtiene al vender un bien por más de lo que costó— y en qué se diferencia del ingreso ordinario."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Las ganancias de capital: impuestos sobre la ganancia de las inversiones

## Objetivos de aprendizaje

- Definir una ganancia de capital en términos sencillos.
- Explicar el cálculo básico de una ganancia de capital.
- Reconocer por qué las ganancias solo se realizan (y normalmente se gravan) al vender, no mientras simplemente se conserva un bien.

## Contenido principal

Una ganancia de capital es la ganancia que se obtiene cuando usted vende un bien —como una acción o una propiedad inmueble— por más de lo que pagó por él. El cálculo básico es sencillo: precio de venta menos precio de compra (a menudo llamado la «base») es igual a la ganancia. Si el bien se vendió por menos que su base, se trata en cambio de una pérdida de capital.

Un matiz importante: en la mayoría de los sistemas, una ganancia solo se «realiza», y en general solo tributa, cuando el bien se vende de verdad. Si el valor de una acción se duplica pero usted nunca la vende, en general todavía no debe impuesto sobre ganancias de capital por ese aumento: es una ganancia no realizada, o «en papel». Esta distinción importa para la planificación de las inversiones, porque vender un bien que ha subido de valor suele ser una decisión deliberada, cuyo momento se puede escoger y que tiene consecuencias tributarias, no algo que ocurre automáticamente solo porque subió el valor del bien.

## Ejemplo práctico

**Pregunta:** Una inversionista compra una acción por $1,000. Dos años después vale $3,000, pero no la ha vendido. ¿Debe impuesto sobre ganancias de capital ahora mismo?

**Estudiante:** Según esta lección, probablemente todavía no, porque la ganancia no se ha realizado mediante una venta.

**Guía:** ¿Qué activaría el impuesto y cómo se calcularía si vendiera a $3,000?

**Estudiante:** Venderla lo activaría: la ganancia sería $3,000 menos su base de $1,000, es decir, una ganancia de capital de $2,000.

**Guía:** Exactamente. Y ella tiene cierto control sobre ese momento, lo cual es una herramienta de planificación real.

## Prueba práctica

**Pregunta 1.** Una ganancia de capital se calcula como:

A) Precio de compra menos precio de venta
B) Precio de venta menos precio de compra (base)
C) Solo el precio de compra
D) Una cantidad fija que establece el gobierno

**Pregunta 2.** Si un bien se vende por menos que su base, eso se llama:

A) Ganancia de capital
B) Pérdida de capital
C) Crédito contributivo
D) Reintegro

**Pregunta 3.** Una ganancia de capital generalmente tributa:

A) En el momento en que sube el valor del bien, se venda o no
B) Cuando la ganancia se realiza, normalmente al vender
C) Nunca
D) Solo si el bien es una propiedad inmueble

**Pregunta 4.** Una ganancia no realizada, o «en papel», se refiere a:

A) Una ganancia que ya tributó
B) Un aumento de valor que todavía no se ha asegurado mediante una venta
C) Un tipo de crédito contributivo
D) Una pérdida de capital

## Clave de respuestas

1. B, 2. B, 3. B, 4. B

## Respuestas y explicaciones

**1.** El cálculo de la ganancia compara el precio al que usted vendió el bien con lo que pagó originalmente.

**2.** Una pérdida es simplemente lo opuesto de una ganancia: vender por menos que la base original.

**3.** La realización mediante una venta es el detonante general del impuesto sobre ganancias de capital en la mayoría de los sistemas.

**4.** El valor puede subir en papel sin activar el impuesto, porque todavía no se ha vendido nada.

## Puntos clave

- Una ganancia de capital es el precio de venta menos el precio de compra (base).
- Vender por debajo de la base produce, en cambio, una pérdida de capital.
- Las ganancias generalmente tributan al realizarse, normalmente cuando se vende el bien.
- Las ganancias no realizadas todavía no tributan, lo que convierte el momento de la venta en una verdadera decisión de planificación.
