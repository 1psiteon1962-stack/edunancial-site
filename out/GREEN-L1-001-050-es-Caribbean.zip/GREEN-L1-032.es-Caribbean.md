---
id: GREEN-L1-032
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 32
locale: es-Caribbean
title: "Ganancias de capital a corto plazo y a largo plazo"
summary: "Explica por qué muchos sistemas gravan las ganancias de forma distinta según cuánto tiempo se conservó un bien antes de venderlo."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Ganancias de capital a corto plazo y a largo plazo

## Objetivos de aprendizaje

- Definir las ganancias de capital a corto plazo y a largo plazo.
- Explicar el razonamiento general de política pública detrás de favorecer los periodos de tenencia más largos.
- Reconocer el periodo de tenencia como una consideración de planificación.

## Contenido principal

Muchos sistemas tributarios distinguen entre las ganancias de capital a corto plazo (de bienes conservados por un periodo más corto, a menudo menos de un año) y las ganancias de capital a largo plazo (de bienes conservados por más tiempo), y a menudo gravan las de largo plazo a una tasa más favorable. El umbral exacto del periodo de tenencia y la diferencia de tasas varían según el país y cambian con el tiempo, pero el patrón general —premiar la paciencia— es común.

El razonamiento general de política pública es fomentar la inversión a largo plazo y desalentar la compraventa excesiva a corto plazo, aunque hay personas razonables que debaten qué tan bien funciona esto en la práctica. Para un inversionista individual, la conclusión práctica es que el periodo de tenencia es una verdadera herramienta de planificación: vender un bien un poco antes o un poco después de un umbral clave puede cambiar de forma significativa el resultado tributario, y por eso los inversionistas a veces programan deliberadamente una venta en torno a un hito del periodo de tenencia.

## Ejemplo práctico

**Pregunta:** Una inversionista está cerca del umbral de largo plazo con una acción que le ha dado ganancias y está decidiendo si vender ahora o esperar unas semanas más. ¿Qué debería considerar?

**Estudiante:** Según esta lección, esperar hasta cruzar el umbral de largo plazo podría significar una tasa de impuesto más favorable sobre la ganancia.

**Guía:** ¿Debería ser el tratamiento tributario el único factor de esa decisión?

**Estudiante:** Probablemente no: el precio de la acción también podría moverse mientras tanto, así que es un verdadero balance entre el momento tributario y el riesgo de la inversión, no una decisión puramente tributaria.

**Guía:** Exactamente. La planificación tributaria es un elemento más, no toda la decisión.

## Prueba práctica

**Pregunta 1.** Las ganancias de capital a corto plazo generalmente provienen de bienes:

A) Conservados por un periodo más largo
B) Conservados por un periodo más corto, a menudo menos de un año
C) Que nunca se venden
D) Solo de propiedades inmuebles

**Pregunta 2.** Las ganancias de capital a largo plazo a menudo tributan:

A) A una tasa menos favorable que las de corto plazo
B) A una tasa más favorable que las de corto plazo, en muchos sistemas
C) Exactamente igual que las de corto plazo en todas partes
D) Nunca, en ningún caso

**Pregunta 3.** El razonamiento general de política pública detrás de esta distinción es:

A) Castigar a los inversionistas a largo plazo
B) Fomentar la inversión a largo plazo frente a la compraventa excesiva a corto plazo
C) Aumentar la recaudación del gobierno sin ningún otro propósito
D) Simplificar el código tributario

**Pregunta 4.** El periodo de tenencia se entiende mejor como:

A) Algo irrelevante para la planificación tributaria
B) Una verdadera herramienta de planificación que puede afectar el resultado tributario de una venta
C) Algo fijo e inmodificable
D) Algo relevante solo para los negocios

## Clave de respuestas

1. B, 2. B, 3. B, 4. B

## Respuestas y explicaciones

**1.** Las ganancias a corto plazo generalmente provienen de bienes conservados por un periodo relativamente breve antes de la venta.

**2.** Muchos sistemas aplican, por política pública, una tasa más favorable a las ganancias a largo plazo.

**3.** El objetivo general es empujar a los inversionistas hacia la paciencia en lugar de la compraventa frecuente a corto plazo, aunque se debate su eficacia real.

**4.** Como el momento puede cambiar el resultado tributario, el periodo de tenencia es un factor en torno al cual los inversionistas pueden planificar deliberadamente.

## Puntos clave

- Las ganancias a corto plazo suelen provenir de bienes conservados brevemente; las de largo plazo, de bienes conservados por más tiempo.
- Las ganancias a largo plazo a menudo tributan de forma más favorable, aunque los detalles varían y cambian.
- El objetivo de política pública suele ser fomentar una inversión paciente y a largo plazo.
- El periodo de tenencia es una herramienta de planificación real y controlable para los inversionistas.
