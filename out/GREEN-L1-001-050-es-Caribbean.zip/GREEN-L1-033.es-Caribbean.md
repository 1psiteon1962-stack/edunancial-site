---
id: GREEN-L1-033
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 33
locale: es-Caribbean
title: "Dividendos e intereses: cómo tributan los ingresos de inversión"
summary: "Presenta los dividendos y los intereses como dos formas comunes de ingreso de inversión distintas de las ganancias de capital, porque se generan al conservar un bien, no al venderlo."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Dividendos e intereses: cómo tributan los ingresos de inversión

## Objetivos de aprendizaje

- Distinguir los dividendos y los intereses de las ganancias de capital.
- Explicar que el ingreso por dividendos e intereses generalmente tributa en el año en que se recibe.
- Reconocer que son fuentes de ingreso continuas, no eventos de venta de una sola vez.

## Contenido principal

Hasta ahora, este curso se ha enfocado mucho en las ganancias de capital: la ganancia que se obtiene al vender un bien. Pero otras dos formas comunes de ingreso de inversión no requieren vender nada: los dividendos (una parte de las ganancias de una empresa que se paga a los accionistas, a menudo de forma periódica) y los intereses (pagos que se ganan por prestar dinero, como mediante una cuenta de ahorros o un bono).

A diferencia de las ganancias de capital, que normalmente se activan con una venta, el ingreso por dividendos e intereses generalmente tributa en el año en que se recibe, se venda o no la inversión de fondo. Una inversionista que conserva durante décadas una acción que paga dividendos, sin vender ni una sola acción, en general seguirá debiendo impuestos cada año sobre los dividendos recibidos durante ese tiempo. Reconocer que estas son fuentes de ingreso distintas y continuas —separadas de la mecánica de las ganancias de capital, que se activa con una venta— completa la imagen básica de cómo tributan los ingresos de inversión.

## Ejemplo práctico

**Pregunta:** Una inversionista conserva una acción durante 15 años sin venderla nunca, pero la empresa paga un dividendo cada trimestre. ¿Evita todo impuesto sobre esa acción por no venderla nunca?

**Estudiante:** Según esta lección, no: los dividendos en sí generalmente tributan cada año en que los recibe, aunque no haya venta.

**Guía:** Entonces, ¿qué tributa realmente cada año, frente a lo que solo tributaría si ella llegara a vender?

**Estudiante:** Los dividendos tributan a medida que se reciben. El aumento del precio de la acción solo se convertiría en una ganancia de capital tributable si ella la vende y cuando la venda.

**Guía:** Exactamente: dos fuentes de ingreso distintas, dos detonantes distintos.

## Prueba práctica

**Pregunta 1.** Un dividendo es:

A) Un tipo de préstamo
B) Una parte de las ganancias de una empresa que se paga a los accionistas
C) Lo mismo que una ganancia de capital
D) Un crédito contributivo del gobierno

**Pregunta 2.** Los intereses son, en general:

A) La ganancia por vender un bien
B) Un pago que se gana por prestar dinero, como mediante ahorros o bonos
C) Lo mismo que un dividendo
D) Algo relevante solo para los negocios

**Pregunta 3.** A diferencia de las ganancias de capital, el ingreso por dividendos e intereses generalmente tributa:

A) Solo al vender el bien de fondo
B) En el año en que se recibe, haya venta o no
C) Nunca
D) Solo después de diez años

**Pregunta 4.** ¿Puede una inversionista evitar todo impuesto sobre una acción simplemente no vendiéndola nunca?

A) Sí, siempre
B) No: los dividendos que recibe en el camino siguen tributando en general
C) Solo si la acción pierde valor
D) Solo en el caso de los bonos

## Clave de respuestas

1. B, 2. B, 3. B, 4. B

## Respuestas y explicaciones

**1.** Un dividendo es una distribución de las ganancias de la empresa a los accionistas, distinta de una transacción de venta.

**2.** Los intereses son la compensación por prestar dinero, ya sea mediante una cuenta bancaria, un bono o un instrumento similar.

**3.** Estos tipos de ingreso tributan a medida que se reciben, a diferencia de las ganancias de capital, que esperan una venta para activar el impuesto.

**4.** Los ingresos continuos, como los dividendos, siguen generando obligaciones tributarias año tras año, se venda o no el bien.

## Puntos clave

- Los dividendos y los intereses son tipos de ingreso de inversión distintos de las ganancias de capital.
- Generalmente tributan en el año en que se reciben, no al vender.
- Conservar un bien sin venderlo no evita el impuesto sobre el ingreso que genera en el camino.
- Reconocer que son fuentes distintas y continuas completa la imagen básica de los ingresos de inversión.
