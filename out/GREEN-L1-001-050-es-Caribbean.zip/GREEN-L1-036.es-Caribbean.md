---
id: GREEN-L1-036
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 36
locale: es-Caribbean
title: "Las implicaciones tributarias de vender una casa"
summary: "Presenta las consideraciones tributarias generales que surgen al vender una residencia principal, en conexión con las lecciones sobre ganancias de capital."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Las implicaciones tributarias de vender una casa

## Objetivos de aprendizaje

- Conectar la venta de una casa con el concepto anterior de ganancia de capital.
- Explicar por qué muchos sistemas ofrecen algún trato favorable a la residencia principal.
- Reconocer la importancia de llevar el control de la base de una casa a lo largo del tiempo.

## Contenido principal

Vender una casa es, en el fondo, otro ejemplo del concepto de ganancia de capital visto antes: el precio de venta menos la base (aproximadamente, el precio de compra más ciertas mejoras que cualifican) es igual a la ganancia. Pero como la residencia principal es un evento de vida tan común e importante, y no una transacción de inversión pura, muchos sistemas tributarios ofrecen algún trato favorable —como excluir de impuestos una parte de la ganancia— específicamente para la residencia principal, distinto del trato que darían, por ejemplo, a una propiedad de inversión.

Este es un buen ejemplo práctico de por qué importa llevar el control de su base a lo largo del tiempo. Si un dueño de casa hace mejoras importantes que cualifican con los años —una ampliación, una remodelación grande—, esos costos a menudo pueden aumentar la base, lo que reduce la ganancia tributable cuando finalmente se vende la casa. Sin registros de esas mejoras, el dueño puede terminar pagando más impuestos de lo necesario simplemente porque no puede documentar lo que realmente gastó.

## Ejemplo práctico

**Pregunta:** Un dueño de casa hace una ampliación importante al principio, pero nunca guarda registros de su costo. Años después vende la casa con una ganancia grande. ¿Qué podría costarle eso?

**Estudiante:** Según esta lección, sin registros del costo de la ampliación, quizá no pueda aumentar su base, lo que podría significar pagar impuestos sobre una ganancia mayor de lo necesario.

**Guía:** ¿Qué habría evitado este problema?

**Estudiante:** Guardar los recibos y registros de los costos de la mejora a medida que ocurrieron, lo que se conecta con la lección anterior sobre llevar registros.

**Guía:** Exactamente. Este es un ejemplo muy concreto y costoso de por qué importa ese hábito.

## Prueba práctica

**Pregunta 1.** Vender una casa es, en el fondo, un ejemplo de:

A) El impuesto sobre las ventas
B) El concepto de ganancia de capital: precio de venta menos base
C) El impuesto sobre la nómina
D) Un crédito contributivo

**Pregunta 2.** ¿Por qué muchos sistemas podrían ofrecer un trato favorable específicamente a la residencia principal?

A) Por ninguna razón real
B) Se trata como un evento de vida común e importante, no como una inversión pura
C) Las casas nunca se venden
D) Solo las propiedades de inversión reciben un trato favorable

**Pregunta 3.** Las mejoras al hogar que cualifican generalmente pueden:

A) Disminuir la base de la casa
B) Aumentar la base de la casa, lo que reduce después la ganancia tributable
C) No tener ningún efecto sobre la base
D) Importar solo en las propiedades de alquiler

**Pregunta 4.** Sin registros de los costos de las mejoras, un dueño de casa se arriesga a:

A) Nada
B) Pagar más impuestos de lo necesario en la venta futura
C) Un reintegro automático
D) Perder la titularidad de la casa

## Clave de respuestas

1. B, 2. B, 3. B, 4. B

## Respuestas y explicaciones

**1.** La venta de una casa sigue el mismo cálculo básico de ganancia que la venta de cualquier otro bien de capital.

**2.** La residencia principal a menudo recibe un trato distinto, que refleja su papel como necesidad de vida y no como un vehículo de inversión puro.

**3.** Las mejoras que cualifican generalmente se suman a la base, lo que puede reducir de forma significativa la ganancia tributable al vender.

**4.** La falta de documentación se traduce directamente en una ganancia tributable mayor y en una factura de impuestos innecesariamente más grande.

## Puntos clave

- Vender una casa sigue la misma lógica básica de ganancia de capital que la venta de otros bienes.
- La residencia principal a menudo recibe algún trato tributario favorable.
- Las mejoras que cualifican pueden aumentar la base y reducir después la ganancia tributable.
- No llevar registros de las mejoras al hogar puede ser un error costoso y evitable.
