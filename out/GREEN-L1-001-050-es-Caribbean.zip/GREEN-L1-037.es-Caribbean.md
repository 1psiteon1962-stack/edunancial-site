---
id: GREEN-L1-037
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 37
locale: es-Caribbean
title: "Lo básico del impuesto sobre donaciones y herencias"
summary: "Presenta los conceptos generales de la tributación relacionada con las donaciones y las herencias, de forma amplia, dada la gran variación entre sistemas."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Lo básico del impuesto sobre donaciones y herencias

## Objetivos de aprendizaje

- Explicar el concepto general detrás de la tributación sobre las donaciones.
- Explicar el concepto general detrás de la tributación sobre las herencias o el caudal relicto.
- Reconocer que estas reglas varían enormemente y dependen mucho de la jurisdicción.

## Contenido principal

Algunos sistemas tributarios aplican reglas a las donaciones grandes que una persona hace en vida y a los bienes que se transfieren después de su muerte (lo que a menudo se llama tributación sobre las herencias o sobre el caudal relicto). La preocupación general que atienden los legisladores es la transferencia de riqueza por fuera del sistema de generación de ingresos: como una donación o una herencia no se «gana» en el sentido tradicional, plantea preguntas de política pública distintas a las de un cheque de pago.

Esta es un área en la que generalizar demasiado sería engañoso: la existencia de estos impuestos, los umbrales a partir de los cuales aplican, quién los debe (el donante o el que recibe) y las tasas varían enormemente según el país, y muchos países no tienen ningún impuesto de este tipo, o lo aplican solo por encima de umbrales muy altos que afectan a un porcentaje pequeño de las transferencias. La lección práctica aquí no es una regla para memorizar, sino una señal de alerta: si usted es el donante, el que recibe o el heredero en una situación de donación o herencia realmente grande, ese es exactamente el tipo de caso que requiere orientación profesional en lugar de suposiciones.

## Ejemplo práctico

**Pregunta:** Una familia planea traspasar un negocio familiar grande a la siguiente generación. ¿Debería suponer que se le aplican las reglas tributarias que escuchó de un amigo en otro país?

**Estudiante:** Según esta lección, definitivamente no: estas reglas varían enormemente según el país y la situación.

**Guía:** ¿Cuál sería el siguiente paso responsable para esta familia?

**Estudiante:** Buscar el consejo de un profesional cualificado que conozca las reglas específicas de su país, en lugar de depender de información de segunda mano de otro lugar.

**Guía:** Exactamente. Este es un caso de manual para «ver a un profesional», según la analogía del médico vista antes en el currículo.

## Prueba práctica

**Pregunta 1.** Los impuestos relacionados con las donaciones y las herencias generalmente se refieren a:

A) Los cheques de pago regulares
B) Las transferencias de riqueza por fuera del sistema normal de generación de ingresos
C) El impuesto sobre las ventas de alimentos
D) La retención de la nómina

**Pregunta 2.** ¿Aplican todos los países las mismas reglas sobre donaciones y herencias?

A) Sí, de forma universal
B) No: las reglas varían enormemente, y muchos países no tienen este impuesto o tienen umbrales muy altos
C) Solo los países ricos tienen reglas
D) Estos impuestos nunca han existido en ninguna parte

**Pregunta 3.** La lección práctica de este tema es:

A) Memorizar los umbrales específicos de un país
B) Reconocer esto como una señal para buscar orientación profesional en situaciones reales
C) Ignorar por completo las donaciones grandes
D) Suponer que nunca se aplica ningún impuesto en ninguna parte

**Pregunta 4.** ¿Con qué concepto anterior del currículo se conecta esta lección?

A) La analogía del médico: consultar a un profesional en situaciones complejas
B) Los bienes públicos
C) El cobro del impuesto sobre las ventas
D) Los tramos impositivos marginales

## Clave de respuestas

1. B, 2. B, 3. B, 4. A

## Respuestas y explicaciones

**1.** Estos impuestos generalmente apuntan a la riqueza que se mueve por fuera del marco típico del ingreso ganado.

**2.** La enorme variación, incluidos muchos países sin ningún impuesto de este tipo, hace que las generalizaciones amplias no sean confiables aquí.

**3.** La enseñanza duradera es reconocer cuándo una situación requiere ayuda experta, no memorizar reglas que tal vez ni siquiera apliquen.

**4.** Esta es una aplicación directa y concreta de la lección anterior que comparaba la consulta sobre riesgos legales y tributarios con ir al médico.

## Puntos clave

- Los impuestos sobre donaciones y herencias se refieren a las transferencias de riqueza por fuera del ingreso ganado normal.
- Las reglas varían enormemente según el país: muchos no los tienen, o los aplican solo por encima de umbrales altos.
- La lección clave es reconocer cuándo buscar orientación profesional, no memorizar reglas específicas.
- Las situaciones de donación o herencia grandes o complejas son un caso claro para consultar a un profesional.
