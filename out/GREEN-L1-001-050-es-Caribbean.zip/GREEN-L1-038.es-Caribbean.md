---
id: GREEN-L1-038
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 38
locale: es-Caribbean
title: "Los impuestos selectivos al consumo («impuestos al pecado»)"
summary: "Presenta los impuestos selectivos al consumo, a menudo llamados «impuestos al pecado» cuando se aplican a bienes específicos como el alcohol o el tabaco, como una categoría tributaria distinta impulsada por la política pública."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Los impuestos selectivos al consumo («impuestos al pecado»)

## Objetivos de aprendizaje

- Definir un impuesto selectivo al consumo.
- Explicar el término «impuesto al pecado» y el razonamiento de política pública que lo sostiene.
- Distinguir los impuestos selectivos al consumo del impuesto general sobre las ventas.

## Contenido principal

Un impuesto selectivo al consumo (en inglés, *excise tax*; también llamado arbitrio en algunos lugares) es un impuesto que se aplica a un bien o actividad específicos, en lugar de a las compras en general, como hace un impuesto amplio sobre las ventas. Cuando un impuesto selectivo apunta a un bien que se considera dañino en exceso —el alcohol, el tabaco y a veces las bebidas azucaradas son ejemplos comunes—, a menudo se le llama de manera informal «impuesto al pecado». (En la República Dominicana, por ejemplo, existe el Impuesto Selectivo al Consumo sobre bienes como el alcohol y el tabaco; en Puerto Rico se cobran arbitrios sobre ciertos productos.)

El razonamiento de política pública detrás de los impuestos al pecado suele tener dos partes: recaudar dinero y desalentar el consumo del bien gravado haciéndolo más caro. A diferencia del impuesto general sobre las ventas, que se aplica de forma amplia y neutral a la mayoría de las compras, los impuestos selectivos son deliberadamente estrechos y focalizados, y reflejan un juicio de política pública específico sobre ese bien o actividad en particular. Si los impuestos al pecado realmente reducen el consumo de forma eficaz, y si recaen de manera desproporcionada sobre los consumidores de menores ingresos, son preguntas genuinamente debatidas y no hechos establecidos.

## Ejemplo práctico

**Pregunta:** Un gobierno añade un impuesto adicional específicamente a los refrescos azucarados, además del impuesto regular sobre las ventas que se aplica a todas las compras al detal. ¿Qué tipo de impuesto es el cargo adicional a los refrescos?

**Estudiante:** Según esta lección, parece un impuesto selectivo al consumo, porque apunta específicamente a un producto y no a las compras en general.

**Guía:** ¿Cuál es el doble propósito probable detrás de ese tipo de impuesto focalizado?

**Estudiante:** Recaudar dinero y también desalentar el consumo de refrescos haciéndolos más caros.

**Guía:** Exactamente. Y vale la pena notar que ambos efectos, y su justicia, se debaten genuinamente.

## Prueba práctica

**Pregunta 1.** Un impuesto selectivo al consumo se describe mejor como:

A) Un impuesto amplio sobre todas las compras
B) Un impuesto focalizado en un bien o actividad específicos
C) Lo mismo que el impuesto sobre la renta
D) Un tipo de impuesto sobre la propiedad

**Pregunta 2.** Un «impuesto al pecado» es:

A) Algo ajeno a los impuestos selectivos al consumo
B) Un término informal para un impuesto selectivo sobre bienes que se consideran dañinos en exceso
C) Un impuesto solo sobre el ingreso
D) Un tipo de crédito contributivo

**Pregunta 3.** El doble propósito típico detrás de los impuestos al pecado es:

A) Ningún propósito
B) Recaudar dinero y desalentar el consumo
C) Solo desalentar el consumo, nunca recaudar
D) Solo recaudar, sin ningún objetivo de conducta

**Pregunta 4.** ¿Es la eficacia y la justicia de los impuestos al pecado una cuestión resuelta?

A) Sí, hay acuerdo universal
B) No: es una cuestión de política pública genuinamente debatida
C) Solo se debate en un país
D) Nunca se ha discutido

## Clave de respuestas

1. B, 2. B, 3. B, 4. B

## Respuestas y explicaciones

**1.** Los impuestos selectivos se enfocan en un producto o actividad específicos en lugar de aplicarse de forma amplia.

**2.** La etiqueta de «impuesto al pecado» refleja que el bien gravado se considera dañino en exceso, como el alcohol o el tabaco.

**3.** La recaudación y el desaliento de una conducta son los dos objetivos que se mencionan comúnmente detrás de estos impuestos focalizados.

**4.** Hay personas razonables que no están de acuerdo sobre qué tan bien funcionan los impuestos al pecado y quién soporta realmente su carga.

## Puntos clave

- Los impuestos selectivos al consumo apuntan a bienes o actividades específicos, a diferencia del impuesto general y amplio sobre las ventas.
- «Impuesto al pecado» es un término informal para los impuestos selectivos sobre bienes que se consideran dañinos en exceso.
- Los objetivos típicos son recaudar y desalentar el consumo.
- La eficacia y la justicia de los impuestos al pecado siguen siendo genuinamente debatidas.
