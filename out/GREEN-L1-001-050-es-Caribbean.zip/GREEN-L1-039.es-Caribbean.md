---
id: GREEN-L1-039
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 39
locale: es-Caribbean
title: "Los aranceles: impuestos sobre los bienes importados"
summary: "Presenta los aranceles como un impuesto sobre los bienes que cruzan una frontera, en conexión con la política comercial a un nivel conceptual básico."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Los aranceles: impuestos sobre los bienes importados

## Objetivos de aprendizaje

- Definir un arancel.
- Explicar quién suele terminar soportando el costo de un arancel.
- Reconocer los aranceles como una herramienta de recaudación y también de política comercial.

## Contenido principal

Un arancel es un impuesto que se aplica a los bienes cuando se importan a un país desde el extranjero. A diferencia del impuesto sobre las ventas, que se aplica a las compras en general, o del impuesto selectivo al consumo, que apunta a bienes específicos sin importar su origen, un arancel apunta específicamente a los bienes que cruzan una frontera para entrar al país.

Los aranceles tienen dos propósitos que se mencionan comúnmente: generar ingresos para el gobierno y proteger las industrias nacionales haciendo que los bienes importados sean más caros en comparación con las alternativas producidas en el país. Un punto importante que a menudo se pasa por alto es que, aunque técnicamente el arancel se le cobra a la empresa que importa, el costo adicional con frecuencia se traslada a los consumidores mediante precios más altos; es decir, las personas que pagan más en la caja pueden estar muy lejos de cualquier conversación sobre política comercial. Si un arancel determinado realmente ayuda o perjudica a la economía general de un país es una pregunta muy debatida en la economía, con balances reales en ambos lados.

## Ejemplo práctico

**Pregunta:** Un país añade un arancel al acero importado para proteger a sus fabricantes nacionales de acero. ¿Quién probablemente terminará sintiendo el costo de ese arancel?

**Estudiante:** Según esta lección, técnicamente se les cobra a las empresas que importan, pero el costo a menudo se traslada a los consumidores mediante precios más altos.

**Guía:** Entonces, ¿quién podría terminar pagando más, aunque nunca trate directamente con importaciones de acero?

**Estudiante:** Los consumidores que compran productos hechos con ese acero —carros, enseres, construcción— podrían ver precios más altos, aunque el arancel en sí se le cobró a una empresa.

**Guía:** Exactamente. Los aranceles tienen efectos en cadena que van mucho más allá de las empresas a las que se grava directamente.

## Prueba práctica

**Pregunta 1.** Un arancel es un impuesto que se aplica a:

A) Todas las compras nacionales
B) Los bienes que se importan a un país desde el extranjero
C) Solo los servicios, nunca los bienes
D) El ingreso de inversiones

**Pregunta 2.** Los aranceles se usan comúnmente para:

A) Generar ingresos y proteger las industrias nacionales
B) Eliminar todo el comercio
C) Beneficiar solo a las empresas extranjeras
D) Reducir los precios nacionales

**Pregunta 3.** ¿Quién suele terminar soportando el costo real de un arancel, aunque se les cobre a los importadores?

A) Nadie: los aranceles no tienen ningún costo posterior
B) Los consumidores, mediante precios más altos
C) Solo los gobiernos extranjeros
D) Solo la empresa que importa, sin traslado alguno

**Pregunta 4.** ¿Es el efecto económico general de los aranceles una cuestión resuelta?

A) Sí, siempre son beneficiosos
B) Sí, siempre son perjudiciales
C) No: es una pregunta muy debatida, con balances reales
D) Los aranceles no tienen ningún efecto económico

## Clave de respuestas

1. B, 2. A, 3. B, 4. C

## Respuestas y explicaciones

**1.** Los aranceles están vinculados específicamente al acto de importar bienes a través de una frontera, lo que los distingue de los impuestos más amplios.

**2.** La generación de ingresos y la protección de la industria nacional son los dos propósitos que se mencionan con mayor frecuencia para los aranceles.

**3.** El traslado del costo hace que la carga práctica a menudo recaiga sobre los consumidores comunes, y no solo sobre las empresas gravadas directamente.

**4.** Los economistas genuinamente no se ponen de acuerdo sobre los efectos netos de los aranceles, que implican balances reales entre distintos grupos.

## Puntos clave

- Los aranceles gravan los bienes que se importan a través de una frontera.
- Se usan comúnmente para recaudar y proteger las industrias nacionales.
- El costo real a menudo se traslada a los consumidores, aunque los aranceles se les cobren a los importadores.
- El impacto económico general de los aranceles es una cuestión genuinamente debatida.
