---
id: GREEN-L1-041
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 41
locale: es-Caribbean
title: "La doble tributación: lo que significa para las corporaciones"
summary: "Explica el concepto de doble tributación —la ganancia que tributa una vez a nivel corporativo y otra vez cuando se distribuye a los accionistas— a partir de la lección anterior."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# La doble tributación: lo que significa para las corporaciones

## Objetivos de aprendizaje

- Definir la doble tributación en el contexto corporativo.
- Seguir los dos momentos en que la misma ganancia puede tributar.
- Reconocer por qué la elección de la estructura del negocio, que se verá pronto, importa en parte por este tema.

## Contenido principal

A partir de la lección anterior: como una corporación tributa como su propia entidad, su ganancia puede tributar dos veces: una vez a nivel corporativo, cuando la propia corporación informa y paga impuestos sobre su ganancia, y otra vez a nivel de los accionistas, si esa ganancia se distribuye a los accionistas (comúnmente como dividendos) y cuando se distribuye, y esos accionistas deben su propio impuesto sobre la cantidad recibida.

Eso es lo que se quiere decir con «doble tributación» en el contexto corporativo: el mismo dólar de ganancia tributa una vez dentro de la corporación y posiblemente otra vez en manos de la persona que finalmente lo recibe. No todas las estructuras de negocio funcionan así: algunas, que se verán en una próxima lección, están diseñadas específicamente para que la ganancia pase a los dueños sin esta tributación en dos capas. Entender la doble tributación es una de las razones clave por las que la estructura del negocio no es una simple formalidad legal: puede tener un costo tributario real y continuo según la estructura que elija el negocio.

## Ejemplo práctico

**Pregunta:** Una corporación obtiene $100,000 de ganancia, paga el impuesto corporativo y después distribuye lo que queda a sus accionistas como dividendos. ¿Termina ahí la historia, en términos tributarios?

**Estudiante:** Según esta lección, no: los accionistas probablemente deben su propio impuesto sobre los dividendos que reciben.

**Guía:** Entonces, ¿cuántas veces tocó el impuesto, en la práctica, esa ganancia original de $100,000?

**Estudiante:** Dos veces: una a nivel corporativo, cuando la corporación pagó impuestos sobre su ganancia, y otra a nivel de los accionistas, cuando recibieron el dividendo y tributaron por él.

**Guía:** Exactamente. Ese es, en resumen, el patrón de la doble tributación.

## Prueba práctica

**Pregunta 1.** La doble tributación se refiere a:

A) Pagar dos veces el impuesto sobre las ventas en una misma compra
B) Que la misma ganancia corporativa tribute tanto a nivel corporativo como a nivel de los accionistas
C) Un tipo de crédito contributivo
D) Presentar dos planillas por error

**Pregunta 2.** La primera capa de tributación en este patrón ocurre:

A) A nivel de los accionistas
B) A nivel corporativo, sobre la propia ganancia de la corporación
C) Solo a nivel del gobierno
D) Nunca

**Pregunta 3.** La segunda capa de tributación ocurre:

A) Nunca
B) Cuando la ganancia distribuida (como los dividendos) vuelve a tributar en manos del accionista
C) Solo en los negocios individuales
D) Solo si la corporación pierde dinero

**Pregunta 4.** ¿Todas las estructuras de negocio implican doble tributación?

A) Sí, todas
B) No: algunas estructuras están diseñadas para evitar este patrón de dos capas, como se verá en una próxima lección
C) Solo los negocios individuales
D) La doble tributación en realidad no existe

## Clave de respuestas

1. B, 2. B, 3. B, 4. B

## Respuestas y explicaciones

**1.** La doble tributación describe específicamente la tributación en dos capas de la misma ganancia corporativa de fondo.

**2.** La propia corporación es el primer contribuyente: debe impuestos sobre su propia ganancia antes de distribuir nada.

**3.** El accionista se convierte en un segundo contribuyente sobre esa misma ganancia original una vez que se distribuye y la recibe.

**4.** Existen estructuras alternativas diseñadas específicamente para evitar este patrón, que aquí se anticipa y se verá a continuación.

## Puntos clave

- La doble tributación significa que la misma ganancia corporativa puede tributar a nivel corporativo y a nivel de los accionistas.
- La corporación paga primero impuestos sobre su propia ganancia.
- Los accionistas pueden deber impuestos adicionales cuando esa ganancia se les distribuye después.
- Esta es una razón clave por la que la elección de la estructura del negocio tiene consecuencias tributarias reales y continuas.
