---
id: GREEN-L1-042
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 42
locale: es-Caribbean
title: "Las entidades de paso: LLC, corporaciones S y negocios individuales"
summary: "Presenta el concepto general de la tributación de paso como alternativa al patrón de doble tributación de las corporaciones regulares."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Las entidades de paso: LLC, corporaciones S y negocios individuales

## Objetivos de aprendizaje

- Definir una entidad de paso en términos generales.
- Explicar cómo la tributación de paso evita el patrón de la doble tributación.
- Reconocer ejemplos comunes de estructuras de paso sin tratar sus nombres como universales.

## Contenido principal

Una entidad de paso (en inglés, *pass-through entity*) es una estructura de negocio en la que la ganancia no tributa en absoluto a nivel del negocio: en cambio, «pasa» directamente a los dueños, quienes la informan y pagan impuestos sobre ella en sus propias planillas personales, generalmente una sola vez. Esto evita directamente el patrón de doble tributación de la lección anterior, porque para empezar no existe una capa de impuesto separada a nivel corporativo.

Entre los ejemplos comunes de estructuras que a menudo se organizan para tributar como entidades de paso están los negocios individuales (el caso más sencillo: no hay ninguna capa de impuesto separada para el negocio) y, en muchos sistemas, ciertas compañías de responsabilidad limitada (LLC) o estructuras corporativas con una elección especial (que en el sistema de los Estados Unidos suelen llamarse «corporaciones S», aunque existen conceptos equivalentes en otros lugares con otros nombres). (En Puerto Rico, por ejemplo, el código tributario local permite que ciertas entidades elijan tributar como sociedades o como corporaciones de individuos.) Las reglas legales y tributarias específicas para cualificar como entidad de paso varían según el país e implican balances reales más allá de evitar la doble tributación, y precisamente por eso la elección de la estructura del negocio, que se verá a continuación, merece una reflexión cuidadosa en lugar de una elección por defecto.

## Ejemplo práctico

**Pregunta:** La dueña de un pequeño negocio quiere evitar el patrón de doble tributación que se aplica a las corporaciones regulares. ¿Qué categoría general de estructura de negocio podría investigar?

**Estudiante:** Según esta lección, probablemente le convenga investigar las estructuras de paso, porque evitan una capa de impuesto separada a nivel del negocio.

**Guía:** ¿Cuál es el balance? ¿Es evitar la doble tributación siempre lo único que hay que considerar al elegir una estructura?

**Estudiante:** No: la lección menciona que hay otros balances reales además de la capa de impuesto, así que vale la pena mirar el panorama completo y no solo este tema.

**Guía:** Exactamente. Por eso la próxima lección examina más a fondo la elección de la estructura del negocio.

## Prueba práctica

**Pregunta 1.** Una entidad de paso es aquella en la que la ganancia:

A) Tributa dos veces, a nivel del negocio y del dueño
B) No tributa a nivel del negocio y pasa directamente a las planillas personales de los dueños
C) Nunca tributa
D) Solo tributa si el negocio fracasa

**Pregunta 2.** La tributación de paso atiende directamente, ¿qué concepto anterior?

A) El cobro del impuesto sobre las ventas
B) La doble tributación
C) Los aranceles
D) La retención de la nómina

**Pregunta 3.** En esta lección, el negocio individual se describe como:

A) Siempre sujeto a doble tributación
B) El caso de paso más sencillo, sin una capa de impuesto separada para el negocio
C) Ilegal en la mayoría de los países
D) Lo mismo que una corporación

**Pregunta 4.** ¿Es evitar la doble tributación lo único que hay que considerar al elegir una estructura de negocio?

A) Sí, es lo único
B) No: hay otros balances reales que sopesar
C) La estructura del negocio no importa
D) Solo importan los impuestos, nada más

## Clave de respuestas

1. B, 2. B, 3. B, 4. B

## Respuestas y explicaciones

**1.** Las estructuras de paso se saltan por completo el impuesto separado a nivel del negocio y envían la ganancia directamente a la planilla propia del dueño.

**2.** Esta estructura existe específicamente como alternativa al patrón de tributación en dos capas descrito en la lección anterior.

**3.** El negocio individual es el ejemplo más claro, porque el negocio y el dueño ya se tratan como un solo contribuyente.

**4.** La elección de la estructura implica varios balances —la protección de responsabilidad, la complejidad y más—, no solo la cuestión tributaria.

## Puntos clave

- Las entidades de paso evitan el impuesto a nivel del negocio y envían la ganancia directamente a las planillas personales de los dueños.
- Son la alternativa directa al patrón de doble tributación de las corporaciones regulares.
- El negocio individual es el ejemplo de paso más sencillo; ciertas LLC y estructuras con elección especial también pueden cualificar.
- Elegir una estructura de negocio implica balances que van más allá de este tema tributario.
