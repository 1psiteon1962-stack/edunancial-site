---
id: GREEN-L1-043
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 43
locale: es-Caribbean
title: "Elegir una estructura de negocio: una perspectiva tributaria"
summary: "Integra los conceptos de impuesto corporativo, doble tributación y entidades de paso en un marco para pensar la elección de la estructura del negocio, deliberadamente a un nivel general y acompañado de una advertencia sobre consultar a un profesional."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Elegir una estructura de negocio: una perspectiva tributaria

## Objetivos de aprendizaje

- Resumir los balances tributarios entre las estructuras corporativas y las de paso.
- Reconocer que la elección de la estructura implica más que impuestos (responsabilidad, complejidad, captación de fondos).
- Reforzar el principio de la analogía del médico ante una decisión tan importante.

## Contenido principal

Integrando las últimas tres lecciones: la elección de la estructura del negocio tiene una dimensión tributaria real. Las estructuras corporativas regulares conllevan la posibilidad de la doble tributación, pero pueden ofrecer otras ventajas, como un acceso más fácil a ciertos tipos de inversión o una separación clara entre el negocio y el dueño. Las estructuras de paso evitan la capa de doble tributación, pero tienen sus propios balances y reglas de elegibilidad que varían según el sistema.

Pero el tratamiento tributario es solo un elemento de esta decisión: la protección de responsabilidad (qué tan expuestos quedan los bienes personales del dueño si demandan al negocio o si este se endeuda), la complejidad administrativa y los planes del negocio para captar fondos también importan, y a veces apuntan en una dirección distinta a la que sugeriría una respuesta basada solo en los impuestos. Este es precisamente el tipo de decisión en la que se aplica directamente la analogía del médico: el costo de una consulta con un profesional cualificado, antes de fijar una estructura, es pequeño comparado con el costo de reestructurar más adelante o de vivir durante años con una estructura que no se ajusta a las necesidades reales del negocio.

## Ejemplo práctico

**Pregunta:** Una amiga que está empezando un negocio dice: «Voy a escoger la estructura que me ahorre más impuestos y después me preocupo por lo demás». ¿Cómo le respondería, con lo que ha aprendido?

**Estudiante:** Según este curso, le señalaría que los impuestos son solo un factor: la protección de responsabilidad y los planes para captar fondos también importan, y podrían apuntar hacia otra estructura.

**Guía:** ¿Qué le recomendaría concretamente que haga antes de decidir?

**Estudiante:** Hablar con un profesional cualificado que pueda examinar toda su situación, no solo el ángulo tributario, antes de comprometerse con una estructura.

**Guía:** Exactamente. Esa es la analogía del médico en acción, aplicada a una decisión real e importante.

## Prueba práctica

**Pregunta 1.** La elección de la estructura del negocio implica balances tributarios relacionados con:

A) Nada de lo visto en este curso
B) La doble tributación frente al tratamiento de paso
C) Solo el impuesto sobre las ventas
D) Solo el impuesto sobre la nómina

**Pregunta 2.** Además de los impuestos, ¿qué otros factores importan al elegir una estructura de negocio?

A) Nada más importa
B) La protección de responsabilidad, la complejidad administrativa y los planes para captar fondos
C) Solo el color favorito del dueño
D) Solo la ubicación física del negocio

**Pregunta 3.** ¿Por qué un negocio podría elegir una estructura que no es la opción más eficiente en impuestos?

A) Nunca hay una buena razón
B) Porque las necesidades de responsabilidad, complejidad o captación de fondos podrían pesar más que el beneficio tributario
C) La eficiencia tributaria siempre es el único factor
D) Esto nunca pasa en la práctica

**Pregunta 4.** ¿Qué principio visto antes en el currículo se aplica directamente a esta decisión?

A) La analogía del médico: consultar a un profesional antes de comprometerse
B) La revelación de los sistemas
C) La relatividad del logro
D) La paradoja de la elección

## Clave de respuestas

1. B, 2. B, 3. B, 4. A

## Respuestas y explicaciones

**1.** La elección entre doble tributación y tratamiento de paso es el balance tributario central visto en las últimas lecciones.

**2.** La exposición a la responsabilidad, la complejidad y la forma en que el negocio planea captar dinero determinan qué estructura se ajusta realmente mejor.

**3.** Una estructura que ahorra impuestos, pero que expone innecesariamente los bienes personales o bloquea una vía de financiamiento necesaria, puede no ser la opción correcta en conjunto.

**4.** Dados lo que está en juego y la complejidad, consultar a un profesional antes de definir la estructura refleja directamente la analogía del médico vista antes.

## Puntos clave

- La elección de la estructura tiene balances tributarios reales entre el tratamiento corporativo (con posible doble tributación) y el de paso.
- La protección de responsabilidad, la complejidad y las necesidades de captación de fondos importan tanto como los impuestos, o más.
- La estructura más eficiente en impuestos no es automáticamente la opción correcta en conjunto.
- Lo que está en juego en esta decisión hace que consultar a un profesional, según la analogía del médico, sea una inversión inteligente y no un costo innecesario.
