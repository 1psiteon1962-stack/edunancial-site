---
id: GREEN-L1-045
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 45
locale: es-Caribbean
title: "Evasión y elusión contributiva: una distinción fundamental"
summary: "Traza una línea clara y esencial entre la elusión contributiva legal (usar las reglas tal como están escritas para reducir los impuestos) y la evasión contributiva ilegal (falsear los hechos para no pagar el impuesto adeudado)."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Evasión y elusión contributiva: una distinción fundamental

## Objetivos de aprendizaje

- Definir la elusión contributiva y dar un ejemplo.
- Definir la evasión contributiva y dar un ejemplo.
- Expresar con claridad por qué esta distinción es fundamental y no un tecnicismo menor.

## Contenido principal

Esta es una de las distinciones más importantes de todo este curso, y vale la pena decirlo sin rodeos: la elusión contributiva (en inglés, *tax avoidance*; a veces llamada planificación tributaria legítima) es legal; la evasión contributiva no lo es. La elusión significa usar las reglas tributarias tal como realmente están escritas —deducciones, créditos, el momento de recibir ingresos o de vender, la elección de una estructura de negocio favorable— para reducir legalmente la cantidad de impuestos adeudada. Todo lo visto en este curso hasta ahora, hecho correctamente y con honestidad, cae dentro de la elusión legal.

La evasión contributiva significa falsear ilegalmente los hechos para no pagar un impuesto que realmente se debe: ocultar ingresos, inventar deducciones falsas, falsificar registros o engaños similares. La línea entre ambas no tiene que ver con qué tan agresiva sea la planificación tributaria, sino con si los hechos de fondo que se informan son verdaderos. Reclamar todas las deducciones a las que usted tiene derecho por ley, aunque reduzcan de forma significativa su factura de impuestos, es elusión legal. Reclamar una deducción por un gasto que nunca ocurrió, u ocultar un ingreso que sí ocurrió, es evasión: un asunto legal serio, no solo un error de papeleo.

## Ejemplo práctico

**Pregunta:** Una dueña de negocio deduce legalmente todos los gastos a los que tiene derecho y reduce de forma agresiva su factura de impuestos con las reglas vistas en este curso. Otro dueño de negocio informa gastos falsos que nunca ocurrieron. ¿Es lo mismo?

**Estudiante:** No. Según esta lección, la primera dueña usa reglas legítimas con honestidad, y eso es elusión legal. El segundo dueño falsea los hechos, y eso es evasión.

**Guía:** ¿Cuál es la verdadera línea divisoria entre ambas, si los dos terminan pagando menos impuestos?

**Estudiante:** No se trata de cuánto impuesto se ahorra, sino de si lo que se informa es realmente cierto.

**Guía:** Exactamente. Y esa distinción es la línea más importante de todo este curso.

## Prueba práctica

**Pregunta 1.** La elusión contributiva es:

A) Ilegal
B) El uso legal de las reglas tributarias para reducir el impuesto adeudado
C) Lo mismo que la evasión contributiva
D) Algo disponible solo para las corporaciones

**Pregunta 2.** La evasión contributiva es:

A) Legal
B) Falsear ilegalmente los hechos para no pagar el impuesto realmente adeudado
C) Lo mismo que la elusión contributiva
D) Solo un error de papeleo

**Pregunta 3.** La verdadera línea divisoria entre ambas es:

A) Cuánto impuesto se ahorra al final
B) Si los hechos de fondo que se informan son verdaderos
C) Si participó un profesional
D) No hay ninguna diferencia significativa

**Pregunta 4.** Reclamar con honestidad todas las deducciones disponibles por ley es:

A) Evasión contributiva
B) Elusión contributiva legal
C) Un delito
D) Algo ajeno a esta distinción

## Clave de respuestas

1. B, 2. B, 3. B, 4. B

## Respuestas y explicaciones

**1.** La elusión opera completamente dentro de las reglas realmente escritas, usándolas como se pretendía o como la ley lo permite.

**2.** La evasión cruza al terreno del falseamiento: informar algo falso para reducir ilegalmente el impuesto adeudado.

**3.** El problema no es qué tan agresiva sea la planificación tributaria, sino la veracidad de los hechos de fondo.

**4.** Incluso las reclamaciones de deducciones grandes y agresivas, pero honestas, permanecen claramente del lado legal de la línea.

## Puntos clave

- La elusión contributiva es legal: usar las reglas reales para reducir el impuesto adeudado.
- La evasión contributiva es ilegal: falsear los hechos para no pagar el impuesto realmente adeudado.
- La línea divisoria es la veracidad, no cuánto impuesto se ahorra.
- Esta distinción es una de las más importantes de todo el currículo de alfabetización tributaria.
