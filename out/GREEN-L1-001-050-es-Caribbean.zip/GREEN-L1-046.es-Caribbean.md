---
id: GREEN-L1-046
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 46
locale: es-Caribbean
title: "Las auditorías: qué son y por qué ocurren"
summary: "Desmitifica el proceso de auditoría tributaria y lo presenta como un procedimiento de verificación, no como una acusación automática de haber hecho algo mal."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-08-09
---

# Las auditorías: qué son y por qué ocurren

## Objetivos de aprendizaje

- Definir qué es una auditoría.
- Identificar razones comunes, no acusatorias, por las que podría ocurrir una auditoría.
- Explicar cómo llevar buenos registros protege directamente a una persona durante una auditoría.

## Contenido principal

Una auditoría es un proceso de revisión en el que una autoridad tributaria examina con más detalle una planilla presentada para verificar que la información informada sea exacta. Vale la pena separar el hecho de ser auditado de la suposición de culpa: las auditorías ocurren por muchas razones, como la selección al azar, las anomalías estadísticas (cifras que parecen inusuales en comparación con contribuyentes similares) o simplemente porque una deducción o un tipo de ingreso en particular atrae un escrutinio más rutinario.

Aquí es donde la lección anterior sobre llevar registros rinde frutos de forma más directa. Alguien que ha llevado una documentación limpia y organizada durante el año normalmente puede responder a una auditoría con calma y eficiencia, presentando respaldo para lo que se cuestione. Alguien sin registros puede tener dificultades para sustentar sus reclamaciones aunque estas fueran totalmente legítimas; es decir, llevar buenos registros no solo sirve para evitar la evasión: es una protección activa para los contribuyentes honestos cuyas planillas simplemente se seleccionan para revisión.

## Ejemplo práctico

**Pregunta:** Alguien recibe una notificación de auditoría e inmediatamente supone que debe haber hecho algo ilegal. ¿Es correcta esa suposición?

**Estudiante:** Según esta lección, no necesariamente: las auditorías pueden ocurrir por razones que no tienen que ver con haber hecho algo mal, como la selección al azar o una cifra que parece inusual.

**Guía:** ¿Qué determina qué tan bien le irá a esta persona en la auditoría?

**Estudiante:** Si llevó buenos registros: si tiene documentación de lo que reclamó, puede sustentarlo con calma, aunque no haya hecho nada mal.

**Guía:** Exactamente. Una notificación de auditoría es una solicitud de verificación, no automáticamente una acusación.

## Prueba práctica

**Pregunta 1.** Una auditoría se describe mejor como:

A) Una acusación automática de un delito
B) Un proceso de revisión para verificar que la información informada sea exacta
C) Un tipo de crédito contributivo
D) Una penalidad que siempre se aplica

**Pregunta 2.** Las auditorías pueden activarse por:

A) Solo un mal manejo evidente
B) La selección al azar, las anomalías estadísticas o el escrutinio rutinario de ciertas reclamaciones
C) Nada: las auditorías son totalmente al azar, sin ninguna otra causa
D) Solo a quienes trabajan por cuenta propia

**Pregunta 3.** Llevar buenos registros ayuda más directamente durante una auditoría al:

A) No tener ningún efecto
B) Permitir sustentar las reclamaciones con calma y eficiencia
C) Garantizar que nunca haya una auditoría
D) Importar solo en el caso de los negocios

**Pregunta 4.** ¿Es recibir una notificación de auditoría una prueba automática de haber hecho algo mal?

A) Sí, siempre
B) No: es una solicitud de verificación, no una acusación automática
C) Solo para las corporaciones
D) Solo si se recibió un reintegro

## Clave de respuestas

1. B, 2. B, 3. B, 4. B

## Respuestas y explicaciones

**1.** La función de una auditoría es verificar, no emitir automáticamente una conclusión o acusación de culpa.

**2.** Existen varios detonantes no acusatorios, incluida la simple selección al azar.

**3.** La documentación es exactamente lo que permite a un contribuyente honesto responder a las preguntas de forma eficiente en lugar de andar corriendo.

**4.** La notificación en sí indica una solicitud para verificar, no una conclusión predeterminada.

## Puntos clave

- Una auditoría es una revisión de verificación, no una acusación automática de haber hecho algo mal.
- Las auditorías pueden activarse por la selección al azar, las anomalías estadísticas o el escrutinio rutinario.
- Llevar buenos registros es una protección directa y práctica durante una auditoría.
- Ser auditado y ser culpable de algo son dos cosas totalmente distintas.
