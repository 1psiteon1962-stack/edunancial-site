---
id: GREEN-L1-008
track: GREEN
officialTrackName: Taxes
level: 1
lessonNumber: 8
locale: it
title: "Imposte progressive vs. regressive"
summary: "Spiega la differenza tra strutture fiscali progressive e regressive con confronti semplici e facili da capire."
version: 1.0
author: Waldemar M. Caban, JD MA
date: 2026-09-24
---

# Imposte progressive vs. regressive

## Obiettivi di apprendimento

Alla fine di questa lezione sarai in grado di:

- Definire un'imposta progressiva
- Definire un'imposta regressiva
- Classificare esempi semplici in una delle due categorie

## Contenuto principale

Un'imposta progressiva chiede una percentuale più alta a chi guadagna di più. L'idea è che chi ha più capacità di pagare contribuisca con una quota maggiore. Molti sistemi di imposta sul reddito seguono questo modello.

Un'imposta regressiva finisce per pesare di più, in proporzione, su chi guadagna meno. Succede anche quando l'aliquota è uguale per tutti. L'imposta sui consumi è l'esempio classico: tutti pagano la stessa percentuale sull'acquisto, ma per chi guadagna poco rappresenta una parte maggiore del reddito.

Esiste anche l'imposta proporzionale, o ad aliquota unica (flat tax), che chiede la stessa percentuale del reddito a tutti. Capire queste strutture ti aiuta a seguire i dibattiti su chi debba pagare quanto, senza dover scegliere una parte.

## Esempio pratico

**[ESEMPIO ILLUSTRATIVO]** I nomi e i numeri che seguono sono inventati e servono solo a illustrare il concetto.

**Insegnante:** Due persone comprano lo stesso cellulare e pagano $50 di imposta. Una guadagna $1.000 al mese, l'altra $10.000. Che percentuale del reddito ha pagato ciascuna?

**Studente:** La prima il 5%. La seconda lo 0,5%.

**Insegnante:** L'imposta era uguale in denaro. Ma ha pesato allo stesso modo?

**Studente:** No. Ha pesato dieci volte di più su chi guadagna meno.

**Insegnante:** Questo è un effetto regressivo.

## Quiz di verifica

**1.** Un'imposta progressiva...

- A) Chiede una percentuale più alta a chi guadagna di più
- B) Chiede la stessa somma a tutti
- C) Pesa di più su chi guadagna meno
- D) Esiste solo per le imprese

**2.** Perché l'imposta sui consumi è spesso regressiva?

- A) Perché l'aliquota è più alta per i poveri
- B) Perché rappresenta una parte maggiore del reddito di chi guadagna meno
- C) Perché la pagano solo i ricchi
- D) Perché non ha un'aliquota

**3.** Un'imposta che chiede a tutti la stessa percentuale del reddito si chiama...

- A) Progressiva
- B) Regressiva
- C) Proporzionale
- D) Negativa

**4.** Qual è l'obiettivo di questa lezione?

- A) Dire quale sistema è il migliore
- B) Insegnare a non pagare le imposte
- C) Confrontare i Paesi
- D) Capire come funziona ciascuna struttura

## Chiave delle risposte

1. A
2. B
3. C
4. D

## Risposte e spiegazioni

**1. A) Chiede una percentuale più alta a chi guadagna di più** — Progressiva significa che la percentuale sale con il reddito.

**2. B) Perché rappresenta una parte maggiore del reddito di chi guadagna meno** — L'aliquota è uguale, ma la quota di reddito è maggiore per chi guadagna meno.

**3. C) Proporzionale** — Proporzionale, o ad aliquota unica, applica la stessa aliquota a tutti.

**4. D) Capire come funziona ciascuna struttura** — Lo scopo è comprendere le strutture, non prendere posizione.

## Punti chiave

- Progressiva: chi guadagna di più paga una percentuale maggiore
- Regressiva: pesa di più, in proporzione, su chi guadagna meno
- Conoscere le strutture aiuta a seguire i dibattiti pubblici

---

*Questa lezione ha finalità esclusivamente educative e non costituisce consulenza fiscale, legale o finanziaria personalizzata. Per decisioni sulla tua situazione, rivolgiti a un professionista qualificato.*
