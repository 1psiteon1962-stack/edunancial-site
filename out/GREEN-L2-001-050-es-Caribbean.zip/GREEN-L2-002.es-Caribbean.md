---
id: GREEN-L2-002
track: GREEN
officialTrackName: "Taxes"
level: 2
lessonNumber: 2
title: "Ingreso bruto vs. ingreso neto: dónde ocurren las deducciones"
summary: "Aprende la diferencia entre ingreso bruto e ingreso neto, qué categorías de deducciones los separan y por qué debes basar tu presupuesto en lo que realmente te depositan."
version: "1.0"
author: "Edunancial Faculty"
date: "2026-10-21"
locale: es-Caribbean
source_locale: en-US
---
# GREEN-L2-002: Ingreso bruto vs. ingreso neto: dónde ocurren las deducciones

## GREEN-L2-002
### Ingreso bruto vs. ingreso neto: dónde ocurren las deducciones

**1. Objetivos de aprendizaje**
Al terminar esta lección, podrás:
- Definir el ingreso bruto y el ingreso neto a nivel conceptual.
- Identificar las categorías generales de partidas que reducen el ingreso bruto hasta el ingreso neto (el pago que te llevas a casa).
- Distinguir este concepto a nivel individual de la discusión del estado de resultados de un negocio en el área BLUE.

**2. Contenido principal**
El ingreso bruto es el ingreso total antes de cualquier deducción o retención: el "salario establecido" de la Lección 1. El ingreso neto (o "pago neto") es lo que realmente queda después de restar los impuestos, las retenciones obligatorias y cualquier deducción elegida. Entre ambos hay varias categorías: las deducciones antes de impuestos (aportaciones de retiro, ciertas primas de seguro de salud y otros beneficios que reducen el ingreso tributable antes de calcular el impuesto), la retención de impuestos (federal, estatal y FICA, Lecciones 9 y 11) y las deducciones después de impuestos (como las aportaciones de retiro Roth u otros beneficios elegidos después de que el impuesto ya fue calculado).

Esta distinción individual entre bruto y neto hace eco de la discusión de BLUE-L2-011 sobre la ganancia de un negocio frente al flujo de efectivo, pero es distinta de ella: el recorrido de lo bruto a lo neto de una persona trata de la ruta que sigue un solo cheque de pago a través de impuestos y beneficios, mientras que la distinción entre ganancia y flujo de efectivo de un negocio trata de los desajustes de tiempo entre los ingresos devengados y el efectivo realmente recibido. Ambas ilustran la misma lección de fondo del Nivel 2: un número de la línea superior pocas veces es igual a lo que realmente se puede usar.

**3. Ejemplo práctico**
Al revisar su primer talonario de pago, Amara se sorprende de que el pago que realmente le depositaron es notablemente menor que el salario que le cotizaron al contratarla. Repasando el talonario línea por línea, identifica su aportación al 401(k) (plan de ahorro para el retiro) antes de impuestos, su retención de impuestos federales y estatales, su retención de FICA (Seguro Social y Medicare) y una pequeña deducción después de impuestos por una póliza de seguro suplementario que eligió; en conjunto, estas partidas explican toda la diferencia entre su salario bruto y su depósito neto real. Entender este desglose la ayuda a hacer un presupuesto preciso de ahora en adelante, usando su ingreso neto real en lugar de su salario bruto como el número alrededor del cual planifica.

**4. Prueba de práctica**
1. ¿Qué es el ingreso bruto?
   a) El pago neto después de todas las deducciones
   b) El ingreso total antes de cualquier deducción o retención
   c) Un tipo de crédito tributario
   d) Un programa de beneficios del gobierno
2. ¿Qué es una "deducción antes de impuestos"?
   a) Una deducción que se toma después de calcular los impuestos
   b) Una deducción, como una aportación a un 401(k) tradicional, que reduce el ingreso tributable antes de calcular el impuesto
   c) Un tipo de reembolso de impuestos
   d) Una penalidad por pago insuficiente
3. Cierto o falso: El recorrido de lo bruto a lo neto en el cheque de pago de una persona y la distinción entre ganancia y flujo de efectivo de un negocio son exactamente el mismo concepto.
4. ¿Por qué debe Amara hacer su presupuesto con su ingreso neto en lugar de su salario bruto?
   a) El salario bruto siempre es idéntico al ingreso neto
   b) El ingreso neto refleja lo que realmente se deposita y se puede usar, a diferencia de la cifra bruta
   c) El presupuesto debe ignorar los impuestos por completo
   d) El ingreso neto siempre es mayor que el ingreso bruto

**5. Clave de respuestas**
1. b  2. b  3. Falso  4. b

**6. Respuestas y explicaciones**
1. El ingreso bruto es el ingreso total antes de aplicar cualquier deducción o retención.
2. Una deducción antes de impuestos reduce el ingreso tributable antes de calcular el impuesto, como una aportación a un 401(k) tradicional.
3. Son conceptos relacionados pero distintos: uno trata del recorrido tributario del cheque de pago de una persona; el otro, de los desajustes de tiempo en un negocio.
4. Hacer el presupuesto con el ingreso neto refleja lo que realmente hay disponible para gastar y evita el error común de planificar con el salario bruto.

**7. Puntos clave**
- El ingreso bruto es el ingreso total antes de las deducciones; el ingreso neto es lo que realmente queda después de los impuestos y las deducciones elegidas.
- Las deducciones antes de impuestos reducen el ingreso tributable antes del cálculo del impuesto; las deducciones después de impuestos se toman luego.
- Este concepto del cheque de pago individual hace eco de la distinción entre ganancia y flujo de efectivo del área BLUE, pero es distinto de ella.
- El presupuesto debe basarse en el ingreso neto, no en la cifra bruta, para reflejar lo que realmente se puede usar.

---
