---
id: GREEN-L2-006
track: GREEN
officialTrackName: "Taxes"
level: 2
lessonNumber: 6
title: "Deducciones vs. créditos: dos herramientas distintas"
summary: "Aprende la diferencia entre una deducción, que reduce el ingreso tributable, y un crédito tributario, que reduce el impuesto adeudado dólar por dólar, y por qué un crédito suele valer más."
version: "1.0"
author: "Edunancial Faculty"
date: "2026-10-21"
locale: es-Caribbean
source_locale: en-US
---
# GREEN-L2-006: Deducciones vs. créditos: dos herramientas distintas

## GREEN-L2-006
### Deducciones vs. créditos: dos herramientas distintas

**1. Objetivos de aprendizaje**
Al terminar esta lección, podrás:
- Distinguir una deducción tributaria de un crédito tributario.
- Explicar por qué un crédito generalmente es más valioso, dólar por dólar, que una deducción.
- Aplicar esta distinción a una comparación sencilla.

**2. Contenido principal**
Una deducción tributaria reduce el ingreso tributable antes de calcular el impuesto, lo que significa que su valor real depende de la tasa impositiva marginal del contribuyente (Lección 3): una deducción vale más para alguien en un tramo más alto que para alguien en un tramo más bajo, ya que reduce ingreso que de otro modo se habría gravado a esa tasa marginal más alta. Un crédito tributario, en cambio, reduce el impuesto realmente adeudado dólar por dólar, sin importar el tramo del contribuyente, por lo que un crédito de cierto tamaño generalmente es más valioso que una deducción del mismo tamaño.

Algunos créditos son "no reembolsables" (pueden reducir el impuesto adeudado a cero, pero no por debajo de cero, lo que significa que cualquier exceso de crédito más allá del impuesto adeudado generalmente se pierde), mientras que otros son "reembolsables" (pueden reducir el impuesto adeudado por debajo de cero, lo que resulta en un pago de reembolso real aunque no se adeudara ningún impuesto). Esta distinción de reembolsabilidad afecta significativamente el valor real de un crédito para los contribuyentes de menores ingresos, que pueden deber poco o ningún impuesto antes de aplicar el crédito.

**3. Ejemplo práctico**
Al comparar una deducción tributaria de $1,000 con un crédito tributario de $1,000, una contribuyente en el tramo marginal de 22% calcula que la deducción reduciría su impuesto adeudado en $220 (22% de $1,000), mientras que el crédito reduciría su impuesto adeudado en los $1,000 completos: una ilustración directa de por qué un crédito del mismo tamaño generalmente vale mucho más que una deducción. También aprende que, si el crédito específico que está evaluando es no reembolsable, su valor estaría limitado a la cantidad de impuesto que realmente debe antes de aplicarlo, mientras que un crédito reembolsable podría resultar en un reembolso incluso más allá de su obligación tributaria real.

**4. Prueba de práctica**
1. ¿Qué hace generalmente una deducción tributaria?
   a) Reduce el impuesto adeudado dólar por dólar
   b) Reduce el ingreso tributable antes de calcular el impuesto
   c) Garantiza un reembolso de impuestos
   d) Aumenta la tasa marginal del contribuyente
2. ¿Por qué un crédito tributario generalmente es más valioso, dólar por dólar, que una deducción del mismo tamaño?
   a) Los créditos no tienen valor real
   b) Un crédito reduce el impuesto adeudado dólar por dólar, sin importar el tramo marginal del contribuyente
   c) Las deducciones siempre superan a los créditos en valor
   d) Los créditos solo se aplican a los negocios
3. Cierto o falso: Un crédito no reembolsable puede reducir el impuesto adeudado de un contribuyente por debajo de cero, lo que resulta en un reembolso más allá de su obligación real.
4. ¿Por qué el crédito de $1,000 valió más para la contribuyente que la deducción de $1,000?
   a) La deducción redujo su impuesto adeudado en los $1,000 completos, igual que el crédito
   b) La deducción solo redujo su impuesto adeudado en $220 (su tasa marginal), mientras que el crédito lo redujo en los $1,000 completos
   c) Los créditos y las deducciones son funcionalmente idénticos
   d) El crédito no tenía valor real

**5. Clave de respuestas**
1. b  2. b  3. Falso  4. b

**6. Respuestas y explicaciones**
1. Una deducción tributaria reduce el ingreso tributable antes de calcular el impuesto.
2. Un crédito reduce el impuesto adeudado dólar por dólar sin importar el tramo, lo que generalmente lo hace más valioso que una deducción del mismo tamaño.
3. Un crédito no reembolsable puede reducir el impuesto adeudado a cero pero no por debajo de cero; un crédito reembolsable puede resultar en un reembolso más allá de la obligación real.
4. El valor de la deducción estuvo limitado por la tasa marginal de la contribuyente, mientras que el crédito aportó su valor completo directamente contra el impuesto adeudado.

**7. Puntos clave**
- Una deducción reduce el ingreso tributable antes del cálculo del impuesto; un crédito reduce el impuesto adeudado dólar por dólar.
- Un crédito de cierto tamaño generalmente es más valioso que una deducción del mismo tamaño.
- Los créditos no reembolsables están limitados al impuesto realmente adeudado; los créditos reembolsables pueden producir un reembolso más allá de esa obligación.
- Entender esta distinción aclara por qué no todos los beneficios tributarios valen lo mismo.

---
