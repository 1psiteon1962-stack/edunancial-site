---
id: GREEN-L2-008
track: GREEN
officialTrackName: "Taxes"
level: 2
lessonNumber: 8
title: "Deducciones \"sobre la línea\" vs. \"debajo de la línea"
summary: "Aprende la diferencia entre las deducciones sobre la línea, que reducen el ingreso bruto hasta el ingreso bruto ajustado, y las de debajo de la línea, y por qué las primeras pueden aportar un valor adicional."
version: "1.0"
author: "Edunancial Faculty"
date: "2026-10-21"
locale: es-Caribbean
source_locale: en-US
---
# GREEN-L2-008: Deducciones "sobre la línea" vs. "debajo de la línea

## GREEN-L2-008
### Deducciones "sobre la línea" vs. "debajo de la línea"

**1. Objetivos de aprendizaje**
Al terminar esta lección, podrás:
- Distinguir las deducciones sobre la línea de las deducciones debajo de la línea.
- Explicar por qué las deducciones sobre la línea pueden ser particularmente valiosas.
- Aplicar esta distinción a una situación tributaria hipotética.

**2. Contenido principal**
Partiendo de las Lecciones 6–7, esta lección presenta una distinción adicional. Las deducciones "sobre la línea" (above-the-line), como ciertas aportaciones de retiro o los intereses de préstamos estudiantiles, sujetas a los límites aplicables, reducen el ingreso bruto para llegar al ingreso bruto ajustado (AGI, por sus siglas en inglés), una cifra que se usa como umbral para varios otros beneficios tributarios y cálculos de elegibilidad. Las deducciones "debajo de la línea" (below-the-line), que son la deducción estándar o las deducciones detalladas (Lección 7), se restan después de calcular el AGI y reducen aún más el AGI para llegar al ingreso tributable.

Esta distinción importa porque las deducciones sobre la línea se pueden tomar sin importar si el contribuyente detalla o toma la deducción estándar, y porque reducir el propio AGI puede afectar la elegibilidad para otros beneficios tributarios y umbrales de eliminación gradual (phase-out) que se calculan con base en el AGI. Esto significa que una deducción sobre la línea puede aportar valor más allá de su reducción tributaria directa, al posiblemente preservar la elegibilidad para otros beneficios ligados a los umbrales de AGI.

**3. Ejemplo práctico**
Al aportar a una cuenta IRA (cuenta individual de retiro) tradicional, Simone aprovecha una deducción sobre la línea que reduce su AGI directamente, sin importar si detalla o toma la deducción estándar como su elección de deducción debajo de la línea (Lección 7). Este AGI reducido no solo baja su ingreso tributable directamente, sino que también la ayuda a seguir siendo elegible para un beneficio tributario aparte con un umbral de eliminación gradual basado en el AGI, al que habría perdido parcialmente el acceso con su nivel de AGI más alto antes de la deducción. Esto ilustra el valor adicional que pueden aportar las deducciones sobre la línea más allá de su reducción tributaria directa.

**4. Prueba de práctica**
1. ¿Qué reducen generalmente las deducciones sobre la línea?
   a) El ingreso tributable directamente, sin relación con el AGI
   b) El ingreso bruto para llegar al ingreso bruto ajustado (AGI)
   c) Solo los totales de deducciones detalladas
   d) Exclusivamente los impuestos estatales
2. ¿Por qué las deducciones sobre la línea pueden aportar valor más allá de su reducción tributaria directa?
   a) No tienen ningún valor adicional
   b) Reducir el AGI puede ayudar a preservar la elegibilidad para otros beneficios tributarios con umbrales de eliminación gradual basados en el AGI
   c) Eliminan automáticamente todos los impuestos adeudados
   d) Solo se aplican a las opciones de deducción debajo de la línea
3. Cierto o falso: Un contribuyente debe detallar sus deducciones para poder reclamar cualquier deducción sobre la línea.
4. ¿Cómo aportó la aportación de Simone a la IRA valor más allá de su reducción tributaria directa?
   a) No tuvo ningún efecto adicional
   b) La ayudó a preservar la elegibilidad para un beneficio aparte con un umbral de eliminación gradual basado en el AGI
   c) La obligó a detallar sus deducciones
   d) Aumentó su AGI

**5. Clave de respuestas**
1. b  2. b  3. Falso  4. b

**6. Respuestas y explicaciones**
1. Las deducciones sobre la línea reducen el ingreso bruto para llegar al ingreso bruto ajustado (AGI).
2. Reducir el AGI puede ayudar a preservar la elegibilidad para otros beneficios tributarios ligados a umbrales de eliminación gradual basados en el AGI.
3. Las deducciones sobre la línea se pueden tomar sin importar si el contribuyente detalla o toma la deducción estándar.
4. El AGI reducido de Simone ayudó a preservar su elegibilidad para un beneficio aparte que depende de un umbral de AGI, más allá de la reducción tributaria directa.

**7. Puntos clave**
- Las deducciones sobre la línea reducen el ingreso bruto hasta el AGI; las deducciones debajo de la línea reducen aún más el AGI hasta el ingreso tributable.
- Las deducciones sobre la línea se pueden reclamar sin importar si se elige la deducción estándar o detallar.
- Reducir el AGI puede preservar la elegibilidad para otros beneficios tributarios ligados a umbrales de eliminación gradual basados en el AGI.
- Este valor adicional hace que valga la pena entender y aprovechar las deducciones sobre la línea cuando estén disponibles.

---
