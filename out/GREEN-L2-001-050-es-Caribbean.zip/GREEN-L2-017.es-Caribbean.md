---
id: GREEN-L2-017
track: GREEN
officialTrackName: "Taxes"
level: 2
lessonNumber: 17
title: "Deuda buena vs. deuda mala: una introducción (adelanto del Nivel 3)"
summary: "Conoce la distinción básica entre deuda productiva, que financia un activo o capacidad que genera valor, y deuda de consumo, que financia gasto inmediato, y cómo se conecta con adelantos de otros colores."
version: "1.0"
author: "Edunancial Faculty"
date: "2026-10-21"
locale: es-Caribbean
source_locale: en-US
---
# GREEN-L2-017: Deuda buena vs. deuda mala: una introducción (adelanto del Nivel 3)

## GREEN-L2-017
### Deuda buena vs. deuda mala: una introducción (adelanto del Nivel 3)

**1. Objetivos de aprendizaje**
Al terminar esta lección, podrás:
- Definir a nivel introductorio la distinción general entre deuda productiva y deuda de consumo.
- Conectar este concepto con los adelantos de deuda estratégica de RED-L2-050 y BLUE-L2-050.
- Reconocer este tema como uno del Nivel 3 que se presenta temprano para dar contexto.

**2. Contenido principal**
Haciendo eco de la distinción entre deuda estratégica y deuda de consumo que se adelantó en RED-L2-050 y BLUE-L2-050, esta lección presenta el mismo concepto central desde la perspectiva de finanzas personales de GREEN: la deuda que se usa para adquirir un activo o una capacidad que puede generar ingresos o valor futuros (una hipoteca sobre una propiedad de alquiler, un préstamo para estudios que lleva a un mayor potencial de ingresos) a veces se llama deuda "productiva" o "estratégica", mientras que la deuda que se usa para financiar consumo inmediato sin ningún activo duradero ni capacidad de generar ingresos (la mayor parte de la deuda de tarjeta de crédito por gastos cotidianos, un préstamo para un bien de consumo que se deprecia rápidamente) a veces se llama deuda "de consumo".

Esta distinción se presenta aquí a nivel introductorio específicamente para adelantar un tema que será central en el Nivel 3 en varios colores: el caso de estudio de apalancamiento hipotecario de RED-L3 y el caso de estudio de financiamiento del vendedor de BLUE-L3 se construirán directamente sobre este mismo concepto fundamental, ahora presentado desde la perspectiva de las finanzas personales cotidianas que aborda esta lección del área GREEN.

**3. Ejemplo práctico**
Al revisar sus propias deudas, un joven profesional distingue entre su préstamo estudiantil, que financió estudios directamente conectados con su carrera actual de mayores ingresos (un ejemplo de deuda productiva, haciendo eco de los adelantos de deuda estratégica de las áreas RED y BLUE), y el balance de su tarjeta de crédito arrastrado por cubrir gastos de vida cotidianos durante un período de subempleo, sin ningún activo ni capacidad de generar ingresos detrás (un ejemplo de deuda de consumo). Reconocer esta distinción lo ayuda a priorizar cuál deuda atacar con más agresividad, una estrategia que se desarrolla más en la Lección 18.

**4. Prueba de práctica**
1. ¿Qué caracteriza generalmente a la deuda "productiva" o "estratégica"?
   a) Deuda que se usa para consumo inmediato sin valor duradero
   b) Deuda que se usa para adquirir un activo o una capacidad que puede generar ingresos o valor futuros
   c) Un tipo de crédito tributario
   d) Deuda que nunca necesita pagarse
2. ¿Qué caracteriza generalmente a la deuda "de consumo"?
   a) Deuda respaldada por un activo que produce ingresos
   b) Deuda que se usa para financiar consumo inmediato sin ningún activo duradero ni capacidad de generar ingresos
   c) Deuda que se usa exclusivamente para bienes raíces
   d) Deuda que siempre le gana dinero al prestatario
3. Cierto o falso: Esta distinción es completamente nueva en este currículo y no tiene relación con la discusión de ningún otro color.
4. ¿Por qué el préstamo estudiantil del joven profesional calificó como deuda productiva en su análisis?
   a) Financió consumo sin valor duradero
   b) Financió estudios directamente conectados con su carrera actual de mayores ingresos
   c) Toda deuda es productiva automáticamente
   d) Ya lo había pagado por completo

**5. Clave de respuestas**
1. b  2. b  3. Falso  4. b

**6. Respuestas y explicaciones**
1. La deuda productiva o estratégica financia un activo o una capacidad capaz de generar ingresos o valor futuros.
2. La deuda de consumo financia consumo inmediato sin ningún activo duradero ni capacidad de generar ingresos.
3. Esta distinción hace eco directo y adelanta las discusiones de deuda estratégica de RED-L2-050 y BLUE-L2-050.
4. La conexión del préstamo estudiantil con su carrera actual de mayores ingresos lo calificó como un ejemplo de deuda productiva.

**7. Puntos clave**
- La deuda productiva o estratégica financia un activo o una capacidad que puede generar ingresos o valor futuros.
- La deuda de consumo financia consumo inmediato sin ningún activo duradero ni capacidad de generar ingresos.
- Esta distinción hace eco y adelanta las discusiones de deuda estratégica de RED-L2-050 y BLUE-L2-050 desde la perspectiva de las finanzas personales.
- Este concepto será central en el Nivel 3 en varios colores, y se presenta aquí a nivel introductorio.

---
