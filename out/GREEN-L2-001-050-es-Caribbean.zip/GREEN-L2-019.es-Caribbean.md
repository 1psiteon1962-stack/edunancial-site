---
id: GREEN-L2-019
track: GREEN
officialTrackName: "Taxes"
level: 2
lessonNumber: 19
title: "Puntajes de crédito: qué mueve realmente el número"
summary: "Aprende los factores generales que influyen en un puntaje de crédito, cuáles suelen pesar más, como el historial de pagos, y cómo el pago puntual y constante conecta el crédito personal, el hipotecario y el de negocios."
version: "1.0"
author: "Edunancial Faculty"
date: "2026-10-21"
locale: es-Caribbean
source_locale: en-US
---
# GREEN-L2-019: Puntajes de crédito: qué mueve realmente el número

## GREEN-L2-019
### Puntajes de crédito: qué mueve realmente el número

**1. Objetivos de aprendizaje**
Al terminar esta lección, podrás:
- Identificar los factores generales que influyen en un puntaje de crédito.
- Explicar el peso relativo que comúnmente se atribuye a los distintos factores.
- Conectar este concepto con discusiones anteriores sobre el crédito de negocios y el crédito hipotecario.

**2. Contenido principal**
Los puntajes de crédito generalmente están influenciados por varios factores, que comúnmente incluyen el historial de pagos (si los pagos se han hecho a tiempo), los montos adeudados en relación con el crédito disponible (se desarrolla más en la Lección 20), la antigüedad del historial de crédito, la mezcla de crédito (la variedad de tipos de crédito que se usan) y las nuevas consultas de crédito. El historial de pagos y los montos adeudados comúnmente se citan como los que tienen mayor peso relativo entre estos factores en muchos modelos de puntaje comunes, aunque los pesos exactos pueden variar según el modelo de puntaje específico que se use.

Esto hace eco de conceptos presentados en otras partes de este currículo: RED-L2-001 discutió cómo el historial de pagos de una hipoteca afecta el crédito, y BLUE-L2-016 discutió cómo construir un crédito de negocio separado mediante pagos puntuales y constantes. El mismo principio central (el pago constante y a tiempo como el factor de mayor peso) se repite en los contextos de crédito personal, de bienes raíces y de negocios por igual.

**3. Ejemplo práctico**
Al revisar su informe de crédito después de un período de estrés financiero que causó algunos pagos tardíos, Amara nota que su puntaje bajó mucho más de lo que esperaba por lo que parecía un descuido relativamente menor. Al investigar el peso general de los factores del puntaje de crédito, aprende que el historial de pagos tiene un peso sustancial en los modelos de puntaje comunes, lo que explica por qué incluso unos pocos pagos tardíos tuvieron un efecto desproporcionado en su puntaje en comparación con otros factores. Se compromete a mantener un patrón constante de pagos a tiempo de ahora en adelante, y reconoce este como el factor individual de mayor impacto que puede controlar.

**4. Prueba de práctica**
1. ¿Cuál de los siguientes se cita comúnmente como un factor de peso sustancial en los modelos de puntaje de crédito?
   a) El color de la tarjeta de crédito
   b) El historial de pagos: si los pagos se han hecho a tiempo
   c) El pasatiempo favorito del tarjetahabiente
   d) La ubicación física de la sucursal del banco
2. ¿Qué principio recurrente conecta esta lección con RED-L2-001 y BLUE-L2-016?
   a) Nada conecta estas lecciones
   b) El pago constante y a tiempo es un factor de gran peso en los contextos de crédito personal, de bienes raíces y de negocios
   c) Los puntajes de crédito solo se aplican a las finanzas personales, nunca a los negocios ni a los bienes raíces
   d) Los pagos tardíos no tienen efecto en ningún tipo de crédito
3. Cierto o falso: Todos los factores del puntaje de crédito tienen un peso idéntico e igual en todos los modelos de puntaje comunes.
4. ¿Por qué el puntaje de Amara bajó más de lo que esperaba por unos pocos pagos tardíos?
   a) Los pagos tardíos no tienen efecto en los puntajes de crédito
   b) El historial de pagos tiene un peso sustancial en los modelos de puntaje comunes, lo que le da incluso a unos pocos pagos tardíos un efecto desproporcionado
   c) Lo único afectado fue la antigüedad de su historial de crédito
   d) Los puntajes de crédito se calculan al azar

**5. Clave de respuestas**
1. b  2. b  3. Falso  4. b

**6. Respuestas y explicaciones**
1. El historial de pagos se cita comúnmente como un factor de gran peso en los modelos comunes de puntaje de crédito.
2. El principio del pago constante y a tiempo se repite en los contextos de crédito personal, de bienes raíces y de negocios a lo largo de este currículo.
3. Los modelos de puntaje comunes generalmente le dan más peso a factores como el historial de pagos y los montos adeudados que a otros factores.
4. El peso sustancial del historial de pagos explica por qué incluso unos pocos pagos tardíos tuvieron un efecto desproporcionado en el puntaje de Amara.

**7. Puntos clave**
- Los puntajes de crédito comúnmente están influenciados por el historial de pagos, los montos adeudados, la antigüedad del historial de crédito, la mezcla de crédito y las nuevas consultas.
- El historial de pagos y los montos adeudados comúnmente tienen un peso relativo sustancial en muchos modelos de puntaje.
- Este principio recurrente se conecta con la discusión del crédito hipotecario de RED-L2-001 y con la del crédito de negocios de BLUE-L2-016.
- El pago constante y a tiempo es un factor controlable con un efecto desproporcionado en los puntajes de crédito en todos los contextos.

---
