---
id: GREEN-L2-020
track: GREEN
officialTrackName: "Taxes"
level: 2
lessonNumber: 20
title: "La utilización del crédito y su impacto desproporcionado"
summary: "Aprende qué es la utilización del crédito, por qué pesa tanto en tu puntaje aunque pagues a tiempo, cómo calcularla y por qué el balance reportado al cierre del estado de cuenta es el que cuenta."
version: "1.0"
author: "Edunancial Faculty"
date: "2026-10-21"
locale: es-Caribbean
source_locale: en-US
---
# GREEN-L2-020: La utilización del crédito y su impacto desproporcionado

## GREEN-L2-020
### La utilización del crédito y su impacto desproporcionado

**1. Objetivos de aprendizaje**
Al terminar esta lección, podrás:
- Definir la utilización del crédito a nivel conceptual.
- Explicar por qué este factor tiene un peso significativo en el puntaje de crédito.
- Calcular una razón sencilla de utilización del crédito.

**2. Contenido principal**
La utilización del crédito es la razón entre los balances actuales de crédito y el crédito total disponible, y generalmente se calcula tanto por cada cuenta individual como en conjunto entre todas las cuentas de crédito rotativo. Este factor se cita comúnmente como uno de peso significativo en los modelos de puntaje de crédito (haciendo eco de la discusión de la Lección 19), independientemente de si los pagos se hacen realmente a tiempo: una persona podría pagar su balance completo todos los meses sin faltar nunca a un pago, y aun así ver afectada su razón de utilización por balances altos en relación con sus límites de crédito en el momento específico en que se revisa o se reporta su crédito.

Una guía general que se menciona comúnmente sugiere mantener la utilización claramente por debajo de 30% del crédito disponible, tanto por tarjeta como en conjunto, para obtener mejores resultados de puntaje de crédito, aunque una utilización más baja se ve aún más favorablemente. Es un factor que puede cambiar con relativa rapidez en comparación con la antigüedad del historial de crédito, lo que lo convierte en una de las palancas más directamente controlables para alguien que trabaja activamente en mejorar su puntaje de crédito en un plazo más corto.

**3. Ejemplo práctico**
Julio (de la Lección 18) tiene una tarjeta de crédito con un límite de $10,000 y normalmente tiene un balance de $4,000 cuando cierra su estado de cuenta cada mes, aunque paga el balance completo antes de que se acumulen intereses: una razón de utilización de 40% ($4,000 dividido entre $10,000), por encima de la guía de 30% que se menciona comúnmente. Al aprender que la utilización se calcula con el balance reportado al cierre del estado de cuenta, y no necesariamente con su balance final de cero después de pagar, ajusta su práctica haciendo un pago antes de la fecha de cierre del estado de cuenta, específicamente para reducir su balance reportado y su razón de utilización, aunque ya pagaba su balance completo todos los meses sin cargos por intereses.

**4. Prueba de práctica**
1. ¿Qué es la utilización del crédito?
   a) La tasa de interés de una tarjeta de crédito
   b) La razón entre los balances actuales de crédito y el crédito total disponible
   c) La antigüedad del historial de crédito de una persona
   d) Un tipo de deducción tributaria
2. ¿Cuál es una guía general de utilización que se menciona comúnmente?
   a) Mantener la utilización por encima de 90%
   b) Mantener la utilización claramente por debajo de 30% del crédito disponible
   c) La utilización no tiene ningún efecto en los puntajes de crédito
   d) La utilización solo importa para el crédito de negocios
3. Cierto o falso: Pagar el balance completo de una tarjeta de crédito todos los meses garantiza automáticamente una razón de utilización reportada baja.
4. ¿Por qué la razón de utilización de Julio se mantuvo alta a pesar de que pagaba su balance completo todos los meses?
   a) La utilización no tiene relación con los balances reportados
   b) La utilización generalmente se calcula con el balance reportado al cierre del estado de cuenta, no con su balance final de cero después de pagar
   c) En realidad nunca pagó su balance
   d) Su límite de crédito era demasiado alto

**5. Clave de respuestas**
1. b  2. b  3. Falso  4. b

**6. Respuestas y explicaciones**
1. La utilización del crédito es la razón entre los balances actuales de crédito y el crédito total disponible.
2. Una guía que se menciona comúnmente sugiere mantener la utilización claramente por debajo de 30% del crédito disponible.
3. La utilización generalmente se calcula con el balance al cierre del estado de cuenta, que puede ser alto aunque luego se pague por completo.
4. El balance alto de Julio al cierre del estado de cuenta creó una razón de utilización reportada alta, a pesar de sus pagos completos y a tiempo antes de que se acumularan intereses.

**7. Puntos clave**
- La utilización del crédito es la razón entre los balances actuales de crédito y el crédito total disponible, y se calcula por cuenta y en conjunto.
- Este factor tiene un peso significativo en el puntaje de crédito, aparte del historial de pagos a tiempo.
- Una guía que se menciona comúnmente sugiere mantener la utilización claramente por debajo de 30%.
- La utilización generalmente se basa en el balance al cierre del estado de cuenta, lo que significa que incluso pagar todo cada mes puede aun así mostrar una utilización reportada alta.

---
