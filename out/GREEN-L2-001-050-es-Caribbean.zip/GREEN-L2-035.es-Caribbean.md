---
id: GREEN-L2-035
track: GREEN
officialTrackName: "Taxes"
level: 2
lessonNumber: 35
title: "Auditorías: qué las provoca y qué implican realmente"
summary: "Entiende para qué sirve una auditoría de impuestos, qué factores pueden aumentar su probabilidad y por qué ser auditado no significa necesariamente haber hecho algo mal, sobre todo si llevas buenos registros."
version: "1.0"
author: "Edunancial Faculty"
date: "2026-10-21"
locale: es-Caribbean
source_locale: en-US
---
# GREEN-L2-035: Auditorías: qué las provoca y qué implican realmente

## GREEN-L2-035
### Auditorías: qué las provoca y qué implican realmente

**1. Objetivos de aprendizaje**
Al terminar esta lección, podrás:
- Explicar el propósito general de una auditoría de impuestos.
- Identificar los factores generales que pueden aumentar la probabilidad de una auditoría.
- Reconocer qué implica realmente una auditoría, y atender los conceptos erróneos comunes.

**2. Contenido principal**
Una auditoría de impuestos es un proceso de revisión en el cual una autoridad tributaria examina con más detalle la declaración de un contribuyente y sus registros de respaldo para verificar su exactitud. Las auditorías pueden ser provocadas por varios factores, entre ellos anomalías estadísticas en relación con declaraciones similares, partidas específicas conocidas por atraer mayor escrutinio (como deducciones inusualmente grandes en relación con el ingreso) o, en algunos casos, una selección al azar: que un contribuyente sea auditado no significa necesariamente que haya hecho algo mal, y muchas auditorías no resultan en ningún cambio a la declaración presentada originalmente.

Contrario a un concepto erróneo común que genera ansiedad, una auditoría no significa automáticamente una falta grave ni consecuencias severas: muchas auditorías se realizan por correo, y piden documentación que respalde partidas específicas, en lugar de un examen intensivo en persona de toda la vida financiera de la persona. Esta es precisamente la razón por la que la discusión sobre el mantenimiento de registros de la Lección 36 importa directamente: unos buenos registros hacen que responder a una auditoría, sea cual sea su alcance, sea considerablemente más sencillo y menos estresante.

**3. Ejemplo práctico**
Al recibir un aviso de auditoría por una deducción específica reclamada en su declaración de impuestos, Fatima (de la Lección 21) siente inicialmente mucha ansiedad y asume lo peor. Después de consultar con su profesional de impuestos, aprende que se trata de una auditoría rutinaria por correo que solicita documentación específica que respalde esa deducción, y no de un examen integral de toda su vida financiera. Como había mantenido registros organizados que respaldaban esa deducción (haciendo eco de las prácticas de mantenimiento de registros de la Lección 36), puede responder con prontitud y de forma completa, y resuelve la auditoría sin ningún cambio a su declaración presentada originalmente.

**4. Prueba de práctica**
1. ¿Cuál es el propósito general de una auditoría de impuestos?
   a) Penalizar automáticamente a todo contribuyente seleccionado
   b) Revisar con más detalle la declaración de un contribuyente y sus registros de respaldo para verificar su exactitud
   c) Eliminar la necesidad de presentar cualquier declaración de impuestos
   d) Garantizar un reembolso más grande
2. ¿Ser seleccionado para una auditoría significa automáticamente que el contribuyente hizo algo mal?
   a) Sí, siempre
   b) No: muchas auditorías no resultan en ningún cambio a la declaración presentada originalmente
   c) Las auditorías en realidad nunca ocurren
   d) Solo los negocios pueden ser auditados
3. Cierto o falso: Toda auditoría implica un examen intensivo en persona de toda la vida financiera de un contribuyente.
4. ¿Por qué Fatima pudo resolver su auditoría sin ningún cambio a su declaración?
   a) No tenía registros que respaldaran su deducción
   b) Sus registros organizados, mantenidos con anticipación, le permitieron responder con prontitud y de forma completa
   c) Ignoró por completo el aviso de auditoría
   d) La auditoría no tenía nada que ver con su deducción real

**5. Clave de respuestas**
1. b  2. b  3. Falso  4. b

**6. Respuestas y explicaciones**
1. Una auditoría de impuestos revisa con más detalle la declaración de un contribuyente y sus registros de respaldo para verificar su exactitud.
2. Muchas auditorías no resultan en ningún cambio a la declaración presentada originalmente; la selección no indica automáticamente una falta.
3. Muchas auditorías se realizan por correo y atienden partidas específicas, en lugar de un examen integral en persona.
4. El mantenimiento anticipado de registros de Fatima le permitió responder con prontitud y de forma completa, y resolver su auditoría sin ningún cambio.

**7. Puntos clave**
- Una auditoría de impuestos revisa con más detalle una declaración y sus registros de respaldo para verificar su exactitud, y no para penalizar automáticamente.
- Las auditorías pueden ser provocadas por anomalías estadísticas, partidas específicas bajo escrutinio o selección al azar.
- Muchas auditorías se realizan por correo y atienden partidas específicas, y no son un examen integral en persona.
- Unos buenos registros, haciendo eco de la Lección 36, hacen considerablemente más sencillo responder a cualquier auditoría.

---
