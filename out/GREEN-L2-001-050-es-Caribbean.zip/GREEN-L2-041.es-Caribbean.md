---
id: GREEN-L2-041
track: GREEN
officialTrackName: "Taxes"
level: 2
lessonNumber: 41
title: "Impuestos sobre ganancias de capital, de nuevo: una perspectiva GREEN de WHITE-L2-031"
summary: "Repasa cómo las ganancias de capital a corto y largo plazo interactúan con las tasas marginales y efectivas, y por qué escoger el momento de una venta es una decisión de planificación que se toma antes de vender."
version: "1.0"
author: "Edunancial Faculty"
date: "2026-10-21"
locale: es-Caribbean
source_locale: en-US
---
# GREEN-L2-041: Impuestos sobre ganancias de capital, de nuevo: una perspectiva GREEN de WHITE-L2-031

## GREEN-L2-041
### Impuestos sobre ganancias de capital, de nuevo: una perspectiva GREEN de WHITE-L2-031

**1. Objetivos de aprendizaje**
Al terminar esta lección, podrás:
- Reforzar la discusión de las ganancias de capital de WHITE-L2-031 desde la perspectiva de la mecánica tributaria de GREEN.
- Explicar cómo interactúan las ganancias de capital con los conceptos de tasa marginal y efectiva de las Lecciones 3–4.
- Conectar este concepto con la distinción entre planificación y preparación de impuestos de la Lección 39.

**2. Contenido principal**
Al retomar la presentación de WHITE-L2-031 sobre las ganancias de capital a corto y a largo plazo, esta lección examina cómo estas ganancias interactúan con la mecánica tributaria más amplia que se desarrolló a lo largo de GREEN-L2. Las ganancias de capital a corto plazo comúnmente se gravan a las mismas tasas que el ingreso ordinario (la misma estructura de tramos de las Lecciones 3–4), mientras que las ganancias de capital a largo plazo comúnmente reciben tasas distintas, a menudo más favorables, en muchas jurisdicciones, incluido EE. UU. Esto significa que la distinción del período de tenencia de WHITE-L2-031 tiene un efecto directo, y a veces significativo, en la obligación tributaria total real de un contribuyente.

Esto se conecta directamente con la distinción entre planificación y preparación de la Lección 39: la decisión de cuándo vender un activo que ha subido de valor (potencialmente pasando del trato de corto plazo al de largo plazo, o escogiendo el momento de una venta para alinearla con el nivel de ingreso esperado y el tramo impositivo de un año específico) es una decisión de planificación proactiva que está disponible antes de que ocurra una venta, y no algo que se pueda ajustar retroactivamente una vez que empieza la preparación de impuestos de un año en el que la venta ya se completó.

**3. Ejemplo práctico**
Al considerar vender una inversión que ha subido de valor, Renata (de la Lección 15) reconoce que está a solo unas semanas de pasar al trato de tenencia a largo plazo, haciendo eco de la discusión de WHITE-L2-031. Aplicando la perspectiva de planificación de la Lección 39, conversa con su profesional de impuestos si esperar esas semanas adicionales produciría un resultado tributario notablemente mejor, dado su ingreso esperado y su tramo específicos para el año. Trata esto como una decisión de planificación proactiva que se toma antes de la venta, y no como algo que se atiende solo al preparar su declaración meses después.

**4. Prueba de práctica**
1. Según esta lección, ¿cómo se gravan comúnmente las ganancias de capital a corto plazo?
   a) A una tasa fija idéntica para todos los contribuyentes
   b) A las mismas tasas que el ingreso ordinario, usando la misma estructura de tramos
   c) Nunca se gravan bajo ninguna circunstancia
   d) Solo a nivel estatal, nunca a nivel federal
2. ¿Cómo se conecta esta lección con la distinción entre planificación y preparación de la Lección 39?
   a) No tiene ninguna conexión
   b) Escoger el momento de una venta para obtener un trato más favorable de las ganancias de capital es una decisión de planificación proactiva, y no un ajuste retroactivo de preparación
   c) Las ganancias de capital siempre se pueden ajustar después de ocurridos los hechos durante la preparación
   d) La planificación y la preparación son conceptos idénticos
3. Cierto o falso: La distinción del período de tenencia entre ganancias de capital a corto y a largo plazo no tiene ningún efecto en la obligación tributaria real de un contribuyente.
4. Según el marco de la Lección 39, ¿por qué Renata trató su decisión sobre el momento de la venta como un asunto de planificación?
   a) La decisión se podía ajustar con la misma facilidad después de que el año ya había terminado
   b) La decisión debía tomarse de forma proactiva, antes de que ocurriera la venta, para afectar su resultado tributario real
   c) Las ganancias de capital no tienen relación con el período de tenencia
   d) Ya había completado la venta meses antes

**5. Clave de respuestas**
1. b  2. b  3. Falso  4. b

**6. Respuestas y explicaciones**
1. Las ganancias de capital a corto plazo comúnmente se gravan a las mismas tasas que el ingreso ordinario, usando la misma estructura de tramos.
2. Escoger el momento de una venta para obtener un trato favorable de las ganancias de capital es una decisión de planificación proactiva, que ya no está disponible cuando la preparación empieza de forma retrospectiva.
3. La distinción del período de tenencia puede afectar de forma significativa la obligación tributaria real de un contribuyente, dado el trato de tasas distinto.
4. El enfoque proactivo de Renata reflejó el marco de planificación de la Lección 39, ya que la decisión debía tomarse antes de que ocurriera la venta.

**7. Puntos clave**
- Las ganancias de capital a corto plazo comúnmente se gravan como ingreso ordinario; las de largo plazo comúnmente reciben tasas más favorables.
- Esto refuerza la discusión del período de tenencia de WHITE-L2-031 desde la perspectiva de la mecánica tributaria de GREEN.
- Escoger el momento de una venta para obtener un trato favorable es una decisión de planificación proactiva, haciendo eco de la distinción entre planificación y preparación de la Lección 39.
- Esta conexión ilustra cómo las decisiones de inversión del área WHITE y la mecánica tributaria del área GREEN funcionan juntas en la práctica.

---
