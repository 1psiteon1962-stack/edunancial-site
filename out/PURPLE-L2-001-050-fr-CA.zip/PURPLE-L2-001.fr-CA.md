---
id: PURPLE-L2-001
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 1
title: "De la connaissance du droit à la littératie juridique : la première interaction entre les pièces"
summary: "Vois comment une seule décision juridique, comme signer un contrat, touche à la fois tes obligations financières, ta responsabilité, ton temps et parfois ta propriété intellectuelle."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-001
### De la connaissance du droit à la littératie juridique : la première interaction entre les pièces

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer comment une seule décision juridique fait bouger plusieurs pièces à la fois, en écho aux parcours RED, WHITE et BLUE.
- Nommer au moins trois aspects de la vie qu'une décision juridique touche souvent.
- Appliquer la pensée de niveau 2, « qu'est-ce que ce geste touche d'autre? », à un scénario juridique.

**2. Contenu principal**
Le niveau 1 a présenté des notions juridiques individuelles — contrats, entités, responsabilité, droits — comme des pièces distinctes. Le niveau 2 commence, comme dans chaque couleur, en observant ce qui arrive au reste de l'échiquier quand on prend une décision juridique.

Pense à la signature d'un contrat simple, comme accepter un projet à la pige. Ce seul geste touche plusieurs pièces à la fois : des obligations *financières* (conditions de paiement, pénalités en cas de retard de livraison), la *responsabilité* (ce qui arrive si quelque chose tourne mal, et qui en est responsable), le *temps* (échéances, délais de préavis de résiliation) et parfois la *propriété intellectuelle* (à qui appartient le travail produit, un sujet approfondi aux leçons 20 à 25). Un apprenant qui ne lit que le montant du paiement avant de signer n'a vu qu'une seule pièce d'un document qui en contient plusieurs.

C'est la même discipline du « qu'est-ce que ce geste touche d'autre? » bâtie tout au long de RED-L2, WHITE-L2 et BLUE-L2, maintenant appliquée directement aux instruments juridiques. La littératie juridique, ce n'est pas apprendre des lois par cœur; c'est reconnaître que les documents juridiques sont justement structurés pour définir comment plusieurs pièces — l'argent, le risque, le temps et les droits — interagissent.

**3. Exemple pratique**
Avant de signer un contrat de conception de site Web à la pige, Tobias le lit au complet au lieu de le survoler pour trouver seulement le montant du paiement. Il remarque qu'il fixe aussi une échéance avec une pénalité en cas de retard (les pièces du temps et de l'argent), une clause sur la propriété du code final du site (une pièce de propriété intellectuelle) et une clause qui limite sa responsabilité si le propre contenu du client cause un problème juridique (une pièce de responsabilité). Reconnaître ces quatre pièces avant de signer permet à Tobias de négocier la clause de propriété, que la première version attribuait entièrement au client, alors que sa pratique habituelle est de garder certains éléments réutilisables.

**4. Quiz de pratique**
1. Selon cette leçon, lequel des éléments suivants n'est PAS une des pièces qu'un document juridique comme un contrat touche souvent?
   a) Les obligations financières
   b) La responsabilité
   c) La couleur préférée
   d) La propriété intellectuelle
2. Vrai ou faux : Lire seulement le montant du paiement dans un contrat suffit pour comprendre son effet complet.
3. Qu'est-ce que Tobias a découvert en lisant tout son contrat, au-delà des conditions de paiement?
   a) Rien au-delà du montant du paiement
   b) Des clauses qui touchent les échéances, la propriété intellectuelle et la responsabilité
   c) Une garantie de succès du projet
   d) Une exemption fiscale
4. Quelle est la compétence de base de niveau 2 que cette leçon développe, en écho aux parcours RED, WHITE et BLUE?
   a) Apprendre des lois par cœur
   b) Se demander « qu'est-ce que ce geste touche d'autre? » avant d'agir
   c) Éviter complètement les contrats
   d) Ignorer les questions de responsabilité

**5. Corrigé**
1. c  2. Faux  3. b  4. b

**6. Réponses et explications**
1. La couleur préférée n'a aucun lien juridique avec un contrat; les trois autres sont des pièces souvent touchées.
2. L'effet complet d'un contrat touche plusieurs pièces — financières, de responsabilité, de temps et parfois de propriété intellectuelle —, pas seulement les conditions de paiement.
3. La lecture complète de Tobias a révélé des clauses sur les échéances, la propriété intellectuelle et la responsabilité, au-delà des conditions de paiement.
4. Cette leçon renforce la même habitude de pensée à plusieurs pièces bâtie tout au long de RED-L2, WHITE-L2 et BLUE-L2, maintenant appliquée aux instruments juridiques.

**7. Points clés à retenir**
- Les décisions juridiques, comme les contrats, ne sont jamais isolées : elles touchent à la fois des pièces financières, de responsabilité, de temps et souvent de propriété intellectuelle.
- La littératie juridique, c'est reconnaître ces nombreuses pièces, pas apprendre des lois par cœur.
- Lire un document juridique au complet, et pas seulement sa condition la plus visible, révèle son effet réel complet.
- Cette leçon renforce la même habitude de pensée à plusieurs pièces bâtie tout au long de RED-L2, WHITE-L2 et BLUE-L2.
