---
id: PURPLE-L2-002
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 2
title: "Contrats et ententes : ce qui rend un contrat exécutoire"
summary: "Distingue une simple entente d'un contrat exécutoire et apprends les éléments généraux qu'un tribunal cherche avant de faire respecter une entente."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-002
### Contrats et ententes : ce qui rend un contrat exécutoire

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Distinguer un contrat juridiquement exécutoire d'une entente ou d'une compréhension générale.
- Nommer les éléments généraux nécessaires pour qu'un contrat soit exécutoire.
- Reconnaître que c'est un domaine propre à chaque juridiction, qui exige un encadrement professionnel en cas de vrai litige.

**2. Contenu principal**
Toutes les ententes entre des personnes ne deviennent pas des contrats juridiquement exécutoires. Une entente ou une compréhension générale peut refléter une vraie intention entre les parties, mais sans certains éléments, un tribunal pourrait ne pas la faire respecter en cas de litige. En général, un contrat exécutoire exige une offre, une acceptation et une contrepartie (quelque chose de valeur échangé, approfondi à la leçon 3), ainsi que l'intention commune des parties d'être juridiquement liées et leur capacité juridique de conclure l'entente (par exemple, être majeur et sain d'esprit).

Cette distinction a des conséquences concrètes : une entente conclue d'une poignée de main pour « donner un coup de main sur un projet un de ces jours » n'a probablement pas la précision ni l'intention commune nécessaires pour lier juridiquement les parties, alors qu'une entente écrite détaillée, qui précise l'étendue des travaux, le paiement et les échéances, et qui est signée par les deux parties, a beaucoup plus de chances d'être exécutoire si un litige survient plus tard. Les règles précises sur le caractère exécutoire varient selon la juridiction et le type de contrat; c'est donc un domaine où la formation générale établit la notion, alors qu'un vrai litige exige un avocat qualifié.

**3. Exemple pratique**
Deux voisins s'entendent verbalement pour que l'un aide l'autre à déménager des meubles « un moment donné le mois prochain » en échange d'« un bon souper ». Quand celui qui devait aider n'est pas disponible et que l'autre voisin est fâché, il n'existe probablement aucun contrat exécutoire : l'entente n'a pas la précision, la clarté de la contrepartie ni l'intention commune d'être juridiquement liés qu'un tribunal chercherait. Ça contraste fortement avec un contrat écrit qui préciserait la date exacte du déménagement, la rémunération exacte et les signatures des deux parties, et qui aurait beaucoup plus de poids comme véritable obligation exécutoire en cas de litige.

**4. Quiz de pratique**
1. Qu'est-ce qui est généralement nécessaire pour qu'un contrat soit exécutoire?
   a) Seulement une promesse verbale
   b) Une offre, une acceptation, une contrepartie et l'intention commune d'être juridiquement liés
   c) Un sceau notarié dans tous les cas
   d) Rien — toutes les ententes sont automatiquement exécutoires
2. Pourquoi une entente verbale vague pourrait-elle ne pas être considérée comme un contrat exécutoire?
   a) Les ententes verbales sont toujours exécutoires, peu importe leur précision
   b) Elle peut manquer de la précision, de la clarté de la contrepartie et de l'intention commune que les tribunaux recherchent
   c) Les contrats doivent toujours être tapés, jamais écrits à la main
   d) Les déclarations verbales n'ont aucune importance juridique
3. Vrai ou faux : Toute entente entre deux personnes est automatiquement un contrat juridiquement exécutoire.
4. Pourquoi l'entente des voisins pour déménager des meubles n'était-elle probablement pas exécutoire?
   a) Elle était trop précise
   b) Elle manquait de précision, de clarté de la contrepartie et d'intention commune d'être juridiquement liés
   c) Elle avait été mise par écrit
   d) Les deux parties avaient signé un document officiel

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Les contrats exécutoires exigent généralement une offre, une acceptation, une contrepartie et l'intention commune d'être juridiquement liés.
2. Les ententes vagues manquent souvent de la précision et de l'intention commune claire que les tribunaux recherchent pour les faire respecter.
3. Toutes les ententes ne deviennent pas des contrats exécutoires; certains éléments précis doivent généralement être présents.
4. Les conditions vagues et informelles des voisins manquaient de la précision et de l'intention claire nécessaires pour que l'entente soit exécutoire.

**7. Points clés à retenir**
- Toutes les ententes ne sont pas des contrats juridiquement exécutoires; certains éléments précis sont généralement nécessaires.
- Ces éléments comprennent l'offre, l'acceptation, la contrepartie et l'intention commune d'être juridiquement liés.
- Les ententes vagues et informelles manquent souvent de la précision que les tribunaux recherchent pour les faire respecter.
- Les règles sur le caractère exécutoire varient selon la juridiction et le type de contrat, ce qui exige un encadrement professionnel en cas de vrai litige.
