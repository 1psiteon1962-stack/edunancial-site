---
id: PURPLE-L2-003
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 3
title: "L'offre, l'acceptation et la contrepartie : les trois piliers"
summary: "Comprends les trois piliers de la formation d'un contrat, pourquoi une réponse qui change les conditions devient une contre-offre et pourquoi une promesse sans contrepartie ne suffit pas."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-003
### L'offre, l'acceptation et la contrepartie : les trois piliers

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle l'offre, l'acceptation et la contrepartie.
- Expliquer pourquoi les trois doivent généralement concorder pour qu'un contrat se forme.
- Appliquer ces trois piliers à un exemple de transaction simple.

**2. Contenu principal**
Dans la suite de la leçon 2, cette leçon examine de plus près les trois piliers fondamentaux. Une offre est une proposition claire faite par une partie de conclure une entente selon des conditions précises. L'acceptation est l'accord clair de l'autre partie sur ces mêmes conditions précises; si l'« acceptation » change en fait les conditions, elle peut plutôt agir comme une contre-offre, et non comme une acceptation, ce qui relance la négociation au lieu de former un contrat. La contrepartie est quelque chose de valeur échangé entre les parties — souvent de l'argent, mais ce peut être la promesse de fournir un service, de livrer des biens, ou même de s'abstenir de faire quelque chose que la partie avait autrement le droit de faire.

Les trois doivent généralement concorder : une offre sans acceptation correspondante n'est pas encore un contrat, et une entente sans contrepartie échangée entre les parties (une pure promesse de don, sans réciprocité, par exemple) n'est généralement pas traitée comme un contrat exécutoire, même si les deux parties en ont réellement l'intention.

**3. Exemple pratique**
Une photographe à la pige offre de photographier l'événement d'un client pour 800 $ (l'offre). Le client répond qu'il accepte de payer 800 $ pour la séance (une acceptation qui correspond aux conditions de l'offre); à ce moment-là, un contrat s'est probablement formé, le paiement de 800 $ et le service de photographie représentant chacun la contrepartie échangée entre les deux parties. Si le client avait plutôt répondu « je vais payer 600 $ », cette réponse agirait comme une contre-offre, et non comme une acceptation; aucun contrat n'existerait encore tant qu'une partie n'accepte pas les conditions les plus récentes de l'autre.

**4. Quiz de pratique**
1. Dans la formation d'un contrat, qu'est-ce qu'une « offre »?
   a) Un contrat terminé
   b) Une proposition claire faite par une partie de conclure une entente selon des conditions précises
   c) Un type de contrepartie
   d) Un dépôt gouvernemental
2. Qu'arrive-t-il si une réponse à une offre change les conditions au lieu de les reprendre exactement?
   a) Elle forme automatiquement un contrat selon les conditions d'origine
   b) Elle agit généralement comme une contre-offre, et non comme une acceptation
   c) Elle n'a aucune importance juridique
   d) Elle est toujours traitée comme une fraude
3. Vrai ou faux : Une pure promesse de don, sans réciprocité et sans contrepartie en retour, est généralement traitée comme un contrat exécutoire.
4. Dans l'exemple pratique, qu'est-il arrivé quand le client a répondu « je vais payer 600 $ » au lieu des 800 $ offerts?
   a) Un contrat s'est formé tout de suite à 800 $
   b) Sa réponse a agi comme une contre-offre, et non comme une acceptation de l'offre d'origine
   c) La photographe était légalement obligée d'accepter
   d) La réponse n'avait aucune signification juridique

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une offre est une proposition claire faite par une partie de conclure une entente selon des conditions précises.
2. Une réponse qui change les conditions agit généralement comme une contre-offre, ce qui relance la négociation.
3. La contrepartie doit généralement être échangée entre les parties; une promesse de don purement unilatérale n'est généralement pas exécutoire comme contrat.
4. Les conditions modifiées par le client ont agi comme une contre-offre, et non comme une acceptation de l'offre d'origine de 800 $ de la photographe.

**7. Points clés à retenir**
- L'offre, l'acceptation et la contrepartie sont les trois piliers fondamentaux de la formation d'un contrat.
- L'acceptation doit généralement reprendre exactement les conditions de l'offre; sinon, elle agit plutôt comme une contre-offre.
- La contrepartie est quelque chose de valeur échangé entre les parties, pas nécessairement limité à l'argent.
- Les trois piliers doivent généralement concorder pour qu'un contrat exécutoire se forme.
