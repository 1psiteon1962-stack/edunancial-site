---
id: PURPLE-L2-004
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 4
title: "Contrats écrits ou verbaux : pourquoi la protection écrite compte"
summary: "Compare les contrats verbaux et écrits, découvre les règles qui exigent l'écrit pour certains contrats et pourquoi mettre une entente par écrit protège même quand ce n'est pas obligatoire."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-004
### Contrats écrits ou verbaux : pourquoi la protection écrite compte

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Comparer les éléments généraux qui touchent le caractère exécutoire des contrats écrits et verbaux.
- Expliquer le concept général d'une « loi sur les fraudes » (*Statute of Frauds*), qui exige que certains contrats soient écrits.
- Nommer les raisons pratiques de préférer les contrats écrits, même quand la loi ne l'exige pas.

**2. Contenu principal**
Beaucoup de contrats verbaux peuvent être juridiquement exécutoires, à condition que les éléments des leçons 2 et 3 soient présents. Par contre, bien des juridictions ont une « loi sur les fraudes » (*Statute of Frauds*), une règle qui exige que certaines catégories de contrats (souvent les transactions immobilières, les ententes qui ne peuvent pas être exécutées en moins d'un an et les contrats de vente de biens au-delà d'une certaine valeur) soient faites par écrit pour être exécutoires, même si tous les autres éléments du contrat sont présents. C'est une RÈGLE PROPRE À UNE RÉGION, dont les catégories et les seuils précis varient selon la juridiction.

Au-delà des exigences légales sur le caractère exécutoire, les contrats écrits offrent des avantages pratiques importants, même quand la forme écrite n'est pas strictement exigée par la loi : ils créent une trace claire de ce qui a exactement été convenu, ce qui réduit le risque de litiges fondés sur la mémoire ou l'interprétation, et ils obligent les deux parties à penser à des détails importants (échéances, recours en cas d'inexécution) et à les régler, alors qu'une entente verbale informelle pourrait les oublier complètement.

**3. Exemple pratique**
Deux propriétaires d'entreprise s'entendent verbalement sur une entente de marketing commune qui devrait durer dix-huit mois — une durée de plus d'un an qui, dans bien des juridictions, déclencherait une exigence de contrat écrit en vertu de la loi sur les fraudes pour que l'entente soit exécutoire. Conscients de ça, et peu importe si leur entente précise devait légalement être écrite, ils rédigent une entente écrite qui précise l'étendue de la collaboration, sa durée et les responsabilités de chaque partie. Ils se protègent ainsi tous les deux avec une trace claire, à laquelle ils peuvent se référer ensemble, plutôt que de se fier à leurs souvenirs respectifs d'une conversation informelle des mois plus tard.

**4. Quiz de pratique**
1. Qu'exige généralement une « loi sur les fraudes »?
   a) Que tous les contrats soient notariés
   b) Que certaines catégories de contrats soient faites par écrit pour être exécutoires
   c) Que tous les contrats soient seulement verbaux
   d) Rien — elle n'a aucun effet juridique réel
2. Quel est un avantage pratique d'un contrat écrit, même quand la loi ne l'exige pas?
   a) Il n'a aucun avantage par rapport à une entente verbale
   b) Il crée une trace claire, ce qui réduit les litiges fondés sur la mémoire ou l'interprétation
   c) Il élimine le besoin de toute contrepartie
   d) Il garantit un résultat favorable dans n'importe quel litige
3. Vrai ou faux : Les catégories et les seuils de la loi sur les fraudes sont identiques dans toutes les juridictions.
4. Pourquoi les deux propriétaires d'entreprise ont-ils rédigé une entente écrite pour leur collaboration de marketing?
   a) C'était purement facultatif, sans avantage pratique
   b) La durée de leur entente déclenchait probablement une exigence de contrat écrit, et une trace écrite protégeait les deux parties
   c) Les ententes verbales sont toujours illégales
   d) Ils n'avaient aucune vraie relation d'affaires

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une loi sur les fraudes exige généralement que certaines catégories de contrats soient faites par écrit pour être exécutoires.
2. Les contrats écrits créent une trace claire, ce qui réduit les litiges fondés sur la mémoire ou l'interprétation des conditions.
3. Les catégories et les seuils de la loi sur les fraudes varient beaucoup selon la juridiction.
4. La durée de l'entente des propriétaires d'entreprise et la protection pratique d'une trace claire justifiaient toutes les deux la rédaction d'une entente écrite.

**7. Points clés à retenir**
- Beaucoup de contrats verbaux peuvent être exécutoires, mais une loi sur les fraudes exige que certaines catégories soient écrites, ce qui varie selon la juridiction.
- Les contrats écrits créent une trace claire et commune, ce qui réduit les litiges fondés sur la mémoire ou l'interprétation.
- Les contrats écrits obligent aussi les parties à penser à des détails importants qu'une entente verbale informelle pourrait oublier.
- Préférer les contrats écrits est une bonne pratique, même au-delà des situations où la loi l'exige strictement.
