---
id: PURPLE-L2-006
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 6
title: "L'inexécution d'un contrat : ce qui arrive quand quelqu'un ne respecte pas ses obligations"
summary: "Comprends ce qu'est une inexécution de contrat, la différence entre une inexécution importante et mineure, et pourquoi ce type change les recours possibles."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-006
### L'inexécution d'un contrat : ce qui arrive quand quelqu'un ne respecte pas ses obligations

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle l'inexécution d'un contrat (la violation de contrat).
- Distinguer une inexécution importante d'une inexécution mineure.
- Expliquer pourquoi le type d'inexécution influence les réponses possibles.

**2. Contenu principal**
Il y a inexécution d'un contrat (ou violation de contrat) quand une partie ne remplit pas une obligation prévue dans un contrat exécutoire, sans excuse reconnue par la loi. Toutes les inexécutions ne sont pas traitées de la même façon : une inexécution importante est assez grave pour miner le but principal du contrat, ce qui permet généralement à la partie qui a respecté ses obligations de considérer le contrat comme résilié et d'exercer des recours (leçon 7). Une inexécution mineure (parfois appelée inexécution partielle) est un manquement moins grave qui ne mine pas le but principal du contrat; la partie qui a respecté ses obligations doit généralement continuer à remplir les siennes, mais elle peut demander une compensation pour le préjudice précis causé par l'inexécution mineure.

Déterminer si une inexécution précise est importante ou mineure dépend des faits de la situation et des conditions du contrat lui-même. C'est donc une détermination propre aux faits, et souvent au contrat, et non une règle tranchée qui s'applique de la même façon à chaque situation.

**3. Exemple pratique**
Un entrepreneur est embauché pour rénover une cuisine avant une date précise, avec une couleur de mur précisée « blanc doux ». L'entrepreneur termine à temps, mais peint le mur d'une teinte de blanc très légèrement différente de celle précisée — probablement une inexécution mineure, puisque le but principal de la rénovation (une cuisine rénovée et fonctionnelle) a quand même été atteint, même si la propriétaire pourrait raisonnablement demander une petite compensation ou qu'on repeigne pour corriger l'écart de couleur. Si, au contraire, l'entrepreneur n'avait pas terminé la rénovation du tout, en dépassant l'échéance de plusieurs mois, sans murs peints, sans planchers posés ni accessoires branchés, ce serait probablement une inexécution importante, qui mine le but principal du contrat et pourrait permettre à la propriétaire de résilier le contrat et de chercher des recours plus importants.

**4. Quiz de pratique**
1. Qu'est-ce que l'inexécution d'un contrat?
   a) Remplir avec succès les conditions d'un contrat
   b) Le fait de ne pas remplir une obligation contractuelle sans excuse reconnue par la loi
   c) Un type de contrepartie
   d) Une exigence de dépôt gouvernemental
2. Qu'est-ce qui distingue généralement une inexécution importante d'une inexécution mineure?
   a) Il n'y a aucune distinction
   b) Une inexécution importante mine le but principal du contrat; une inexécution mineure, non
   c) Les inexécutions importantes sont toujours volontaires; les mineures, toujours accidentelles
   d) Seules les inexécutions importantes ont des conséquences
3. Vrai ou faux : Toute inexécution d'un contrat, aussi petite soit-elle, permet à la partie qui a respecté ses obligations de résilier tout le contrat.
4. Pourquoi la couleur de mur légèrement différente était-elle probablement une inexécution mineure plutôt qu'importante?
   a) Le but principal de la rénovation avait quand même été atteint en bonne partie
   b) Aucune rénovation n'avait eu lieu
   c) L'entrepreneur ne s'était jamais présenté
   d) La propriétaire n'avait aucun recours possible

**5. Corrigé**
1. b  2. b  3. Faux  4. a

**6. Réponses et explications**
1. L'inexécution d'un contrat, c'est le fait de ne pas remplir une obligation contractuelle sans excuse reconnue par la loi.
2. Une inexécution importante mine le but principal du contrat; une inexécution mineure, non, même si elle peut quand même causer un certain préjudice.
3. Seule une inexécution importante permet généralement de résilier tout le contrat; une inexécution mineure exige généralement de continuer à exécuter le contrat, avec une compensation pour le préjudice précis.
4. La couleur de mur légèrement différente ne minait pas le but principal et fonctionnel de la rénovation, ce qui correspond davantage à une inexécution mineure.

**7. Points clés à retenir**
- L'inexécution d'un contrat est le fait de ne pas remplir une obligation contractuelle sans excuse valable.
- Une inexécution importante mine le but principal du contrat; une inexécution mineure, non.
- Les inexécutions importantes permettent généralement de résilier le contrat et d'exercer des recours plus larges; les inexécutions mineures permettent généralement une compensation pendant que l'exécution se poursuit.
- Déterminer la gravité d'une inexécution dépend des faits et n'est pas régi par une seule règle tranchée.
