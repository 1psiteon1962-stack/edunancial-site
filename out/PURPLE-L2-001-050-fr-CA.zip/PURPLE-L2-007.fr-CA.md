---
id: PURPLE-L2-007
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 7
title: "Les recours en cas d'inexécution : dommages-intérêts, exécution en nature et annulation"
summary: "Découvre les trois grands recours en cas d'inexécution d'un contrat et pourquoi le bon recours dépend de la nature du préjudice et de ce qui avait été promis."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-007
### Les recours en cas d'inexécution : dommages-intérêts, exécution en nature et annulation

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Nommer les recours juridiques courants en cas d'inexécution d'un contrat.
- Distinguer de façon conceptuelle les dommages-intérêts, l'exécution en nature et l'annulation.
- Expliquer pourquoi le recours approprié dépend de la situation précise.

**2. Contenu principal**
Dans la suite de la leçon 6, cette leçon présente les recours généraux possibles en cas d'inexécution. Les dommages-intérêts — une compensation en argent qui vise à placer la partie qui a respecté ses obligations dans la situation où elle aurait été si le contrat avait été exécuté — sont le recours le plus courant. L'exécution en nature (*specific performance*) est une ordonnance du tribunal qui oblige la partie fautive à remplir réellement son obligation contractuelle; on la réserve généralement aux situations où des dommages-intérêts en argent ne répareraient pas adéquatement le préjudice, comme un contrat pour un immeuble unique ou un objet unique en son genre, où aucune somme d'argent ne peut vraiment remplacer la chose précise promise. L'annulation (*rescission*) met fin au contrat au complet et ramène généralement les deux parties, autant que possible, à leur situation d'avant la formation du contrat; on l'utilise souvent quand un contrat a été formé à la suite d'une fraude, d'une fausse déclaration ou d'une erreur importante.

Le recours approprié dépend beaucoup des faits précis, du type de contrat et de la nature du préjudice. Les tribunaux privilégient généralement les dommages-intérêts comme recours par défaut et réservent l'exécution en nature et l'annulation aux situations où les dommages-intérêts seuls ne répareraient pas adéquatement le préjudice.

**3. Exemple pratique**
Un acheteur signe un contrat pour acheter un terrain précis et unique, qui a une caractéristique géologique rare, mais le vendeur ne respecte pas le contrat et refuse de transférer la propriété. Comme ce terrain précis ne peut pas être facilement remplacé, peu importe la somme d'argent, un tribunal pourrait ordonner l'exécution en nature et obliger le vendeur à transférer réellement la propriété comme convenu au départ, plutôt que d'accorder seulement des dommages-intérêts en argent qui ne pourraient pas vraiment remplacer cet actif unique. Ça contraste avec une inexécution plus typique portant sur des biens facilement disponibles et remplaçables, où des dommages-intérêts en argent (qui couvrent le coût, pour l'acheteur, d'acheter un bien de remplacement ailleurs) seraient généralement le recours approprié et suffisant.

**4. Quiz de pratique**
1. Quel est le recours contractuel le plus courant?
   a) L'exécution en nature
   b) Les dommages-intérêts, une compensation en argent pour l'inexécution
   c) L'annulation
   d) L'emprisonnement
2. Quand un tribunal pourrait-il ordonner l'exécution en nature plutôt que des dommages-intérêts?
   a) Dans chaque cas d'inexécution
   b) Quand l'objet du contrat est unique et que des dommages-intérêts en argent ne répareraient pas adéquatement le préjudice
   c) Jamais — l'exécution en nature n'existe pas
   d) Seulement pour les contrats de moins de 100 $
3. Vrai ou faux : Les tribunaux privilégient généralement l'exécution en nature plutôt que les dommages-intérêts pour tous les types d'inexécution.
4. Pourquoi l'exécution en nature pourrait-elle être appropriée pour le terrain unique, mais pas pour des biens remplaçables typiques?
   a) Un terrain n'est jamais unique
   b) Le terrain unique ne peut pas être facilement remplacé par de l'argent, contrairement aux biens remplaçables typiques
   c) L'exécution en nature coûte toujours moins cher que les dommages-intérêts
   d) Les biens remplaçables ont toujours plus de valeur qu'un terrain

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Les dommages-intérêts, une compensation en argent pour l'inexécution, sont le recours contractuel le plus courant.
2. L'exécution en nature est généralement réservée aux situations où l'objet du contrat est unique et où les dommages-intérêts ne répareraient pas adéquatement le préjudice.
3. Les tribunaux privilégient généralement les dommages-intérêts comme recours par défaut et réservent l'exécution en nature à des circonstances particulières.
4. Le caractère unique du terrain voulait dire qu'aucune somme d'argent ne pouvait vraiment le remplacer, contrairement à des biens facilement remplaçables.

**7. Points clés à retenir**
- Les dommages-intérêts, l'exécution en nature et l'annulation sont les principaux recours en cas d'inexécution d'un contrat.
- Les dommages-intérêts offrent une compensation en argent et sont le recours par défaut le plus courant.
- L'exécution en nature ordonne de remplir réellement l'obligation et est généralement réservée aux objets uniques.
- L'annulation met fin au contrat au complet et sert souvent en cas de fraude, de fausse déclaration ou d'erreur importante.
