---
id: PURPLE-L2-008
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 8
title: "Les ententes de confidentialité comparées : réciproques ou unilatérales"
summary: "Distingue une entente de confidentialité unilatérale d'une entente réciproque et vois pourquoi choisir la mauvaise structure peut laisser des renseignements sensibles sans protection."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-008
### Les ententes de confidentialité comparées : réciproques ou unilatérales

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Distinguer une entente de confidentialité réciproque d'une entente unilatérale.
- Expliquer quand chaque type convient généralement.
- Relier cette notion à la discussion sur les ententes de confidentialité du parcours BLUE (BLUE-L2-029).

**2. Contenu principal**
Dans la suite de la présentation des ententes de confidentialité (souvent appelées NDA, de l'anglais *non-disclosure agreement*) dans BLUE-L2-029, cette leçon compare deux structures générales. Une entente de confidentialité unilatérale interdit à une seule partie de divulguer des renseignements confidentiels; on l'utilise généralement quand une seule partie partage des renseignements sensibles avec l'autre — par exemple, une entreprise qui partage des détails exclusifs avec un fournisseur potentiel qui n'a pas de renseignements confidentiels comparables à partager en retour. Une entente de confidentialité réciproque (ou bilatérale) interdit aux deux parties de divulguer les renseignements confidentiels de l'autre; on l'utilise généralement quand les deux parties vont échanger des renseignements sensibles, comme deux entreprises qui explorent un partenariat ou une fusion possible (en écho à BLUE-L2-039).

Choisir la mauvaise structure peut créer un vrai déséquilibre, même s'il passe souvent inaperçu : une entente unilatérale dans une situation où les deux parties partagent réellement des renseignements sensibles laisse les renseignements confidentiels d'une partie sans protection, puisque les restrictions de l'entente ne lient que l'autre partie.

**3. Exemple pratique**
Avant de discuter d'une coentreprise possible avec une entreprise complémentaire, deux entreprises reçoivent d'abord une entente de confidentialité unilatérale rédigée par l'une d'elles, qui aurait interdit seulement à l'autre partie de partager des renseignements confidentiels, alors que les deux entreprises avaient l'intention de partager des renseignements sensibles pendant leurs discussions. Remarquant ce décalage, l'avocat de l'une des entreprises signale le déséquilibre et négocie plutôt une entente de confidentialité réciproque, ce qui assure une protection égale des renseignements confidentiels des deux entreprises pendant leurs discussions exploratoires.

**4. Quiz de pratique**
1. Qu'est-ce qu'une entente de confidentialité unilatérale interdit généralement?
   a) Aux deux parties également
   b) À une seule partie de divulguer des renseignements confidentiels
   c) À aucune des parties
   d) À un organisme gouvernemental
2. Quand une entente de confidentialité réciproque convient-elle généralement mieux?
   a) Quand une seule partie partage des renseignements sensibles
   b) Quand les deux parties vont échanger des renseignements sensibles
   c) Quand aucun renseignement confidentiel n'est en jeu
   d) Les ententes réciproques ne conviennent jamais
3. Vrai ou faux : Une entente de confidentialité unilatérale et une entente réciproque offrent une protection identique, peu importe quelle partie partage réellement des renseignements.
4. Pourquoi l'avocat a-t-il signalé l'entente unilatérale de départ comme un problème?
   a) Les ententes unilatérales sont toujours illégales
   b) Les deux entreprises avaient réellement l'intention de partager des renseignements sensibles, ce qui exigeait une protection réciproque
   c) L'entreprise n'aimait pas les ententes de confidentialité en général
   d) Aucun renseignement sensible n'était partagé

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une entente de confidentialité unilatérale interdit à une seule partie de divulguer les renseignements confidentiels de l'autre.
2. Une entente de confidentialité réciproque convient généralement mieux quand les deux parties vont échanger des renseignements sensibles.
3. Les deux structures offrent une protection vraiment différente selon la partie qui partage réellement des renseignements sensibles.
4. L'avocat a reconnu que les besoins réels de partage de renseignements des deux entreprises exigeaient une protection réciproque, et non unilatérale.

**7. Points clés à retenir**
- Une entente de confidentialité unilatérale lie une seule partie; une entente réciproque interdit aux deux parties de divulguer des renseignements confidentiels.
- La structure appropriée dépend du fait qu'une seule partie ou les deux partageront des renseignements sensibles.
- Choisir la mauvaise structure peut laisser les renseignements confidentiels d'une partie réellement sans protection.
- Cette leçon s'appuie directement sur la présentation des ententes de confidentialité du parcours BLUE en y ajoutant une lentille de comparaison structurelle.
