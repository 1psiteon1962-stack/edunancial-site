---
id: PURPLE-L2-009
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 9
title: "Les clauses de non-concurrence : but, limites et caractère exécutoire"
summary: "Comprends à quoi servent les clauses de non-concurrence, ce que les tribunaux examinent et pourquoi leur caractère exécutoire varie énormément d'un endroit à l'autre."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-009
### Les clauses de non-concurrence : but, limites et caractère exécutoire

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le but général d'une clause de non-concurrence.
- Nommer les facteurs courants que les tribunaux examinent pour évaluer son caractère exécutoire.
- Reconnaître que c'est un domaine fortement propre à chaque juridiction, avec des règles très variables.

**2. Contenu principal**
Une clause (ou entente) de non-concurrence empêche généralement une partie (souvent un ancien employé ou le vendeur d'une entreprise) d'exercer des activités concurrentes dans une région et pendant une période précises après la fin d'une relation. Le but général est de protéger des intérêts d'affaires légitimes, comme des secrets commerciaux (leçon 24), des relations avec la clientèle ou des investissements dans une formation spécialisée, pour éviter qu'ils servent immédiatement à faire directement concurrence à l'entreprise même qui les a fournis.

Le caractère exécutoire des clauses de non-concurrence varie énormément selon la juridiction : certaines juridictions les font respecter assez largement si leur portée est raisonnable, alors que d'autres ont beaucoup limité ou même interdit leur utilisation pour les employés, surtout les travailleurs à faible salaire, ce qui reflète des points de vue politiques différents sur l'équilibre entre la protection des entreprises et la mobilité des travailleurs. Les tribunaux qui font respecter les clauses de non-concurrence évaluent souvent si la portée géographique, la durée et les activités restreintes sont raisonnables et pas plus larges que nécessaire pour protéger l'intérêt d'affaires légitime en jeu. Une clause de non-concurrence trop large (une durée illimitée, la portée géographique d'un pays entier, pour un poste qui n'a aucun accès réel à des secrets commerciaux) risque davantage d'être jugée inexécutoire, même dans les juridictions qui sont généralement prêtes à faire respecter des clauses raisonnables.

**3. Exemple pratique**
Une boulangerie régionale demande à une nouvelle employée au comptoir de signer une clause de non-concurrence qui lui interdit de travailler dans n'importe quelle boulangerie du pays pendant cinq ans après son départ. Vu son rôle limité, sans accès à de vrais secrets commerciaux ni à une formation exclusive spécialisée, et la portée géographique et temporelle extrêmement large par rapport à tout intérêt d'affaires légitime en jeu, cette clause de non-concurrence serait probablement jugée inexécutoire dans bien des juridictions, même celles qui sont généralement prêtes à faire respecter des ententes de portée plus raisonnable. Ça montre pourquoi le même instrument (une clause de non-concurrence) peut être exécutoire dans un contexte et complètement inexécutoire dans un autre, selon sa portée réelle et l'intérêt qu'il prétend protéger.

**4. Quiz de pratique**
1. Quel est le but général d'une clause de non-concurrence?
   a) Garantir un emploi à vie
   b) Protéger des intérêts d'affaires légitimes, comme des secrets commerciaux ou des relations avec la clientèle, contre une concurrence immédiate
   c) Éliminer pour toujours toute concurrence dans un secteur
   d) Un type de formulaire fiscal
2. Qu'est-ce que les tribunaux évaluent souvent pour juger du caractère exécutoire d'une clause de non-concurrence?
   a) Rien — toutes les clauses de non-concurrence sont automatiquement exécutoires
   b) Si la portée géographique, la durée et les activités restreintes sont raisonnables par rapport à l'intérêt légitime
   c) Seulement la préférence personnelle de l'employé
   d) Seulement la taille de l'entreprise
3. Vrai ou faux : Les règles sur le caractère exécutoire des clauses de non-concurrence sont identiques dans toutes les juridictions.
4. Pourquoi la clause de non-concurrence de l'employée au comptoir de la boulangerie était-elle probablement inexécutoire?
   a) Sa portée était trop étroite
   b) Sa large portée géographique, sa longue durée et l'absence de lien avec un vrai intérêt à protéger la rendaient déraisonnable
   c) Les clauses de non-concurrence sont illégales partout
   d) L'employée avait plutôt signé une entente de confidentialité réciproque

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Les clauses de non-concurrence visent généralement à protéger des intérêts d'affaires légitimes contre une concurrence immédiate après la fin d'une relation.
2. Les tribunaux évaluent souvent si la portée géographique, la durée et les activités restreintes sont raisonnables par rapport à l'intérêt à protéger.
3. Le caractère exécutoire des clauses de non-concurrence varie énormément selon la juridiction; certaines interdisent ou limitent fortement leur utilisation.
4. La portée excessive de la clause de la boulangerie, compte tenu du rôle limité et de l'absence de vrai intérêt à protéger, la rendait probablement inexécutoire.

**7. Points clés à retenir**
- Les clauses de non-concurrence visent généralement à protéger des intérêts d'affaires légitimes contre une concurrence immédiate après la fin d'une relation.
- Leur caractère exécutoire varie énormément selon la juridiction, ce qui reflète des points de vue différents sur la protection des entreprises et la mobilité des travailleurs.
- Les tribunaux évaluent souvent si la portée, la durée et les restrictions sont raisonnables par rapport à l'intérêt réellement en jeu.
- Une clause de non-concurrence trop large risque davantage d'être jugée inexécutoire, même là où ces ententes sont généralement permises.
