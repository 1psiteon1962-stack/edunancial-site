---
id: PURPLE-L2-010
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 10
title: "Non-concurrence, non-sollicitation et non-dénigrement : une comparaison"
summary: "Distingue trois clauses restrictives proches et vois pourquoi les clauses de non-sollicitation et de non-dénigrement sont souvent plus faciles à faire respecter."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-010
### Non-concurrence, non-sollicitation et non-dénigrement : une comparaison

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Distinguer les clauses de non-concurrence, de non-sollicitation et de non-dénigrement.
- Expliquer pourquoi les clauses de non-sollicitation et de non-dénigrement sont souvent plus faciles à faire respecter que les clauses de non-concurrence.
- Appliquer cette comparaison au scénario hypothétique d'un employé qui quitte son poste.

**2. Contenu principal**
Dans la suite de la leçon 9, cette leçon compare trois engagements restrictifs liés, mais distincts. Une clause de non-concurrence (leçon 9) interdit de travailler pour une entreprise ou dans un secteur concurrent. Une clause de non-sollicitation interdit à la partie qui part de solliciter les clients ou les employés de l'ancien employeur pour qu'ils la suivent, sans nécessairement lui interdire de travailler dans le même secteur. Une clause de non-dénigrement interdit à une partie de faire des déclarations publiques négatives ou nuisibles au sujet de l'autre partie.

Comme les clauses de non-sollicitation et de non-dénigrement ont généralement une portée plus étroite — elles interdisent des gestes nuisibles précis plutôt qu'une catégorie entière d'emploi ou d'activité commerciale —, elles sont souvent plus faciles à faire respecter dans un plus grand nombre de juridictions que les clauses de non-concurrence, même dans celles qui limitent fortement ou interdisent les clauses de non-concurrence en général. C'est pourquoi bien des contrats de travail combinent les trois, ou comptent davantage sur la non-sollicitation et le non-dénigrement, surtout dans les juridictions où les clauses de non-concurrence font face à d'importantes restrictions.

**3. Exemple pratique**
En quittant son poste dans une agence de marketing, dans une juridiction qui limite beaucoup les clauses de non-concurrence, Farida n'est pas empêchée de travailler pour une agence concurrente (une large clause de non-concurrence y serait probablement inexécutoire), mais elle reste liée par une clause de non-sollicitation qui l'empêche de recruter activement ses anciens collègues pour son nouvel employeur, et par une clause de non-dénigrement qui l'empêche de critiquer publiquement son ancien employeur. Cette combinaison donne à son ancien employeur une protection réelle, même sans clause de non-concurrence exécutoire, puisque les restrictions plus étroites visent des gestes nuisibles précis plutôt que sa capacité générale à travailler dans le secteur.

**4. Quiz de pratique**
1. Qu'est-ce qu'une clause de non-sollicitation interdit généralement?
   a) De travailler pour n'importe quelle entreprise concurrente
   b) De solliciter les clients ou les employés de l'ancien employeur pour qu'ils partent
   c) De faire quelque déclaration publique que ce soit
   d) Rien d'important sur le plan juridique
2. Pourquoi les clauses de non-sollicitation et de non-dénigrement sont-elles souvent plus faciles à faire respecter que les clauses de non-concurrence?
   a) Leur portée est plus large
   b) Elles sont généralement plus étroites et interdisent des gestes nuisibles précis plutôt qu'une catégorie entière d'activités
   c) Elles n'ont aucun fondement juridique
   d) Elles ne s'appliquent qu'aux clauses de non-concurrence
3. Vrai ou faux : Les clauses de non-concurrence, de non-sollicitation et de non-dénigrement ont une portée et un caractère exécutoire identiques.
4. Pourquoi l'ancien employeur de Farida pouvait-il quand même obtenir une certaine protection malgré la clause de non-concurrence inexécutoire dans sa juridiction?
   a) Aucune protection n'était possible
   b) Les clauses plus étroites de non-sollicitation et de non-dénigrement restaient exécutoires
   c) La loi lui interdisait complètement de travailler en marketing
   d) Les clauses de non-sollicitation n'existent pas

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Les clauses de non-sollicitation interdisent généralement de solliciter les clients ou les employés d'un ancien employeur, pas d'occuper un emploi concurrent en général.
2. Leur portée plus étroite, qui vise des gestes nuisibles précis, rend les clauses de non-sollicitation et de non-dénigrement plus faciles à faire respecter dans différentes juridictions.
3. Ces trois engagements restrictifs ont une portée vraiment différente et, par conséquent, un caractère exécutoire général différent.
4. Les clauses de non-sollicitation et de non-dénigrement, plus étroites et plus faciles à faire respecter, ont offert une certaine protection malgré la clause de non-concurrence inexécutoire.

**7. Points clés à retenir**
- La non-concurrence interdit largement l'emploi concurrent; la non-sollicitation interdit le recrutement de clients ou d'employés; le non-dénigrement interdit les déclarations publiques négatives.
- Les clauses de non-sollicitation et de non-dénigrement sont généralement plus étroites et souvent plus faciles à faire respecter que les clauses de non-concurrence.
- Bien des ententes combinent les trois et comptent davantage sur les restrictions plus étroites là où les clauses de non-concurrence ont des limites légales.
- Comparer ces instruments liés permet de voir quelles protections restent possibles même là où des restrictions plus larges sont inexécutoires.
