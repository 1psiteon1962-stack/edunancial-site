---
id: PURPLE-L2-011
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 11
title: "Le testament : l'instrument juridique de base pour transmettre ses biens"
summary: "Comprends ce qu'est un testament, ce qu'il contient habituellement et pourquoi le non-respect des formalités de ta juridiction peut le rendre invalide."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-011
### Le testament : l'instrument juridique de base pour transmettre ses biens

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle un testament.
- Nommer les éléments généraux qu'on trouve habituellement dans un testament.
- Reconnaître que les exigences d'un testament sont propres à chaque juridiction.

**2. Contenu principal**
Un testament est un document juridique qui précise comment les biens d'une personne doivent être répartis après son décès; il nomme souvent un exécuteur testamentaire (aussi appelé liquidateur de la succession, la personne chargée d'exécuter les instructions du testament) et, s'il y a lieu, des tuteurs pour les enfants mineurs. Dans la suite de la présentation des notions de planification successorale dans RED-L2-040 et WHITE-L2-046, cette leçon examine le testament lui-même comme instrument juridique de base.

Les éléments généraux qu'on trouve habituellement dans un testament sont : l'identification de la personne qui fait le testament (le « testateur »), les instructions de répartition de biens précis ou de l'ensemble de la succession, la nomination d'un exécuteur testamentaire et, s'il y a lieu, la désignation de tuteurs pour les enfants mineurs. Pour être valide, un testament doit généralement respecter des formalités précises, propres à chaque juridiction — par exemple, être fait par écrit, être signé par le testateur et être signé devant un nombre précis de témoins qui n'héritent pas en vertu du testament. Ne pas respecter ces formalités peut rendre juridiquement invalide un testament par ailleurs clair et bien intentionné.

**3. Exemple pratique**
En rédigeant son premier testament avec une avocate, un père précise comment ses biens doivent être partagés entre ses enfants, nomme sa sœur comme exécutrice testamentaire pour gérer le processus et désigne son frère et sa belle-sœur comme tuteurs de ses enfants mineurs, au cas où lui et sa conjointe ne pourraient plus s'en occuper. Son avocate s'assure que le testament respecte les exigences précises de signature et de témoins de son État, puisqu'un testament qui semble complet sur le fond, mais qui ne respecte pas ces formalités, pourrait être contesté ou complètement annulé, peu importe à quel point il exprime clairement ses vraies volontés.

**4. Quiz de pratique**
1. Qu'est-ce qu'un testament?
   a) Un type de contrat d'affaires
   b) Un document juridique qui précise comment les biens d'une personne doivent être répartis après son décès
   c) Un type de police d'assurance
   d) Un formulaire de déclaration fiscale
2. Qu'est-ce qu'un « exécuteur testamentaire »?
   a) Un type d'obligation
   b) La personne chargée d'exécuter les instructions d'un testament
   c) Un organisme fiscal gouvernemental
   d) Un type de fiducie
3. Vrai ou faux : Les exigences précises de signature et de témoins d'un testament sont identiques dans toutes les juridictions et n'ont jamais besoin d'être vérifiées.
4. Pourquoi l'avocate du père s'est-elle assurée que le testament respectait les formalités précises de son État?
   a) Les formalités n'ont aucune importance pour la validité d'un testament
   b) Ne pas respecter les formalités propres à la juridiction pourrait rendre juridiquement invalide un testament par ailleurs clair
   c) Tous les testaments sont automatiquement valides, peu importe leur forme
   d) Seul le contenu compte, jamais la forme

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Un testament est un document juridique qui précise comment les biens d'une personne doivent être répartis après son décès.
2. L'exécuteur testamentaire est la personne chargée d'exécuter les instructions d'un testament.
3. Les formalités d'un testament varient selon la juridiction et doivent être vérifiées pour qu'un testament précis soit valide.
4. Ne pas respecter certaines formalités précises peut invalider un testament par ailleurs clair et bien intentionné.

**7. Points clés à retenir**
- Le testament est un instrument juridique de base qui précise la répartition des biens et nomme souvent un exécuteur testamentaire et des tuteurs.
- Ses éléments généraux comprennent l'identification du testateur, les instructions de répartition, la nomination d'un exécuteur et la désignation de tuteurs.
- Un testament doit généralement respecter des formalités précises propres à chaque juridiction pour être valide, comme les exigences de signature et de témoins.
- Ne pas respecter ces formalités peut invalider un testament par ailleurs clair et bien intentionné.
