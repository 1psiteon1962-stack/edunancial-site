---
id: PURPLE-L2-012
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 12
title: "La fiducie : en quoi elle diffère d'un testament"
summary: "Comprends le rôle du constituant, du fiduciaire et du bénéficiaire, et pourquoi une fiducie peut gérer des biens dans le temps alors qu'un testament agit une seule fois."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-012
### La fiducie : en quoi elle diffère d'un testament

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle une fiducie.
- Expliquer les rôles généraux du constituant, du fiduciaire et du bénéficiaire.
- Distinguer la fonction de base d'une fiducie de celle d'un testament.

**2. Contenu principal**
Une fiducie est un arrangement juridique dans lequel une partie (le « constituant ») transfère des biens pour qu'ils soient détenus et gérés par une autre partie (le « fiduciaire ») au profit de bénéficiaires désignés, selon les conditions établies par le constituant. Contrairement à un testament, qui ne prend généralement effet et ne dirige la répartition qu'après le décès, une fiducie peut prendre effet du vivant du constituant et gérer et distribuer activement des biens selon ses conditions pendant que le constituant est encore en vie, en plus (ou à la place) de diriger la répartition après le décès.

Ça crée une différence fonctionnelle importante par rapport à un testament : une fiducie peut assurer une gestion continue des biens — utile, par exemple, si un bénéficiaire est mineur, a des besoins particuliers, ou si le constituant veut que les distributions se fassent graduellement avec le temps plutôt que d'un coup —, alors qu'un testament donne généralement une instruction de répartition unique qui ne prend effet qu'au décès, sans ce genre de capacité de gestion continue.

**3. Exemple pratique**
Au lieu de simplement laisser une somme globale à ses jeunes petits-enfants par testament, ce qui leur serait généralement transféré directement (ou à un tuteur nommé par le tribunal) à son décès, une grand-mère établit une fiducie qui nomme un fiduciaire chargé de gérer les fonds et de faire des distributions graduelles avec le temps — pour les frais d'études maintenant, et des distributions plus importantes quand les petits-enfants atteindront certains âges. Cette structure de gestion continue, qui n'est pas possible avec un simple testament, reflète son objectif précis d'orienter comment et quand les fonds seront réellement utilisés, plutôt que de faire une distribution immédiate et unique d'une somme globale.

**4. Quiz de pratique**
1. Qu'est-ce qu'une fiducie?
   a) Un type de police d'assurance
   b) Un arrangement juridique où un fiduciaire détient et gère des biens pour des bénéficiaires, selon les conditions du constituant
   c) Un formulaire fiscal gouvernemental
   d) Un type de contrat réservé aux entreprises
2. Quelle différence fonctionnelle distingue une fiducie d'un testament?
   a) Elles sont identiques sur le plan fonctionnel
   b) Une fiducie peut assurer une gestion et des distributions continues avec le temps, alors qu'un testament donne généralement une répartition unique après le décès
   c) Les testaments peuvent gérer des biens du vivant de la personne, alors que les fiducies ne le peuvent pas
   d) Les fiducies n'ont aucune fonction juridique
3. Vrai ou faux : Un testament et une fiducie ont des fonctions identiques, sans différence importante.
4. Pourquoi la grand-mère a-t-elle choisi une fiducie plutôt qu'un simple testament pour ses petits-enfants?
   a) Elle voulait une distribution immédiate et unique d'une somme globale
   b) Elle voulait une gestion continue et des distributions graduelles avec le temps, ce qu'une fiducie pouvait offrir
   c) Les fiducies sont toujours plus simples que les testaments
   d) Elle n'avait aucun objectif précis pour l'utilisation des fonds

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une fiducie est un arrangement juridique où un fiduciaire détient et gère des biens pour des bénéficiaires selon les conditions du constituant.
2. Une fiducie peut assurer une gestion et des distributions continues avec le temps, contrairement à la répartition généralement unique et après le décès d'un testament.
3. Les testaments et les fiducies ont des fonctions vraiment différentes, même s'ils sont tous les deux des outils de planification successorale.
4. L'objectif de la grand-mère, des distributions graduelles et encadrées avec le temps, était mieux servi par la capacité de gestion continue d'une fiducie.

**7. Points clés à retenir**
- Une fiducie implique un fiduciaire qui détient et gère des biens pour des bénéficiaires selon les conditions du constituant.
- Contrairement à un testament, une fiducie peut prendre effet du vivant du constituant et assurer une gestion continue.
- Ça rend les fiducies utiles pour des distributions graduelles, des bénéficiaires mineurs ou des situations de besoins particuliers.
- Un testament donne généralement une instruction de répartition unique qui ne prend effet qu'après le décès.
