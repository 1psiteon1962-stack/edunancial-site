---
id: PURPLE-L2-013
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 13
title: "Fiducies révocables ou irrévocables : une comparaison"
summary: "Compare les fiducies révocables et irrévocables et comprends le compromis entre la souplesse et la protection des biens, une décision qui exige un conseil professionnel."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-013
### Fiducies révocables ou irrévocables : une comparaison

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Distinguer les fiducies révocables des fiducies irrévocables.
- Expliquer les compromis généraux entre la souplesse et la protection des biens pour chaque type.
- Reconnaître que c'est une décision personnalisée qui exige un encadrement professionnel.

**2. Contenu principal**
Dans la suite de la leçon 12, cette leçon compare deux grandes catégories de fiducies. Une fiducie révocable (parfois appelée « fiducie entre vifs » ou *living trust*) permet généralement au constituant de la modifier ou de la révoquer complètement de son vivant; il garde ainsi beaucoup de souplesse et de contrôle, mais la fiducie offre généralement une protection des biens ou des avantages fiscaux plus limités, puisque le contrôle continu du constituant fait que les biens sont souvent encore considérés comme les siens à certaines fins juridiques et fiscales. Une fiducie irrévocable ne peut généralement pas être facilement modifiée ni révoquée une fois établie; le constituant renonce donc à beaucoup de contrôle, mais ce contrôle réduit peut, selon la structure précise et la juridiction, offrir une meilleure protection des biens ou des avantages fiscaux, puisque les biens sont plus clairement considérés comme séparés du constituant une fois transférés.

C'est un vrai compromis entre la souplesse et la protection, et non un type supérieur à l'autre dans tous les cas. Le bon choix dépend des objectifs précis du constituant, de sa tolérance au fait de renoncer au contrôle et des protections ou avantages recherchés, ce qui exige l'encadrement d'un avocat ou d'un notaire qualifié en planification successorale, vu les conséquences importantes, et parfois difficiles à renverser, de ce choix.

**3. Exemple pratique**
En comparant les options de fiducie avec son avocat en planification successorale, Renata considère une fiducie révocable, qui lui permettrait de garder le plein contrôle et la souplesse de faire des changements à mesure que sa situation évolue, et une fiducie irrévocable, qui offrirait possiblement une meilleure protection des biens pour un objectif précis qu'elle a en tête, mais qui l'obligerait à renoncer à la possibilité de modifier ou de récupérer les biens une fois transférés. Comme sa priorité est de garder de la souplesse pendant une période de grands changements dans sa vie, elle choisit une fiducie révocable pour l'instant, et son avocat note que cette décision pourrait être revue avec l'ensemble de sa planification successorale quand sa situation se sera stabilisée.

**4. Quiz de pratique**
1. Que permet généralement une fiducie révocable au constituant?
   a) Rien — elle ne peut pas être changée une fois créée
   b) La modifier ou la révoquer de son vivant
   c) Éviter automatiquement tous les impôts
   d) Transférer des biens sans aucune formalité juridique
2. Quel est un compromis général d'une fiducie irrévocable?
   a) Il n'y a aucun compromis
   b) Un contrôle réduit du constituant en échange d'une protection des biens ou d'avantages fiscaux possiblement meilleurs
   c) Une souplesse complète, sans perte de contrôle
   d) L'élimination garantie de tous les impôts successoraux
3. Vrai ou faux : Un type de fiducie est supérieur à l'autre pour chaque constituant et chaque situation.
4. Pourquoi Renata a-t-elle choisi une fiducie révocable pour sa situation actuelle?
   a) Elle voulait renoncer à tout contrôle tout de suite
   b) Elle donnait la priorité à la souplesse pendant une période de grands changements dans sa vie
   c) La loi exige toujours des fiducies révocables
   d) Elle n'avait aucun objectif précis

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une fiducie révocable permet généralement au constituant de la modifier ou de la révoquer de son vivant.
2. Une fiducie irrévocable échange généralement un contrôle réduit du constituant contre une protection des biens ou des avantages fiscaux possiblement meilleurs.
3. Le bon choix dépend des objectifs et de la situation précise du constituant, pas d'une supériorité universelle de l'un ou l'autre type.
4. La priorité de Renata pour la souplesse pendant une période de changement faisait de la fiducie révocable le meilleur choix pour sa situation actuelle.

**7. Points clés à retenir**
- Les fiducies révocables permettent des modifications continues et le maintien du contrôle, mais offrent généralement une protection des biens plus limitée.
- Les fiducies irrévocables réduisent le contrôle du constituant, mais peuvent offrir une meilleure protection des biens ou des avantages fiscaux, selon leur structure.
- C'est un vrai compromis entre la souplesse et la protection, pas une supériorité universelle d'un type sur l'autre.
- Cette décision exige l'encadrement d'un avocat ou d'un notaire qualifié en planification successorale, vu ses conséquences importantes et parfois irréversibles.
