---
id: PURPLE-L2-014
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 14
title: "Testaments ou fiducies : homologation, confidentialité et contrôle comparés"
summary: "Compare le testament et la fiducie sur le plan de l'homologation, de la confidentialité et du contrôle, et vois pourquoi bien des plans successoraux utilisent les deux."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-014
### Testaments ou fiducies : homologation, confidentialité et contrôle comparés

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Comparer les testaments et les fiducies sur le plan de l'homologation, de la confidentialité et du contrôle.
- Expliquer le concept général de l'homologation.
- Appliquer cette comparaison à un scénario hypothétique de planification successorale.

**2. Contenu principal**
Dans la suite des leçons 11 à 13, cette leçon compare directement les testaments et les fiducies sur trois aspects pratiques. L'homologation (*probate*) est le processus supervisé par un tribunal qui valide un testament et encadre la répartition d'une succession. Un testament doit généralement passer par ce processus, qui peut entraîner des frais de justice, des délais et — puisque les procédures d'homologation font généralement partie des dossiers publics — une perte de confidentialité sur le contenu et la répartition de la succession. Une fiducie correctement financée (c'est-à-dire dans laquelle les biens ont réellement été transférés, et pas seulement mentionnés dans ses conditions) peut souvent permettre aux biens de passer aux bénéficiaires sans homologation, ce qui peut offrir une répartition plus rapide et plus de confidentialité, puisque les conditions et l'administration d'une fiducie restent généralement privées au lieu de devenir des dossiers judiciaires publics.

Le contrôle diffère aussi selon les types de fiducies vus à la leçon 13 : une fiducie révocable conserve beaucoup de contrôle pour le constituant de son vivant, alors qu'un testament n'offre aucun mécanisme de contrôle continu; il ne prend effet qu'une seule fois, comme instruction après le décès. Cette comparaison ne veut pas dire que les fiducies sont supérieures aux testaments dans tous les cas : bien des plans successoraux utilisent les deux instruments ensemble, avec un testament qui couvre les biens non transférés dans la fiducie, et la bonne combinaison dépend des biens, des objectifs et de la juridiction de chaque personne.

**3. Exemple pratique**
En comparant ses options avec son avocate, une propriétaire d'entreprise reconnaît que se fier uniquement à un testament voudrait dire que sa succession, y compris des détails sensibles sur la propriété de son entreprise, ferait partie du dossier public d'homologation après son décès, et que l'homologation pourrait retarder le transfert de la propriété de son entreprise pendant une période possiblement vulnérable. Elle établit plutôt une fiducie révocable correctement financée pour détenir ses participations dans l'entreprise, ce qui permet un transfert plus rapide et plus confidentiel à sa relève, tout en gardant un simple testament « de transfert » (*pour-over will*) pour couvrir les biens qui n'auraient pas été officiellement transférés dans la fiducie avant son décès.

**4. Quiz de pratique**
1. Qu'est-ce que l'homologation?
   a) Un type de fiducie
   b) Le processus supervisé par un tribunal qui valide un testament et encadre la répartition d'une succession
   c) Un formulaire fiscal
   d) Un type de prêt d'entreprise
2. Sur le plan de la confidentialité, quel est un avantage général d'une fiducie correctement financée par rapport à un testament?
   a) Les fiducies sont toujours plus publiques que les testaments
   b) Les conditions et l'administration d'une fiducie restent généralement privées, contrairement aux procédures publiques d'homologation
   c) Il n'y a aucune différence de confidentialité entre les deux
   d) Les testaments ne font jamais partie d'un dossier public
3. Vrai ou faux : Les fiducies sont supérieures aux testaments dans toutes les situations, ce qui rend les testaments complètement inutiles.
4. Pourquoi la propriétaire d'entreprise a-t-elle établi une fiducie en plus d'un simple testament?
   a) Elle voulait que les détails de son entreprise deviennent publics
   b) Elle voulait un transfert plus rapide et plus confidentiel de la propriété de son entreprise, en évitant les délais d'homologation
   c) La loi exige des fiducies pour tous les propriétaires d'entreprise
   d) Elle n'avait aucune participation dans une entreprise à protéger

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'homologation est le processus supervisé par un tribunal qui valide un testament et encadre la répartition d'une succession.
2. Une fiducie correctement financée permet généralement aux biens d'éviter l'homologation publique, ce qui offre plus de confidentialité qu'un testament seul.
3. Bien des plans successoraux utilisent ensemble des testaments et des fiducies, et la bonne combinaison dépend de la situation de chacun.
4. La fiducie de la propriétaire d'entreprise a permis un transfert plus rapide et plus confidentiel de ses participations sensibles dans l'entreprise, en évitant l'homologation.

**7. Points clés à retenir**
- L'homologation est le processus supervisé par un tribunal, et généralement public, par lequel un testament doit passer pour être validé et exécuté.
- Une fiducie correctement financée peut souvent éviter l'homologation, ce qui offre une répartition plus rapide et plus de confidentialité.
- Le contrôle diffère aussi : une fiducie révocable conserve le contrôle du constituant de son vivant, alors qu'un testament ne prend effet qu'après le décès.
- Bien des plans successoraux utilisent les deux instruments ensemble, et la bonne combinaison dépend de la situation de chacun.
