---
id: PURPLE-L2-015
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 15
title: "La procuration : types et but général"
summary: "Comprends ce qu'est une procuration, la différence entre une procuration générale et une procuration durable, et pourquoi elle sert à planifier l'inaptitude, pas seulement le décès."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-015
### La procuration : types et but général

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle la procuration.
- Distinguer la procuration générale de la procuration durable.
- Expliquer pourquoi cet instrument vise l'inaptitude, et pas seulement le décès.

**2. Contenu principal**
Une procuration est un document juridique qui donne à une personne (le « mandataire » ou « fondé de pouvoir ») le pouvoir d'agir au nom d'une autre personne (le « mandant »), généralement pour des questions financières ou juridiques. Contrairement aux testaments et à bien des dispositions de fiducie, qui portent surtout sur ce qui arrive après le décès, une procuration vise des situations du vivant du mandant, particulièrement l'inaptitude — une maladie ou une blessure grave qui empêche le mandant de gérer lui-même ses affaires.

Une procuration générale donne habituellement des pouvoirs étendus, mais elle devient généralement invalide si le mandant devient inapte — précisément la situation où ces pouvoirs pourraient être le plus nécessaires —, à moins que le document contienne expressément une clause de « durabilité ». Une procuration durable (*durable power of attorney*; au Québec, on parle plutôt de mandat de protection, ou mandat en cas d'inaptitude) contient précisément des dispositions qui garantissent que les pouvoirs restent valides même si le mandant devient inapte. C'est donc l'instrument le plus souvent recommandé pour planifier l'inaptitude en particulier, puisqu'une procuration ordinaire, non durable, peut cesser d'être valide exactement au moment où on en aurait le plus besoin.

**3. Exemple pratique**
Avant une opération prévue qui comporte un certain risque de convalescence difficile, un homme établit une procuration durable qui nomme sa conjointe pour gérer ses affaires financières — payer les factures, gérer les comptes —, en s'assurant précisément que ces pouvoirs resteraient valides même si des complications l'empêchaient temporairement de gérer lui-même ces questions. S'il avait plutôt signé seulement une procuration générale non durable, les pouvoirs de sa conjointe d'agir en son nom auraient pu devenir invalides exactement au moment où son inaptitude les rendait le plus nécessaires, ce qui aurait annulé tout l'intérêt d'avoir organisé ces pouvoirs d'avance.

**4. Quiz de pratique**
1. Qu'est-ce qu'une procuration?
   a) Un type de testament
   b) Un document juridique qui donne à une personne le pouvoir d'agir au nom d'une autre
   c) Un type de fiducie réservé aux entreprises
   d) Un formulaire de déclaration fiscale
2. Qu'est-ce que la « durabilité » ajoute à une procuration?
   a) Rien d'important
   b) Des dispositions qui garantissent que les pouvoirs restent valides même si le mandant devient inapte
   c) Une garantie que le document n'expire jamais, peu importe les circonstances
   d) Une valeur financière supplémentaire pour la succession
3. Vrai ou faux : Une procuration ordinaire, non durable, reste valide même si le mandant devient inapte.
4. Pourquoi l'homme a-t-il choisi précisément une procuration durable avant son opération?
   a) Il voulait que les pouvoirs deviennent invalides s'il devenait inapte
   b) Il voulait que les pouvoirs de sa conjointe restent valides précisément pendant une période d'inaptitude possible
   c) La loi exige une procuration durable pour toutes les opérations
   d) Il n'avait aucune inquiétude au sujet de l'inaptitude

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une procuration donne à une personne le pouvoir juridique d'agir au nom d'une autre.
2. La durabilité garantit que les pouvoirs de la procuration restent valides même si le mandant devient inapte.
3. Une procuration ordinaire, non durable, devient généralement invalide quand le mandant devient inapte.
4. La procuration durable de l'homme garantissait que les pouvoirs de sa conjointe resteraient valides précisément pendant une période d'inaptitude possible.

**7. Points clés à retenir**
- Une procuration donne à un mandataire le pouvoir d'agir au nom d'un mandant, généralement pour des questions financières ou juridiques.
- Contrairement aux testaments, une procuration vise des situations du vivant du mandant, particulièrement l'inaptitude.
- Une procuration générale non durable devient généralement invalide en cas d'inaptitude, sauf si elle contient des dispositions de durabilité.
- La procuration durable est généralement l'instrument recommandé précisément pour planifier l'inaptitude.
