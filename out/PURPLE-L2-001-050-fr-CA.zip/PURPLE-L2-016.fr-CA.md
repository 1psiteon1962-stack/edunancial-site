---
id: PURPLE-L2-016
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 16
title: "Les directives médicales anticipées et le testament de vie : un autre type d'instrument"
summary: "Comprends ce que sont la procuration en matière de soins de santé et le testament de vie, et pourquoi ils couvrent les décisions médicales plutôt que financières."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-016
### Les directives médicales anticipées et le testament de vie : un autre type d'instrument

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle une directive en matière de soins de santé et un testament de vie.
- Distinguer ces instruments d'une procuration financière (leçon 15).
- Expliquer pourquoi ces instruments portent sur des décisions médicales, et non financières.

**2. Contenu principal**
Dans la suite de la discussion sur la procuration financière de la leçon 15, cette leçon présente une catégorie d'instruments liée, mais distincte, qui porte sur les décisions médicales plutôt que financières en cas d'inaptitude. Une procuration en matière de soins de santé (parfois appelée mandataire aux soins) désigne une personne précise pour prendre des décisions médicales au nom du mandant s'il devient incapable de les prendre lui-même. Un testament de vie (parfois appelé directive médicale anticipée) consigne précisément les propres volontés du mandant concernant certains traitements médicaux — comme les mesures de maintien de la vie —, ce qui guide à la fois le mandataire désigné et les professionnels de la santé, même en l'absence d'indications précises du mandataire.

Ces instruments ont une fonction différente de celle de la procuration financière de la leçon 15 : les procurations financières visent le paiement des factures et la gestion des biens, alors que les directives en matière de soins de santé visent les décisions de traitement médical. Un plan complet en cas d'inaptitude comprend généralement les deux types, puisqu'ils couvrent des catégories de décisions fondamentalement différentes.

**3. Exemple pratique**
Dans le cadre d'une planification successorale et d'inaptitude complète, une femme établit à la fois une procuration financière durable (leçon 15), qui nomme son frère pour gérer ses finances au besoin, et, séparément, une procuration en matière de soins de santé qui nomme sa sœur pour prendre des décisions médicales en son nom, ainsi qu'un testament de vie qui consigne ses volontés précises au sujet des traitements de maintien de la vie dans certaines circonstances définies. Cette approche complète assure que ses affaires financières et médicales sont prises en charge par des personnes de confiance, avec des indications claires, au lieu de compter sur un seul document pour couvrir ces catégories de décisions fondamentalement différentes.

**4. Quiz de pratique**
1. Que désigne généralement une procuration en matière de soins de santé?
   a) Une personne pour gérer des comptes financiers
   b) Une personne pour prendre des décisions médicales au nom du mandant s'il devient incapable de le faire
   c) Un type de police d'assurance
   d) Un statut de déclaration fiscale
2. Que consigne généralement un testament de vie?
   a) Comment les biens doivent être répartis après le décès
   b) Les propres volontés du mandant concernant certains traitements médicaux
   c) Des instructions de transfert de la propriété d'une entreprise
   d) Les conditions précises d'une procuration financière
3. Vrai ou faux : Une procuration financière et une procuration en matière de soins de santé portent sur les mêmes catégories de décisions.
4. Pourquoi la femme a-t-elle établi les deux types de procurations, en plus d'un testament de vie?
   a) Un seul document aurait couvert toutes les décisions possibles
   b) Les décisions financières et médicales sont des catégories fondamentalement différentes qui exigent des instruments distincts
   c) Elle n'avait besoin d'aucune indication pour les décisions médicales
   d) Le testament de vie remplace complètement le besoin d'une procuration en matière de soins de santé

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une procuration en matière de soins de santé désigne une personne pour prendre des décisions médicales au nom du mandant en cas d'inaptitude.
2. Un testament de vie consigne les propres volontés du mandant concernant certains traitements médicaux.
3. Les procurations financières et en matière de soins de santé portent sur des catégories de décisions fondamentalement différentes.
4. L'approche complète de la femme couvrait à la fois les décisions financières et médicales, en reconnaissant qu'elles exigent des instruments distincts.

**7. Points clés à retenir**
- Une procuration en matière de soins de santé désigne une personne pour prendre des décisions médicales en cas d'inaptitude.
- Un testament de vie consigne les propres volontés du mandant concernant des traitements médicaux précis.
- Ces instruments portent sur des décisions médicales, ce qui les distingue de la procuration financière vue à la leçon 15.
- Un plan complet en cas d'inaptitude comprend généralement des instruments financiers et des instruments de soins de santé.
