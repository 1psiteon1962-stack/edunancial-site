---
id: PURPLE-L2-017
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 17
title: "Désignations de bénéficiaire ou testament : lequel l'emporte?"
summary: "Revois du point de vue juridique pourquoi une désignation de bénéficiaire l'emporte généralement sur un testament contradictoire, et pourquoi il faut la mettre à jour directement auprès de chaque institution."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-017
### Désignations de bénéficiaire ou testament : lequel l'emporte?

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Renforcer, du point de vue des instruments juridiques, la discussion de WHITE-L2-046 sur les désignations de bénéficiaire.
- Expliquer la règle générale de priorité entre les désignations de bénéficiaire et les testaments.
- Appliquer cette notion à un scénario hypothétique de planification successorale.

**2. Contenu principal**
En reprenant la discussion de WHITE-L2-046 sur les désignations de bénéficiaire, cette leçon examine plus directement la relation juridique entre ces désignations et un testament. Certains biens — comptes de retraite, polices d'assurance vie et certains comptes bancaires ou de courtage comportant une désignation « payable au décès » ou « transférable au décès » — passent généralement directement au bénéficiaire nommé au décès du titulaire du compte, selon la désignation inscrite auprès de l'institution, en grande partie indépendamment de ce qu'un testament pourrait dire séparément au sujet de ce même bien.

Ça veut dire qu'une désignation de bénéficiaire l'emporte généralement sur une disposition contradictoire d'un testament pour ce bien précis : une désignation désuète (qui nomme un ex-conjoint, par exemple) peut l'emporter même sur les instructions d'un testament plus récent et soigneusement rédigé pour ce compte précis — exactement l'écart illustré dans l'exemple de WHITE-L2-046. C'est une réalité juridique essentielle, et parfois sous-estimée : une planification successorale complète exige de revoir et de mettre à jour les désignations de bénéficiaire directement auprès de chaque institution, et pas seulement de mettre un testament à jour en supposant qu'il couvre tout.

**3. Exemple pratique**
Après avoir rédigé un nouveau testament complet qui reflète ses volontés actuelles à la suite d'un remariage, un homme suppose que sa planification successorale est terminée. Lors d'un examen avec son avocat, ils découvrent que son compte de retraite nomme encore son ex-conjointe comme bénéficiaire désignée, une désignation faite des années plus tôt, qui déterminerait juridiquement la répartition de ce compte précis, peu importe ce que dit son nouveau testament soigneusement rédigé. Il met immédiatement à jour la désignation de bénéficiaire directement auprès du fournisseur de son compte de retraite, ce qui comble un écart que son nouveau testament seul n'aurait pas pu corriger.

**4. Quiz de pratique**
1. Qu'est-ce qui détermine généralement la répartition d'un bien qui comporte une désignation de bénéficiaire valide, comme un compte de retraite?
   a) Le testament, peu importe toute désignation de bénéficiaire
   b) La désignation de bénéficiaire inscrite auprès de l'institution, en grande partie indépendamment du testament
   c) Ni le testament ni la désignation n'ont d'effet juridique
   d) Un tribunal les écarte toujours automatiquement tous les deux
2. Pourquoi est-il important de mettre à jour les désignations de bénéficiaire directement auprès de chaque institution?
   a) C'est inutile une fois le testament mis à jour
   b) Une désignation l'emporte généralement sur une disposition contradictoire d'un testament pour ce bien précis
   c) Les désignations de bénéficiaire n'ont aucune importance juridique
   d) Les testaments l'emportent toujours automatiquement sur les désignations
3. Vrai ou faux : Mettre à jour un testament met automatiquement à jour toutes les désignations de bénéficiaire des comptes de retraite et des polices d'assurance.
4. Quel écart l'avocat de l'homme a-t-il découvert lors de l'examen de sa planification successorale?
   a) Son testament était invalide
   b) Son compte de retraite nommait encore son ex-conjointe comme bénéficiaire, malgré son nouveau testament
   c) Il n'avait aucun compte de retraite
   d) Sa nouvelle conjointe était déjà correctement nommée

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une désignation de bénéficiaire détermine généralement la répartition de ce bien précis, en grande partie indépendamment des dispositions du testament.
2. Comme les désignations l'emportent généralement sur un testament contradictoire pour ce bien, il est essentiel de les mettre à jour directement auprès de chaque institution.
3. Mettre à jour un testament ne met pas automatiquement à jour les désignations de bénéficiaire tenues séparément par chaque institution.
4. La désignation désuète du compte de retraite de l'homme aurait déterminé la répartition, malgré les intentions différentes de son testament mis à jour.

**7. Points clés à retenir**
- Certains biens passent selon les désignations de bénéficiaire, en grande partie indépendamment de ce que dit un testament.
- Une désignation de bénéficiaire l'emporte généralement sur une disposition contradictoire d'un testament pour ce bien précis.
- Mettre à jour un testament ne met pas automatiquement à jour les désignations de bénéficiaire tenues séparément.
- Une planification successorale complète exige de revoir et de mettre à jour les désignations directement auprès de chaque institution concernée.
