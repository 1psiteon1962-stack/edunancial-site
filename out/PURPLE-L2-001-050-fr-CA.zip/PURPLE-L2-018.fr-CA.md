---
id: PURPLE-L2-018
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 18
title: "Les contrats de travail : emploi « à volonté » ou emploi contractuel"
summary: "Comprends ce qu'est l'emploi « à volonté », courant aux États-Unis, en quoi il diffère d'un emploi encadré par un contrat, et pourquoi les règles varient beaucoup selon l'endroit."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-018
### Les contrats de travail : emploi « à volonté » ou emploi contractuel

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle l'emploi « à volonté » (*at-will employment*).
- Distinguer l'emploi à volonté de l'emploi contractuel.
- Reconnaître qu'il s'agit d'une règle juridique par défaut propre à chaque juridiction, qui comporte des exceptions importantes.

**2. Contenu principal**
Dans bien des juridictions américaines, la relation d'emploi par défaut est l'emploi « à volonté » : l'employeur ou l'employé peut généralement mettre fin à la relation en tout temps, pour presque n'importe quelle raison (ou sans raison déclarée), sans avoir à établir une « cause juste », sous réserve d'exceptions importantes. Par exemple, même dans un emploi à volonté, un employeur ne peut généralement pas congédier un employé pour un motif protégé par la loi (comme certaines formes de discrimination). Cette règle par défaut contraste avec l'emploi contractuel, où un contrat de travail précis définit les conditions de la relation, y compris la durée, les motifs de fin d'emploi et souvent des dispositions d'indemnité de départ. Il faut alors généralement un motif précis, défini dans le contrat (ou l'arrivée à échéance naturelle du contrat), pour mettre fin à la relation, au lieu de pouvoir y mettre fin pour n'importe quelle raison.

C'est une règle par défaut PROPRE À UNE RÉGION : les juridictions à l'extérieur des États-Unis ont souvent des protections d'emploi par défaut vraiment différentes (au Canada, par exemple, l'emploi à volonté n'est pas la règle par défaut, et un préavis ou une indemnité de fin d'emploi est généralement exigé), et même aux États-Unis, les exceptions à l'emploi à volonté (lois contre la discrimination, exceptions d'ordre public, exceptions de contrat implicite dans certaines juridictions) peuvent être importantes et dépendre des faits.

**3. Exemple pratique**
En examinant sa nouvelle offre d'emploi, Priya remarque qu'elle ne comprend pas de contrat de travail précis définissant une durée fixe ou des motifs précis nécessaires pour mettre fin à l'emploi; elle est donc probablement embauchée selon le cadre par défaut de l'emploi à volonté de sa juridiction, où elle ou son employeur peut généralement mettre fin à la relation en tout temps. Ça contraste avec une collègue de la même entreprise, embauchée en vertu d'un contrat de travail de cadre précis de deux ans, qui définit précisément les motifs nécessaires pour mettre fin à l'emploi et prévoit une indemnité de départ si l'entreprise met fin à la relation sans respecter ces motifs — un arrangement vraiment différent, et plus protecteur, que le cadre par défaut de l'emploi à volonté dans lequel Priya se trouve.

**4. Quiz de pratique**
1. Que veut généralement dire l'« emploi à volonté »?
   a) On ne peut mettre fin à l'emploi que pour une cause précise et définie
   b) L'une ou l'autre partie peut généralement mettre fin à la relation en tout temps, pour presque n'importe quelle raison, sous réserve d'exceptions importantes
   c) Un contrat de travail est exigé dans tous les cas
   d) La fin d'emploi est illégale en toutes circonstances
2. En quoi l'emploi contractuel diffère-t-il généralement de l'emploi à volonté?
   a) Ils sont identiques à tous points de vue
   b) Un contrat précis définit la durée, les motifs de fin d'emploi et souvent les indemnités de départ
   c) L'emploi contractuel permet de mettre fin à l'emploi pour n'importe quelle raison, en tout temps
   d) L'emploi à volonté comprend toujours des indemnités de départ
3. Vrai ou faux : L'emploi à volonté permet à un employeur de congédier un employé pour n'importe quelle raison, y compris des motifs protégés par la loi, comme certaines formes de discrimination.
4. Qu'est-ce qui distinguait l'offre d'emploi de Priya du contrat de travail de cadre de sa collègue?
   a) C'étaient des arrangements identiques
   b) L'emploi de Priya relevait probablement de l'emploi à volonté par défaut, alors que le contrat de sa collègue définissait des motifs de fin d'emploi et une indemnité de départ précis
   c) Priya avait un arrangement plus protecteur que sa collègue
   d) Aucun des deux arrangements n'avait d'importance juridique

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'emploi à volonté permet généralement à l'une ou l'autre partie de mettre fin à la relation en tout temps, pour presque n'importe quelle raison, sous réserve d'exceptions importantes.
2. L'emploi contractuel définit des conditions précises, y compris les motifs de fin d'emploi et souvent une indemnité de départ, ce qui le distingue de la règle par défaut de l'emploi à volonté.
3. L'emploi à volonté ne permet pas de congédier pour des motifs protégés par la loi, comme certaines formes de discrimination, même s'il accorde par ailleurs une grande latitude.
4. L'arrangement probablement à volonté de Priya contrastait avec l'emploi contractuel de sa collègue, mieux défini et plus protecteur.

**7. Points clés à retenir**
- L'emploi à volonté est une règle par défaut courante aux États-Unis qui permet à l'une ou l'autre partie de mettre fin à la relation en tout temps, sous réserve d'exceptions importantes.
- L'emploi contractuel définit des conditions précises, y compris les motifs de fin d'emploi et souvent des indemnités de départ.
- Les exceptions importantes à l'emploi à volonté comprennent les protections contre la discrimination et, dans certaines juridictions, d'autres limites légales.
- C'est un cadre juridique fortement propre à chaque juridiction, avec des règles par défaut vraiment différentes à l'extérieur des États-Unis.
