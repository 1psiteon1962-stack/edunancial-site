---
id: PURPLE-L2-019
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 19
title: "Les manuels de l'employé : politique ou contrat qui engage"
summary: "Comprends le statut juridique d'un manuel de l'employé, pourquoi certaines formulations peuvent créer des obligations contractuelles non voulues et l'utilité d'un avis de non-responsabilité clair."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-019
### Les manuels de l'employé : politique ou contrat qui engage

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le statut juridique général d'un manuel de l'employé.
- Nommer pourquoi la formulation d'un manuel peut parfois créer des obligations contractuelles non voulues.
- Reconnaître l'utilité d'un avis de non-responsabilité clair dans un manuel.

**2. Contenu principal**
Un manuel de l'employé sert généralement de document de politique qui communique les attentes, les procédures et les renseignements sur les avantages sociaux d'un employeur. Il vise généralement à rester un ensemble de lignes directrices souples et non contraignantes plutôt qu'un contrat qui engage — une distinction importante par rapport à l'emploi contractuel vu à la leçon 18. Par contre, des tribunaux de certaines juridictions ont jugé que des formulations précises qui ressemblent à des promesses (comme des procédures disciplinaires progressives détaillées et obligatoires, présentées comme des étapes garanties avant tout congédiement) peuvent, dans certaines circonstances, créer une obligation contractuelle implicite, ce qui pourrait limiter la relation d'emploi à volonté (leçon 18) qui s'appliquerait autrement.

À cause de ce risque, on conseille généralement aux employeurs d'inclure dans leur manuel un avis de non-responsabilité clair et explicite qui confirme que le manuel ne crée pas de contrat et que l'emploi à volonté reste en vigueur, et d'éviter les formulations trop précises, qui ressemblent à des garanties, au sujet des procédures disciplinaires ou de la sécurité d'emploi, à moins qu'une relation contractuelle soit réellement voulue.

**3. Exemple pratique**
En rédigeant un manuel de l'employé pour son entreprise en croissance, une propriétaire d'entreprise inclut d'abord une formulation détaillée qui décrit un processus disciplinaire précis, en plusieurs étapes, qui doit toujours avoir lieu avant tout congédiement — une formulation qui pourrait, dans certaines juridictions, être interprétée comme une promesse contractuelle implicite limitant sa capacité à mettre fin plus librement à l'emploi d'employés à volonté. Son avocat lui recommande de revoir cette formulation pour décrire le processus disciplinaire comme une ligne directrice générale plutôt que comme une procédure obligatoire et garantie, et d'ajouter un avis de non-responsabilité explicite confirmant que le manuel ne crée pas de contrat et que l'emploi à volonté reste en vigueur. Elle protège ainsi sa souplesse tout en communiquant clairement ses attentes aux employés.

**4. Quiz de pratique**
1. Qu'est-ce qu'un manuel de l'employé vise généralement à être?
   a) Un contrat de travail contraignant et immuable
   b) Un document de politique souple qui communique les attentes et les procédures
   c) Un type de police d'assurance
   d) Une déclaration fiscale gouvernementale
2. Pourquoi une formulation précise qui ressemble à une promesse dans un manuel pourrait-elle créer un risque juridique pour un employeur?
   a) Elle n'a aucune importance juridique
   b) Des tribunaux de certaines juridictions pourraient l'interpréter comme créant une obligation contractuelle implicite, ce qui limiterait la souplesse de l'emploi à volonté
   c) Toutes les formulations d'un manuel sont automatiquement non contraignantes, peu importe les mots utilisés
   d) La loi exige toujours que les manuels soient des contrats contraignants
3. Vrai ou faux : Un avis de non-responsabilité clair dans un manuel n'a aucune importance juridique pour le statut d'emploi à volonté.
4. Quel changement l'avocat a-t-il recommandé pour la formulation disciplinaire du manuel de la propriétaire d'entreprise?
   a) Rendre la formulation plus précise et plus proche d'une garantie
   b) Décrire le processus comme une ligne directrice générale et ajouter un avis explicite sur l'emploi à volonté
   c) Retirer complètement toute mention de la discipline
   d) Faire passer tout de suite tous les employés à un emploi contractuel

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Un manuel de l'employé vise généralement à être un document de politique souple, et non un contrat de travail contraignant.
2. Une formulation précise qui ressemble à une promesse peut, dans certaines juridictions, créer une obligation contractuelle implicite qui limite la souplesse de l'emploi à volonté.
3. Un avis de non-responsabilité clair aide à confirmer que le manuel ne crée pas de contrat, ce qui soutient le maintien de l'emploi à volonté.
4. Les révisions recommandées par l'avocat ont protégé la souplesse de la propriétaire d'entreprise tout en maintenant une communication claire avec les employés.

**7. Points clés à retenir**
- Les manuels de l'employé visent généralement à être des documents de politique souples, et non des contrats contraignants.
- Une formulation précise qui ressemble à une promesse peut, dans certaines juridictions, créer des obligations contractuelles implicites non voulues.
- Un avis de non-responsabilité clair et explicite aide à préserver l'emploi à volonté quand c'est l'intention.
- Ça se rattache directement à la distinction entre l'emploi à volonté et l'emploi contractuel de la leçon 18.
