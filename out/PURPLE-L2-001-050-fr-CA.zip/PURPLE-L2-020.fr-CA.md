---
id: PURPLE-L2-020
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 20
title: "Survol de la propriété intellectuelle : brevets, marques de commerce, droits d'auteur et secrets commerciaux comparés"
summary: "Compare les quatre grandes catégories de propriété intellectuelle, ce que chacune protège et pourquoi une entreprise en utilise souvent plusieurs à la fois."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-020
### Survol de la propriété intellectuelle : brevets, marques de commerce, droits d'auteur et secrets commerciaux comparés

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Comparer les quatre grandes catégories de protection de la propriété intellectuelle.
- Nommer ce que chaque catégorie protège généralement.
- Expliquer pourquoi il est important de choisir le bon type de protection.

**2. Contenu principal**
Cette leçon présente un survol comparatif avant que les leçons 21 à 24 examinent chaque catégorie en profondeur. Un brevet protège généralement des inventions — des procédés, des machines ou des compositions de matières nouveaux, utiles et non évidents — pendant une période limitée, en échange de la divulgation publique de l'invention. Une marque de commerce protège généralement des signes distinctifs d'une marque — noms, logos, slogans — qui distinguent les biens ou les services d'une partie de ceux d'une autre. Un droit d'auteur protège généralement des œuvres originales créatives et écrites — livres, musique, code logiciel, œuvres d'art — contre la copie ou l'utilisation non autorisées. Un secret commercial protège généralement des renseignements d'affaires confidentiels (formules, procédés, listes de clients) par le secret lui-même, plutôt que par un enregistrement public.

Choisir le bon type de protection est important, parce que ces catégories ne sont pas interchangeables : essayer de protéger un nom de marque par le droit d'auteur, par exemple, serait généralement un mauvais choix, puisque le droit d'auteur protège l'expression créative, et non les signes distinctifs d'une marque, dont s'occupe précisément le droit des marques de commerce. Bien des entreprises utilisent plusieurs types de protection de la propriété intellectuelle en même temps pour différents aspects de leurs activités : une entreprise de logiciels peut breveter un procédé technique nouveau, enregistrer son nom comme marque de commerce, protéger par droit d'auteur sa documentation écrite et son code, et protéger ses algorithmes internes comme secrets commerciaux, tout ça en même temps.

**3. Exemple pratique**
En lançant un nouveau logiciel, une fondatrice travaille avec une avocate en propriété intellectuelle pour déterminer la protection appropriée à chaque aspect distinct de l'entreprise : enregistrer le nom et le logo du produit comme marques de commerce, protéger par droit d'auteur le code sous-jacent et la documentation d'utilisation, explorer si un procédé technique nouveau dans le logiciel pourrait être admissible à la protection par brevet, et garder certains algorithmes internes comme secrets commerciaux plutôt que de les divulguer publiquement dans une demande de brevet, à la suite d'un jugement d'affaires selon lequel le secret sert mieux la valeur concurrentielle de cet actif en particulier.

**4. Quiz de pratique**
1. Que protège généralement un brevet?
   a) Les noms de marque et les logos
   b) Les inventions nouvelles, utiles et non évidentes
   c) Uniquement les œuvres créatives et écrites
   d) Les renseignements confidentiels gardés secrets
2. Que protège généralement une marque de commerce?
   a) Les inventions
   b) Les signes distinctifs d'une marque qui distinguent les biens ou services d'une partie de ceux d'une autre
   c) Les formules confidentielles
   d) Uniquement les livres écrits
3. Vrai ou faux : Les quatre catégories de propriété intellectuelle sont interchangeables et protègent exactement les mêmes choses.
4. Pourquoi la fondatrice du logiciel a-t-elle utilisé plusieurs types de protection de la propriété intellectuelle en même temps?
   a) Une entreprise n'a jamais accès qu'à un seul type de protection
   b) Les différents aspects de l'entreprise (marque, code, procédés techniques, algorithmes) exigeaient chacun un type de protection différent et approprié
   c) La protection de la propriété intellectuelle est inutile pour les entreprises de logiciels
   d) Les marques de commerce protègent à elles seules tout ce dont une entreprise a besoin

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Les brevets protègent généralement les inventions nouvelles, utiles et non évidentes.
2. Les marques de commerce protègent généralement les signes distinctifs d'une marque qui distinguent les biens ou les services d'une partie de ceux d'une autre.
3. Ces quatre catégories protègent des types distincts de propriété intellectuelle et ne sont pas interchangeables.
4. Les différents aspects de l'entreprise de la fondatrice exigeaient chacun un type de protection de la propriété intellectuelle différent et bien adapté.

**7. Points clés à retenir**
- Les brevets, les marques de commerce, les droits d'auteur et les secrets commerciaux protègent chacun des catégories distinctes de propriété intellectuelle.
- Les brevets protègent les inventions; les marques de commerce, les signes distinctifs d'une marque; les droits d'auteur, les œuvres créatives; les secrets commerciaux, les renseignements confidentiels, par le secret.
- Ces catégories ne sont pas interchangeables, et choisir le mauvais type de protection crée un vrai décalage.
- Bien des entreprises utilisent plusieurs types de protection de la propriété intellectuelle en même temps pour différents aspects de leurs activités.
