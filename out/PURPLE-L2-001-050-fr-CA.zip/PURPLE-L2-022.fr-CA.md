---
id: PURPLE-L2-022
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 22
title: "Le droit d'auteur : protéger les œuvres créatives et écrites"
summary: "Comprends quand naît le droit d'auteur, ce qu'apporte l'enregistrement et pourquoi il protège l'expression précise d'une idée, et non l'idée elle-même."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-022
### Le droit d'auteur : protéger les œuvres créatives et écrites

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer quand la protection du droit d'auteur naît généralement.
- Nommer les avantages généraux de l'enregistrement officiel du droit d'auteur.
- Distinguer la protection du droit d'auteur de celle des brevets et des marques de commerce.

**2. Contenu principal**
Dans bien des juridictions, y compris aux États-Unis, la protection du droit d'auteur naît généralement automatiquement dès qu'une œuvre créative originale est fixée sur un support tangible (écrite, enregistrée, sauvegardée dans un fichier); aucun enregistrement n'est nécessaire pour que la protection existe techniquement. Par contre, l'enregistrement officiel auprès de l'organisme gouvernemental compétent (comme le Bureau américain du droit d'auteur) offre généralement d'importants avantages pratiques, notamment l'accès à certains types de recours d'exécution (comme des dommages-intérêts préétablis par la loi et le remboursement des honoraires d'avocat dans certaines juridictions) qui pourraient ne pas être offerts pour les œuvres non enregistrées, même si le droit d'auteur sous-jacent existait automatiquement dès la création.

Le droit d'auteur protège l'expression précise d'une idée (les mots, les images ou le code réels), et non l'idée sous-jacente elle-même, ce qui fait écho à la distinction de la leçon 20 : le domaine du droit d'auteur (l'expression créative) est vraiment différent de ce que protège un brevet (les inventions fonctionnelles) ou une marque de commerce (les signes distinctifs d'une marque). Quelqu'un peut donc écrire un livre entièrement original sur une idée ou un thème général semblable à celui d'un livre existant sans violer le droit d'auteur de ce livre, puisque l'idée sous-jacente n'est pas protégée, seulement son expression précise.

**3. Exemple pratique**
Après avoir écrit un roman original, une autrice détient techniquement un droit d'auteur automatique dès le moment où le manuscrit est terminé et sauvegardé, sans enregistrement nécessaire. Son éditeur lui recommande quand même d'enregistrer officiellement le droit d'auteur avant la publication, puisque l'enregistrement lui donnerait accès à des recours d'exécution plus forts si son expression écrite précise était un jour violée par quelqu'un qui copierait son texte réel — contrairement à un autre auteur qui écrirait un roman différent explorant un thème ou un genre largement semblable, ce qui ne violerait pas du tout son droit d'auteur, puisque le droit d'auteur protège son expression précise, et non l'idée générale sous-jacente.

**4. Quiz de pratique**
1. Dans bien des juridictions, y compris aux États-Unis, quand la protection du droit d'auteur naît-elle généralement?
   a) Seulement après un enregistrement gouvernemental officiel
   b) Automatiquement, dès qu'une œuvre originale est fixée sur un support tangible
   c) Seulement après la publication commerciale de l'œuvre
   d) La protection du droit d'auteur n'existe automatiquement nulle part
2. Que protège généralement le droit d'auteur?
   a) L'idée générale sous-jacente elle-même
   b) L'expression précise d'une idée, comme les mots, les images ou le code réels
   c) Les noms de marque et les logos
   d) Les inventions fonctionnelles
3. Vrai ou faux : Quelqu'un qui écrit un livre original sur un thème général semblable à celui d'un livre existant viole toujours le droit d'auteur de ce livre.
4. Pourquoi l'éditeur de l'autrice a-t-il recommandé un enregistrement officiel du droit d'auteur, même si la protection existait déjà automatiquement?
   a) L'enregistrement était complètement inutile
   b) L'enregistrement lui donnerait accès à des recours d'exécution plus forts si son expression précise était violée
   c) La protection automatique du droit d'auteur n'existe pas vraiment
   d) L'enregistrement lui accorderait plutôt un brevet

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La protection du droit d'auteur naît généralement automatiquement dès qu'une œuvre originale est fixée sur un support tangible.
2. Le droit d'auteur protège l'expression précise d'une idée, et non l'idée générale sous-jacente elle-même.
3. Le droit d'auteur protège l'expression précise, et non les idées ou les thèmes généraux; un thème semblable ne constitue donc pas à lui seul une violation.
4. L'enregistrement officiel donne accès à des recours d'exécution plus forts, même si le droit d'auteur sous-jacent existait automatiquement.

**7. Points clés à retenir**
- La protection du droit d'auteur naît généralement automatiquement quand une œuvre originale est fixée sur un support tangible.
- L'enregistrement officiel offre d'importants avantages pratiques, notamment l'accès à des recours d'exécution plus forts.
- Le droit d'auteur protège l'expression précise, et non l'idée générale sous-jacente, ce qui le distingue des brevets et des marques de commerce.
- Comprendre cette distinction entre l'expression et l'idée permet de voir ce que le droit d'auteur peut empêcher les autres de faire, et ce qu'il ne peut pas empêcher.
