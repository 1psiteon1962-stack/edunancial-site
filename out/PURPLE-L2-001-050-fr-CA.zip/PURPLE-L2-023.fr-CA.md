---
id: PURPLE-L2-023
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 23
title: "Les brevets : protéger les inventions"
summary: "Comprends les exigences générales d'un brevet, son compromis entre protection et divulgation publique, et pourquoi il exige l'aide d'un spécialiste."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-023
### Les brevets : protéger les inventions

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer les exigences générales de la protection par brevet.
- Décrire le compromis général des brevets : une protection en échange d'une divulgation.
- Reconnaître que l'obtention d'un brevet exige une expertise juridique spécialisée.

**2. Contenu principal**
Dans la suite du survol de la leçon 20, un brevet protège généralement une invention qui est nouvelle (qui n'était pas déjà connue ou utilisée publiquement), utile (qui a une application pratique) et non évidente (qui n'aurait pas été une étape suivante évidente pour une personne compétente dans le domaine), pendant une période limitée fixée par la loi de la juridiction applicable. En échange de cette exclusivité limitée dans le temps et juridiquement exécutoire, le demandeur doit divulguer publiquement les détails de l'invention dans sa demande de brevet et, une fois le brevet accordé, dans le brevet publié. Une fois la période de protection du brevet terminée, l'invention tombe dans le domaine public et tout le monde peut l'utiliser.

Ça crée un compromis stratégique distinct par rapport à la protection par secret commercial (leçon 24) : un brevet offre une exclusivité forte et juridiquement exécutoire, mais exige une divulgation publique et finit par expirer, alors qu'un secret commercial peut, en théorie, durer indéfiniment, mais ne reste protégé que tant que l'information reste vraiment secrète, sans aucune protection si un concurrent découvre le secret de façon indépendante ou le reproduit par ingénierie inverse. Vu la complexité technique et juridique des demandes de brevet, c'est un domaine qui exige un avocat ou un agent de brevets spécialisé, et non un processus à faire soi-même.

**3. Exemple pratique**
Après avoir mis au point un procédé de fabrication vraiment nouveau, une propriétaire d'entreprise travaille avec un avocat en brevets pour évaluer s'il vaut mieux demander un brevet (une protection forte et exécutoire, avec une divulgation publique et une expiration éventuelle) ou garder le procédé comme secret commercial (une protection possiblement indéfinie, mais seulement tant que le procédé reste vraiment non divulgué et que les concurrents ne peuvent pas le reproduire en examinant le produit fini). Comme son procédé pourrait possiblement être reproduit par un concurrent assez déterminé qui examinerait ses produits, elle et son avocat décident finalement que demander un brevet, malgré son expiration éventuelle, offre une protection plus fiable et plus exécutoire pour sa situation précise que de compter seulement sur le secret.

**4. Quiz de pratique**
1. Pour être admissible à la protection par brevet, qu'est-ce qu'une invention doit généralement être?
   a) Ancienne, inutile et évidente
   b) Nouvelle, utile et non évidente
   c) Seulement nouvelle, sans autre exigence
   d) Gardée entièrement secrète, sans aucune divulgation
2. Que doit généralement faire un demandeur de brevet en échange de la protection par brevet?
   a) Rien — aucune divulgation n'est exigée
   b) Divulguer publiquement les détails de l'invention dans sa demande de brevet
   c) Garder l'invention secrète pour toujours
   d) Transférer la propriété au gouvernement
3. Vrai ou faux : La protection par brevet dure indéfiniment, sans jamais de date d'expiration.
4. Pourquoi la propriétaire d'entreprise a-t-elle choisi la protection par brevet plutôt que par secret commercial pour son procédé de fabrication?
   a) Les secrets commerciaux offrent toujours une protection plus forte
   b) Son procédé pouvait possiblement être reproduit par ingénierie inverse, ce qui rendait le brevet plus fiable malgré son expiration éventuelle
   c) Les brevets n'expirent jamais
   d) Elle n'avait aucune inquiétude au sujet de l'ingénierie inverse

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La protection par brevet exige généralement qu'une invention soit nouvelle, utile et non évidente.
2. Les demandeurs de brevet doivent divulguer publiquement les détails de l'invention en échange de l'exclusivité obtenue.
3. La protection par brevet est limitée dans le temps et finit par expirer; l'invention tombe alors dans le domaine public.
4. Le risque d'ingénierie inverse rendait le caractère exécutoire du brevet plus précieux que la protection indéfinie, mais fragile, du secret commercial.

**7. Points clés à retenir**
- La protection par brevet exige qu'une invention soit nouvelle, utile et non évidente.
- Les brevets offrent une protection forte, exécutoire, mais limitée dans le temps, en échange d'une divulgation publique.
- Ça crée un compromis stratégique avec la protection par secret commercial, qui peut être indéfinie, mais seulement tant que le secret est vraiment gardé.
- Les demandes de brevet exigent une expertise juridique spécialisée, vu leur complexité technique et juridique.
