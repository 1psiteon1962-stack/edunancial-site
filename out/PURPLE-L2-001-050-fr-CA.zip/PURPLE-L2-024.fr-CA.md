---
id: PURPLE-L2-024
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 24
title: "Les secrets commerciaux : une protection par le secret, pas par l'enregistrement"
summary: "Comprends ce qu'est un secret commercial, les mesures raisonnables qu'une entreprise doit prendre pour le protéger et comment il se compare au brevet."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-024
### Les secrets commerciaux : une protection par le secret, pas par l'enregistrement

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle la protection des secrets commerciaux.
- Expliquer ce qu'une entreprise doit faire pour maintenir la protection d'un secret commercial.
- Comparer les secrets commerciaux aux brevets, pour compléter la comparaison de la leçon 23.

**2. Contenu principal**
Pour compléter la comparaison commencée à la leçon 23, un secret commercial est un renseignement d'affaires confidentiel — formules, procédés, listes de clients ou autres renseignements — qui tire sa valeur économique du fait qu'il n'est pas généralement connu, et que l'entreprise prend des mesures raisonnables pour garder secret. Contrairement aux brevets, aux marques de commerce et aux droits d'auteur, la protection des secrets commerciaux ne passe par aucun processus d'enregistrement gouvernemental; la protection existe tant que le renseignement reste vraiment et raisonnablement protégé comme secret.

Maintenir la protection d'un secret commercial exige généralement des mesures de sécurité raisonnables et démontrables : limiter l'accès aux personnes qui en ont vraiment besoin, utiliser des ententes de confidentialité (en écho à la discussion sur les ententes de confidentialité de la leçon 8 et de BLUE-L2-029) avec les employés et les partenaires qui y ont accès, et mettre en place des mesures de sécurité physiques ou numériques adaptées à la sensibilité du renseignement. Si une entreprise ne prend pas de mesures de protection raisonnables, elle risque de perdre complètement la protection de son secret commercial, même si l'acquisition du renseignement par un concurrent était elle-même irrégulière, puisque les tribunaux s'attendent généralement à ce que le détenteur du secret ait pris de vraies mesures pour protéger ce qu'il prétend être confidentiel.

**3. Exemple pratique**
Une entreprise alimentaire traite sa recette vedette comme un secret commercial et prend des moyens réels et démontrables pour la protéger : elle limite la connaissance de la recette complète à un petit nombre d'employés, exige que ces employés signent des ententes de confidentialité précises et utilise des mesures de sécurité physiques pour protéger les documents écrits de la formule. Cet effort de protection réfléchi et raisonnable appuierait la capacité de l'entreprise à revendiquer la protection du secret commercial et à exercer des recours juridiques si un employé qui part divulguait la recette de façon irrégulière — une protection qui serait probablement affaiblie si l'entreprise avait plutôt traité la recette à la légère, avec un accès interne large et sans restriction, et sans ententes de confidentialité.

**4. Quiz de pratique**
1. Contrairement aux brevets ou aux marques de commerce, qu'est-ce qui est nécessaire pour qu'une entreprise obtienne la protection d'un secret commercial?
   a) Un enregistrement gouvernemental officiel
   b) Aucun enregistrement; la protection dépend du maintien d'un vrai secret grâce à des mesures raisonnables
   c) La divulgation publique du renseignement
   d) Une période d'attente minimale de dix ans
2. Quel risque court une entreprise si elle ne prend pas de mesures raisonnables pour protéger un renseignement confidentiel?
   a) Aucun risque
   b) Elle risque de perdre complètement la protection du secret commercial, même si l'acquisition par un concurrent était irrégulière
   c) Elle obtient plutôt une protection par brevet automatique
   d) Une divulgation publique obligatoire
3. Vrai ou faux : La protection d'un secret commercial exige le dépôt d'une demande auprès d'un office gouvernemental des brevets ou des marques de commerce.
4. Pourquoi les mesures de protection de l'entreprise alimentaire comptaient-elles pour sa revendication de secret commercial?
   a) Elles n'avaient aucune importance juridique
   b) Des mesures de protection réelles et raisonnables appuient la capacité de l'entreprise à revendiquer et à faire respecter la protection du secret commercial
   c) Les secrets commerciaux sont protégés peu importe les mesures prises
   d) Les mesures n'étaient que pour la forme, sans importance juridique

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La protection d'un secret commercial n'exige aucun enregistrement; elle dépend du maintien d'un vrai secret grâce à des mesures de protection raisonnables.
2. Ne pas prendre de mesures de protection raisonnables fait courir le risque de perdre complètement la protection du secret commercial, peu importe comment un concurrent a obtenu le renseignement.
3. Contrairement aux brevets, aux marques de commerce et aux droits d'auteur, les secrets commerciaux ne passent par aucun processus d'enregistrement gouvernemental.
4. Les mesures de protection démontrables et raisonnables de l'entreprise alimentaire appuyaient sa capacité à revendiquer et à faire respecter la protection de son secret commercial.

**7. Points clés à retenir**
- La protection d'un secret commercial n'exige aucun enregistrement et existe tant que le renseignement reste vraiment et raisonnablement protégé comme secret.
- Maintenir la protection exige des mesures démontrables : accès limité, ententes de confidentialité et sécurité appropriée.
- Ne pas prendre de mesures de protection raisonnables fait courir le risque de perdre complètement la protection du secret commercial.
- Ça complète la comparaison de la leçon 23 : les brevets offrent une protection exécutoire, mais limitée dans le temps, avec divulgation; les secrets commerciaux, une protection possiblement indéfinie, mais fragile, par le secret.
