---
id: PURPLE-L2-025
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 25
title: "Les accords de licence : accorder des droits sans vendre la propriété"
summary: "Comprends ce qu'est un accord de licence, en quoi il diffère d'une vente ou d'une cession de propriété intellectuelle, et comment ses conditions changent sa valeur."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-025
### Les accords de licence : accorder des droits sans vendre la propriété

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle un accord de licence.
- Distinguer une licence d'une vente pure et simple ou d'une cession de propriété intellectuelle.
- Relier cette notion à la discussion sur le franchisage et les licences de BLUE-L2-038.

**2. Contenu principal**
Dans la suite de la présentation des licences comme modèle de croissance dans BLUE-L2-038, cette leçon examine l'accord de licence lui-même comme instrument juridique. Un accord de licence accorde à une autre partie des droits précis et définis d'utiliser une propriété intellectuelle (une marque de commerce, un brevet, un droit d'auteur ou un secret commercial selon des conditions de confidentialité appropriées) sans transférer la pleine propriété de cette propriété intellectuelle. Le concédant garde la propriété, alors que le titulaire de la licence reçoit la permission de l'utiliser selon les conditions, la portée et la durée précises définies dans l'accord.

C'est différent d'une vente pure et simple ou d'une « cession » de propriété intellectuelle, qui transfère complètement la propriété à la nouvelle partie et laisse le propriétaire d'origine sans autres droits. Les accords de licence peuvent être exclusifs (seul le titulaire précis peut utiliser la propriété intellectuelle dans la portée définie) ou non exclusifs (le concédant peut accorder des droits semblables à plusieurs parties en même temps), et ils peuvent être limités par la région, le domaine d'utilisation ou la durée — chacune de ces conditions ayant un effet important sur la valeur et la pertinence de l'arrangement pour les deux parties.

**3. Exemple pratique**
Au lieu de vendre purement et simplement sa technologie brevetée, une inventrice la concède sous licence à une entreprise de fabrication : elle lui accorde le droit exclusif de fabriquer et de vendre des produits qui utilisent son procédé breveté dans un secteur et une région précis, en échange de redevances continues, tout en gardant la propriété du brevet lui-même. Elle reste libre de concéder la même technologie sous licence à d'autres entreprises dans d'autres secteurs ou régions non visés par cet accord exclusif précis. Cette structure lui permet de tirer des revenus continus de son invention à travers plusieurs utilisations possibles, plutôt que de recevoir un seul paiement unique d'une vente pure et simple qui aurait transféré tous ses droits à un seul acheteur.

**4. Quiz de pratique**
1. Qu'accorde généralement un accord de licence?
   a) Le transfert de la pleine propriété de la propriété intellectuelle
   b) Des droits précis et définis d'utiliser une propriété intellectuelle, pendant que le concédant garde la propriété
   c) Aucun droit
   d) Un certificat d'enregistrement gouvernemental
2. En quoi une licence diffère-t-elle d'une vente pure et simple ou d'une cession de propriété intellectuelle?
   a) Elles sont identiques à tous points de vue
   b) Avec une licence, le concédant garde la propriété; une vente ou une cession transfère complètement la propriété
   c) Une vente laisse toujours la propriété au vendeur
   d) Une licence transfère toujours immédiatement la pleine propriété
3. Vrai ou faux : Tous les accords de licence sont automatiquement exclusifs et empêchent le concédant d'accorder des droits à une autre partie.
4. Pourquoi l'inventrice a-t-elle choisi de concéder sa technologie sous licence plutôt que de la vendre purement et simplement?
   a) Elle voulait transférer tous ses droits tout de suite pour un seul paiement
   b) Elle voulait garder la propriété et tirer des revenus continus de plusieurs accords de licence possibles
   c) Les accords de licence n'existent pas pour les brevets
   d) Elle ne voulait tirer aucun revenu de son invention

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Un accord de licence accorde des droits d'utilisation précis et définis, pendant que le concédant garde la propriété de la propriété intellectuelle.
2. Avec une licence, le concédant garde la propriété, contrairement à une vente ou à une cession, qui transfère complètement la propriété.
3. Les accords de licence peuvent être exclusifs ou non exclusifs, selon les conditions précises négociées.
4. L'approche de licence de l'inventrice lui a permis de garder la propriété et de conclure en même temps plusieurs arrangements qui génèrent des revenus.

**7. Points clés à retenir**
- Un accord de licence accorde des droits précis et définis d'utiliser une propriété intellectuelle, pendant que le concédant garde la propriété.
- C'est différent d'une vente pure et simple ou d'une cession, qui transfère complètement la propriété.
- Les licences peuvent être exclusives ou non exclusives, et limitées par la région, le domaine d'utilisation ou la durée.
- Cette leçon s'appuie directement sur la discussion sur les licences du parcours BLUE et examine plus en profondeur l'instrument juridique sous-jacent.
