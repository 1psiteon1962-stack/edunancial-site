---
id: PURPLE-L2-027
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 27
title: "Les clauses d'indemnisation : déplacer le risque entre les parties"
summary: "Comprends ce qu'est une clause d'indemnisation, en quoi elle diffère d'une renonciation de responsabilité et pourquoi elle mérite toujours une lecture attentive."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-027
### Les clauses d'indemnisation : déplacer le risque entre les parties

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle une clause d'indemnisation.
- Distinguer l'indemnisation d'une renonciation de responsabilité (leçon 26).
- Expliquer pourquoi les clauses d'indemnisation méritent un examen attentif dans tout contrat.

**2. Contenu principal**
Une clause d'indemnisation est une disposition contractuelle dans laquelle une partie accepte de compenser l'autre pour certaines pertes, certains dommages ou certaines réclamations, souvent y compris les réclamations présentées par des tiers (des personnes extérieures au contrat lui-même). C'est différent d'une renonciation de responsabilité (leçon 26), qui libère généralement une partie de sa responsabilité directe envers l'autre partie contractante; l'indemnisation déplace plutôt la responsabilité financière de certaines pertes ou réclamations entre les parties contractantes, souvent y compris des réclamations qu'un tiers pourrait présenter contre l'une d'elles.

Les clauses d'indemnisation peuvent être larges ou étroites, unilatérales (une seule partie indemnise l'autre) ou réciproques (les deux parties s'indemnisent mutuellement pour certaines catégories de réclamations), et elles peuvent déplacer le risque financier de façon importante d'une manière facile à manquer si on survole cette section qui semble dense (en écho à la liste de vérification de lecture de la leçon 5) au lieu de l'examiner attentivement. Une partie qui accepte une clause d'indemnisation large pourrait se retrouver financièrement responsable de réclamations qui dépassent beaucoup ce à quoi elle pourrait raisonnablement s'attendre; c'est pourquoi un examen attentif et, pour les contrats importants, l'avis d'un avocat sont particulièrement utiles pour ce type de clause précis.

**3. Exemple pratique**
En examinant un contrat avec un fournisseur, une propriétaire d'entreprise survole d'abord une clause d'indemnisation dense, en supposant que c'est du texte standard. En l'examinant de plus près avec son avocate, elle découvre que la clause obligerait son entreprise à indemniser le fournisseur pour un large éventail de réclamations de tiers, y compris certaines qui n'ont qu'un lien indirect avec la relation avec le fournisseur — une obligation beaucoup plus large que ce qu'elle avait supposé. Elle négocie une structure d'indemnisation plus étroite et plus réciproque avant de signer, en limitant précisément son exposition aux réclamations qui découlent vraiment des gestes de sa propre entreprise, au lieu d'accepter la formulation d'origine, unilatérale et trop large.

**4. Quiz de pratique**
1. Sur quoi porte généralement une clause d'indemnisation?
   a) La libération d'une partie de toute responsabilité envers l'autre partie contractante
   b) Le fait qu'une partie compense l'autre pour certaines pertes, certains dommages ou certaines réclamations, souvent y compris celles de tiers
   c) Un type de protection de la propriété intellectuelle
   d) Une exigence de déclaration fiscale gouvernementale
2. En quoi l'indemnisation diffère-t-elle généralement d'une renonciation de responsabilité?
   a) Ce sont des notions identiques
   b) L'indemnisation déplace la responsabilité financière de pertes ou de réclamations; une renonciation libère généralement de la responsabilité directe envers l'autre partie contractante
   c) Les renonciations ne s'appliquent qu'aux réclamations de tiers
   d) L'indemnisation n'a aucun lien avec le risque financier
3. Vrai ou faux : Les clauses d'indemnisation sont toujours du texte standard simple qui n'exige aucun examen attentif.
4. Pourquoi la propriétaire d'entreprise a-t-elle renégocié la clause d'indemnisation du contrat avec le fournisseur?
   a) Elle voulait une exposition plus large aux réclamations de tiers
   b) Un examen plus attentif a révélé une obligation beaucoup plus large que ce qu'elle avait supposé au départ
   c) Les clauses d'indemnisation n'ont aucun effet juridique réel
   d) Elle avait déjà accepté les conditions d'origine et ne pouvait plus les changer

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Les clauses d'indemnisation portent sur le fait qu'une partie compense l'autre pour certaines pertes ou réclamations, souvent y compris celles de tiers.
2. L'indemnisation déplace la responsabilité financière des pertes; une renonciation libère généralement de la responsabilité directe envers l'autre partie contractante.
3. Les clauses d'indemnisation peuvent comporter une exposition financière importante et facile à manquer; elles méritent un examen attentif, pas un simple survol.
4. L'examen attentif de la propriétaire d'entreprise a révélé une obligation plus large que prévu, ce qui l'a menée à une renégociation réussie.

**7. Points clés à retenir**
- Les clauses d'indemnisation déplacent la responsabilité financière de certaines pertes, certains dommages ou certaines réclamations, souvent y compris celles de tiers.
- C'est différent d'une renonciation de responsabilité, qui libère généralement de la responsabilité directe envers l'autre partie contractante.
- Les clauses d'indemnisation peuvent être larges ou étroites, unilatérales ou réciproques, ce qui change beaucoup l'exposition au risque financier.
- Un examen attentif de ce type de clause souvent survolé est essentiel, en écho à la liste de vérification de lecture de contrat de la leçon 5.
