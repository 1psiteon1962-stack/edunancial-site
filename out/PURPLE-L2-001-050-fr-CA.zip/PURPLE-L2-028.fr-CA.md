---
id: PURPLE-L2-028
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 28
title: "Arbitrage ou poursuite judiciaire : comparer les voies de règlement des différends"
summary: "Compare l'arbitrage et la poursuite devant les tribunaux, leurs compromis en matière de rapidité, de confidentialité et d'appel, et pourquoi une clause d'arbitrage mérite réflexion."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-028
### Arbitrage ou poursuite judiciaire : comparer les voies de règlement des différends

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Comparer de façon conceptuelle l'arbitrage et la poursuite judiciaire.
- Nommer les compromis généraux de chaque voie.
- Expliquer pourquoi bien des contrats comprennent une clause de règlement des différends qui précise une voie.

**2. Contenu principal**
Quand un litige juridique survient, les parties le règlent généralement par une poursuite judiciaire (une procédure devant un tribunal, généralement publique, qui suit des règles de procédure formelles et qui offre, dans bien des circonstances, le droit de porter une décision en appel devant un tribunal supérieur) ou par l'arbitrage (une procédure privée devant un ou plusieurs arbitres, généralement moins formelle sur le plan de la procédure, avec des délais de règlement plus courts, plus de confidentialité et, dans bien des circonstances, des motifs plus limités pour faire appel de la décision de l'arbitre).

Bien des contrats comprennent une clause précise de règlement des différends qui exige l'arbitrage plutôt que la poursuite judiciaire pour tout litige découlant du contrat. Ça reflète un compromis volontaire : l'arbitrage peut offrir un règlement plus rapide, plus confidentiel et parfois moins coûteux, mais les droits d'appel limités font qu'une partie est généralement plus solidement liée par la décision de l'arbitre, même si elle croit qu'elle est erronée, par rapport aux possibilités d'appel plus larges d'une poursuite judiciaire. Accepter ou non une clause d'arbitrage obligatoire pendant la négociation d'un contrat est une décision qui vaut la peine d'être prise de façon réfléchie, plutôt que d'accepter un texte standard sans comprendre ce vrai compromis.

**3. Exemple pratique**
En négociant un contrat important avec un fournisseur, une propriétaire d'entreprise remarque une clause d'arbitrage obligatoire qui exige que tout litige soit réglé par arbitrage privé plutôt que devant les tribunaux, avec une capacité très limitée de faire appel de la décision de l'arbitre. Reconnaissant le vrai compromis que ça représente — un règlement plus rapide et plus confidentiel en échange de droits d'appel réduits —, elle en discute précisément avec son avocate au lieu de l'accepter comme du texte standard de routine. Elle décide finalement que le compromis est acceptable pour cette relation en particulier, mais seulement après avoir compris ce qu'elle abandonnerait en échange des autres avantages de l'arbitrage.

**4. Quiz de pratique**
1. Par rapport à l'arbitrage, quelle est une caractéristique générale de la poursuite judiciaire?
   a) Elle est généralement privée et confidentielle
   b) Elle est généralement publique, suit des règles de procédure formelles et offre des droits d'appel plus larges
   c) Elle ne permet jamais aucun appel, peu importe les circonstances
   d) Elle est toujours plus rapide que l'arbitrage
2. Quel est un compromis général quand on accepte l'arbitrage obligatoire?
   a) Il n'y a aucun compromis
   b) Un règlement possiblement plus rapide et plus confidentiel en échange de droits d'appel plus limités
   c) L'arbitrage garantit toujours un résultat favorable
   d) La poursuite judiciaire et l'arbitrage sont identiques en pratique
3. Vrai ou faux : L'arbitrage et la poursuite judiciaire offrent des droits d'appel et un formalisme de procédure identiques.
4. Pourquoi la propriétaire d'entreprise a-t-elle discuté de la clause d'arbitrage obligatoire avec son avocate au lieu de l'accepter comme une routine?
   a) Elle voulait éviter de comprendre la clause
   b) Elle a reconnu un vrai compromis entre les avantages de l'arbitrage et ses droits d'appel limités, qui valait la peine d'être compris avant d'accepter
   c) Les clauses d'arbitrage n'ont aucun effet juridique réel
   d) Les conditions de règlement des différends du contrat ne l'intéressaient pas

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La poursuite judiciaire est généralement publique, suit des procédures formelles et offre des droits d'appel plus larges que l'arbitrage.
2. L'arbitrage obligatoire échange généralement un règlement plus rapide et plus confidentiel contre des droits d'appel plus limités.
3. L'arbitrage et la poursuite judiciaire diffèrent vraiment sur le plan du formalisme de la procédure, de la confidentialité et des droits d'appel.
4. L'examen réfléchi de la propriétaire d'entreprise reflétait une bonne pratique : comprendre un vrai compromis avant de l'accepter.

**7. Points clés à retenir**
- La poursuite judiciaire est généralement publique, formelle et offre des droits d'appel plus larges; l'arbitrage est généralement privé, plus rapide et plus limité en matière d'appel.
- Bien des contrats comprennent une clause de règlement des différends qui fait de l'arbitrage la voie obligatoire en cas de litige.
- Accepter l'arbitrage obligatoire implique un vrai compromis réfléchi, pas une simple formalité.
- Comprendre ce compromis avant de signer permet une négociation de contrat plus éclairée.
