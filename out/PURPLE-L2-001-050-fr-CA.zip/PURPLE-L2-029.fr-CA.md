---
id: PURPLE-L2-029
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 29
title: "La médiation : une autre façon de régler les différends"
summary: "Comprends le rôle d'un médiateur, en quoi la médiation diffère de l'arbitrage et de la poursuite judiciaire, et pourquoi elle aide souvent à préserver les relations."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-029
### La médiation : une autre façon de régler les différends

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle la médiation.
- Distinguer la médiation de l'arbitrage et de la poursuite judiciaire.
- Expliquer pourquoi on utilise souvent la médiation avant d'autres voies de règlement des différends ou en même temps.

**2. Contenu principal**
Dans la suite de la comparaison de la leçon 28, la médiation présente une troisième voie générale : un tiers neutre (le médiateur) facilite la communication et la négociation entre les parties en conflit, en les aidant à arriver elles-mêmes à une solution acceptable pour les deux, plutôt que d'imposer une décision qui lie les parties, comme le ferait un juge (poursuite judiciaire) ou un arbitre (arbitrage). La médiation ne lie généralement pas les parties tant qu'elles n'ont pas conclu et officialisé leur propre entente : le médiateur n'a aucun pouvoir d'imposer un résultat précis, seulement d'aider les parties à en trouver un elles-mêmes.

C'est pourquoi on utilise souvent la médiation avant une poursuite judiciaire ou un arbitrage, ou en même temps, parfois comme première étape obligatoire prévue dans la clause de règlement des différends d'un contrat, ou simplement comme une option moins coûteuse, plus rapide et moins conflictuelle que les parties peuvent choisir d'essayer avant de s'engager dans un processus plus formel et contraignant. La médiation peut mieux préserver les relations d'affaires ou personnelles qu'une poursuite judiciaire ou un arbitrage conflictuels, puisqu'elle met l'accent sur la résolution de problèmes en collaboration plutôt que sur une décision gagnant-perdant prise par un tiers.

**3. Exemple pratique**
Devant un litige contractuel avec un partenaire d'affaires de longue date, deux parties choisissent d'essayer la médiation avant de passer à l'arbitrage (que leur contrat prévoit comme prochaine étape obligatoire si la médiation échoue). En travaillant avec un médiateur neutre, elles arrivent à une solution acceptable pour les deux qui répond aux préoccupations de fond de chacune. Elles préservent ainsi leur relation d'affaires, qu'un arbitrage ou une poursuite plus conflictuels auraient pu abîmer, et évitent les coûts et le temps qu'aurait exigés un arbitrage formel.

**4. Quiz de pratique**
1. Que fait généralement un médiateur?
   a) Il impose aux parties une décision qui les lie
   b) Il facilite la communication et la négociation, en aidant les parties à trouver leur propre solution acceptable pour les deux
   c) Il agit comme juge dans une procédure judiciaire formelle
   d) Il n'a aucun rôle dans le processus de règlement des différends
2. Pourquoi pourrait-on utiliser la médiation avant l'arbitrage ou la poursuite judiciaire, ou en même temps?
   a) Elle n'a aucun avantage pratique
   b) Elle peut offrir une voie moins coûteuse, plus rapide et moins conflictuelle, et peut être une première étape contractuelle obligatoire
   c) La médiation est toujours obligatoire et ne peut pas être tentée volontairement
   d) Les résultats de la médiation lient toujours automatiquement les parties
3. Vrai ou faux : Un médiateur a le pouvoir d'imposer aux parties en conflit une solution précise qui les lie.
4. Pourquoi les partenaires d'affaires ont-ils choisi d'essayer la médiation avant de passer à l'arbitrage?
   a) Ils voulaient un processus conflictuel
   b) La médiation offrait une voie de collaboration qui pouvait préserver leur relation d'affaires et éviter les coûts et le temps de l'arbitrage
   c) Leur contrat interdisait toute forme de médiation
   d) Ils ne voulaient pas régler le litige

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Un médiateur facilite la communication et la négociation, en aidant les parties à trouver leur propre solution plutôt que de leur en imposer une.
2. La médiation peut offrir une voie moins coûteuse, plus rapide et moins conflictuelle, et elle est parfois une première étape contractuelle obligatoire.
3. La médiation ne lie généralement pas les parties, à moins qu'elles concluent et officialisent elles-mêmes une entente.
4. La nature collaborative de la médiation, qui préserve les relations, ainsi que les économies possibles de coûts et de temps, ont motivé le choix des partenaires.

**7. Points clés à retenir**
- La médiation fait intervenir un tiers neutre qui facilite la négociation, sans imposer de décision qui lie les parties.
- Elle se distingue de la poursuite judiciaire et de l'arbitrage, où un tiers impose une décision.
- On utilise souvent la médiation avant des processus plus formels ou en même temps, parfois comme première étape contractuelle obligatoire.
- La médiation peut mieux préserver les relations que les processus conflictuels, grâce à son approche collaborative.
