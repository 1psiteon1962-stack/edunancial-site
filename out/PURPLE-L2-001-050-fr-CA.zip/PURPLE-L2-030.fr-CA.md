---
id: PURPLE-L2-030
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 30
title: "Les petites créances : une voie juridique pratique pour les enjeux modestes"
summary: "Comprends le but de la cour des petites créances, en quoi elle diffère d'une poursuite ordinaire et pourquoi ses limites de montant varient selon l'endroit."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-030
### Les petites créances : une voie juridique pratique pour les enjeux modestes

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le but général et la structure de la cour des petites créances.
- Nommer les caractéristiques générales qui la distinguent d'une poursuite judiciaire ordinaire.
- Reconnaître que c'est une option propre à chaque juridiction, avec des limites de montant variables.

**2. Contenu principal**
La cour des petites créances (ou division des petites créances) est un processus judiciaire spécialisé et simplifié, conçu pour régler des litiges de valeur relativement modeste de façon plus rapide, moins formelle et moins coûteuse qu'une poursuite judiciaire ordinaire (leçon 28). Elle permet généralement aux parties de se représenter elles-mêmes sans avocat (et, dans certaines juridictions, elle limite ou décourage précisément la représentation par avocat pour garder le processus accessible et équilibré entre les parties). Les limites de montant qu'on peut réclamer aux petites créances varient beaucoup selon la juridiction; c'est donc un autre détail PROPRE À UNE RÉGION qu'il faut vérifier directement pour une situation précise.

Cette voie peut être une option pratique pour les litiges trop petits pour justifier raisonnablement le coût et la complexité d'une poursuite judiciaire ordinaire ou d'un arbitrage, comme un litige sur un dépôt de garantie, un désaccord contractuel plus petit ou des dommages mineurs à des biens — des situations où les mécanismes de règlement des différends vus aux leçons 28 et 29 pourraient être trop coûteux ou trop lents par rapport au montant réellement en jeu.

**3. Exemple pratique**
Après qu'un propriétaire a retenu de façon injustifiée une partie de son dépôt de garantie, une ancienne locataire examine ses options. Vu le montant relativement modeste en litige, une poursuite judiciaire ordinaire ou un arbitrage lui coûteraient probablement plus en temps et en frais juridiques possibles que le montant réellement en jeu. Elle dépose plutôt une demande aux petites créances de sa juridiction et se représente elle-même dans un processus simplifié et plus rapide, conçu précisément pour les litiges de cette taille, ce qui lui évite le coût disproportionné d'un processus juridique plus formel pour une réclamation relativement modeste.

**4. Quiz de pratique**
1. À quoi la cour des petites créances est-elle généralement destinée?
   a) Traiter les litiges juridiques les plus gros et les plus complexes
   b) Régler des litiges de valeur relativement modeste de façon plus rapide, moins formelle et moins coûteuse
   c) Remplacer complètement toutes les autres formes de règlement des différends
   d) Traiter seulement des affaires criminelles
2. Dans bien des juridictions, quelle est une caractéristique courante de la cour des petites créances?
   a) La représentation par avocat est toujours obligatoire
   b) Les parties peuvent généralement se représenter elles-mêmes, sans avocat
   c) Elle n'a aucune limite de montant pour les réclamations
   d) Elle prend plus de temps qu'une poursuite judiciaire ordinaire
3. Vrai ou faux : Les limites de montant de la cour des petites créances sont identiques dans toutes les juridictions.
4. Pourquoi l'ancienne locataire a-t-elle choisi les petites créances pour son litige sur le dépôt de garantie?
   a) Elle voulait le processus juridique le plus coûteux et le plus complexe possible
   b) Le montant relativement modeste en litige rendait un processus plus rapide et moins coûteux plus pratique qu'une poursuite ordinaire
   c) Les petites créances n'existent pas pour les litiges entre propriétaires et locataires
   d) Elle n'avait aucune réclamation valable

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La cour des petites créances est généralement conçue pour régler plus rapidement et à moindre coût des litiges de valeur relativement modeste.
2. Dans bien des juridictions, les parties peuvent généralement se représenter elles-mêmes aux petites créances, sans avocat.
3. Les limites de montant de la cour des petites créances varient beaucoup selon la juridiction.
4. Le montant modeste de la réclamation de la locataire faisait du processus plus rapide et moins coûteux des petites créances un choix pratique et proportionné.

**7. Points clés à retenir**
- La cour des petites créances règle des litiges de valeur relativement modeste de façon plus rapide, moins formelle et moins coûteuse qu'une poursuite ordinaire.
- Dans bien des juridictions, les parties peuvent généralement se représenter elles-mêmes, sans avoir besoin d'un avocat.
- Les limites de montant varient beaucoup selon la juridiction et doivent être vérifiées pour chaque situation.
- Cette voie convient aux litiges trop petits pour justifier raisonnablement le coût et la complexité d'une poursuite ordinaire ou d'un arbitrage.
