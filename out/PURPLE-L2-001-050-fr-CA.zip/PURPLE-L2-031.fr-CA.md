---
id: PURPLE-L2-031
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 31
title: "La prescription : pourquoi les délais juridiques comptent"
summary: "Comprends ce qu'est un délai de prescription, pourquoi il existe et pourquoi le manquer peut faire perdre une réclamation valable, d'où l'importance de consulter rapidement."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-031
### La prescription : pourquoi les délais juridiques comptent

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle le délai de prescription.
- Expliquer pourquoi ces délais existent et leur conséquence générale si on les manque.
- Reconnaître que les délais précis dépendent de la juridiction et du type de réclamation.

**2. Contenu principal**
Un délai de prescription (*statute of limitations*) est une règle de droit qui fixe une date limite pour déposer une réclamation juridique. Une fois ce délai passé, la réclamation devient généralement complètement irrecevable, peu importe son bien-fondé : une réclamation qui aurait pu être tout à fait valable et gagnable peut devenir complètement inexécutoire simplement parce que le délai de dépôt est passé. Ces délais existent pour plusieurs raisons d'intérêt public : encourager le règlement rapide des litiges pendant que les preuves et les souvenirs sont encore frais, et offrir une certitude et une fin éventuelles aux défendeurs possibles, qui pourraient autrement faire face à des réclamations indéfiniment.

Les délais de prescription précis varient beaucoup selon la juridiction et selon le type de réclamation (les litiges contractuels, les réclamations pour blessures et d'autres catégories ont souvent des délais différents, même dans une même juridiction), et le calcul du moment exact où le délai commence à courir peut lui-même être une question juridique qui dépend des faits dans certaines situations. C'est pourquoi il est important de consulter rapidement un avocat dès qu'on croit avoir une réclamation juridique, puisque retarder cette consultation fait courir le risque que la réclamation soit prescrite avant même d'avoir été déposée.

**3. Exemple pratique**
Croyant avoir une réclamation contractuelle valable contre un ancien partenaire d'affaires, une propriétaire d'entreprise attend plus d'un an avant de consulter un avocat, en essayant d'abord de régler le problème seule, de façon informelle. Quand elle consulte finalement un avocat, elle apprend que le délai de prescription de sa juridiction pour ce type de réclamation contractuelle était plus court qu'elle ne le pensait, et que sa fenêtre pour déposer sa réclamation est peut-être déjà fermée, ou dangereusement près de l'être — un risque qu'une consultation rapide au départ aurait permis de repérer et de gérer avant qu'elle risque de perdre complètement sa capacité de faire valoir sa réclamation.

**4. Quiz de pratique**
1. Qu'est-ce qu'un délai de prescription?
   a) Une règle qui garantit qu'une réclamation réussira toujours
   b) Une règle de droit qui fixe une date limite pour déposer une réclamation juridique
   c) Un type de clause contractuelle
   d) Une exigence de déclaration fiscale
2. Qu'arrive-t-il généralement si une réclamation est déposée après l'expiration du délai de prescription?
   a) Rien — les délais n'ont aucun effet réel
   b) La réclamation devient généralement complètement irrecevable, peu importe son bien-fondé
   c) Le délai est automatiquement prolongé indéfiniment
   d) La réclamation est automatiquement renforcée
3. Vrai ou faux : Les délais de prescription sont identiques pour tous les types de réclamations dans toutes les juridictions.
4. Pourquoi le retard de la propriétaire d'entreprise à consulter un avocat a-t-il créé un risque pour sa réclamation possible?
   a) Un retard ne crée jamais de risque pour une réclamation juridique
   b) Le délai de prescription de sa juridiction était peut-être déjà expiré ou dangereusement près de l'être pendant son retard
   c) Les délais de prescription ne s'appliquent pas aux litiges contractuels
   d) Elle avait un temps illimité pour déposer sa réclamation, peu importe le délai

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Un délai de prescription fixe une date limite pour déposer une réclamation juridique.
2. Manquer ce délai rend généralement la réclamation complètement irrecevable, peu importe son bien-fondé.
3. Les délais de prescription varient beaucoup selon la juridiction et le type de réclamation.
4. Le retard de la propriétaire d'entreprise faisait courir le risque que sa réclamation soit prescrite avant même qu'elle consulte un avocat pour comprendre le délai applicable.

**7. Points clés à retenir**
- Un délai de prescription fixe une date limite de dépôt; après ce délai, une réclamation devient généralement irrecevable, peu importe son bien-fondé.
- Ces délais encouragent le règlement rapide des litiges et offrent une certitude éventuelle aux défendeurs possibles.
- Les délais précis varient beaucoup selon la juridiction et le type de réclamation, et le calcul de leur point de départ peut lui-même être complexe.
- Consulter rapidement un avocat dès qu'on croit avoir une réclamation aide à éviter le risque qu'elle soit prescrite.
