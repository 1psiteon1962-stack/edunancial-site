---
id: PURPLE-L2-032
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 32
title: "Responsabilité civile délictuelle ou contrat : deux fondements juridiques différents"
summary: "Distingue les obligations qui viennent d'un contrat de celles qui viennent d'un devoir général envers les autres, et vois comment une même situation peut toucher les deux."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-032
### Responsabilité civile délictuelle ou contrat : deux fondements juridiques différents

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Distinguer de façon conceptuelle le droit de la responsabilité délictuelle (*tort law*) du droit des contrats.
- Expliquer la source générale de chaque type d'obligation juridique.
- Appliquer cette distinction à un scénario hypothétique qui touche les deux.

**2. Contenu principal**
Cette leçon présente la responsabilité délictuelle (appelée *tort* en common law, ou responsabilité extracontractuelle en droit civil québécois) comme un fondement juridique distinct du droit des contrats vu aux leçons 1 à 10. Une obligation contractuelle découle généralement d'une entente que les parties ont conclue volontairement (leçons 2 et 3) : les devoirs précis existent parce que les parties les ont acceptés. Un délit civil est une faute civile qui cause un préjudice à une autre personne; l'obligation juridique qui en découle (compenser le préjudice) ne vient d'aucune entente entre les parties, mais d'un devoir juridique général envers les autres, qu'il existe ou non une relation contractuelle entre eux.

Une même situation peut parfois donner lieu aux deux types de réclamations en même temps : un entrepreneur qui ne respecte pas un contrat de rénovation (une réclamation contractuelle, leçon 6) peut aussi avoir été négligent d'une façon qui a causé des dommages matériels au-delà de la portée du contrat (une réclamation délictuelle, leçon 33). Une personne demanderesse pourrait possiblement faire valoir les deux types de réclamations à partir de la même situation de base, même si ce sont les faits précis et le droit applicable qui déterminent les réclamations réellement possibles.

**3. Exemple pratique**
Un entrepreneur embauché pour rénover une cuisine ne termine pas les travaux prévus à la date convenue (une inexécution du contrat, leçon 6) et, séparément, cause par négligence une fuite d'eau qui endommage le plancher d'une partie de la maison complètement en dehors de la portée des travaux prévus au contrat (une réclamation délictuelle possible pour négligence, leçon 33). La réclamation contractuelle de la propriétaire porte sur le fait que l'entrepreneur n'a pas rempli les obligations de rénovation précises qu'il avait acceptées; la réclamation délictuelle possible porte sur son devoir général et distinct d'éviter de causer un préjudice par négligence, peu importe ce que disait le contrat de rénovation précis — deux fondements juridiques distincts qui peuvent découler de la même situation globale.

**4. Quiz de pratique**
1. Quelle est la source générale d'une obligation contractuelle?
   a) Un devoir juridique général envers tout le monde
   b) Une entente que les parties ont conclue volontairement
   c) Un règlement gouvernemental sans lien avec une entente
   d) Une loi criminelle
2. Qu'est-ce qu'un délit civil?
   a) Un type de contrat exécutoire
   b) Une faute civile qui cause un préjudice, dont l'obligation découle d'un devoir juridique général, et non d'une entente
   c) Un type de propriété intellectuelle
   d) Une déclaration fiscale gouvernementale
3. Vrai ou faux : Une même situation ne peut jamais donner lieu à la fois à une réclamation contractuelle et à une réclamation délictuelle.
4. Dans l'exemple pratique, qu'est-ce qui distinguait la réclamation contractuelle de la réclamation délictuelle possible?
   a) Elles étaient identiques à tous points de vue
   b) La réclamation contractuelle portait sur les obligations convenues précises; la réclamation délictuelle, sur un devoir général distinct d'éviter de causer un préjudice par négligence
   c) Seule la réclamation délictuelle avait un fondement juridique
   d) L'entrepreneur n'avait aucune obligation contractuelle

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une obligation contractuelle découle généralement de l'entente volontaire des parties.
2. Un délit civil est une faute civile qui cause un préjudice; l'obligation découle d'un devoir juridique général plutôt que d'une entente.
3. Une même situation peut possiblement donner lieu à la fois à des réclamations contractuelles et délictuelles, selon les faits précis.
4. La réclamation contractuelle et la réclamation délictuelle possible reposaient sur des fondements juridiques vraiment différents, découlant de la même situation globale.

**7. Points clés à retenir**
- Les obligations contractuelles découlent d'une entente volontaire; les obligations délictuelles, d'un devoir juridique général envers les autres.
- Une même situation peut possiblement donner lieu à la fois à des réclamations contractuelles et délictuelles.
- Distinguer ces fondements aide à clarifier quels devoirs juridiques et quels recours précis pourraient s'appliquer à une situation donnée.
- Cette distinction prépare la discussion sur la négligence de la leçon 33, qui examine la responsabilité délictuelle plus en profondeur.
