---
id: PURPLE-L2-033
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 33
title: "La négligence : les éléments de base d'une réclamation délictuelle"
summary: "Apprends les quatre éléments d'une réclamation pour négligence — devoir, manquement, lien de causalité et préjudice — et pourquoi ils doivent tous être présents."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-033
### La négligence : les éléments de base d'une réclamation délictuelle

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Nommer les éléments généraux d'une réclamation pour négligence.
- Expliquer comment chaque élément doit généralement être établi.
- Appliquer ces éléments à un scénario hypothétique.

**2. Contenu principal**
Dans la suite de la présentation de la responsabilité délictuelle de la leçon 32, la négligence est l'une des réclamations délictuelles les plus courantes. Elle exige généralement que la personne demanderesse établisse quatre éléments : le devoir (le défendeur avait un devoir juridique de diligence raisonnable envers elle), le manquement (le défendeur n'a pas respecté cette norme de diligence raisonnable), le lien de causalité (le manquement du défendeur a réellement causé le préjudice de la personne demanderesse) et le préjudice (la personne demanderesse a subi un préjudice réel, reconnu par la loi, en conséquence).

Chaque élément doit généralement être établi, et pas seulement un ou deux : un défendeur qui a manqué à un devoir de diligence, mais dont le manquement n'a causé aucun préjudice réel à la personne demanderesse, ne serait généralement pas responsable pour négligence, puisque les éléments du lien de causalité et du préjudice manqueraient, même si le devoir et le manquement étaient clairement présents. Ce cadre structuré à plusieurs éléments explique pourquoi les réclamations pour négligence exigent souvent une analyse attentive des faits et, au besoin, d'experts pour bien établir chaque pièce, plutôt que de s'appuyer sur une impression générale que « quelqu'un a fait quelque chose de mal ».

**3. Exemple pratique**
Le propriétaire d'un magasin ne nettoie pas un liquide renversé sur le plancher pendant une longue période, même s'il est au courant (ce qui pourrait établir le devoir et le manquement : un devoir de diligence raisonnable envers les clients, auquel il a manqué en ne s'occupant pas d'un danger connu). Si une cliente glisse ensuite sur le liquide et subit une vraie blessure qui exige des soins médicaux (ce qui établit le lien de causalité — le manquement a directement causé le préjudice — et le préjudice — un préjudice réel et reconnu par la loi), les quatre éléments de la négligence seraient probablement présents. Si, au contraire, aucun client n'avait jamais été blessé par le liquide, malgré le manquement du propriétaire à son devoir en le laissant là, aucune réclamation pour négligence ne réussirait généralement, puisque les éléments du lien de causalité et du préjudice manqueraient complètement.

**4. Quiz de pratique**
1. Quels sont les quatre éléments généraux d'une réclamation pour négligence?
   a) L'offre, l'acceptation, la contrepartie et l'intention
   b) Le devoir, le manquement, le lien de causalité et le préjudice
   c) Seulement le préjudice, sans autre exigence
   d) Seulement l'intention, sans autre exigence
2. Qu'arrive-t-il si un défendeur manque à un devoir de diligence, mais que son manquement ne cause aucun préjudice réel à la personne demanderesse?
   a) La responsabilité pour négligence s'applique automatiquement quand même
   b) Une réclamation pour négligence ne réussirait généralement pas, puisque les éléments du lien de causalité et du préjudice manqueraient
   c) L'élément du manquement devient sans importance
   d) Le devoir n'est plus exigé dans cette situation
3. Vrai ou faux : Établir un seul des quatre éléments de la négligence suffit généralement pour qu'une réclamation pour négligence réussisse.
4. Pourquoi le scénario de la cliente qui glisse établissait-il probablement les quatre éléments de la négligence?
   a) Seul le devoir était présent
   b) Le devoir connu du magasin, le manquement en laissant le danger et la blessure réelle de la cliente qui en a résulté établissaient ensemble les quatre éléments
   c) Aucun préjudice n'était survenu
   d) Les éléments n'ont aucun lien avec ce scénario

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Les quatre éléments généraux d'une réclamation pour négligence sont le devoir, le manquement, le lien de causalité et le préjudice.
2. Sans lien de causalité réel et sans préjudice qui en découle, une réclamation pour négligence ne réussit généralement pas, même si le devoir et le manquement sont présents.
3. Les quatre éléments doivent généralement être établis ensemble pour qu'une réclamation pour négligence réussisse.
4. Le danger connu du scénario (devoir et manquement), combiné à la blessure réelle de la cliente (lien de causalité et préjudice), établissait les quatre éléments.

**7. Points clés à retenir**
- La négligence exige généralement d'établir ensemble le devoir, le manquement, le lien de causalité et le préjudice.
- Les quatre éléments doivent généralement être présents; s'il en manque un seul, la réclamation échoue généralement.
- Ce cadre structuré exige une analyse attentive des faits, et non seulement une impression générale que quelque chose a mal tourné.
- Comprendre ces éléments aide à voir pourquoi certains comportements qui semblent négligents n'entraînent pas de responsabilité pour négligence quand aucun préjudice réel n'en a résulté.
