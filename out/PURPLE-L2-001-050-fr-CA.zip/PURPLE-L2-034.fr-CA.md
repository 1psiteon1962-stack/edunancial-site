---
id: PURPLE-L2-034
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 34
title: "Responsabilité stricte ou négligence : une comparaison"
summary: "Comprends la responsabilité stricte, en quoi elle diffère de la négligence et dans quels contextes, comme les produits défectueux, la loi l'applique."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-034
### Responsabilité stricte ou négligence : une comparaison

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle la responsabilité stricte.
- Comparer la responsabilité stricte à la négligence (leçon 33).
- Nommer les contextes généraux où la responsabilité stricte s'applique souvent.

**2. Contenu principal**
Dans la suite du cadre de la négligence de la leçon 33, la responsabilité stricte (ou responsabilité sans faute) représente une norme juridique différente : la responsabilité peut être imposée, que le défendeur ait fait preuve de diligence raisonnable ou non. La personne demanderesse n'a donc généralement pas à établir un manquement à un devoir de diligence (le deuxième élément de la leçon 33). Le simple fait d'exercer l'activité ou d'adopter le comportement précis que la loi soumet à la responsabilité stricte, combiné au préjudice qui en résulte, peut suffire pour engager la responsabilité, même si le défendeur a pris toutes les précautions raisonnables.

La responsabilité stricte s'applique souvent dans des contextes précis et définis, comme certaines réclamations liées à des produits défectueux (en écho aux thèmes de protection du consommateur de la leçon 37) et des activités considérées comme anormalement dangereuses, peu importe le soin pris (comme certaines utilisations d'explosifs). C'est un choix politique volontaire dans ces contextes précis : la loi fait porter le risque de préjudice à la partie qui exerce l'activité intrinsèquement risquée ou qui met en circulation le produit défectueux, plutôt que d'exiger de la personne blessée qu'elle prouve un manquement précis à la diligence raisonnable, ce qui peut être particulièrement difficile à établir dans ces contextes.

**3. Exemple pratique**
Un fabricant produit un article qui a un vrai défaut de conception et qui blesse un consommateur qui l'utilise comme prévu, même si le fabricant a suivi des procédures de fabrication et d'essai généralement raisonnables tout au long de la production. Selon les principes de responsabilité stricte du fait des produits qui s'appliquent dans bien des juridictions, le fabricant pourrait quand même être tenu responsable du préjudice qui en résulte, sans que le consommateur blessé ait besoin de prouver que le fabricant a été négligent au sens traditionnel (leçon 33). La simple existence du défaut et le préjudice qui en résulte peuvent suffire, dans ce contexte juridique précis, pour engager la responsabilité, ce qui reflète le choix politique de faire porter ce risque au fabricant plutôt qu'au consommateur.

**4. Quiz de pratique**
1. Contrairement à la négligence, qu'est-ce que la responsabilité stricte n'exige généralement pas de la personne demanderesse?
   a) Un quelconque préjudice
   b) Un manquement à un devoir de diligence raisonnable
   c) L'identité du défendeur
   d) Une réclamation juridique, quelle qu'elle soit
2. Dans quel type de contexte la responsabilité stricte s'applique-t-elle souvent?
   a) Seulement dans les litiges contractuels ordinaires
   b) Certaines réclamations liées à des produits défectueux et les activités anormalement dangereuses
   c) Tous les types de réclamations juridiques possibles, sans exception
   d) Seulement dans les litiges en emploi
3. Vrai ou faux : La responsabilité stricte exige que la personne demanderesse prouve que le défendeur n'a pas fait preuve de diligence raisonnable, exactement comme la négligence.
4. Pourquoi le fabricant pourrait-il être tenu responsable selon la responsabilité stricte du fait des produits, même s'il a suivi des procédures raisonnables?
   a) La responsabilité stricte n'exige aucune preuve de préjudice
   b) Le contexte juridique précis (un défaut de produit) n'exige pas de prouver une négligence au sens traditionnel
   c) Le fabricant a reconnu sa négligence
   d) Aucune responsabilité n'a réellement été établie

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La responsabilité stricte n'exige généralement pas que la personne demanderesse établisse un manquement à un devoir de diligence raisonnable.
2. La responsabilité stricte s'applique souvent dans des contextes comme certaines réclamations liées à des produits défectueux et les activités anormalement dangereuses.
3. La responsabilité stricte n'exige justement pas de prouver un manquement à la diligence raisonnable, contrairement à la négligence.
4. Le contexte précis de responsabilité stricte qui s'applique aux défauts de produits permettait d'engager la responsabilité sans exiger la preuve d'une négligence traditionnelle.

**7. Points clés à retenir**
- La responsabilité stricte peut engager la responsabilité, que la diligence raisonnable ait été exercée ou non, contrairement à la négligence.
- Cette norme s'applique souvent dans des contextes précis, comme les réclamations liées à des produits défectueux et les activités anormalement dangereuses.
- Ça reflète un choix politique volontaire de faire porter certains risques à des parties précises, plutôt que d'exiger la preuve d'un manque de diligence.
- Comparer la responsabilité stricte à la négligence permet de clarifier ces deux normes distinctes de responsabilité civile.
