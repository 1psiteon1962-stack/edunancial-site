---
id: PURPLE-L2-035
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 35
title: "La diffamation : écrite ou verbale"
summary: "Comprends ce qu'est la diffamation, la différence entre la diffamation écrite et verbale, et pourquoi la vérité et l'opinion clairement présentée jouent un rôle clé."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-035
### La diffamation : écrite ou verbale

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle la diffamation.
- Distinguer la diffamation écrite (*libel*) de la diffamation verbale (*slander*).
- Nommer les éléments et les moyens de défense généraux liés aux réclamations en diffamation.

**2. Contenu principal**
La diffamation est une fausse déclaration de fait communiquée à un tiers qui nuit à la réputation d'une autre personne. La diffamation écrite (*libel*) désigne généralement la diffamation sous une forme écrite ou autrement fixée (articles publiés, publications sur les réseaux sociaux, émissions enregistrées); la diffamation verbale (*slander*) désigne généralement la diffamation sous une forme orale et passagère. Cette distinction peut compter à certaines fins de procédure ou de dommages-intérêts, selon la juridiction, même si les deux relèvent de la notion plus large de diffamation.

Les réclamations en diffamation exigent généralement que la déclaration soit fausse (la vérité est généralement un moyen de défense complet, puisqu'une déclaration vraie, aussi dommageable soit-elle, n'est généralement pas diffamatoire) et qu'il s'agisse d'une déclaration de fait plutôt que d'une pure opinion (une opinion clairement présentée comme telle n'est généralement pas considérée comme diffamatoire, puisqu'on ne peut pas prouver qu'une opinion est objectivement vraie ou fausse de la même façon qu'une affirmation factuelle). Cette distinction entre le fait et l'opinion n'est pas toujours simple et peut elle-même être une question juridique qui dépend des faits, surtout pour les déclarations qui mélangent des affirmations factuelles et un langage d'évaluation.

**3. Exemple pratique**
Un ancien employé publie en ligne une déclaration écrite qui affirme faussement que son ancien employeur s'est livré à une conduite illégale précise, qui n'a jamais eu lieu — une réclamation possible en diffamation écrite, vu la fausse déclaration de fait communiquée sous forme écrite et publiée, et le tort causé à la réputation de l'employeur. Ça contraste avec la publication écrite d'une autre ancienne employée qui affirme : « À mon avis, cette entreprise était mal gérée » — une déclaration d'évaluation subjective généralement considérée comme une opinion plutôt que comme une fausse déclaration de fait, et donc généralement pas diffamatoire, même si les deux déclarations peuvent être aussi mal reçues par l'employeur.

**4. Quiz de pratique**
1. Quelle est la distinction générale entre la diffamation écrite et la diffamation verbale?
   a) Elles sont identiques à tous points de vue
   b) La diffamation écrite est généralement sous forme écrite ou fixée; la diffamation verbale, généralement sous forme orale et passagère
   c) La diffamation verbale ne s'applique qu'aux entreprises; la diffamation écrite, qu'aux particuliers
   d) La diffamation écrite est toujours plus grave que la diffamation verbale dans toutes les juridictions
2. Qu'est-ce qui est généralement un moyen de défense complet contre une réclamation en diffamation?
   a) L'ignorance de la loi
   b) La vérité — une déclaration vraie n'est généralement pas diffamatoire, aussi dommageable soit-elle
   c) Des difficultés financières
   d) Des excuses écrites après coup
3. Vrai ou faux : Une opinion clairement présentée est généralement traitée de la même façon qu'une fausse déclaration de fait en matière de diffamation.
4. Pourquoi la déclaration « entreprise mal gérée » n'était-elle probablement pas diffamatoire, contrairement à l'affirmation fausse de conduite illégale?
   a) Les deux déclarations étaient tout aussi diffamatoires
   b) La déclaration d'opinion était une évaluation subjective, et non une fausse déclaration de fait
   c) Les opinions sont toujours diffamatoires, peu importe leur contenu
   d) Aucune des deux déclarations n'avait d'importance juridique

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La diffamation écrite désigne généralement la diffamation sous forme écrite ou fixée; la diffamation verbale, la diffamation orale et passagère.
2. La vérité est généralement un moyen de défense complet contre une réclamation en diffamation, puisqu'une déclaration vraie n'est généralement pas diffamatoire.
3. Une opinion clairement présentée est généralement traitée différemment d'une fausse déclaration de fait en matière de diffamation.
4. La nature subjective et évaluative de la déclaration d'opinion la distinguait d'une affirmation factuelle fausse, susceptible d'être diffamatoire.

**7. Points clés à retenir**
- La diffamation est une fausse déclaration de fait communiquée à un tiers qui nuit à la réputation.
- La diffamation écrite désigne généralement la diffamation sous forme écrite ou fixée; la diffamation verbale, la diffamation orale et passagère.
- La vérité est généralement un moyen de défense complet, et une opinion clairement présentée n'est généralement pas considérée comme diffamatoire.
- Distinguer le fait de l'opinion peut, dans certaines situations, être une question juridique qui dépend des faits.
