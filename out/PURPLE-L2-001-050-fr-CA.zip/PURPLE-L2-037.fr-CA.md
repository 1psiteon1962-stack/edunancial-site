---
id: PURPLE-L2-037
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 37
title: "La protection du consommateur : un survol"
summary: "Comprends le but des lois sur la protection du consommateur, ce qu'elles couvrent et pourquoi les entreprises doivent en tenir compte dans leur marketing et leurs contrats."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-037
### La protection du consommateur : un survol

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Nommer les catégories générales du droit de la protection du consommateur.
- Expliquer le but d'intérêt public général derrière ces protections.
- Relier cette notion à la discussion sur les activités d'entreprise du parcours BLUE.

**2. Contenu principal**
Le droit de la protection du consommateur regroupe un ensemble de protections juridiques conçues pour corriger le déséquilibre général d'information et de pouvoir de négociation entre les entreprises et les consommateurs individuels. Il comprend notamment des protections contre les pratiques commerciales trompeuses ou déloyales, des exigences de divulgation claire de certaines conditions (comme les conditions de prêt, en écho aux discussions sur le financement de RED-L2), des garanties pour les produits défectueux et des protections précises dans certaines transactions de consommation à enjeux élevés.

Pour les entreprises (en écho au parcours BLUE), comprendre les principes généraux de protection du consommateur a une importance directe : les affirmations de marketing doivent généralement être vraies et justifiées (ce qui annonce la discussion sur le droit de la publicité de la leçon 41), certaines conditions contractuelles avec des consommateurs peuvent être examinées de plus près que des conditions semblables entre entreprises averties, et certains secteurs précis (prêt, santé, certains biens de consommation) font souvent face à des règlements supplémentaires de protection du consommateur propres à leur secteur, au-delà de ces principes généraux.

**3. Exemple pratique**
En révisant son matériel de marketing avant le lancement d'un produit, une propriétaire d'entreprise s'assure que ses affirmations sur les capacités du produit sont exactes et justifiées, en reconnaissant que le droit de la protection du consommateur interdit généralement les affirmations de marketing trompeuses ou non justifiées, même si aucune plainte de client n'a encore été reçue. Elle fait aussi examiner ses conditions contractuelles standards pour les consommateurs par une avocate qui connaît bien le droit de la protection du consommateur, en reconnaissant que des conditions acceptables dans un contrat entre entreprises averties pourraient être examinées de plus près dans un contexte de consommation, vu les dynamiques d'information et de pouvoir de négociation différentes.

**4. Quiz de pratique**
1. Quel déséquilibre général le droit de la protection du consommateur vise-t-il à corriger?
   a) Il n'existe aucun déséquilibre entre les entreprises et les consommateurs
   b) Le déséquilibre général d'information et de pouvoir de négociation entre les entreprises et les consommateurs individuels
   c) Les déséquilibres entre deux entreprises averties seulement
   d) Des déséquilibres sans aucun lien avec le marketing ou les contrats
2. Pourquoi cette leçon se rattache-t-elle à la discussion sur les entreprises du parcours BLUE?
   a) Elle n'a aucun lien avec les activités d'entreprise
   b) Les entreprises doivent comprendre les principes de protection du consommateur qui touchent les affirmations de marketing et les conditions des contrats avec les consommateurs
   c) Le droit de la protection du consommateur ne s'applique qu'aux organismes gouvernementaux
   d) Il ne s'applique qu'aux entreprises qui n'ont aucun consommateur
3. Vrai ou faux : Des conditions contractuelles acceptables entre deux entreprises averties sont toujours examinées de la même façon dans un contexte de consommation.
4. Pourquoi la propriétaire d'entreprise a-t-elle révisé ses affirmations de marketing et ses conditions de contrat pour les consommateurs avant le lancement?
   a) Le droit de la protection du consommateur n'a aucun lien avec le marketing ou les contrats
   b) Elle a reconnu que ces aspects font l'objet d'un examen précis en matière de protection du consommateur, différent du contexte entre entreprises
   c) Elle voulait faire des affirmations volontairement fausses
   d) Aucune révision n'était nécessaire à aucun moment

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Le droit de la protection du consommateur vise généralement à corriger le déséquilibre d'information et de pouvoir de négociation entre les entreprises et les consommateurs.
2. Ça se rattache directement au parcours BLUE, puisque les entreprises doivent gérer des pratiques de marketing et de contrat qui touchent les consommateurs.
3. Les conditions des contrats avec les consommateurs font souvent l'objet d'un examen plus attentif que des conditions semblables entre entreprises averties.
4. La révision proactive de la propriétaire d'entreprise reflétait une bonne pratique, vu l'examen particulier du marketing et des contrats de consommation en droit de la protection du consommateur.

**7. Points clés à retenir**
- Le droit de la protection du consommateur vise le déséquilibre d'information et de pouvoir de négociation entre les entreprises et les consommateurs.
- Les protections comprennent l'interdiction des pratiques trompeuses, des exigences de divulgation et des garanties.
- Ça se rattache directement au parcours BLUE, puisque les entreprises doivent appliquer ces principes dans leur marketing et leurs contrats.
- Les conditions des contrats de consommation font souvent l'objet d'un examen plus attentif que des conditions semblables entre entreprises averties.
