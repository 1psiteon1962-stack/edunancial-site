---
id: PURPLE-L2-038
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 38
title: "Conformité réglementaire ou droit des contrats : deux pressions juridiques différentes"
summary: "Distingue les obligations réglementaires imposées par l'État des obligations nées des contrats, et vois pourquoi respecter l'une ne règle pas automatiquement l'autre."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-038
### Conformité réglementaire ou droit des contrats : deux pressions juridiques différentes

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Distinguer les obligations de conformité réglementaire des obligations contractuelles.
- Expliquer pourquoi une entreprise peut faire face aux deux en même temps, ce qui exige des réponses différentes.
- Appliquer cette distinction à un scénario d'entreprise hypothétique.

**2. Contenu principal**
Cette leçon distingue deux pressions juridiques liées, mais différentes, auxquelles une entreprise fait face. La conformité réglementaire consiste à respecter les lois et les règlements imposés par des organismes gouvernementaux, qui s'appliquent généralement peu importe tout contrat ou toute entente précise : une entreprise doit respecter les règlements applicables, qu'elle ait ou non un contrat précis qui porte sur ce domaine réglementaire, et la non-conformité l'expose généralement à des mesures d'application gouvernementales, et pas seulement à la réclamation d'une partie privée. Les obligations du droit des contrats (leçons 1 à 10), au contraire, découlent des ententes précises qu'une entreprise conclut volontairement; elles sont généralement appliquées par une action en justice privée de l'autre partie contractante, et non par des mesures gouvernementales.

Une entreprise peut faire face aux deux en même temps dans des situations qui se chevauchent : un contrat avec un fournisseur peut préciser des normes de qualité (une obligation contractuelle, que l'autre partie contractante peut faire respecter), alors que des règlements gouvernementaux distincts peuvent exiger, de façon indépendante, certaines normes de sécurité pour le même produit (une obligation réglementaire, que l'État peut faire respecter). Respecter un type d'obligation ne satisfait pas automatiquement l'autre, et une entreprise doit suivre les deux catégories séparément.

**3. Exemple pratique**
Un fabricant d'aliments a un contrat avec un distributeur qui précise certaines normes de qualité et d'emballage (une obligation contractuelle), tout en étant soumis, séparément, à des règlements gouvernementaux sur la salubrité des aliments qui exigent des essais de sécurité et un étiquetage précis, peu importe ce que dit le contrat avec le distributeur (une obligation réglementaire). Le fabricant reconnaît qu'il s'agit de deux volets de conformité distincts qui exigent une attention séparée : respecter entièrement les normes de qualité du contrat avec le distributeur n'excuserait pas un manquement aux règlements gouvernementaux sur la salubrité des aliments, qui s'appliquent de façon indépendante, et vice versa. Il faut s'occuper des deux ensemble, sans les traiter comme interchangeables.

**4. Quiz de pratique**
1. Qu'est-ce qui déclenche généralement une obligation de conformité réglementaire, par opposition à une obligation contractuelle?
   a) Une entente volontaire précise entre deux parties privées
   b) Les lois et les règlements imposés par des organismes gouvernementaux, qui s'appliquent généralement peu importe tout contrat précis
   c) Rien — les obligations réglementaires et contractuelles sont identiques
   d) Seulement les obligations qu'une entreprise choisit d'accepter
2. Qui fait généralement respecter une obligation contractuelle, par opposition à une obligation réglementaire?
   a) Un organisme gouvernemental, dans tous les cas
   b) L'autre partie contractante, par une action en justice privée
   c) Personne — les contrats ne sont pas exécutoires
   d) Seulement les tribunaux criminels
3. Vrai ou faux : Respecter une norme de qualité contractuelle satisfait automatiquement toute exigence réglementaire gouvernementale distincte et applicable.
4. Pourquoi le fabricant d'aliments a-t-il traité son contrat avec le distributeur et les règlements gouvernementaux comme deux volets de conformité distincts?
   a) C'étaient des exigences identiques qui ne demandaient aucune attention séparée
   b) Respecter un type d'obligation ne satisfait pas automatiquement l'autre, ce qui exige une attention séparée aux deux
   c) Seul le contrat comptait; les règlements n'avaient aucune importance
   d) Seuls les règlements comptaient; le contrat n'avait aucune importance

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Les obligations de conformité réglementaire découlent des lois et règlements imposés par l'État, qui s'appliquent généralement peu importe tout contrat précis.
2. Les obligations contractuelles sont généralement appliquées par une action en justice privée de l'autre partie contractante, et non par des mesures gouvernementales.
3. Respecter une norme contractuelle ne satisfait pas automatiquement une exigence réglementaire distincte qui s'applique de façon indépendante.
4. Le fabricant a eu raison de reconnaître qu'il s'agissait d'obligations distinctes qui exigent une attention séparée et simultanée.

**7. Points clés à retenir**
- Les obligations de conformité réglementaire découlent de lois imposées par l'État et s'appliquent généralement peu importe tout contrat précis.
- Les obligations contractuelles découlent d'ententes volontaires et sont généralement appliquées par une action en justice privée.
- Une entreprise peut faire face aux deux en même temps dans des situations qui se chevauchent, ce qui exige un suivi et une attention séparés.
- Respecter un type d'obligation ne satisfait pas automatiquement l'autre.
