---
id: PURPLE-L2-039
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 39
title: "Le zonage et le droit de l'aménagement revisités (PURPLE rencontre RED)"
summary: "Revois le zonage du point de vue juridique comme une obligation réglementaire et comprends pourquoi un contrat d'achat valide ne garantit pas que ton usage prévu est permis."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-039
### Le zonage et le droit de l'aménagement revisités (PURPLE rencontre RED)

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Renforcer, du point de vue juridique de PURPLE, la discussion sur le zonage de RED-L2-023.
- Expliquer le zonage comme une application précise du droit réglementaire (leçon 38).
- Reconnaître qu'il s'agit d'un vrai pont entre les couleurs PURPLE et RED.

**2. Contenu principal**
Cette leçon revisite la discussion sur le zonage et les permis de RED-L2-023 explicitement à travers la lentille juridique PURPLE établie dans ce niveau, en particulier la distinction entre le réglementaire et le contractuel de la leçon 38. Le droit du zonage est un exemple clair de conformité réglementaire : il s'applique aux propriétés peu importe tout contrat ou toute entente privée entre des parties, il est appliqué par des mesures gouvernementales (amendes, correctifs obligatoires ou ordonnances juridiques) et il existe indépendamment de ce que peut préciser séparément un contrat d'achat ou un bail.

Ça veut dire qu'un contrat d'achat ou de location immobilier peut être tout à fait valide et exécutoire comme contrat, alors que l'usage prévu de la propriété par l'acheteur ou le locataire est quand même interdit, séparément et indépendamment, par les règlements de zonage — en écho au point central de la leçon 38 selon lequel respecter une catégorie juridique (la validité du contrat) ne satisfait pas l'autre (la conformité réglementaire). Un acheteur qui se fie uniquement aux conditions d'un contrat d'achat sans vérifier de façon indépendante la conformité au zonage de son usage prévu s'expose exactement au genre de risque réglementaire que ce niveau a examiné tout au long.

**3. Exemple pratique**
Une acheteuse signe un contrat d'achat tout à fait valide et exécutoire pour une propriété, dans l'intention d'y exploiter un type d'entreprise précis. Après la clôture, elle découvre que le zonage de la propriété ne permet pas l'usage commercial qu'elle prévoyait — une infraction au zonage complètement indépendante de la validité de son contrat, puisque l'obligation contractuelle du vendeur de transférer la propriété ne va pas jusqu'à garantir que son usage prévu respecte le droit du zonage, qui s'applique séparément. Ça illustre exactement pourquoi RED-L2-023 recommandait de vérifier le zonage avant l'achat : la validité du contrat et la conformité réglementaire sont de vrais volets juridiques distincts, exactement comme la leçon 38 l'a établi.

**4. Quiz de pratique**
1. Selon le cadre de cette leçon, quel type d'obligation juridique le droit du zonage représente-t-il?
   a) Une obligation purement contractuelle entre parties privées
   b) Une obligation de conformité réglementaire, appliquée par des mesures gouvernementales
   c) Ni contractuelle ni réglementaire
   d) Un type de protection de la propriété intellectuelle
2. Pourquoi le contrat d'achat valide de l'acheteuse ne l'a-t-il pas protégée contre l'infraction au zonage?
   a) Le contrat était invalide
   b) La validité du contrat et la conformité réglementaire sont des volets juridiques distincts; l'un ne satisfait pas l'autre
   c) Le droit du zonage n'existe pas vraiment
   d) Le vendeur était légalement tenu de garantir son usage prévu
3. Vrai ou faux : Un contrat d'achat valide et exécutoire assure automatiquement que l'usage prévu de l'acheteur respecte tous les règlements de zonage applicables.
4. Quel cadre d'une leçon précédente cette leçon applique-t-elle directement au contexte du zonage?
   a) Le survol de la propriété intellectuelle de la leçon 20
   b) La distinction entre le réglementaire et le contractuel de la leçon 38
   c) La comparaison entre l'arbitrage et la poursuite judiciaire de la leçon 28
   d) La discussion sur les testaments de la leçon 11

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Le droit du zonage est un exemple clair d'obligation de conformité réglementaire, appliquée par des mesures gouvernementales.
2. La validité du contrat et la conformité réglementaire sont des volets juridiques distincts, et respecter l'un ne satisfait pas l'autre.
3. La conformité au zonage est indépendante de la validité du contrat et doit être vérifiée séparément.
4. Cette leçon applique directement le cadre de la leçon 38 sur le réglementaire et le contractuel au contexte précis du zonage.

**7. Points clés à retenir**
- Le droit du zonage est un exemple clair de conformité réglementaire, qui s'applique indépendamment de tout contrat privé.
- Un contrat d'achat valide ne garantit pas que l'usage prévu de l'acheteur respecte le droit du zonage, qui s'applique séparément.
- Ça renforce la distinction de la leçon 38 entre les obligations contractuelles et réglementaires, appliquée à la discussion sur le zonage du parcours RED.
- C'est un vrai pont entre les couleurs, qui relie les cadres juridiques PURPLE à la pratique immobilière RED.
