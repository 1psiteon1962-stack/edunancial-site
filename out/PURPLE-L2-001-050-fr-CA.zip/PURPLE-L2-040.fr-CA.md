---
id: PURPLE-L2-040
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 40
title: "Le droit du travail et la constitution d'entreprise (PURPLE rencontre BLUE)"
summary: "Revois la constitution d'entité, l'embauche et la classification des travailleurs à travers les principes juridiques de ce niveau, et vois pourquoi ils s'appliquent à toutes les décisions d'affaires."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-040
### Le droit du travail et la constitution d'entreprise (PURPLE rencontre BLUE)

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Renforcer, du point de vue juridique de PURPLE, la discussion du parcours BLUE sur l'embauche et la conformité.
- Nommer les éléments juridiques qui touchent à la fois la constitution d'une entité et le droit du travail.
- Reconnaître qu'il s'agit d'un vrai pont entre les couleurs PURPLE et BLUE.

**2. Contenu principal**
Cette leçon revisite plusieurs fils du parcours BLUE — la constitution d'une entité (BLUE-L2-002 et 003), l'embauche (BLUE-L2-021 à 023) et la classification des travailleurs (BLUE-L2-023) — explicitement à travers les instruments et les cadres juridiques PURPLE développés dans ce niveau. Les documents de constitution d'une entité (le parallèle de la discussion sur le zonage de la leçon 39 s'applique aussi ici) sont eux-mêmes des instruments juridiques de base qui exigent les formalités vues aux leçons 2 et 11 : les notions d'offre, d'acceptation et de contrepartie guident les conventions de société et les conventions d'exploitation, alors que les exigences de forme rappellent les règles de constitution des testaments et des fiducies. Les relations d'emploi (la discussion sur l'emploi à volonté de la leçon 18) et la classification des travailleurs (en écho à BLUE-L2-023) comportent toutes les deux des obligations de conformité réglementaire (leçon 38) qui s'ajoutent à toute condition précise d'un contrat de travail.

Ce lien entre les couleurs renforce un thème qui traverse tout ce niveau : les instruments et les cadres juridiques ne sont pas limités à une seule fonction de l'entreprise. Les mêmes principes contractuels (leçons 2 à 7), la même distinction entre le réglementaire et le contractuel (leçon 38) et les mêmes thèmes d'encadrement professionnel (en écho au principe de BLUE-L2-031, « les affaires sont un sport d'équipe ») s'appliquent, que la décision d'affaires précise porte sur la constitution d'une entité, l'embauche d'un employé ou tout autre terrain juridique vu dans BLUE-L2.

**3. Exemple pratique**
En constituant sa LLC et en embauchant son premier employé la même année, une propriétaire d'entreprise reconnaît que les deux décisions exigent la même littératie juridique de base que ce niveau a bâtie : la convention d'exploitation de sa LLC est elle-même un contrat qui exige les mêmes principes de rédaction et d'examen attentifs que ceux des leçons 2 à 5, alors que sa nouvelle relation d'emploi comporte à la fois un contrat de travail possible (leçon 18) et des obligations de conformité réglementaire distinctes et indépendantes (en écho à la leçon 38) en matière de paie et de classification des travailleurs, qui existent peu importe ce que dit précisément son contrat de travail.

**4. Quiz de pratique**
1. Quels domaines du parcours BLUE cette leçon revisite-t-elle à travers la lentille juridique PURPLE?
   a) Seulement la stratégie de marketing
   b) La constitution d'une entité, l'embauche et la classification des travailleurs
   c) Seulement les décisions immobilières
   d) Seulement la philosophie de placement
2. Quel thème cette leçon entre les couleurs renforce-t-elle?
   a) Les instruments et cadres juridiques ne s'appliquent qu'à une seule fonction précise de l'entreprise
   b) Les mêmes principes juridiques de ce niveau s'appliquent à la constitution d'une entité, à l'embauche et à d'autres décisions d'affaires
   c) Les notions du parcours PURPLE n'ont aucun rapport avec les décisions d'affaires du parcours BLUE
   d) Les obligations réglementaires et contractuelles sont des notions identiques
3. Vrai ou faux : Cette leçon présente des notions juridiques entièrement nouvelles, sans lien avec le reste de PURPLE-L2 ni avec le parcours BLUE.
4. Qu'est-ce que la propriétaire d'entreprise a reconnu au sujet de la constitution de sa LLC et de son embauche?
   a) Elles exigeaient des principes juridiques sans aucun lien
   b) Les deux exigeaient la même littératie juridique de base — les principes contractuels et la distinction entre le réglementaire et le contractuel — bâtie dans ce niveau
   c) Aucune des deux décisions n'avait d'importance juridique
   d) Seule la décision d'embauche comportait des éléments juridiques

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Cette leçon revisite la constitution d'une entité, l'embauche et la classification des travailleurs du parcours BLUE.
2. Cette leçon renforce l'idée que les mêmes principes juridiques de ce niveau s'appliquent largement à différentes décisions d'affaires.
3. Cette leçon se rattache volontairement à des notions déjà vues dans PURPLE-L2 et dans le parcours BLUE.
4. La propriétaire d'entreprise a reconnu que sa décision de constitution et sa décision d'embauche s'appuyaient sur la même littératie juridique de base de ce niveau.

**7. Points clés à retenir**
- La constitution d'une entité, l'embauche et la classification des travailleurs s'appuient toutes sur les mêmes principes contractuels et réglementaires vus dans PURPLE-L2.
- Les conventions d'exploitation sont elles-mêmes des contrats qui exigent les mêmes principes de rédaction attentive que ceux des leçons 2 à 5.
- Les relations d'emploi comportent à la fois des conditions contractuelles et des obligations de conformité réglementaire qui s'appliquent séparément.
- C'est un vrai pont entre les couleurs, qui montre que la littératie juridique PURPLE s'applique largement aux décisions d'affaires du parcours BLUE.
