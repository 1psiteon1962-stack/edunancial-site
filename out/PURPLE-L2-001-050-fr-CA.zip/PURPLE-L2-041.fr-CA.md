---
id: PURPLE-L2-041
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 41
title: "Le droit de la publicité et la vérité en marketing (PURPLE rencontre ORANGE)"
summary: "Applique les principes de protection du consommateur à la publicité : affirmations vraies et justifiées, règles plus strictes pour la publicité comparative et rôle de l'examen juridique."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-041
### Le droit de la publicité et la vérité en marketing (PURPLE rencontre ORANGE)

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Renforcer les notions de protection du consommateur (leçon 37) appliquées précisément à la publicité.
- Nommer les exigences générales pour des affirmations de marketing vraies et justifiées.
- Reconnaître qu'il s'agit d'un vrai pont entre les couleurs PURPLE et ORANGE.

**2. Contenu principal**
En s'appuyant directement sur le survol de la protection du consommateur de la leçon 37, cette leçon applique ces principes précisément à la publicité et au marketing (le parcours ORANGE). Les exigences générales dans bien des juridictions comprennent que les affirmations publicitaires doivent généralement être vraies et non trompeuses, et que les affirmations de nature factuelle (comme des affirmations précises de performance ou de santé) doivent généralement être justifiées par des preuves suffisantes avant d'être faites, et non simplement affirmées en espérant qu'elles soient vraies. Certaines catégories d'affirmations — la publicité comparative qui nomme des concurrents, les témoignages et les recommandations, et les affirmations dans des secteurs très réglementés (santé, services financiers) — font souvent face à des exigences réglementaires supplémentaires et précises, au-delà de ces principes généraux.

Ça fait directement écho à la distinction entre le réglementaire et le contractuel de la leçon 38 : les règlements sur la publicité s'appliquent peu importe ce que dit un contrat précis avec un client, et les affirmations de marketing d'une entreprise sont soumises de façon indépendante à des mesures d'application gouvernementales (et parfois à des réclamations privées de consommateurs) si elles sont jugées trompeuses, peu importe les conditions réelles du contrat de vente de l'entreprise avec un client précis.

**3. Exemple pratique**
Avant de lancer une campagne de marketing qui fait des affirmations précises sur la performance de son produit, une propriétaire d'entreprise s'assure d'avoir une justification suffisante — de vrais essais ou de vraies données qui appuient les affirmations précises — plutôt que de faire des affirmations fondées sur des suppositions optimistes ou seulement sur des commentaires anecdotiques de clients. Elle fait aussi examiner par son avocate une publicité comparative prévue qui nomme un concurrent précis, en reconnaissant que les affirmations comparatives qui nomment des concurrents font souvent l'objet d'un examen plus strict et d'exigences juridiques précises, au-delà de la norme générale de vérité qui s'applique à la publicité en général.

**4. Quiz de pratique**
1. Qu'est-ce que les affirmations publicitaires de nature factuelle doivent généralement avoir avant d'être faites?
   a) Aucune exigence
   b) Une justification suffisante, et non de simples suppositions optimistes
   c) Une approbation gouvernementale préalable dans tous les cas
   d) Le consentement écrit préalable d'un client
2. Quel type d'affirmation publicitaire fait souvent face à des exigences réglementaires supplémentaires et précises?
   a) Aucun — toutes les affirmations sont traitées de la même façon
   b) La publicité comparative qui nomme des concurrents, les témoignages et les affirmations dans des secteurs réglementés
   c) Seulement les affirmations sur la météo
   d) Seulement les affirmations faites dans des documents privés non publiés
3. Vrai ou faux : Les affirmations de marketing d'une entreprise ne sont examinées que si un contrat précis avec un client porte sur des conditions publicitaires.
4. Pourquoi la propriétaire d'entreprise a-t-elle fait examiner sa publicité comparative par son avocate avant de la lancer?
   a) Les affirmations comparatives qui nomment des concurrents ne comportent aucun élément juridique particulier
   b) La publicité comparative qui nomme des concurrents fait souvent l'objet d'un examen plus strict et d'exigences juridiques précises
   c) Elle voulait faire des affirmations non justifiées
   d) L'examen d'un avocat n'a jamais d'importance pour les décisions de marketing

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Les affirmations publicitaires factuelles exigent généralement une justification suffisante avant d'être faites.
2. La publicité comparative, les témoignages et les affirmations dans des secteurs réglementés font souvent face à des exigences réglementaires supplémentaires et précises.
3. Les règlements sur la publicité s'appliquent indépendamment de tout contrat précis avec un client, en écho à la distinction entre le réglementaire et le contractuel de la leçon 38.
4. L'examen plus strict des affirmations publicitaires comparatives justifiait l'examen attentif par une avocate avant le lancement.

**7. Points clés à retenir**
- Les affirmations publicitaires doivent généralement être vraies, non trompeuses et suffisamment justifiées si elles sont de nature factuelle.
- La publicité comparative, les témoignages et les affirmations dans les secteurs réglementés font souvent face à des exigences précises supplémentaires.
- Ça applique directement la distinction entre le réglementaire et le contractuel de la leçon 38 au marketing et à la publicité.
- C'est un vrai pont entre les couleurs, qui relie les principes de protection du consommateur PURPLE à la pratique du marketing ORANGE.
