---
id: PURPLE-L2-042
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 42
title: "Les bases de la gouvernance d'entreprise : règlements intérieurs, conseil et devoir fiduciaire"
summary: "Comprends ce qu'est la gouvernance d'entreprise, le rôle des règlements intérieurs et du conseil d'administration, et pourquoi une société par actions exige une structure plus formelle."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-042
### Les bases de la gouvernance d'entreprise : règlements intérieurs, conseil et devoir fiduciaire

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle la gouvernance d'entreprise.
- Nommer les rôles généraux des règlements intérieurs et d'un conseil d'administration.
- Avoir un aperçu de la notion de devoir fiduciaire approfondie à la leçon 43.

**2. Contenu principal**
La gouvernance d'entreprise désigne les structures et les processus par lesquels une société par actions (ou, avec des variations, d'autres types d'entités) est dirigée et contrôlée, en écho à la présentation de la société par actions comme structure d'entité plus formelle dans BLUE-L2-002. Les règlements intérieurs (*bylaws*) sont des documents de gouvernance interne qui établissent la façon dont la société fonctionnera — comment les administrateurs sont élus, comment les réunions se déroulent, et d'autres règles de procédure et de structure. Ils sont généralement exigés pour les sociétés par actions et adoptés au moment de la constitution ou peu après.

Un conseil d'administration supervise généralement les grandes décisions et la direction de la société, et a des devoirs fiduciaires (présentés ici, approfondis à la leçon 43) envers la société et ses actionnaires. Cette structure de gouvernance existe justement parce qu'une société par actions, en tant qu'entité juridique distincte, a besoin de mécanismes définis pour que des personnes prennent des décisions en son nom. Les règlements intérieurs et la supervision du conseil fournissent cette structure, distincte et plus formelle que les structures de gouvernance habituellement utilisées pour les entreprises individuelles ou les LLC plus simples.

**3. Exemple pratique**
En constituant une société par actions pour son entreprise en croissance, plutôt que de continuer comme LLC, une fondatrice travaille avec son avocate pour rédiger des règlements intérieurs qui établissent comment son conseil d'administration sera élu, à quelle fréquence il se réunira, et quelles grandes décisions exigent l'approbation du conseil par rapport à celles qu'elle peut prendre seule comme dirigeante. Cette structure de gouvernance formelle, exigée pour sa société par actions, contraste avec la structure plus simple de convention d'exploitation que sa LLC utilisait auparavant, ce qui reflète la gouvernance plus formelle généralement attendue d'une société par actions.

**4. Quiz de pratique**
1. Dans un contexte de gouvernance d'entreprise, que sont les règlements intérieurs?
   a) Un type de déclaration fiscale
   b) Des documents de gouvernance interne qui établissent comment une société par actions fonctionnera
   c) Un type de protection de la propriété intellectuelle
   d) Un document de marketing
2. Que fait généralement un conseil d'administration?
   a) Rien d'important
   b) Il supervise les grandes décisions et la direction de la société, et a des devoirs fiduciaires envers la société et les actionnaires
   c) Il s'occupe seulement du service à la clientèle quotidien
   d) Il remplace le besoin de règlements intérieurs
3. Vrai ou faux : Les structures de gouvernance d'entreprise comme les règlements intérieurs et les conseils sont identiques aux structures de gouvernance habituellement utilisées pour les entreprises individuelles.
4. Pourquoi la fondatrice devait-elle rédiger des règlements intérieurs en constituant sa société par actions?
   a) Les règlements intérieurs sont facultatifs et inutiles pour les sociétés par actions
   b) Les règlements intérieurs établissent la structure de gouvernance formelle généralement exigée et attendue d'une société par actions
   c) La convention d'exploitation de sa LLC suffisait automatiquement pour sa nouvelle société
   d) Elle n'avait besoin d'aucune structure de gouvernance

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Les règlements intérieurs sont des documents de gouvernance interne qui établissent le fonctionnement d'une société par actions.
2. Un conseil d'administration supervise les grandes décisions et la direction, et a des devoirs fiduciaires envers la société et les actionnaires.
3. Les structures de gouvernance d'entreprise sont généralement plus formelles que celles des entreprises individuelles ou des types d'entités plus simples.
4. Constituer une société par actions exige généralement la structure de gouvernance plus formelle qu'établissent les règlements intérieurs.

**7. Points clés à retenir**
- La gouvernance d'entreprise désigne les structures et les processus qui dirigent et contrôlent une société par actions.
- Les règlements intérieurs sont des documents de gouvernance interne qui établissent des règles de fonctionnement et de procédure.
- Un conseil d'administration supervise les grandes décisions et a des devoirs fiduciaires envers la société et les actionnaires.
- Cette structure formelle est généralement exigée pour les sociétés par actions et est plus formelle que la gouvernance habituelle d'une entreprise individuelle ou d'une LLC simple.
