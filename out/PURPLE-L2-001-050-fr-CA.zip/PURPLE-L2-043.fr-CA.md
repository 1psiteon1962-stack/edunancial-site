---
id: PURPLE-L2-043
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 43
title: "Le devoir fiduciaire : ce qu'il veut dire et qui le doit"
summary: "Comprends ce qu'est un devoir fiduciaire, dans quelles relations il apparaît et ce que veulent dire le devoir de diligence et le devoir de loyauté."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-043
### Le devoir fiduciaire : ce qu'il veut dire et qui le doit

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle le devoir fiduciaire.
- Nommer les relations courantes où naît un devoir fiduciaire.
- Expliquer les composantes générales du devoir fiduciaire, comme le devoir de diligence et le devoir de loyauté.

**2. Contenu principal**
Dans la suite de la présentation de la leçon 42, un devoir fiduciaire est une obligation juridique renforcée qui exige qu'une partie (le fiduciaire) agisse dans le meilleur intérêt d'une autre partie (le bénéficiaire du devoir). Il naît généralement dans des relations qui comportent beaucoup de confiance, de dépendance ou de contrôle sur les intérêts d'une autre personne. Les relations courantes qui comportent des devoirs fiduciaires comprennent celles des administrateurs et des dirigeants envers leur société et ses actionnaires (leçon 42), des fiduciaires envers les bénéficiaires d'une fiducie (en écho à la discussion sur les fiducies de la leçon 12) et des avocats envers leurs clients.

Le devoir fiduciaire comprend généralement un devoir de diligence (agir avec la compétence et le soin qu'une personne raisonnablement prudente exercerait dans une situation semblable) et un devoir de loyauté (faire passer les intérêts du bénéficiaire avant ses propres intérêts personnels, en évitant les transactions intéressées et les conflits d'intérêts). Cette norme renforcée, qui va bien au-delà des obligations contractuelles ou délictuelles ordinaires, reflète la confiance et la dépendance importantes propres à ces relations précises.

**3. Exemple pratique**
Comme administrateur au conseil d'une société par actions, un homme d'affaires se voit offrir personnellement l'occasion d'acheter, à un prix intéressant, une propriété que la société elle-même pourrait raisonnablement vouloir acquérir pour ses propres activités. Reconnaissant son devoir fiduciaire de loyauté envers la société, il ne l'achète pas simplement pour lui-même sans d'abord divulguer l'occasion au conseil et permettre à la société de la saisir si elle est vraiment intéressée. Le devoir fiduciaire d'un administrateur interdit généralement de détourner une occasion d'affaires de la société à son profit personnel sans divulgation appropriée et, s'il y a lieu, sans que la société renonce à l'occasion.

**4. Quiz de pratique**
1. Qu'est-ce qu'un devoir fiduciaire?
   a) Une obligation contractuelle ordinaire, identique à tout autre contrat
   b) Une obligation juridique renforcée d'agir dans le meilleur intérêt d'une autre partie
   c) Un type de protection de la propriété intellectuelle
   d) Une exigence de déclaration fiscale gouvernementale
2. Qu'exige généralement le devoir de loyauté?
   a) Faire passer ses propres intérêts personnels avant tout
   b) Faire passer les intérêts du bénéficiaire avant ses propres intérêts personnels, en évitant les transactions intéressées
   c) Rien de précis
   d) Il ne s'applique qu'aux fiduciaires, jamais aux administrateurs de société
3. Vrai ou faux : Le devoir fiduciaire est identique à une obligation contractuelle ordinaire et n'en diffère en rien.
4. Pourquoi l'administrateur a-t-il divulgué l'occasion d'achat au conseil plutôt que d'acheter la propriété lui-même?
   a) Son devoir fiduciaire de loyauté lui interdisait généralement de détourner une occasion d'affaires de la société à son profit personnel sans divulgation appropriée
   b) Il n'avait aucun devoir fiduciaire
   c) La propriété n'avait aucune valeur pour la société
   d) La divulgation était purement facultative, sans importance juridique

**5. Corrigé**
1. b  2. b  3. Faux  4. a

**6. Réponses et explications**
1. Un devoir fiduciaire est une obligation juridique renforcée d'agir dans le meilleur intérêt d'une autre partie.
2. Le devoir de loyauté exige de faire passer les intérêts du bénéficiaire avant ses propres intérêts personnels.
3. Le devoir fiduciaire représente une norme renforcée qui va bien au-delà des obligations contractuelles ordinaires.
4. Le devoir fiduciaire de loyauté de l'administrateur exigeait une divulgation appropriée avant de saisir une occasion personnelle que la société pourrait raisonnablement vouloir.

**7. Points clés à retenir**
- Le devoir fiduciaire est une obligation juridique renforcée d'agir dans le meilleur intérêt d'une autre partie, qui naît dans des relations de grande confiance.
- Les relations fiduciaires courantes comprennent celles des administrateurs et dirigeants, des fiduciaires et des avocats envers leurs bénéficiaires respectifs.
- Le devoir fiduciaire comprend généralement un devoir de diligence et un devoir de loyauté.
- Cette norme renforcée reflète la confiance et la dépendance importantes propres à ces relations précises.
