---
id: PURPLE-L2-045
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 45
title: "Les bases du droit international : pourquoi la compétence compte"
summary: "Comprends ce qu'est la compétence juridique, pourquoi les questions qui traversent les frontières ajoutent de la complexité et pourquoi elles exigent un conseiller spécialisé."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-045
### Les bases du droit international : pourquoi la compétence compte

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle la compétence juridique.
- Expliquer pourquoi les questions juridiques transfrontalières ajoutent de la complexité.
- Reconnaître que les questions juridiques internationales exigent une expertise spécialisée.

**2. Contenu principal**
La compétence (*jurisdiction*) désigne le pouvoir juridique d'un tribunal ou d'un gouvernement d'entendre une affaire ou de faire appliquer une loi, généralement lié à l'emplacement géographique, aux liens des parties avec cet endroit ou à un domaine précis. Tout au long de ce niveau, des notes de RÈGLE PROPRE À UNE RÉGION ont souligné à quel point les règles juridiques varient, même à l'intérieur d'un seul pays; les questions internationales ajoutent encore à cette complexité, puisque les différents pays ont des systèmes juridiques, des structures judiciaires et des mécanismes d'exécution complètement distincts, sans autorité unique qui régit la plupart des litiges privés entre pays.

Les questions juridiques d'affaires ou personnelles qui traversent les frontières — un contrat entre des parties de pays différents, une propriété détenue dans un pays étranger ou un litige qui implique des parties situées dans des juridictions différentes — exigent généralement de déterminer quelle loi nationale s'applique (un sujet approfondi dans la discussion sur le choix de la loi applicable de la leçon 46) et quels tribunaux nationaux ont le pouvoir d'entendre le litige. Ces questions peuvent elles-mêmes être complexes et contestées, ce qui rend essentiel un conseiller juridique qualifié et spécialisé en droit international pour toute question qui comporte de vrais éléments transfrontaliers.

**3. Exemple pratique**
En concluant une relation d'affaires avec une entreprise établie dans un autre pays, une propriétaire d'entreprise reconnaît que cet arrangement comporte une vraie complexité juridique transfrontalière qui dépasse son expérience des affaires au pays : quelle loi nationale régirait un litige possible, quels tribunaux nationaux pourraient réellement entendre ce litige, et comment un jugement éventuel pourrait réellement être exécuté de l'autre côté de la frontière si l'autre partie ne s'y conformait pas volontairement. Au lieu de supposer que ses connaissances juridiques nationales et ses modèles de contrats standards répondraient adéquatement à ces questions transfrontalières, elle fait appel à une avocate qui a une expérience précise en droit international des affaires pour bien structurer la relation.

**4. Quiz de pratique**
1. De façon conceptuelle, qu'est-ce que la compétence juridique?
   a) Un type de clause contractuelle
   b) Le pouvoir juridique d'un tribunal ou d'un gouvernement d'entendre une affaire ou de faire appliquer une loi
   c) Un type de propriété intellectuelle
   d) Une exigence de déclaration fiscale
2. Pourquoi la complexité juridique internationale ajoute-t-elle aux défis propres à chaque juridiction déjà vus dans ce niveau?
   a) Les questions internationales n'ajoutent aucune complexité
   b) Les différents pays ont des systèmes juridiques, des structures judiciaires et des mécanismes d'exécution complètement distincts
   c) Tous les pays partagent un système juridique identique
   d) Les questions internationales sont toujours plus simples que les questions nationales
3. Vrai ou faux : Les connaissances juridiques nationales et les modèles de contrats standards suffisent toujours pour de vraies relations d'affaires transfrontalières.
4. Pourquoi la propriétaire d'entreprise a-t-elle fait appel à une avocate qui a une expérience précise en droit international?
   a) Ses connaissances juridiques nationales suffisaient entièrement pour la relation transfrontalière
   b) La vraie complexité juridique transfrontalière exigeait une expertise spécialisée qui dépassait son expérience nationale
   c) Le droit international n'existe pas vraiment
   d) Elle n'avait aucune relation d'affaires transfrontalière à gérer

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La compétence désigne le pouvoir juridique d'un tribunal ou d'un gouvernement d'entendre une affaire ou de faire appliquer une loi.
2. Les systèmes juridiques et les mécanismes d'exécution complètement distincts des différents pays ajoutent à la complexité juridique transfrontalière.
3. Les vraies relations transfrontalières exigent généralement une expertise spécialisée qui dépasse les connaissances juridiques nationales et les modèles standards.
4. La propriétaire d'entreprise a eu raison, en reconnaissant une vraie complexité transfrontalière, de chercher un conseiller juridique spécialisé en droit international.

**7. Points clés à retenir**
- La compétence désigne le pouvoir juridique d'un tribunal ou d'un gouvernement d'entendre une affaire ou de faire appliquer une loi.
- Les questions internationales ajoutent à la complexité propre à chaque juridiction vue dans ce niveau, puisque les pays ont des systèmes juridiques complètement distincts.
- Les questions transfrontalières exigent de déterminer à la fois la loi applicable et les tribunaux qui ont le pouvoir d'entendre un litige.
- Les vraies questions juridiques transfrontalières exigent un conseiller juridique spécialisé en droit international, et non des suppositions fondées sur le droit national.
