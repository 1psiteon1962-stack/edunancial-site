---
id: PURPLE-L2-046
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 46
title: "Les clauses de choix de la loi applicable et du tribunal compétent"
summary: "Comprends à quoi servent les clauses qui fixent d'avance la loi applicable et le lieu de règlement des litiges, et pourquoi elles réduisent l'incertitude."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-046
### Les clauses de choix de la loi applicable et du tribunal compétent

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir les clauses de choix de la loi applicable et de choix du tribunal compétent.
- Expliquer pourquoi les parties incluent souvent ces clauses de façon proactive dans leurs contrats.
- Relier cette notion à la discussion sur la compétence de la leçon 45.

**2. Contenu principal**
En s'appuyant directement sur la leçon 45, une clause de choix de la loi applicable précise quelle loi juridictionnelle régira l'interprétation et l'exécution d'un contrat, et une clause de choix du tribunal compétent (ou d'élection de for) précise où (devant quel tribunal ou à quel lieu d'arbitrage) tout litige doit être réglé. Les parties incluent souvent ces clauses de façon proactive précisément pour éviter la complexité et l'incertitude décrites à la leçon 45 : au lieu de laisser ces questions être contestées et tranchées après la naissance d'un litige, les parties s'entendent d'avance, ce qui réduit l'imprévisibilité pour les deux côtés.

Ces clauses sont particulièrement utiles dans les contrats entre des parties de différents États, provinces ou pays, en écho à la discussion transfrontalière de la leçon 45, mais elles peuvent être incluses dans n'importe quel contrat pour apporter de la clarté et de la prévisibilité. Les tribunaux respectent et font généralement respecter, même si ce n'est pas universel, les clauses raisonnables de choix de la loi applicable et du tribunal compétent que les parties ont librement négociées; leur caractère exécutoire peut toutefois dépendre de règles juridictionnelles précises et du fait que la clause était réellement équitable, et non le résultat du pouvoir de négociation écrasant et inéquitable d'une partie.

**3. Exemple pratique**
En négociant un contrat avec une entreprise établie dans un autre État, deux propriétaires d'entreprise incluent de façon proactive une clause de choix de la loi applicable qui précise que la loi de leur propre État régira l'entente, et une clause de choix du tribunal compétent qui précise que tout litige doit être réglé devant un tribunal précis situé dans ce même État. Grâce à cette entente proactive, si un litige survient plus tard, les deux parties savent déjà quelle loi s'applique et où toute procédure juridique aurait lieu, ce qui évite la bataille juridictionnelle coûteuse et incertaine qui pourrait autrement survenir si ces questions restaient sans réponse jusqu'à ce qu'un litige se concrétise.

**4. Quiz de pratique**
1. Que précise généralement une clause de choix de la loi applicable?
   a) L'endroit physique où un litige doit être réglé
   b) Quelle loi juridictionnelle régira l'interprétation et l'exécution du contrat
   c) Les dommages-intérêts précis possibles
   d) Un type de protection de la propriété intellectuelle
2. Que précise généralement une clause de choix du tribunal compétent?
   a) Quelle loi de fond s'applique
   b) Où (devant quel tribunal ou à quel lieu d'arbitrage) tout litige doit être réglé
   c) Les conditions de paiement du contrat
   d) Un type d'exigence d'assurance
3. Vrai ou faux : Les clauses de choix de la loi applicable et du tribunal compétent garantissent toujours un caractère exécutoire absolu, peu importe comment elles ont été négociées.
4. Pourquoi les deux propriétaires d'entreprise ont-ils inclus ces clauses de façon proactive dans leur contrat?
   a) Pour créer le plus d'incertitude possible en cas de litige
   b) Pour éviter la bataille juridictionnelle coûteuse et incertaine qui pourrait autrement survenir après la naissance d'un litige
   c) Ces clauses n'ont aucune utilité pratique
   d) Ils voulaient empêcher tout règlement de litige

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une clause de choix de la loi applicable précise quelle loi juridictionnelle régit l'interprétation et l'exécution du contrat.
2. Une clause de choix du tribunal compétent précise où tout litige doit être réglé.
3. Le caractère exécutoire peut dépendre de règles juridictionnelles précises et du fait que la clause était réellement équitable; il n'est pas automatique dans tous les cas.
4. Inclure ces clauses de façon proactive a réduit l'incertitude et évité une bataille juridictionnelle coûteuse si un litige survenait plus tard.

**7. Points clés à retenir**
- Une clause de choix de la loi applicable précise quelle loi régit un contrat; une clause de choix du tribunal compétent précise où les litiges seront réglés.
- Les parties incluent souvent ces clauses de façon proactive pour réduire l'incertitude décrite à la leçon 45.
- Ces clauses sont particulièrement utiles dans les contrats entre différents États, provinces ou pays.
- Leur caractère exécutoire dépend généralement de leur caractère raisonnable et d'une négociation équitable; il n'est pas automatique en toutes circonstances.
