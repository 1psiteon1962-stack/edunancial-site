---
id: PURPLE-L2-047
track: PURPLE
officialTrackName: "Law"
level: 2
lessonNumber: 47
title: "Travailler avec un avocat : la lettre de mandat et sa portée"
summary: "Comprends à quoi sert une lettre de mandat, ce qu'elle contient et pourquoi il faut vérifier sa portée avant de supposer qu'une question est couverte."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## PURPLE-L2-047
### Travailler avec un avocat : la lettre de mandat et sa portée

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le but général d'une lettre de mandat d'avocat.
- Nommer les éléments clés qu'on trouve habituellement dans une lettre de mandat.
- Renforcer, du point de vue du client, la discussion de BLUE-L2-033 sur la relation continue avec un avocat.

**2. Contenu principal**
Dans la suite de la discussion de BLUE-L2-033 sur les relations continues avec un avocat, cette leçon examine la lettre de mandat (*engagement letter*), le document qui officialise la portée précise, les conditions et la structure des honoraires d'une relation avocat-client pour un dossier donné. Les éléments clés comprennent habituellement la portée précise du mandat (ce que l'avocat prendra en charge et ce qu'il ne prendra pas en charge), la structure des honoraires (à l'heure, forfaitaire, à pourcentage ou un autre arrangement), les conditions de facturation et de paiement, et les responsabilités générales de chaque partie.

Comprendre et examiner attentivement une lettre de mandat est important pour les mêmes raisons que la liste de vérification de lecture de contrat de la leçon 5 s'applique de façon générale : une portée de mandat vague ou trop étroite peut créer de la confusion plus tard sur ce dont l'avocat est réellement responsable, et des conditions d'honoraires floues peuvent créer des litiges ou des surprises de facturation. Les clients devraient se sentir à l'aise de poser des questions de clarification sur une lettre de mandat avant de la signer, comme ce niveau l'a souligné tout au long pour tout contrat important.

**3. Exemple pratique**
Avant d'embaucher une avocate pour un dossier d'affaires précis, une propriétaire d'entreprise lit attentivement la lettre de mandat proposée et remarque que la portée du mandat est définie de façon étroite : elle couvre seulement la négociation de contrat en cours, et non des conseils juridiques continus plus larges. Reconnaissant cette limite de portée, elle demande à l'avocate si une autre question liée qu'elle a sur la structure de son entité ferait partie de ce mandat ou exigerait un arrangement distinct, ce qui lui évite la surprise de découvrir plus tard qu'une question qu'elle croyait couverte était en fait hors de la portée définie du mandat.

**4. Quiz de pratique**
1. Qu'officialise généralement une lettre de mandat d'avocat?
   a) Une déclaration fiscale gouvernementale
   b) La portée précise, les conditions et la structure des honoraires d'une relation avocat-client pour un dossier donné
   c) Un type de protection de la propriété intellectuelle
   d) Une entente de marketing
2. Selon cette leçon, pourquoi la section sur la portée du mandat est-elle importante?
   a) Elle n'a aucune importance pratique
   b) Une portée vague ou trop étroite peut créer de la confusion sur ce dont l'avocat est réellement responsable
   c) La portée du mandat n'est jamais incluse dans les lettres de mandat
   d) Seules les conditions d'honoraires comptent dans une lettre de mandat
3. Vrai ou faux : Les clients devraient éviter de poser des questions de clarification sur une lettre de mandat avant de la signer.
4. Pourquoi la propriétaire d'entreprise a-t-elle demandé si sa question sur la structure de son entité faisait partie de son mandat actuel?
   a) Elle supposait que tout était automatiquement couvert
   b) Elle a reconnu que la portée définie pourrait ne pas inclure cette question supplémentaire et voulait une clarification avant de supposer qu'elle était couverte
   c) Les lettres de mandat ne définissent jamais de portée
   d) Elle n'avait aucune autre question

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une lettre de mandat officialise la portée, les conditions et la structure des honoraires d'une relation avocat-client pour un dossier donné.
2. Une portée vague ou étroite peut créer de la confusion sur ce dont l'avocat est réellement responsable.
3. Les clients devraient se sentir à l'aise de poser des questions de clarification sur une lettre de mandat avant de la signer.
4. La question de clarification de la propriétaire d'entreprise a réglé, à juste titre, un écart de portée possible avant de supposer une couverture qui pourrait ne pas exister.

**7. Points clés à retenir**
- Une lettre de mandat officialise la portée, les conditions et la structure des honoraires d'une relation avocat-client précise.
- Les éléments clés comprennent la portée du mandat, la structure des honoraires, les conditions de facturation et les responsabilités de chaque partie.
- Une portée vague ou étroite peut créer de la confusion sur ce que l'avocat prendra réellement en charge.
- Les clients devraient examiner attentivement les lettres de mandat et poser des questions de clarification, en écho à la discipline de lecture de contrat plus large de ce niveau.
