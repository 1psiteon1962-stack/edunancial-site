---
id: PURPLE-L4-026
track: PURPLE
officialTrackName: "Law"
level: 4
lessonNumber: 26
locale: ht
title: "Analiz lwa antitrust: poukisa monopolizasyon mande plis pase tou senpleman gen yon pozisyon dominan nan mache a"
summary: "Konprann poukisa posede yon gwo pouvwa sou mache a pa ilegal pou kont li anba lwa antitrust Etazini, ak kondisyon anplis konduit antikonpetitif yon reklamasyon monopolizasyon mande."
version: "1.0"
author: "Edunancial Faculty"
date: "2026-10-11"
---
Filename: PURPLE-L4-026.ht.md
Folder: PURPLE/L4
Title: Analiz lwa antitrust: poukisa monopolizasyon mande plis pase tou senpleman gen yon pozisyon dominan nan mache a
Lesson ID: PURPLE-L4-026
Author: Waldemar M. Caban, JD MA
Meta Description: Konprann poukisa posede yon gwo pouvwa sou mache a pa ilegal pou kont li anba lwa antitrust Etazini, ak kondisyon anplis konduit antikonpetitif yon reklamasyon monopolizasyon mande.
SEO Keywords: lwa antitrust, monopolizasyon, pouvwa sou mache, konduit antikonpetitif
Slug: antitrust-law-analysis-why-monopolization-requires-more-than-simply-having-a-dominant-market-position

# Analiz lwa antitrust: poukisa monopolizasyon mande plis pase tou senpleman gen yon pozisyon dominan nan mache a

## Senaryo pou louvri leson an
SIPOZISYON/OPINYON (senaryo ipotetik pou objektif ansèyman sèlman): Imajine de gwo pisans ekonomik k ap ogmante kontwòl sou ekspòtasyon youn kont lòt sou yon kategori pyès teknoloji avanse yo itilize nan anpil endistri. Pandan de gwo pisans ekonomik sa yo ap ogmante restriksyon sou teknoloji, konpayi dominan nan endistri ki gen enpòtans estratejik fè fas ak plis kontwòl regilatè sou kesyon si gwo pozisyon yo nan mache a li menm vyole lwa antitrust, sa ki fè moun bay plis atansyon a sa lwa antitrust Etazini vrèman entèdi, ak poukisa tou senpleman gen yon gwo pati dominan nan mache a pa ilegal pou kont li. Leson sa a egzamine vrè kad legal ki gouvène reklamasyon monopolizasyon yo.

## Objektif aprantisaj
- Esplike poukisa tou senpleman posede yon gwo pouvwa sou mache a oswa yon pozisyon dominan nan mache a pa ilegal pou kont li anba lwa antitrust Etazini.
- Esplike eleman anplis 'konduit antikonpetitif' yon reklamasyon monopolizasyon mande, pi lwen pase pouvwa sou mache a sèlman.
- Fè diferans ant fè konkirans yon fason vigoure e lejitim sou merit ak fè yon konduit esklizyon ki vrèman antikonpetitif.
- Esplike diferans jeneral ant restriksyon orizontal (akò ant konkiran) ak restriksyon vètikal, ak poukisa akò orizontal pou fikse pri yo trete yon fason patikilyèman sevè.

## Kontni prensipal
FÈ VERIFYE: lwa antitrust Etazini, ki gouvène sitou pa Sherman Antitrust Act ak lòt lwa federal ki gen rapò, pa fè li ilegal pou yon konpayi tou senpleman posede yon gwo pouvwa sou mache a oswa menm yon pozisyon vrèman dominan nan mache a — yon konpayi ki rive gen yon gwo dominasyon sou mache a sèlman gras a pi bon pwodui, pi bon konpetans nan biznis, oswa yon aksidan istorik pa vyole lwa antitrust pou rezon sa a sèlman, paske lwa a fèt espesyalman pou pwoteje pwosesis konkirans lan li menm, olye pou l pini yon konpayi tou senpleman paske li te reyisi depase rival li yo ak mwayen lejitim. RÈG ESPESIFIK POU REJYON AN: Ann Ayiti ak nan lòt peyi, règ sou konkirans yo baze sou pwòp lwa lokal yo; verifye ak yon avoka ki kalifye.

Men "poukisa" yon reklamasyon monopolizasyon mande pou w pwouve yon eleman anplis "konduit antikonpetitif", pi lwen pase pouvwa sou mache a sèlman: pou etabli yon monopolizasyon ilegal, yon pleyan (kit se yon ajans gouvènman ki fè respekte lwa antitrust, kit se yon pati prive) anjeneral dwe pwouve toude ke akize a posede yon vrè pouvwa monopòl nan yon mache ki gen rapò ki byen defini, e ke akize a te jwenn oswa kenbe pouvwa monopòl sa a atravè yon konduit esklizyon ki pa kòrèk, olye atravè "kwasans oswa devlopman ki soti nan yon pi bon pwodui, konpetans nan biznis, oswa yon aksidan istorik" tribinal yo rekonèt espesyalman kòm lejitim — RÈG ESPESIFIK POU REJYON AN, konfime estanda legal espesifik ki an vigè yo ak devlopman resan nan jirisprisans lan, paske sa a rete yon domèn lalwa k ap devlope e k ap plede aktivman, kondisyon sa a ki mande yon konduit antikonpetitif pwouve, anplis yon pouvwa sou mache a pwouve, se egzakteman sa ki fè diferans ant yon siksè konpetitif legal ak yon monopolizasyon ilegal.

Se poutèt sa fè diferans ant fè konkirans yon fason vigoure e lejitim sou merit ak fè yon konduit esklizyon ki vrèman antikonpetitif enpòtan nan sant nenpòt analiz monopolizasyon: konduit konpetitif lejitim — ofri pi bon pwodui, fè konkirans agresif sou pri, envesti nan vrè inovasyon, oswa tou senpleman egzekite yon pi bon estrateji biznis an jeneral — pwoteje e ankouraje espesyalman, menm lè sa fè yon konpayi dominan ranfòse pwòp pozisyon li nan mache a plis, sou do konkiran li yo dirèkteman, alòske yon konduit ki vrèman esklizyon — ki fèt espesyalman pou pa fè konkirans sou vrè merit debaz yo, men pito pou anpeche konkiran yo yon fason ki pa kòrèk gen yon vrè opòtinite ki jis pou yo fè konkirans ditou (tankou kèk fòm pri predatè ki fèt espesyalman pou mete konkiran yo deyò anvan w monte pri yo pita, oswa kèk akò distribisyon eksklizif ki fèt espesyalman pou anpeche konkiran yo gen aksè a kanal distribisyon esansyèl, san okenn jistifikasyon biznis lejitim) — ka soutni yon vrè reklamasyon monopolizasyon lè l konbine ak yon pouvwa sou mache a ki pwouve. Se poutèt sa diferans ant restriksyon orizontal (akò ant konkiran dirèk) ak restriksyon vètikal (akò ant pati ki nan diferan nivo nan menm chèn apwovizyònman an, tankou yon manifaktirye ak yon distribitè) enpòtan anpil, ak poukisa akò orizontal pou fikse pri yo trete yon fason patikilyèman sevè: OPINYON ak yon karakterizasyon moun pataje lajman nan lwa antitrust, yon akò orizontal ant konkiran dirèk pou fikse pri, separe mache oswa kliyan espesifik ant yo, oswa limite pwodiksyon yon lòt fason, anjeneral konsidere kòm yon vyolasyon antitrust "per se" (pou kont li), sa ki vle di tribinal yo anjeneral pa mande okenn lòt analiz sou vrè efè konpetitif akò a oswa sou okenn jistifikasyon biznis posib anvan yo jwenn li ilegal, paske kategori espesifik akò orizontal sa a konsidere tèlman danjere nan nati li e yon fason ou ka prevwa pou vrè konkirans lan ke pa gen okenn lòt analiz ekonomik ka pa ka ki anjeneral nesesè — restriksyon vètikal yo, okontrè, anjeneral evalye anba yon analiz "règ rezon" (rule of reason) ki pi fleksib, ki peze vrè efè konpetitif espesifik restriksyon an ak nenpòt jistifikasyon biznis lejitim, olye yo kondane l otomatikman san analiz anplis sa a.

## Egzanp pratik
EGZANP ILISTRATIF: Yon konpayi teknoloji dominan rive nan gwo pozisyon li nan mache a sitou gras a pwodui ki vrèman pi bon ak yon konkirans pri agresif e lejitim, yon konduit lwa antitrust pwoteje espesyalman menm si li fè lavi konkiran konpayi an vin pi difisil anpil. Yon lòt konpayi, ki gen yon pozisyon dominan ki sanble nan mache a, fè pito yon seri akò distribisyon eksklizif ki fèt espesyalman pou anpeche konkiran yo gen aksè a kanal distribisyon esansyèl, san okenn jistifikasyon biznis lejitim anplis tou senpleman eskli rival yo de yon opòtinite ki jis pou yo fè konkirans — konduit dezyèm konpayi sa a, konbine ak pouvwa li sou mache a ki pwouve, ta ka soutni yon vrè reklamasyon monopolizasyon, alòske siksè konpetitif lejitim premye konpayi an, kèlkeswa jan li dominan, anjeneral pa ta soutni l, sa ki montre egzakteman poukisa pouvwa sou mache a pou kont li pa janm ase san w pa pwouve tou yon konduit ki vrèman antikonpetitif.

## Egzamen pratik
**Q1. Poukisa tou senpleman posede yon gwo pouvwa sou mache a oswa yon pozisyon dominan nan mache a pa ilegal pou kont li anba lwa antitrust Etazini?**
A) Lwa antitrust fè li otomatikman ilegal pou nenpòt konpayi gen yon pozisyon dominan nan mache a, kèlkeswa kijan li te rive nan pozisyon sa a
B) Lwa antitrust fèt espesyalman pou pwoteje pwosesis konkirans lan li menm, olye pou l pini yon konpayi tou senpleman paske li te reyisi depase rival li yo ak mwayen lejitim tankou pi bon pwodui oswa konpetans nan biznis
C) Pouvwa sou mache a pa gen okenn vrè rapò ak okenn analiz antitrust anba lwa Etazini
D) Se sèlman konpayi gouvènman posede, jamè konpayi prive, ki ka janm gen yon pozisyon dominan nan mache a legalman

**Q2. Ki eleman anplis yon reklamasyon monopolizasyon mande, pi lwen pase yon pouvwa sou mache a ki pwouve?**
A) Pa gen okenn eleman anplis ki nesesè; yon pouvwa sou mache a ki pwouve pou kont li toujou ase pou etabli yon monopolizasyon ilegal
B) Prèv ke akize a te jwenn oswa kenbe pouvwa monopòl atravè yon konduit esklizyon ki pa kòrèk, olye atravè yon kwasans lejitim ki soti nan yon pi bon pwodui, konpetans nan biznis, oswa yon aksidan istorik
C) Prèv ke konkiran akize a te fèmen biznis yo kòm rezilta dirèk pozisyon akize a nan mache a
D) Yon reklamasyon monopolizasyon mande pou w pwouve sèlman ke pati akize a nan mache a depase yon pousantaj espesifik

**Q3. Kisa ki fè diferans ant yon konduit konpetitif lejitim ak yon konduit esklizyon ki vrèman antikonpetitif?**
A) Konkirans lejitim ak konduit antikonpetitif se konsèp idantik san okenn diferans enpòtan ant yo
B) Konduit lejitim mande pou w fè konkirans sou vrè merit yo (pi bon pwodui, pri agresif, vrè inovasyon), alòske konduit antikonpetitif fèt espesyalman pou anpeche konkiran yo gen yon opòtinite ki jis pou yo fè konkirans ditou, san okenn jistifikasyon biznis lejitim
C) Nenpòt konduit ki fè biznis konkiran yo vin pi difisil otomatikman konsidere kòm antikonpetitif, kèlkeswa kijan yo te reyalize l
D) Konduit antikonpetitif vle di sèlman konduit ki ogmante pwòp pri yon konpayi, san okenn lòt karakteristik ki enpòtan

**Q4. Poukisa akò orizontal pou fikse pri ant konkiran dirèk yo trete kòm vyolasyon antitrust 'per se'?**
A) Akò orizontal pou fikse pri yo toujou evalye anba menm analiz règ rezon fleksib yo aplike pou restriksyon vètikal yo
B) Kategori espesifik akò orizontal sa a konsidere tèlman danjere nan nati li e yon fason ou ka prevwa pou vrè konkirans lan ke tribinal yo anjeneral pa mande okenn lòt analiz ka pa ka sou vrè efè konpetitif li yo oswa sou okenn jistifikasyon biznis posib anvan yo jwenn li ilegal
C) Akò orizontal ant konkiran yo toujou legal, kèlkeswa objektif oswa efè espesifik yo
D) Vyolasyon per se yo mande pou w pwouve menm analiz ekonomik detaye yon ka règ rezon mande

**Q5. Nan egzanp lan, poukisa konduit dezyèm konpayi an ta ka soutni yon vrè reklamasyon monopolizasyon alòske konduit premye konpayi an pa ta soutni l?**
A) Toude konpayi yo te an reyalite fè yon konduit idantik, kontrè a sa egzanp lan dekri
B) Dezyèm konpayi an te fè akò distribisyon eksklizif ki te fèt espesyalman pou anpeche konkiran yo gen aksè a kanal distribisyon esansyèl san okenn jistifikasyon biznis lejitim, alòske premye konpayi an te rive nan pozisyon li gras a pwodui ki vrèman pi bon ak yon konkirans pri lejitim
C) Konduit premye konpayi an te an reyalite pi antikonpetitif pase konduit dezyèm konpayi an
D) Pouvwa sou mache a pou kont li, kèlkeswa konduit espesifik la, toujou ase pou etabli yon reklamasyon monopolizasyon kont nenpòt konpayi dominan

## Kle repons yo
Q1: B
Q2: B
Q3: B
Q4: B
Q5: B

## Repons ak eksplikasyon
**Q1.** Diferans sa a ant pwoteje pwosesis konkirans lan ak pini yon siksè konpetitif lejitim se egzakteman poukisa pouvwa sou mache a pou kont li pa vyole lwa antitrust.

**Q2.** Prèv anplis obligatwa sa a sou yon konduit esklizyon ki pa kòrèk se egzakteman sa ki fè diferans ant yon dominasyon legal sou mache a ak yon monopolizasyon ilegal anba lwa antitrust Etazini.

**Q3.** Diferans sa a ant fè konkirans sou vrè merit ak anpeche yon fason ki pa kòrèk opòtinite ki jis konkiran yo genyen pou yo fè konkirans se egzakteman sa ki separe yon siksè konpetitif lejitim ak yon konduit ki vrèman antikonpetitif.

**Q4.** Rekonesans sa a sou domaj natirèl e ou ka prevwa fikse pri orizontal fè konkirans lan se egzakteman poukisa yo trete l kòm yon vyolasyon per se, san yo pa mande analiz anplis ka pa ka yon apwòch règ rezon mande.

**Q5.** Kontras dirèk sa a ant yon siksè konpetitif lejitim ak yon konduit ki vrèman esklizyon san okenn jistifikasyon lejitim montre egzakteman poukisa pouvwa sou mache a konbine ak yon konduit antikonpetitif, pa pouvwa sou mache a pou kont li, ki soutni yon vrè reklamasyon monopolizasyon.

## Pwen kle yo
- Tou senpleman posede yon gwo pouvwa oswa yon dominasyon sou mache a pa ilegal pou kont li anba lwa antitrust Etazini, paske lalwa pwoteje pwosesis konkirans lan olye l pini yon siksè lejitim.
- Yon reklamasyon monopolizasyon mande anplis pou w pwouve akize a te jwenn oswa kenbe pouvwa li atravè yon konduit esklizyon ki pa kòrèk, pa atravè yon kwasans lejitim.
- Konkirans lejitim sou merit pwoteje, alòske yon konduit ki vrèman antikonpetitif ki fèt espesyalman pou anpeche konkiran yo gen yon opòtinite ki jis pou yo fè konkirans ka soutni responsablite lè l konbine ak yon pouvwa sou mache a ki pwouve.
- Akò orizontal pou fikse pri ant konkiran yo trete kòm vyolasyon per se, ki pa mande okenn lòt analiz sou efè konpetitif, alòske restriksyon vètikal yo evalye anba yon estanda règ rezon ki pi fleksib.
