---
id: PURPLE-L4-041
track: PURPLE
officialTrackName: "Law"
level: 4
lessonNumber: 41
locale: ht
title: "Analiz jiridiksyon pèsonèl: poukisa yon tribinal bezwen plis pase yon pleyan ki vle pou l tande yon ka"
summary: "Konprann kisa jiridiksyon pèsonèl ye, estanda 'kontak minimòm' lan, konsèp 'pwofite espre' (purposeful availment), ak sa ki rive si yon pleyan depoze pwosè nan yon tribinal ki pa gen jiridiksyon sou akize a."
version: "1.0"
author: "Edunancial Faculty"
date: "2026-10-11"
---
Filename: PURPLE-L4-041.ht.md
Folder: PURPLE/L4
Title: Analiz jiridiksyon pèsonèl: poukisa yon tribinal bezwen plis pase yon pleyan ki vle pou l tande yon ka
Lesson ID: PURPLE-L4-041
Author: Waldemar M. Caban, JD MA
Meta Description: Konprann kisa jiridiksyon pèsonèl ye, estanda 'kontak minimòm' lan, konsèp 'pwofite espre' (purposeful availment), ak sa ki rive si yon pleyan depoze pwosè nan yon tribinal ki pa gen jiridiksyon sou akize a.
SEO Keywords: jiridiksyon pèsonèl, kontak minimòm, pwofite espre, limit pwosedi legal sou jiridiksyon
Slug: personal-jurisdiction-analysis-why-a-court-needs-more-than-just-a-willing-plaintiff-to-hear-a-case

# Analiz jiridiksyon pèsonèl: poukisa yon tribinal bezwen plis pase yon pleyan ki vle pou l tande yon ka

## Senaryo pou louvri leson an
SIPOZISYON/OPINYON (senaryo ipotetik pou objektif ansèyman sèlman): Imajine de gwo pisans ekonomik k ap ogmante kontwòl ekspòtasyon youn kont lòt sou yon kategori konpozan teknoloji avanse yo itilize nan anpil endistri. Pandan de gwo pisans ekonomik ap ogmante restriksyon teknoloji e diskisyon komèsyal atravè fwontyè ap ogmante, pleyan ki vle fè yon akize etranje oswa ki soti nan yon lòt eta pwosè nan pwòp tribinal lokal yo pi pito, ki pi pratik pou yo, dekouvri ke pwòp otorite yon tribinal pou l vrèman tande yon ka kont yon akize espesifik se pa tou senpleman yon kesyon chwa oswa konfò pleyan an. Leson sa a egzamine limit konstitisyonèl espesifik ki gouvène otorite sa a.

## Objektif aprantisaj
- Esplike kisa jiridiksyon pèsonèl vle di, ak poukisa yon tribinal dwe genyen l sou yon akize anvan l bay yon jijman ki obligatwa.
- Esplike estanda jeneral 'kontak minimòm' ki gouvène si yon tribinal ka egzèse jiridiksyon pèsonèl sou yon akize ki soti nan yon lòt eta.
- Esplike konsèp 'pwofite espre' (purposeful availment), ak poukisa pwòp aksyon volontè yon akize ki vize eta tribinal la enpòtan nan sant analiz sa a.
- Esplike poukisa yon akize ka konteste jiridiksyon pèsonèl, ak konsekans pratik si yon pleyan depoze pwosè nan yon tribinal ki pa gen bon jiridiksyon sou akize a.

## Kontni prensipal
Jiridiksyon pèsonèl vle di otorite legal yon tribinal espesifik sou yon akize patikilye, sa ki pèmèt tribinal sa a vrèman bay yon jijman ki obligatwa kont akize sa a. FÈ VERIFYE: yon tribinal dwe gen jiridiksyon pèsonèl sou yon akize anvan li ka legalman bay okenn jijman ki obligatwa kont akize espesifik sa a, sa ki vle di yon pleyan pa ka tou senpleman chwazi fè yon akize pwosè nan nenpòt tribinal espesifik pleyan an pèsonèlman jwenn ki pi pratik, kèlkeswa vrè koneksyon, oswa mank koneksyon, akize patikilye sa a ak tribinal espesifik sa a. RÈG ESPESIFIK POU REJYON AN: estanda kontak minimòm lan soti nan lwa konstitisyonèl Etazini; Ann Ayiti ak nan lòt peyi, règ konpetans tribinal yo diferan; verifye ak yon avoka ki kalifye.

Men "poukisa" estanda "kontak minimòm" lan gouvène si yon tribinal ka egzèse jiridiksyon pèsonèl sou yon akize ki soti nan yon lòt eta: anba estanda konstitisyonèl pwosedi legal (due process) sa a, yon tribinal anjeneral ka egzèse jiridiksyon pèsonèl sou yon akize ki pa prezan fizikman nan, e ki pa otreman abite nan, eta tribinal la sèlman si akize sa a gen kèk "kontak minimòm" ak eta tribinal la yon fason ki fè egzèse jiridiksyon sou akize sa a pa ta ofanse nosyon tradisyonèl jwèt ki jis ak jistis enpòtan (fair play and substantial justice), RÈG ESPESIFIK POU REJYON AN, konfime estanda jiridiksyon espesifik ki an vigè yo ak devlopman resan nan jiripridans, paske domèn sa a toujou ap plede aktivman e y ap toujou rafine l, sitou jan li aplike pou aktivite komèsyal modèn ki fèt an pati oswa nèt sou entènèt.

Se poutèt sa konsèp "pwofite espre" a enpòtan nan sant analiz sa a, ak poukisa pwòp aksyon volontè yon akize ki vize eta tribinal la tèlman enpòtan: tribinal yo anjeneral egzamine si akize a te pwofite espre de privilèj pou fè aktivite nan eta tribinal la, kidonk li te envoke benefis ak pwoteksyon pwòp lwa eta sa a, olye li te tou senpleman sibi kèk koneksyon totalman o aza, akoz chans, oswa ki byen lwen ak eta sa a ke akize a li menm pa t vrèman chwazi oswa kreye espre — yon akize ki fè espre fè maketing pwodwi bay, ki siyen kontra ak, oswa ki otreman dirije espre pwòp aktivite biznis li vè kliyan nan yon eta espesifik anjeneral te pwofite espre de eta sa a yon fason ki ka soutni jiridiksyon pèsonèl la, alòske yon akize ki gen sèl koneksyon li ak yon eta espesifik ki soti nan kèk aksyon totalman san rapò, inilateral yon twazyèm moun, san okenn aksyon volontè oswa vrè chwa akize a li menm, anjeneral pa t pwofite espre de eta sa a menm jan an, e jiridiksyon pèsonèl la ta gen chans ofanse estanda jwèt ki jis ak jistis enpòtan doktrin sa a fèt espesyalman pou pwoteje. Se poutèt sa yon akize ka konteste jiridiksyon pèsonèl, ak konsekans pratik si yon pleyan depoze pwosè nan yon tribinal ki pa gen bon jiridiksyon sou akize a: yon akize ki kwè yon tribinal espesifik pa gen bon jiridiksyon pèsonèl sou li ka anjeneral leve kontestasyon espesifik sa a bonè nan pwosè a, e si tribinal la dakò ke li vrèman pa gen jiridiksyon pèsonèl sou akize patikilye sa a, yo ap anjeneral rejte ka kont akize sa a nan tribinal espesifik sa a (menm si pleyan an ka souvan toujou depoze menm reklamasyon an ankò nan yon lòt tribinal ki apwopriye ki gen bon jiridiksyon sou akize a) — se egzakteman poukisa idantifye kòrèkteman yon tribinal ki gen yon vrè jiridiksyon pèsonèl ki kòrèk sou yon akize espesifik, anvan w vrèman depoze pwosè la, tèlman enpòtan pou yon pleyan, paske depoze nan yon tribinal ki pa kòrèk ka lakòz vrè reta, plis depans, ak bezwen pou depoze ka a ankò nèt yon lòt kote, menm lè pwòp reklamasyon debaz pleyan an ta ka otreman vrèman solid e byen soutni.

## Egzanp pratik
EGZANP ILISTRATIF: Yon biznis ki gen biwo santral li nan yon eta fè espre fè maketing pwodwi li dirèkteman bay kliyan nan yon lòt eta, li siyen anpil kontra ak moun ki abite nan eta espesifik sa a pandan yon long peryòd. Lè yon diskisyon parèt pita ak youn nan kliyan espesifik sa yo, yon tribinal nan pwòp eta kliyan sa a gen chans ka egzèse jiridiksyon pèsonèl sou biznis ki soti nan lòt eta a, paske biznis la te pwofite espre de mache eta sa a atravè pwòp aktivite maketing ak kontra volontè li la. Yon lòt biznis ki pa gen okenn koneksyon volontè konparab ak menm eta sa a, ki gen sèl lyen li ki te parèt paske yon sèl kliyan te rive pote youn nan pwodwi biznis la nan eta sa a poukont li, sou pwòp inisyativ li, pa ta gen chans pou l sibi jiridiksyon pèsonèl la, sa ki montre egzakteman poukisa pwòp aksyon volontè akize a ki vize yon tribinal espesifik, pa sèlman kèk koneksyon pa aza oswa byen lwen, deside si jiridiksyon pèsonèl vrèman egziste.

## Egzamen pratik
**Q1. Kisa jiridiksyon pèsonèl vle di, e poukisa yon tribinal dwe genyen l anvan l bay yon jijman ki obligatwa?**
A) Otorite yon tribinal pou l detèmine montan lajan espesifik dedomajman ki disponib nan yon ka
B) Otorite legal yon tribinal espesifik sou yon akize patikilye, ke tribinal la dwe genyen anvan li ka legalman bay yon jijman ki obligatwa kont akize espesifik sa a
C) Jiridiksyon pèsonèl pa gen okenn vrè rapò ak otorite yon tribinal sou okenn akize espesifik
D) Pwòp preferans pèsonèl pleyan an sou ki tribinal li ta renmen tande ka li

**Q2. Kisa estanda 'kontak minimòm' lan anjeneral mande pou yon tribinal egzèse jiridiksyon pèsonèl sou yon akize ki soti nan yon lòt eta?**
A) Okenn estanda espesifik pa aplike, e nenpòt tribinal ka egzèse jiridiksyon sou nenpòt akize kèlkeswa okenn koneksyon ak tribinal sa a
B) Akize a dwe gen kèk kontak minimòm ak eta tribinal la yon fason ki fè egzèse jiridiksyon pa ta ofanse nosyon tradisyonèl jwèt ki jis ak jistis enpòtan
C) Akize a dwe abite fizikman nan eta tribinal la tout tan, san okenn eksepsyon pou okenn lòt kalite koneksyon
D) Kontak minimòm vle di sèlman montan lajan espesifik biznis yon akize fè nan eta tribinal la

**Q3. Kisa 'pwofite espre' egzamine, e poukisa li enpòtan nan sant analiz jiridiksyon pèsonèl la?**
A) Pwofite espre egzamine si pleyan an pèsonèlman pito yon tribinal espesifik, san okenn rapò ak pwòp aksyon akize a
B) Li egzamine si akize a te pwofite espre de privilèj pou fè aktivite nan eta tribinal la, li envoke benefis lwa eta sa a, olye li gen kèk koneksyon o aza, akoz chans, oswa byen lwen li pa t vrèman chwazi
C) Pwofite espre pa gen okenn vrè rapò ak si yon tribinal ka egzèse jiridiksyon pèsonèl sou yon akize
D) Konsèp sa a aplike sèlman pou pwosedi kriminèl, jamè pou pwosè sivil ki gen rapò ak jiridiksyon pèsonèl

**Q4. Kisa ki rive si yon pleyan depoze pwosè nan yon tribinal yon jij deside pa gen bon jiridiksyon pèsonèl sou akize a?**
A) Ka a kontinye nòmalman, paske jiridiksyon pèsonèl pa gen okenn vrè efè sou si yon tribinal ka tande yon ka
B) Yo ap anjeneral rejte ka kont akize sa a nan tribinal espesifik sa a, menm si pleyan an ka souvan toujou depoze menm reklamasyon an ankò nan yon tribinal ki apwopriye ki gen yon vrè jiridiksyon sou akize a
C) Akize a otomatikman genyen tout ka a sou merit yo, san okenn posiblite pou pleyan an depoze ankò yon lòt kote
D) Tribinal la tou senpleman transfere tout ka a bay yon lòt tribinal san okenn rejè oswa lòt aksyon pleyan an bezwen fè

**Q5. Nan egzanp lan, poukisa tribinal eta kliyan an te gen chans ka egzèse jiridiksyon pèsonèl sou biznis ki soti nan lòt eta a, men pa sou yon biznis ki gen sèlman yon koneksyon pa aza?**
A) De biznis yo te an reyalite gen koneksyon idantik, ki menm jan solid, ak eta kliyan an
B) Premye biznis la te fè espre fè maketing pwodwi e li te siyen anpil kontra ak moun ki abite nan eta sa a pandan yon bon tan, sa ki satisfè pwofite espre, alòske sèl koneksyon dezyèm biznis la te soti nan pwòp aksyon inilateral yon kliyan, san okenn aksyon volontè biznis la li menm
C) Jiridiksyon pèsonèl pa gen okenn rapò ak si yon biznis te fè espre fè maketing bay moun ki abite nan yon eta espesifik
D) Okenn nan de biznis yo pa t gen okenn koneksyon ditou ak eta kliyan an nan egzanp sa a

## Kle repons yo
Q1: B
Q2: B
Q3: B
Q4: B
Q5: B

## Repons ak eksplikasyon
**Q1.** Otorite legal obligatwa sa a sou akize espesifik la, san li yon tribinal pa ka legalman bay yon jijman ki obligatwa, se egzakteman sa jiridiksyon pèsonèl vle di.

**Q2.** Estanda konstitisyonèl pwosedi legal sa a, ki mande vrè kontak minimòm ki an akò ak jwèt ki jis ak jistis enpòtan, se egzakteman sa ki gouvène jiridiksyon pèsonèl sou yon akize ki soti nan yon lòt eta.

**Q3.** Konsantrasyon sa a sou pwòp aksyon volontè, chwazi akize a ki vize tribinal la, olye koneksyon pa aza oswa ki pa chwazi, se egzakteman poukisa pwofite espre enpòtan nan sant analiz sa a.

**Q4.** Rejè sa a nan tribinal ki pa kòrèk la, ansanm ak posiblite pou depoze ankò nan yon tribinal ki apwopriye, se egzakteman konsekans pratik pou w depoze pwosè kote jiridiksyon pèsonèl sou akize a manke.

**Q5.** Kontras dirèk sa a ant aktivite biznis volontè, fèt espre, ki vize yon tribinal ak yon koneksyon pa aza, ki pa chwazi montre egzakteman poukisa yon biznis te satisfè estanda kontak minimòm ak pwofite espre a alòske lòt la pa t satisfè l.

## Pwen kle yo
- Yon tribinal dwe gen jiridiksyon pèsonèl sou yon akize anvan li ka legalman bay yon jijman ki obligatwa kont akize sa a.
- Estanda kontak minimòm lan mande pou egzèse jiridiksyon sou yon akize ki soti nan yon lòt eta pa ofanse nosyon tradisyonèl jwèt ki jis ak jistis enpòtan.
- Pwofite espre egzamine si akize a te fè espre dirije aktivite vè eta tribinal la, li envoke lwa li yo, olye li gen kèk koneksyon pa aza, ki pa chwazi.
- Yon akize ka konteste jiridiksyon pèsonèl, e yo ap anjeneral rejte yon ka yo depoze nan yon tribinal ki pa kòrèk, menm si pleyan an ka souvan depoze ankò nan yon tribinal ki apwopriye.
