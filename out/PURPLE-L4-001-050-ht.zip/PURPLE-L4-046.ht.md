---
id: PURPLE-L4-046
track: PURPLE
officialTrackName: "Law"
level: 4
lessonNumber: 46
locale: ht
title: "Analiz responsablite siksesè: poukisa achte byen yon biznis pa toujou vle di ou separe nèt ak dèt li yo"
summary: "Konprann règ jeneral ke achtè byen yon biznis pa pran dèt vandè a otomatikman, ak twa gwo eksepsyon yo: fizyon de fakto, senp kontinyasyon, ak transfè fwòd."
version: "1.0"
author: "Edunancial Faculty"
date: "2026-10-11"
---
Filename: PURPLE-L4-046.ht.md
Folder: PURPLE/L4
Title: Analiz responsablite siksesè: poukisa achte byen yon biznis pa toujou vle di ou separe nèt ak dèt li yo
Lesson ID: PURPLE-L4-046
Author: Waldemar M. Caban, JD MA
Meta Description: Konprann règ jeneral ke achtè byen yon biznis pa pran dèt vandè a otomatikman, ak twa gwo eksepsyon yo: fizyon de fakto, senp kontinyasyon, ak transfè fwòd.
SEO Keywords: responsablite siksesè, eksepsyon nan acha byen, fizyon de fakto, doktrin senp kontinyasyon
Slug: successor-liability-analysis-why-buying-a-businesss-assets-doesnt-always-mean-a-clean-break-from-its-liabilities

# Analiz responsablite siksesè: poukisa achte byen yon biznis pa toujou vle di ou separe nèt ak dèt li yo

## Senaryo pou louvri leson an
SIPOZISYON/OPINYON (senaryo ipotetik pou objektif ansèyman sèlman): Imajine mache imobilye ak mache kredi konsomatè yon peyi ki gen anpil moun, apre plizyè ane ekspansyon rapid, k ap kòmanse montre siy yon gwo koreksyon pandan moun ki pa peye dèt yo ap kòmanse ogmante. Pandan yon boom ki te alimante pa kredi ap defèt e plis an plis biznis ki gen difikilte vin achte atravè acha byen ki òganize espesyalman pou kite kèk dèt ki egziste deja nan men antite k ap vann nan, achtè yo vle konprann egzakteman ki lè kalite òganizasyon sa a vrèman reyisi evite dèt vandè a ki egziste deja, ak eksepsyon enpòtan, espesifik kote yon tribinal ta ka kanmenm enpoze dèt sa yo dirèkteman sou achtè a. Leson sa a egzamine règ jeneral sa a ak eksepsyon enpòtan li yo, ki konekte ak analiz taks vant byen konpare ak vant aksyon nan pakou GREEN-L4 la.

## Objektif aprantisaj
- Esplike règ jeneral ke yon achtè ki achte byen espesifik yon biznis anjeneral pa pran otomatikman dèt vandè a ki egziste deja, ki konekte ak diferans vant byen konpare ak vant aksyon nan pakou GREEN-L4 la.
- Esplike eksepsyon 'fizyon de fakto' a, ak poukisa yon tribinal ka trete yon acha byen kòm si li ekivalan ak yon fizyon konplè nan fonksyònman li malgre estrikti fòmèl li.
- Esplike eksepsyon 'senp kontinyasyon' an, ak poukisa yon gwo kontinwite ant biznis vandè a ak biznis achtè a ka deklanche responsablite siksesè.
- Esplike eksepsyon transfè fwòd la, ak poukisa yo ka anile yon tranzaksyon ki òganize espesyalman pou bloke, retade, oswa twonpe kreyansye ki egziste deja kèlkeswa estrikti fòmèl li.

## Kontni prensipal
Nou konekte ak analiz taks vant byen konpare ak vant aksyon nan pakou GREEN-L4 la, FÈ VERIFYE, règ jeneral common law la di ke yon achtè ki achte byen espesifik yon biznis (olye l pran tout antite biznis la atravè yon acha aksyon oswa yon fizyon) anjeneral pa pran otomatikman dèt vandè a ki egziste deja, sa ki vle di yon achtè ka anjeneral òganize yon acha byen espesyalman pou l pran sèlman byen li vle, li chwazi yo, pandan l kite dèt ak lòt obligasyon vandè a ki egziste deja nan men antite k ap vann nan li menm — men règ jeneral sa a gen plizyè eksepsyon enpòtan, byen etabli ki ka, nan sitiyasyon ki apwopriye, kanmenm enpoze responsablite siksesè dirèkteman sou achtè a, kèlkeswa jan yo te òganize tranzaksyon debaz la fòmèlman. RÈG ESPESIFIK POU REJYON AN: Ann Ayiti, transfè fon komès ak dwa kreyansye yo swiv lwa lokal ak Kòd Sivil la (pa egzanp aksyon polyèn); verifye ak yon avoka oswa yon notè ki kalifye.

Men "poukisa" eksepsyon "fizyon de fakto" a pèmèt yon tribinal trete yon acha byen kòm si li ekivalan ak yon fizyon konplè, malgre estrikti fòmèl li: tribinal yo egzamine si yon tranzaksyon ki òganize fòmèlman kòm yon acha byen vrèman fonksyone, nan vrè sans pratik li, kòm yon fizyon konplè de biznis yo — yo konsidere faktè tankou si achtè a te kontinye menm operasyon biznis vandè a ak pratikman menm direksyon an, menm anplwaye yo, ak menm kote fizik la, si pwòp aksyonè vandè a te resevwa yon pati pwopriyete nan achtè a kòm peman pou tranzaksyon an (olye tou senpleman lajan kach), ak si vandè a te fonn rapidman e li te sispann egziste apa poukont li yon ti tan apre tranzaksyon an — RÈG ESPESIFIK POU REJYON AN, konfime estanda espesifik jiridiksyon an ki an vigè yo ak pwa chak faktè, paske yo varye, e si yon tribinal deside tranzaksyon an te vrèman fonksyone kòm yon fizyon de fakto malgre etikèt fòmèl "acha byen" li a, tribinal la ka enpoze responsablite siksesè sou achtè a menm jan kòm si yon fizyon fòmèl, konplè te vrèman fèt.

Se poutèt sa eksepsyon "senp kontinyasyon" an ka deklanche tou responsablite siksesè sou baz yon gwo kontinwite ant biznis vandè a ak biznis achtè a: eksepsyon sa a anjeneral aplike lè achtè a reprezante, nan vrè sans pratik li, tou senpleman yon kontinyasyon menm antrepriz biznis debaz la anba yon nouvo pwopriyetè, sa yo souvan wè lè pratikman menm pwopriyetè yo, menm direksyon an, menm anplwaye yo, ak menm operasyon biznis yo kontinye pratikman san chanjman apre tranzaksyon an, RÈG ESPESIFIK POU REJYON AN, konfime estanda espesifik jiridiksyon an ki an vigè yo, paske eksepsyon sa a kouvri anpil menm teren ak fizyon de fakto nan kèk jiridiksyon pandan li rete yon ti jan pi diferan nan lòt — eksepsyon sa a reflete yon enkyetid jidisyè debaz ki sanble ke yo pa ta dwe pèmèt yon tranzaksyon reyalize, sèlman atravè yon fòm legal patikilye yo chwazi, sa ki ta otreman reprezante yon vrè kontinyasyon debaz egzakteman menm biznis debaz la k ap tou senpleman evite pwòp dèt li ki egziste deja atravè chwa estriktirèl espesifik sa a poukont li. Se poutèt sa eksepsyon transfè fwòd la pèmèt yo anile yon tranzaksyon ki òganize espesyalman pou bloke, retade, oswa twonpe kreyansye ki egziste deja kèlkeswa estrikti fòmèl li: si yo òganize yon acha byen espesyalman, oswa yo fè kondisyon li espesyalman, ak vrè entansyon pou bloke, retade, oswa twonpe kreyansye vandè a ki egziste deja (tankou atravè yon pri ki twò ba anpil yo peye pou byen yo transfere yo, oswa lòt siy klè entansyon fwòd), tribinal yo ka anjeneral mete tranzaksyon an sou kote oswa anile l anba lwa transfè fwòd ki aplike a, sa ki pèmèt kreyansye vandè a rive jwenn byen yo transfere yo nan pwòp men achtè a malgre estrikti fòmèl acha byen an, sa ki vle di yon achtè k ap konsidere yon acha byen nan men yon vandè ki gen difikilte finansyè ta dwe evalye espesyalman si pri acha a ak lòt kondisyon tranzaksyon an vrèman jis e ase, akoz vrè risk enpòtan ke yon pri ki twò ba anpil ta ka li menm vin yon prèv espesifik ki soutni yon reklamasyon transfè fwòd kont achtè a.

## Egzanp pratik
EGZANP ILISTRATIF: Yon biznis ki gen difikilte vann pratikman tout byen li bay yon achtè ki kontinye opere egzakteman menm biznis la nan menm kote a, ak menm anplwaye yo, menm direksyon an, ak menm kliyan yo, li òganize tranzaksyon an kòm yon acha byen fòmèl ak entansyon espesifik pou kite dèt vandè a ki egziste deja dèyè. Yon tribinal ki egzamine tranzaksyon sa a pita, apre yon kreyansye konteste l espesyalman, jwenn ase prèv yon gwo kontinwite ant biznis vandè a ak biznis achtè a pou l enpoze responsablite siksesè anba eksepsyon senp kontinyasyon an, li fè achtè a responsab pou omwen kèk nan dèt vandè a ki egziste deja malgre estrikti fòmèl acha byen tranzaksyon an — sa ki montre egzakteman poukisa estrikti legal fòmèl yon tranzaksyon pa pwoteje otomatikman yon achtè kont responsablite siksesè lè sans debaz la revele yon vrè kontinwite biznis.

## Egzamen pratik
**Q1. Ki règ jeneral common law la konsènan si yon achtè pran dèt vandè a ki egziste deja nan yon acha byen?**
A) Yon achtè ki achte byen espesifik yon biznis otomatikman pran tout dèt vandè a ki egziste deja, kèlkeswa jan yo òganize tranzaksyon an
B) Yon achtè ki achte byen espesifik yon biznis anjeneral pa pran otomatikman dèt vandè a ki egziste deja, sa ki pèmèt achtè a òganize acha a espesyalman pou l kite dèt ki egziste deja yo nan men vandè a
C) Acha byen pa janm vrèman yon estrikti tranzaksyon lalwa rekonèt nan okenn sitiyasyon
D) Règ jeneral la pa gen okenn vrè rapò ak si yon achtè pran dèt vandè a ki egziste deja

**Q2. Kisa eksepsyon 'fizyon de fakto' a egzamine?**
A) Si yo te mete etikèt fizyon fòmèlman sou tranzaksyon an olye acha byen, san okenn konsiderasyon sou vrè sans li
B) Si yon tranzaksyon ki òganize fòmèlman kòm yon acha byen vrèman fonksyone, nan vrè sans pratik li, kòm yon fizyon konplè, li konsidere faktè tankou operasyon ki kontinye, peman bay aksyonè yo, ak fonn rapid vandè a
C) Sèlman si pri acha yo te peye a te valè mache jis la, san okenn lòt konsiderasyon enpòtan
D) Fizyon de fakto pa gen okenn vrè rapò ak si yo ta ka enpoze responsablite siksesè sou yon achtè

**Q3. Kisa eksepsyon 'senp kontinyasyon' an anjeneral mande pou l deklanche responsablite siksesè?**
A) Achtè a dwe te peye egzakteman menm pri acha vandè a te peye orijinalman pou l te achte menm byen yo
B) Achtè a dwe reprezante, nan vrè sans pratik li, tou senpleman yon kontinyasyon menm antrepriz biznis debaz la anba yon nouvo pwopriyetè, sa yo souvan wè lè pratikman menm pwopriyetè yo, direksyon an, anplwaye yo, ak operasyon yo kontinye pratikman san chanjman
C) Senp kontinyasyon aplike sèlman si achtè a dakò klèman e fòmèlman alekri pou l pran dèt vandè a ki egziste deja
D) Eksepsyon sa a pa gen okenn vrè rapò ak okenn kontinwite ant biznis vandè a ak biznis achtè a

**Q4. Kisa eksepsyon transfè fwòd la pèmèt, e ki lè li aplike?**
A) Li pèmèt yo anile yon tranzaksyon ki òganize espesyalman pou bloke, retade, oswa twonpe kreyansye ki egziste deja kèlkeswa estrikti fòmèl li, tankou atravè yon pri ki twò ba anpil oswa lòt siy klè entansyon fwòd
B) Eksepsyon sa a aplike sèlman pou tranzaksyon ki òganize fòmèlman kòm yon acha aksyon, jamè pou yon acha byen
C) Lwa transfè fwòd pa gen okenn vrè rapò ak responsablite siksesè oswa tranzaksyon acha byen
D) Eksepsyon sa a mande pou pwouve achtè a pa t konnen anyen ditou sou difikilte finansyè vandè a ki egziste deja

**Q5. Nan egzanp lan, poukisa tribinal la te enpoze responsablite siksesè sou achtè a malgre estrikti fòmèl acha byen tranzaksyon an?**
A) Tribinal la pa t jwenn okenn prèv okenn kontinwite ant biznis vandè a ak biznis achtè a, e yo pa t dwe enpoze responsablite siksesè
B) Tribinal la te jwenn ase prèv yon gwo kontinwite — menm kote a, anplwaye yo, direksyon an, ak kliyan yo — ki soutni responsablite siksesè anba eksepsyon senp kontinyasyon an, malgre etikèt fòmèl acha byen an
C) Yo pa janm ka vrèman enpoze responsablite siksesè sou yon achtè kèlkeswa okenn kontinwite ant biznis vandè a ak biznis achtè a
D) Achtè a te dakò klèman e fòmèlman alekri pou l pran tout dèt vandè a ki egziste deja, sa ki fè rezilta sa a pa gen rapò ak eksepsyon senp kontinyasyon an

## Kle repons yo
Q1: B
Q2: B
Q3: B
Q4: A
Q5: B

## Repons ak eksplikasyon
**Q1.** Règ jeneral sa a ki di achtè a pa pran dèt yo otomatikman, ki pèmèt yon achtè òganize yon acha byen pou l kite dèt ki egziste deja yo dèyè, se egzakteman prensip common law debaz leson sa a egzamine, ki gen eksepsyon enpòtan li yo.

**Q2.** Egzamen sa a ki mete sans la pi wo pase fòm nan pou wè si yon acha byen fonksyone kòm yon vrè fizyon se egzakteman sa eksepsyon fizyon de fakto a konsidere, kèlkeswa etikèt fòmèl tranzaksyon an.

**Q3.** Konsantrasyon sa a sou yon gwo kontinwite biznis anba yon nouvo pwopriyetè se egzakteman sa eksepsyon senp kontinyasyon an egzamine lè l ap deside si responsablite siksesè ta dwe aplike.

**Q4.** Kapasite sa a pou anile yon tranzaksyon ki fèt espesyalman pou bloke, retade, oswa twonpe kreyansye, kèlkeswa estrikti fòmèl li, se egzakteman sa eksepsyon transfè fwòd la bay.

**Q5.** Aplikasyon dirèk sa a analiz gwo kontinwite eksepsyon senp kontinyasyon an montre egzakteman poukisa estrikti fòmèl acha byen an pa t pwoteje achtè a kont responsablite siksesè nan sitiyasyon espesifik sa a.

## Pwen kle yo
- Yon achtè ki achte byen yon biznis anjeneral pa pran otomatikman dèt vandè a ki egziste deja, sa ki pèmèt yo òganize dèt yo pou yo rete nan men vandè a.
- Eksepsyon fizyon de fakto a pèmèt yon tribinal trete yon acha byen ki òganize fòmèlman kòm yon vrè fizyon sou baz yon gwo kontinwite pratik ant biznis yo.
- Eksepsyon senp kontinyasyon an aplike lè achtè a reprezante yon vrè kontinyasyon menm antrepriz biznis la anba yon nouvo pwopriyetè.
- Eksepsyon transfè fwòd la pèmèt yo anile yon tranzaksyon ki òganize espesyalman pou bloke, retade, oswa twonpe kreyansye kèlkeswa estrikti fòmèl li.
