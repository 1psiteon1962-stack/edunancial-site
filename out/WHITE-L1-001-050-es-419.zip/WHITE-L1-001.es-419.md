---
id: WHITE-L1-001
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 1
locale: es-419
title: "¿Qué es un activo en papel? (Y por qué lo llamamos así)"
summary: "Aprende qué representa realmente un activo en papel y en qué se diferencia de ser dueño de una propiedad física."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es un activo en papel? (Y por qué lo llamamos así)

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir un activo en papel en palabras sencillas.
- Explicar qué representa realmente un activo en papel.
- Comparar los activos en papel con los bienes raíces como un tipo distinto de valor.

## Contenido principal

### Qué significa "activo en papel"

Un activo en papel es un derecho financiero —antes, un certificado físico; hoy, casi siempre un registro digital— que representa la propiedad de algo o el derecho a un valor futuro, en lugar de ser en sí mismo una cosa física y utilizable. Una acción representa la propiedad parcial de una empresa. Un bono representa una promesa de que te van a devolver tu dinero, con intereses.

### Qué hay detrás de un activo en papel

Tener una acción de una empresa no significa ser dueño de un escritorio o de una máquina específicos: significa ser dueño de una pequeñísima porción del valor total de la empresa. El valor del activo en papel depende por completo de lo que hay detrás: la empresa real, el deudor real o el gobierno real que respalda un bono.

### Activos en papel frente a bienes raíces

Los bienes raíces de la caja RED son físicos: terrenos y construcciones que puedes tocar. Los activos en papel de la caja WHITE son derechos: porciones de propiedad, acuerdos de préstamo, derechos a pagos futuros. Además, los activos en papel generalmente son más fáciles y rápidos de comprar, vender y dividir en partes pequeñas que una propiedad física.

## Ejemplo práctico

Tener 10 acciones de una empresa significa ser dueño de una porción pequeña y definida del valor total de la empresa, no de alguna parte específica de sus bienes físicos. Ese valor sube o baja según cambien las perspectivas de la empresa.

## Prueba de práctica

1. La mejor descripción de un activo en papel es:
   A. Un objeto físico que puedes usar directamente
   B. Un derecho sobre una propiedad o sobre un valor futuro
   C. Un tipo de moneda
   D. Un formulario emitido por el gobierno
2. Verdadero o falso: El valor de una acción viene principalmente de que es un registro oficial.
3. ¿Por qué vender una acción normalmente es mucho más rápido que vender una casa?
   A. Es ilegal conservar acciones a largo plazo
   B. Las acciones son unidades pequeñas y estandarizadas que no exigen encontrar a un comprador específico que encaje
   C. Las casas valen más
   D. No hay ninguna diferencia real de rapidez

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Un activo en papel representa una propiedad o un derecho sobre un valor futuro.

### Pregunta 2

Respuesta correcta: Falso. El valor viene de lo que el activo representa, no del papel o del registro en sí.

### Pregunta 3

Respuesta correcta: B. Las unidades pequeñas y estandarizadas, sin necesidad de un comprador único que encaje, son lo que hace más rápida la venta de acciones.

## Puntos clave

- Un activo en papel es un derecho sobre un valor, no un objeto físico.
- Su valor viene de lo que hay detrás de él.
- Los activos en papel generalmente son más fáciles y rápidos de comprar, vender y dividir que los bienes raíces.
