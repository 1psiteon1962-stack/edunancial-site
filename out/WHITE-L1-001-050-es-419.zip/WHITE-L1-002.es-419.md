---
id: WHITE-L1-002
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 2
locale: es-419
title: "¿Qué es el ROI? (Y por qué la misma idea se ve distinta en cada caja)"
summary: "Aprende la fórmula del ROI (retorno sobre la inversión), qué mide y por qué el mismo concepto se aplica en los bienes raíces, los negocios y los activos en papel."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es el ROI? (Y por qué la misma idea se ve distinta en cada caja)

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Calcular un ROI básico a partir de una ganancia y un costo.
- Explicar qué mide realmente el ROI.
- Reconocer el ROI como un concepto que atraviesa todas las cajas, e identificar una de sus limitaciones.

## Contenido principal

### La fórmula del ROI

ROI (retorno sobre la inversión) = (Ganancia de la inversión − Costo de la inversión) ÷ Costo de la inversión, normalmente expresado como porcentaje. Si $1,000 crecen a $1,200, la ganancia es de $200, y ROI = $200 ÷ $1,000 = 20 %.

### El mismo concepto, cajas distintas

El ROI no es una idea exclusiva de la caja WHITE. Un inversionista en bienes raíces de la caja RED calcula el ROI con los ingresos por renta y la plusvalía frente al precio de compra. El dueño de un negocio de la caja BLUE lo calcula con la utilidad generada frente al dinero invertido. La lógica de la fórmula es la misma —la ganancia comparada con el costo—, pero lo que cuenta como ganancia y como costo cambia según la caja.

### Una limitación real

El ROI básico no toma en cuenta el tiempo. Un ROI del 20 % obtenido en un año es muy distinto del mismo 20 % obtenido en diez años, aunque la fórmula por sí sola no muestre esa diferencia.

## Ejemplo práctico

$500 que crecen a $575 son una ganancia de $75: ROI = $75 ÷ $500 = 15 %. Una compra de equipo para un negocio por $10,000 que genera $2,500 de utilidad adicional: ROI = $2,500 ÷ $10,000 = 25 %. Es la misma fórmula, en situaciones muy distintas.

## Prueba de práctica

1. El ROI mide:
   A. El monto total en dólares que se ganó
   B. La ganancia en relación con el costo, como porcentaje
   C. El valor total de una inversión
   D. El nivel de riesgo de una inversión
2. Verdadero o falso: El ROI básico toma en cuenta cuánto tiempo tomó obtener el rendimiento.
3. Inviertes $2,000 y crecen a $2,400. ¿Cuál es el ROI?
   A. 10 %
   B. 15 %
   C. 20 %
   D. 40 %

## Clave de respuestas

1. B
2. Falso
3. C

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. El ROI es específicamente una medida porcentual de la ganancia en relación con el costo.

### Pregunta 2

Respuesta correcta: Falso. El ROI básico no toma en cuenta el tiempo, y esa es una limitación real.

### Pregunta 3

Respuesta correcta: C. ($2,400 − $2,000) ÷ $2,000 = 20 %.

## Puntos clave

- ROI = (Ganancia − Costo) ÷ Costo, normalmente expresado como porcentaje.
- El ROI se aplica por igual en los bienes raíces, los negocios y los activos en papel.
- El ROI básico no toma en cuenta el tiempo: una limitación real que hay que tener presente.
