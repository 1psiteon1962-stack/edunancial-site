---
id: WHITE-L1-004
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 4
locale: es-419
title: "¿Qué es realmente un bono? (Estás prestando dinero, no comprando propiedad)"
summary: "Aprende qué representa realmente un bono —un préstamo, no una propiedad— y las condiciones básicas que lo definen."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es realmente un bono? (Estás prestando dinero, no comprando propiedad)

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir un bono en palabras sencillas.
- Explicar la relación central entre el tenedor de un bono y el emisor.
- Nombrar las condiciones básicas que definen un bono.

## Contenido principal

### Un bono es un préstamo, no una propiedad

Cuando compras un bono, le estás prestando dinero a quien lo emitió (una empresa o un gobierno); no estás comprando una parte de la propiedad, como te daría una acción. Esta es la distinción más importante entre las acciones y los bonos.

### La relación central

El emisor promete devolver el monto original (el principal o "valor nominal") en una fecha futura establecida (el vencimiento) y, normalmente, hacer pagos periódicos de intereses (llamados cupón) durante ese tiempo, a cambio de usar tu dinero.

### Las condiciones básicas

Todo bono tiene un valor nominal (el monto que se devuelve al vencimiento), una tasa de cupón (la tasa de interés que se paga) y una fecha de vencimiento (cuando se paga el préstamo). Estas condiciones se fijan cuando se emite el bono.

## Ejemplo práctico

Un inversionista compra un bono con valor nominal de $1,000, una tasa de cupón del 4 % y un vencimiento a 10 años. Recibe $40 al año de intereses (el 4 % de $1,000) y le devuelven sus $1,000 después de 10 años.

## Prueba de práctica

1. Comprar un bono significa:
   A. Comprar una parte de la propiedad de una empresa
   B. Prestarle dinero al emisor
   C. Comprar un bien físico
   D. Convertirte en empleado de una empresa
2. Verdadero o falso: La tasa de cupón de un bono se refiere al monto que se devuelve al vencimiento.
3. ¿Qué es el valor nominal de un bono?
   A. La tasa de interés que se paga
   B. El monto que se le devuelve al tenedor del bono al vencimiento
   C. El precio actual del bono en el mercado
   D. La deuda total del emisor

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Un bono representa prestar dinero, no propiedad.

### Pregunta 2

Respuesta correcta: Falso. La tasa de cupón es la tasa de interés; el valor nominal es el monto que se devuelve al vencimiento.

### Pregunta 3

Respuesta correcta: B. El valor nominal es el principal que se devuelve al vencimiento.

## Puntos clave

- Un bono representa prestar dinero, no propiedad.
- El emisor promete devolver el principal al vencimiento, más intereses periódicos (el cupón).
- El valor nominal, la tasa de cupón y la fecha de vencimiento son las condiciones centrales que lo definen.
