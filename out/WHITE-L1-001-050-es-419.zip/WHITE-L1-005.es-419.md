---
id: WHITE-L1-005
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 5
locale: es-419
title: "Acciones frente a bonos: ¿cuál es la verdadera disyuntiva?"
summary: "Aprende la verdadera disyuntiva entre acciones y bonos —potencial de crecimiento frente a prioridad de pago—, no solo \"riesgoso frente a seguro\"."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# Acciones frente a bonos: ¿cuál es la verdadera disyuntiva?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Explicar la diferencia estructural central entre acciones y bonos.
- Explicar por qué a los tenedores de bonos generalmente se les paga antes que a los accionistas.
- Evitar el planteamiento simplista de que "las acciones son riesgosas y los bonos son seguros".

## Contenido principal

### La diferencia estructural

Una acción representa propiedad; un bono representa un préstamo. Esta sola diferencia explica la mayoría de las diferencias prácticas entre ambos, que se ven en esta lección.

### Prioridad de pago

Si una empresa tiene problemas financieros serios, los tenedores de bonos (como prestamistas) generalmente tienen el derecho legal a que se les pague antes de que los accionistas (como dueños) reciban algo. Es una prioridad estructural real, no solo una fama general de seguridad.

### Más allá de "riesgoso frente a seguro"

Decir simplemente que las acciones son "riesgosas" y que los bonos son "seguros" simplifica de más una disyuntiva con más matices: las acciones ofrecen el potencial de ganancia de ser dueño (un crecimiento potencial ilimitado, pero sin garantía de recuperar el dinero), mientras que los bonos ofrecen condiciones de pago definidas por contrato (pero con un rendimiento potencial limitado y con sus propios riesgos reales, como que el emisor no pague).

## Ejemplo práctico

Si una empresa quiebra, a sus tenedores de bonos generalmente les toca cobrar de los bienes que queden antes de que sus accionistas reciban algo: el derecho de los accionistas va al final, lo que refleja la diferencia estructural entre propiedad y préstamo.

## Prueba de práctica

1. La diferencia estructural central entre acciones y bonos es:
   A. Las acciones siempre son más riesgosas que los bonos
   B. Las acciones representan propiedad; los bonos representan un préstamo
   C. Los bonos siempre pagan rendimientos más altos
   D. No hay ninguna diferencia real
2. Verdadero o falso: En la quiebra de una empresa, los tenedores de bonos generalmente tienen derecho a cobrar antes que los accionistas.
3. ¿Por qué "las acciones son riesgosas y los bonos son seguros" es una simplificación excesiva?
   A. Es totalmente exacto, sin matices
   B. Ambos tienen disyuntivas reales, con tipos distintos de riesgo y recompensa
   C. Los bonos no tienen ningún riesgo
   D. Las acciones siempre pierden dinero

## Clave de respuestas

1. B
2. Verdadero
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Propiedad frente a préstamo es la diferencia estructural central.

### Pregunta 2

Respuesta correcta: Verdadero. Los tenedores de bonos generalmente tienen prioridad de pago sobre los accionistas.

### Pregunta 3

Respuesta correcta: B. Ambos tienen tipos de riesgo reales y distintos; el planteamiento simple no capta ese matiz.

## Puntos clave

- Las acciones representan propiedad; los bonos representan un préstamo.
- Los tenedores de bonos generalmente tienen prioridad de pago sobre los accionistas.
- "Riesgoso frente a seguro" simplifica de más una disyuntiva con más matices entre ambos.
