---
id: WHITE-L1-006
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 6
locale: es-419
title: "¿Qué es un dividendo?"
summary: "Aprende qué es un dividendo, cómo se paga y por qué nunca está garantizado."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es un dividendo?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir un dividendo en palabras sencillas.
- Explicar cómo se pagan normalmente los dividendos.
- Explicar por qué los dividendos nunca están garantizados.

## Contenido principal

### Qué es un dividendo

Un dividendo es una parte de las utilidades de una empresa que se reparte entre los accionistas, en proporción a cuántas acciones tiene cada uno.

### Cómo se pagan normalmente

Los dividendos comúnmente se pagan en efectivo, con una periodicidad regular (muchas veces trimestral), directamente a los accionistas según cuántas acciones tengan en una fecha de registro específica.

### Por qué nunca están garantizados

El consejo de administración (o junta directiva) de una empresa decide si se paga un dividendo y de cuánto; no existe una obligación legal de pagarlo. Las empresas pueden reducir, suspender o nunca empezar a pagar dividendos, muchas veces según su rentabilidad y sus planes de crecimiento.

## Ejemplo práctico

Un inversionista que tiene 100 acciones de una empresa que paga un dividendo trimestral de $0.50 por acción recibiría $50 ese trimestre: un monto que podría cambiar en trimestres futuros, a criterio de la empresa.

## Prueba de práctica

1. Un dividendo es:
   A. Un pago fijo garantizado
   B. Una parte de las utilidades de la empresa que se reparte entre los accionistas
   C. Un tipo de pago de intereses de un bono
   D. Un impuesto que se debe por tener acciones
2. Verdadero o falso: Las empresas están legalmente obligadas a pagar dividendos.
3. ¿Quién decide si se paga un dividendo y de cuánto?
   A. Cada accionista
   B. El consejo de administración de la empresa
   C. La bolsa de valores
   D. El gobierno

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Un dividendo es un reparto de utilidades entre los accionistas.

### Pregunta 2

Respuesta correcta: Falso. El pago de dividendos es discrecional, no una obligación legal.

### Pregunta 3

Respuesta correcta: B. El consejo de administración decide sobre el pago de dividendos.

## Puntos clave

- Un dividendo es una parte de las utilidades que se reparte entre los accionistas.
- Normalmente los pagos son en efectivo y con una periodicidad regular.
- Los dividendos nunca están garantizados: son una decisión del consejo de administración.
