---
id: WHITE-L1-007
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 7
locale: es-419
title: "¿Qué es el precio de una acción y qué lo mueve?"
summary: "Aprende qué determina día a día el precio de una acción, más allá de solo \"la oferta y la demanda\"."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es el precio de una acción y qué lo mueve?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir el precio de una acción en palabras sencillas.
- Explicar el mecanismo básico de oferta y demanda detrás de los cambios de precio.
- Nombrar factores que pueden cambiar esa oferta y esa demanda.

## Contenido principal

### Qué es el precio de una acción

El precio de una acción es el monto actual al que se negocia una acción en el mercado: el precio que acordaron el comprador y el vendedor más recientes.

### El mecanismo básico

En el fondo, el precio de una acción se mueve por la oferta y la demanda: si hay más compradores que vendedores a cierto precio, el precio tiende a subir; si hay más vendedores que compradores, tiende a bajar.

### Qué cambia la oferta y la demanda

Las noticias específicas de la empresa (resultados, productos nuevos, cambios en la dirección), las condiciones económicas generales, las tendencias de la industria y el ánimo de los inversionistas pueden cambiar cuántas personas quieren comprar o vender a cierto precio; por eso los precios pueden moverse aunque no cambie nada en la empresa misma.

## Ejemplo práctico

Una empresa reporta utilidades mejores de lo esperado. Hay más inversionistas que quieren comprar acciones al precio actual que vendedores dispuestos a vender, y eso empuja el precio hacia arriba hasta que se alcanza un nuevo equilibrio.

## Prueba de práctica

1. En el fondo, el precio de una acción se mueve por:
   A. Reglas fijadas por el gobierno
   B. La oferta y la demanda
   C. La fecha de fundación de la empresa
   D. El símbolo bursátil de la acción
2. Verdadero o falso: El precio de una acción solo puede cambiar si cambia algo en la empresa misma.
3. ¿Cuál es un factor que puede cambiar la oferta y la demanda de una acción?
   A. Las noticias sobre los resultados de la empresa
   B. El símbolo bursátil de la acción
   C. La fecha de fundación de la empresa
   D. El color del logotipo de la empresa

## Clave de respuestas

1. B
2. Falso
3. A

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. En el fondo, la oferta y la demanda mueven el precio de una acción.

### Pregunta 2

Respuesta correcta: Falso. Las condiciones generales del mercado y el ánimo de los inversionistas pueden mover los precios sin ningún cambio específico en la empresa.

### Pregunta 3

Respuesta correcta: A. Las noticias sobre los resultados son una causa común de cambios en la oferta y la demanda.

## Puntos clave

- El precio de una acción refleja el precio de la operación acordada más reciente.
- En el fondo, la oferta y la demanda mueven el precio.
- Las noticias de la empresa, las condiciones económicas y el ánimo de los inversionistas pueden cambiar la oferta y la demanda.
