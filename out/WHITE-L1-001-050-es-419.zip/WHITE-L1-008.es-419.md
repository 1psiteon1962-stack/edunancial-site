---
id: WHITE-L1-008
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 8
locale: es-419
title: "¿Qué es la capitalización de mercado?"
summary: "Aprende qué mide la capitalización de mercado, cómo se calcula y por qué no es lo mismo que el efectivo o el valor total de una empresa."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es la capitalización de mercado?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Enunciar la fórmula de la capitalización de mercado.
- Calcular la capitalización de mercado a partir del precio de la acción y de las acciones en circulación.
- Explicar por qué la capitalización de mercado no es lo mismo que el efectivo o los activos totales de una empresa.

## Contenido principal

### La fórmula

Capitalización de mercado = Precio de la acción × Total de acciones en circulación. Representa el valor de mercado total de todas las acciones de una empresa juntas.

### Qué mide realmente

La capitalización de mercado refleja lo que los inversionistas, en conjunto, creen que vale la propiedad de la empresa en este momento: una estimación del mercado en tiempo real, no una cifra auditada ni fija.

### Por qué no es lo mismo que el efectivo o el valor total

La capitalización de mercado no es lo mismo que el efectivo que tiene una empresa, sus ingresos totales ni siquiera sus activos totales. Una empresa puede tener una capitalización de mercado grande y relativamente poco efectivo disponible, porque la capitalización de mercado refleja lo que esperan los inversionistas sobre el valor futuro, no una foto actual del balance general.

## Ejemplo práctico

Una empresa con 10,000,000 de acciones en circulación que se negocian a $50 por acción tiene una capitalización de mercado de 10,000,000 × $50 = $500,000,000, sin importar cuánto efectivo real tenga la empresa.

## Prueba de práctica

1. La capitalización de mercado se calcula como:
   A. Ingresos totales × número de empleados
   B. Precio de la acción × total de acciones en circulación
   C. Activos totales − pasivos totales
   D. Utilidad anual ÷ acciones en circulación
2. Verdadero o falso: La capitalización de mercado es lo mismo que el efectivo disponible de una empresa.
3. Una empresa tiene 2,000,000 de acciones en circulación que se negocian a $30 por acción. ¿Cuál es su capitalización de mercado?
   A. $6,000
   B. $60,000
   C. $6,000,000
   D. $60,000,000

## Clave de respuestas

1. B
2. Falso
3. D

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Capitalización de mercado = precio de la acción × acciones en circulación.

### Pregunta 2

Respuesta correcta: Falso. La capitalización de mercado refleja el valor de mercado, no el efectivo que se tiene.

### Pregunta 3

Respuesta correcta: D. 2,000,000 × $30 = $60,000,000.

## Puntos clave

- Capitalización de mercado = Precio de la acción × Total de acciones en circulación.
- Refleja la valuación conjunta que hace el mercado de toda la propiedad de la empresa.
- No es lo mismo que el efectivo, los ingresos ni los activos totales de una empresa.
