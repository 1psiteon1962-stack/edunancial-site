---
id: WHITE-L1-009
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 9
locale: es-419
title: "¿Qué es un ETF? (Una canasta, no una sola acción)"
summary: "Aprende qué es un ETF, en qué se diferencia de comprar una sola acción y por qué importa esa estructura de canasta."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es un ETF? (Una canasta, no una sola acción)

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir un ETF en palabras sencillas.
- Explicar en qué se diferencia de comprar una sola acción.
- Explicar un beneficio práctico de la estructura de canasta.

## Contenido principal

### Qué es un ETF

Un ETF (fondo cotizado en bolsa, por sus siglas en inglés) es un fondo que tiene un conjunto de activos (muchas veces numerosas acciones o bonos), con participaciones que se negocian en una bolsa durante todo el día, de forma parecida a una acción individual.

### En qué se diferencia de una sola acción

Comprar una acción de una sola empresa te da exposición solo a esa empresa. Comprar una participación de un ETF te da exposición a todo lo que hay dentro de esa canasta a la vez: posiblemente decenas o cientos de inversiones subyacentes, con una sola compra.

### Un beneficio práctico de la estructura de canasta

Como un ETF reparte la exposición entre muchas inversiones a la vez, el mal desempeño de cualquiera de ellas tiene un impacto menor en el ETF completo del que tendría si fuera la única inversión del inversionista: una forma básica de diversificación, que se ve con más detalle en una lección posterior.

## Ejemplo práctico

En lugar de escoger una sola empresa para invertir, un inversionista compra una participación de un ETF que tiene acciones de 500 empresas distintas: reparte su exposición entre las 500 con una sola compra.

## Prueba de práctica

1. La mejor descripción de un ETF es:
   A. La acción de una sola empresa
   B. Un fondo que tiene un conjunto de activos y se negocia como una acción
   C. Un tipo de cuenta de ahorro
   D. Un bono del gobierno
2. Verdadero o falso: Comprar una participación de un ETF solo da exposición a una empresa subyacente.
3. ¿Cuál es un beneficio práctico de la estructura de canasta de un ETF?
   A. Garantiza una ganancia
   B. Reparte la exposición entre muchas inversiones a la vez
   C. Elimina todo el riesgo de inversión
   D. Exige escoger acciones individuales

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Un ETF es un fondo negociable que tiene varios activos.

### Pregunta 2

Respuesta correcta: Falso. Normalmente una participación de un ETF da exposición a muchas inversiones subyacentes a la vez.

### Pregunta 3

Respuesta correcta: B. Repartir la exposición entre muchas inversiones es el beneficio central.

## Puntos clave

- Un ETF es un fondo que tiene un conjunto de activos y se negocia como una acción.
- Una participación de un ETF puede dar exposición a muchas inversiones subyacentes a la vez.
- Esta estructura de canasta da una forma básica de diversificación.
