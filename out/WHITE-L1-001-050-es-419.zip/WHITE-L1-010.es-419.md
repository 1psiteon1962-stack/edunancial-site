---
id: WHITE-L1-010
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 10
locale: es-419
title: "¿Qué es un fondo de inversión (fondo mutuo) y en qué se diferencia de un ETF?"
summary: "Aprende qué es un fondo de inversión y las diferencias prácticas clave entre los fondos de inversión y los ETF."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es un fondo de inversión (fondo mutuo) y en qué se diferencia de un ETF?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir un fondo de inversión en palabras sencillas.
- Explicar en qué se parecen los fondos de inversión y los ETF.
- Nombrar al menos una diferencia práctica entre ellos.

## Contenido principal

### Qué es un fondo de inversión

Igual que un ETF, un fondo de inversión (también llamado fondo mutuo) junta el dinero de muchos inversionistas para comprar un conjunto de activos. Ambos comparten el concepto básico de "canasta" de la lección anterior.

### En qué se parecen

Tanto los fondos de inversión como los ETF ofrecen exposición diversificada a una canasta de inversiones mediante una sola inversión, y ambos pueden administrarse de forma activa o pasiva.

### Una diferencia práctica clave

A diferencia de los ETF, que se negocian durante todo el día en una bolsa a precios que cambian constantemente, las participaciones de los fondos de inversión normalmente se valúan y se negocian solo una vez al día, después del cierre de los mercados, con base en el valor calculado de ese día.

## Ejemplo práctico

Un inversionista que compra un ETF puede ver cómo cambia su precio minuto a minuto durante el horario del mercado. Un inversionista que compra un fondo de inversión hace su orden y recibe un precio calculado al final de esa jornada de operaciones, no en tiempo real.

## Prueba de práctica

1. Un fondo de inversión es:
   A. La acción de una sola empresa
   B. Un fondo común que invierte en un conjunto de activos, parecido en concepto a un ETF
   C. Exclusivamente un tipo de bono
   D. Un programa de ahorro del gobierno
2. Verdadero o falso: Las participaciones de los fondos de inversión se negocian de forma continua durante todo el día, como las de los ETF.
3. ¿Cuál es una diferencia práctica clave entre los fondos de inversión y los ETF?
   A. Los fondos de inversión no pueden tener acciones
   B. Los fondos de inversión normalmente se valúan una vez al día; los ETF se negocian durante todo el día
   C. Los ETF no pueden estar diversificados
   D. No hay ninguna diferencia real

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Un fondo de inversión junta dinero en una canasta diversificada, parecida en concepto a un ETF.

### Pregunta 2

Respuesta correcta: Falso. A diferencia de los ETF, los fondos de inversión normalmente se valúan una vez al día.

### Pregunta 3

Respuesta correcta: B. La frecuencia de valuación es una diferencia práctica clave.

## Puntos clave

- Un fondo de inversión junta el dinero de los inversionistas en una canasta diversificada, parecida a un ETF.
- Ambos ofrecen exposición diversificada mediante una sola inversión.
- Los fondos de inversión normalmente se valúan una vez al día; los ETF se negocian durante todo el día.
