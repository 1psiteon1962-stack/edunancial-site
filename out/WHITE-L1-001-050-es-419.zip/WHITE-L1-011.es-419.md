---
id: WHITE-L1-011
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 11
locale: es-419
title: "¿Qué es un índice? (Qué significa realmente \"el mercado\" cuando la gente lo dice)"
summary: "Aprende qué es realmente un índice de mercado y qué significa cuando la gente dice que \"el mercado subió\"."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es un índice? (Qué significa realmente "el mercado" cuando la gente lo dice)

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir un índice de mercado en palabras sencillas.
- Explicar qué significa cuando alguien dice que "el mercado subió".
- Reconocer que un índice sigue un grupo definido, no literalmente todo.

## Contenido principal

### Qué es un índice

Un índice de mercado es un conjunto definido de acciones (u otros activos) que se siguen juntas para representar el desempeño de un segmento específico del mercado: es una herramienta de medición, no algo de lo que seas dueño directamente.

### Qué significa realmente "el mercado subió"

Cuando la gente dice que "hoy subió el mercado", normalmente se refiere a que subió de valor un índice específico y conocido, no literalmente todas las acciones de todas partes. Distintos índices pueden moverse en direcciones distintas el mismo día.

### Un grupo definido, no todo

Un índice sigue un conjunto específico y definido de empresas (elegidas con reglas específicas), no toda la economía mundial. Entender qué empresas forman realmente parte de un índice importa para entender qué representa de verdad su movimiento.

## Ejemplo práctico

Un titular que dice que "el mercado subió 1 % hoy" normalmente se refiere a un índice específico formado por un grupo definido de empresas; otro índice que sigue a un grupo distinto de empresas pudo haberse movido de otra forma ese mismo día.

## Prueba de práctica

1. Un índice de mercado es:
   A. La acción de una sola empresa
   B. Un conjunto definido de activos que se sigue para representar un segmento del mercado
   C. Un tipo de cuenta bancaria
   D. Un informe económico del gobierno
2. Verdadero o falso: "El mercado subió" siempre significa que literalmente todas las acciones del mundo subieron ese día.
3. ¿Por qué importa qué empresas forman realmente parte de un índice?
   A. No importa en absoluto
   B. Determina lo que realmente representa el movimiento de ese índice
   C. Todos los índices tienen empresas idénticas
   D. Los índices nunca cambian su composición

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Un índice es un conjunto definido que se sigue para representar un segmento del mercado.

### Pregunta 2

Respuesta correcta: Falso. Se refiere a un índice específico, no literalmente a todas las acciones.

### Pregunta 3

Respuesta correcta: B. La composición determina lo que realmente refleja el movimiento del índice.

## Puntos clave

- Un índice de mercado sigue un conjunto definido de activos.
- "El mercado subió" normalmente se refiere a un índice específico, no a todo.
- Entender la composición real de un índice importa para interpretar su movimiento.
