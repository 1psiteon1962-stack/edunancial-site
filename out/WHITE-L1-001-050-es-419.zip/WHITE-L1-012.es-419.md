---
id: WHITE-L1-012
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 12
locale: es-419
title: "¿Qué es el índice de gastos (expense ratio) y por qué debería importarte un porcentaje pequeño?"
summary: "Aprende qué es el índice de gastos de un fondo y por qué un porcentaje anual que parece pequeño importa con el tiempo."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es el índice de gastos (expense ratio) y por qué debería importarte un porcentaje pequeño?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir el índice de gastos en palabras sencillas.
- Calcular el costo anual aproximado a partir del saldo de un fondo y su índice de gastos.
- Explicar por qué las diferencias pequeñas de porcentaje importan con el tiempo.

## Contenido principal

### Qué es el índice de gastos

El índice de gastos (expense ratio) es la comisión anual que cobra un fondo (como un ETF o un fondo de inversión), expresada como porcentaje del monto invertido, para cubrir los costos de operación del fondo.

### Cómo calcular el costo

Un índice de gastos del 0.50 % sobre una inversión de $10,000 cuesta aproximadamente $50 al año, y se descuenta automáticamente de los rendimientos del fondo: normalmente los inversionistas no lo pagan como una factura aparte.

### Por qué los porcentajes pequeños importan con el tiempo

Como el índice de gastos se cobra cada año, incluso las diferencias pequeñas se acumulan de forma importante en periodos largos. Una comisión del 0.10 % frente a una del 1.00 % sobre la misma inversión, mantenida durante décadas, puede sumar un costo total muy distinto, aunque la diferencia anual parezca pequeña.

## Ejemplo práctico

Una inversión de $10,000 con un índice de gastos del 1.00 % cuesta unos $100 al año en comisiones. La misma inversión con un índice de gastos del 0.10 % cuesta unos $10 al año: una diferencia de $90 que se acumula de forma importante si se mantiene durante muchos años.

## Prueba de práctica

1. El índice de gastos es:
   A. Una comisión única de compra
   B. Una comisión anual que se cobra como porcentaje del monto invertido
   C. Un impuesto sobre los dividendos
   D. Una comisión que solo se cobra al vender
2. Verdadero o falso: Las diferencias en el índice de gastos son demasiado pequeñas para importar con el tiempo.
3. Una inversión de $20,000 tiene un índice de gastos del 0.40 %. ¿Aproximadamente cuánto cuesta eso al año?
   A. $8
   B. $40
   C. $80
   D. $400

## Clave de respuestas

1. B
2. Falso
3. C

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. El índice de gastos es una comisión anual basada en un porcentaje.

### Pregunta 2

Respuesta correcta: Falso. Las diferencias anuales pequeñas se acumulan de forma importante en periodos largos.

### Pregunta 3

Respuesta correcta: C. $20,000 × 0.40 % = $80.

## Puntos clave

- El índice de gastos es una comisión anual que se cobra como porcentaje de los activos invertidos.
- Se descuenta automáticamente de los rendimientos del fondo; no se cobra aparte.
- Las diferencias pequeñas en el índice de gastos pueden acumularse en costos importantes con el tiempo.
