---
id: WHITE-L1-013
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 13
locale: es-419
title: "¿Qué es la diversificación, en palabras sencillas?"
summary: "Aprende qué hace y qué no hace realmente la diversificación: reduce cierto riesgo, pero no elimina todo el riesgo."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es la diversificación, en palabras sencillas?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir la diversificación en palabras sencillas.
- Explicar qué tipo de riesgo reduce.
- Explicar por qué no elimina todo el riesgo.

## Contenido principal

### Qué es la diversificación

Diversificar significa repartir las inversiones entre varios activos distintos en lugar de concentrarlo todo en uno solo: es la idea básica detrás de la estructura de "canasta" de los ETF y los fondos de inversión que vimos antes.

### Qué tipo de riesgo reduce

La diversificación reduce específicamente el riesgo de concentración: el riesgo de que una sola inversión tenga un mal desempeño y arrastre todo un portafolio. Si una inversión entre muchas tiene un mal desempeño, su impacto en el total es menor que si fuera la única.

### Por qué no elimina todo el riesgo

La diversificación no protege contra las caídas generales de todo el mercado que afectan a muchas o a la mayoría de las inversiones a la vez, y no garantiza una ganancia. Maneja un tipo específico de riesgo, no todos los riesgos posibles.

## Ejemplo práctico

Un inversionista que solo tiene acciones de una empresa pierde mucho si a esa empresa le va mal. Un inversionista que tiene acciones de 50 empresas distintas se ve mucho menos afectado por el mal desempeño de cualquiera de ellas, aunque una caída general del mercado podría afectar de todos modos a las 50.

## Prueba de práctica

1. Diversificar significa:
   A. Invertirlo todo en un solo activo
   B. Repartir las inversiones entre varios activos distintos
   C. Evitar todo el riesgo de inversión
   D. Garantizar una ganancia
2. Verdadero o falso: La diversificación elimina todo el riesgo de inversión.
3. ¿Qué tipo específico de riesgo reduce principalmente la diversificación?
   A. El riesgo de todo el mercado
   B. El riesgo de concentración (depender demasiado de una sola inversión)
   C. Exclusivamente el riesgo cambiario
   D. Exclusivamente el riesgo de inflación

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Diversificar significa repartir las inversiones entre varios activos.

### Pregunta 2

Respuesta correcta: Falso. Reduce cierto riesgo, pero no elimina todo el riesgo, sobre todo el de las caídas generales del mercado.

### Pregunta 3

Respuesta correcta: B. El riesgo de concentración es el riesgo específico que atiende la diversificación.

## Puntos clave

- Diversificar significa repartir las inversiones entre varios activos.
- Reduce específicamente el riesgo de concentración.
- No elimina todo el riesgo ni garantiza una ganancia.
