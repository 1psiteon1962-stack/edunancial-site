---
id: WHITE-L1-014
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 14
locale: es-419
title: "¿Qué es el riesgo y por qué no es lo mismo que \"malo\"?"
summary: "Aprende cómo define este curso el riesgo de inversión, y por qué \"riesgo\" y \"malo\" no son el mismo concepto."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es el riesgo y por qué no es lo mismo que "malo"?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir el riesgo de inversión en palabras sencillas.
- Explicar por qué "riesgo" y "malo" son conceptos distintos.
- Explicar la relación general entre el riesgo y el rendimiento potencial.

## Contenido principal

### Qué significa aquí el riesgo

En las inversiones, el riesgo generalmente se refiere a la incertidumbre de un resultado: específicamente, a la posibilidad de que el rendimiento real de una inversión sea distinto del esperado, incluida la posibilidad de una pérdida.

### El riesgo no es lo mismo que "malo"

El riesgo describe incertidumbre, no un resultado negativo seguro. Una inversión "riesgosa" no es automáticamente una mala elección: significa que el rango de resultados posibles es más amplio, para bien o para mal, que el de una opción de menor riesgo.

### La relación general entre riesgo y rendimiento

Por lo general, las inversiones con un rendimiento potencial más alto tienden a tener más riesgo, y las inversiones con más certeza o seguridad tienden a ofrecer un rendimiento potencial más bajo. No es una garantía estricta en todos los casos, pero es un patrón común que vale la pena entender.

## Ejemplo práctico

Un bono del gobierno de un emisor estable generalmente se considera de menor riesgo, con un rendimiento modesto acorde. La acción de una empresa nueva generalmente se considera de mayor riesgo, con la posibilidad de un rendimiento mucho más alto (o mucho más bajo) que el del bono.

## Prueba de práctica

1. En las inversiones, el riesgo generalmente se refiere a:
   A. Una pérdida segura
   B. La incertidumbre del resultado real de una inversión
   C. Un tipo de dividendo
   D. Una regulación del gobierno
2. Verdadero o falso: Una inversión "riesgosa" es automáticamente una mala elección.
3. ¿Cuál es la relación general entre el riesgo y el rendimiento potencial?
   A. Un riesgo más alto generalmente no tiene relación con el rendimiento potencial
   B. Los rendimientos potenciales más altos generalmente vienen con más riesgo
   C. Menos riesgo siempre significa rendimientos más altos
   D. El riesgo y el rendimiento siempre son idénticos

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. El riesgo se refiere a la incertidumbre del resultado, no a una pérdida segura.

### Pregunta 2

Respuesta correcta: Falso. El riesgo describe incertidumbre, no un mal resultado automático.

### Pregunta 3

Respuesta correcta: B. Los rendimientos potenciales más altos generalmente van de la mano de un riesgo más alto.

## Puntos clave

- El riesgo se refiere a la incertidumbre del resultado, no a un mal resultado seguro.
- Una inversión riesgosa no es automáticamente una mala elección.
- Como patrón general, los rendimientos potenciales más altos vienen con más riesgo.
