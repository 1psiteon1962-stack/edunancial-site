---
id: WHITE-L1-015
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 15
locale: es-419
title: "¿Qué es la volatilidad?"
summary: "Aprende qué mide la volatilidad y por qué es distinta del riesgo de una pérdida permanente."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es la volatilidad?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir la volatilidad en palabras sencillas.
- Explicar qué mide específicamente la volatilidad.
- Distinguir la volatilidad de una pérdida permanente.

## Contenido principal

### Qué significa la volatilidad

La volatilidad se refiere a cuánto y qué tan rápido sube y baja el precio de un activo en un periodo determinado. Un activo muy volátil tiene cambios de precio grandes y frecuentes; un activo de baja volatilidad se mueve de forma más gradual.

### Qué mide específicamente

La volatilidad mide el movimiento del precio, no necesariamente la dirección ni el resultado final. Un activo puede ser muy volátil y aun así terminar más arriba con el tiempo: la volatilidad describe lo accidentado del camino, no automáticamente el destino.

### Volatilidad frente a pérdida permanente

Una caída temporal del precio de un activo volátil no es lo mismo que una pérdida permanente: si el precio se recupera después, un inversionista que no vendió durante la caída vive la volatilidad sin una pérdida duradera. La pérdida solo queda "asegurada" si el activo se vende al precio más bajo.

## Ejemplo práctico

El precio de una acción oscila entre $80 y $120 durante unos meses antes de estabilizarse cerca de $115: fue muy volátil en el camino, pero un inversionista que la conservó durante las oscilaciones terminó cerca de una ganancia, no de una pérdida.

## Prueba de práctica

1. La volatilidad mide:
   A. Una pérdida segura
   B. Cuánto y qué tan rápido sube y baja un precio
   C. La utilidad total de una empresa
   D. El número de acciones en circulación
2. Verdadero o falso: Una caída temporal del precio es automáticamente lo mismo que una pérdida permanente.
3. ¿Cuándo una pérdida en papel por la volatilidad se convierte en una pérdida asegurada?
   A. Nunca
   B. Cuando el activo se vende al precio más bajo
   C. Automáticamente después de un año
   D. En cuanto el precio baja, por poco que sea

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. La volatilidad mide el grado de movimiento del precio.

### Pregunta 2

Respuesta correcta: Falso. Una caída temporal no es una pérdida permanente a menos que el activo realmente se venda a ese precio más bajo.

### Pregunta 3

Respuesta correcta: B. Vender al precio más bajo es lo que asegura la pérdida.

## Puntos clave

- La volatilidad mide cuánto y qué tan rápido se mueve el precio.
- Describe el movimiento del precio, no automáticamente un resultado final.
- Una caída temporal no es una pérdida permanente a menos que se venda a ese precio.
