---
id: WHITE-L1-016
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 16
locale: es-419
title: "¿Qué es un mercado alcista y un mercado bajista?"
summary: "Aprende qué significan los mercados alcistas y bajistas, y por qué estas etiquetas describen una tendencia, no una garantía de lo que va a pasar."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es un mercado alcista y un mercado bajista?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir un mercado alcista y un mercado bajista.
- Explicar en qué se basan normalmente estas etiquetas.
- Explicar por qué describen una tendencia y no un futuro garantizado.

## Contenido principal

### Qué significa cada término

Un mercado alcista (en inglés, bull market) generalmente se refiere a un periodo sostenido de precios en aumento en un mercado. Un mercado bajista (bear market) generalmente se refiere a un periodo sostenido de precios en caída, que muchas veces se define de manera informal como una baja de un porcentaje importante (comúnmente alrededor del 20 %) desde un máximo reciente.

### En qué se basan las etiquetas

Estos términos describen una tendencia observada durante un periodo, no una predicción. Normalmente un mercado se llama "alcista" o "bajista" por movimientos de precio que ya ocurrieron, viendo hacia atrás o a un patrón sostenido actual.

### Por qué no son una garantía

Estar en un mercado alcista o bajista no garantiza lo que pasará después: los mercados pueden pasar de uno a otro, y nadie puede predecir de forma confiable cuándo exactamente ocurrirá ese cambio. Tratar las etiquetas actuales como un pronóstico es un supuesto común, pero riesgoso.

## Ejemplo práctico

Un mercado que ha subido de forma constante durante dos años podría describirse como un mercado alcista, pero esa etiqueta describe lo que ya pasó, no una garantía de que los precios seguirán subiendo.

## Prueba de práctica

1. Un mercado alcista generalmente se refiere a:
   A. Un periodo sostenido de precios en caída
   B. Un periodo sostenido de precios en aumento
   C. Un solo día de operaciones
   D. Un tipo de bono
2. Verdadero o falso: Que un mercado se considere "alcista" garantiza que los precios seguirán subiendo.
3. ¿En qué se basan normalmente las etiquetas de mercado alcista y bajista?
   A. En un anuncio del gobierno
   B. En una tendencia de precios observada durante un periodo
   C. En el informe de resultados de una sola empresa
   D. En el clima

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Un mercado alcista se refiere a una tendencia sostenida al alza.

### Pregunta 2

Respuesta correcta: Falso. La etiqueta describe una tendencia pasada o actual, no un futuro garantizado.

### Pregunta 3

Respuesta correcta: B. Estas etiquetas reflejan una tendencia de precios observada.

## Puntos clave

- Un mercado alcista es una tendencia sostenida al alza; un mercado bajista, una tendencia sostenida a la baja.
- Estas etiquetas describen una tendencia observada, no una predicción.
- Los mercados pueden pasar de uno a otro de forma impredecible.
