---
id: WHITE-L1-017
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 17
locale: es-419
title: "¿Qué es el interés compuesto? (La idea que todos mencionan, pero pocos explican)"
summary: "Aprende cómo funciona realmente el interés compuesto, paso a paso, y no solo como una palabra de moda."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es el interés compuesto? (La idea que todos mencionan, pero pocos explican)

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir el interés compuesto en palabras sencillas.
- Distinguirlo del interés simple.
- Calcular un ejemplo básico de crecimiento compuesto durante algunos periodos.

## Contenido principal

### Qué es el interés compuesto

El interés compuesto es el interés que se calcula no solo sobre el monto original invertido, sino también sobre los intereses que ya se han acumulado; es decir, el crecimiento se suma al crecimiento anterior, no solo al monto inicial.

### Interés compuesto frente a interés simple

El interés simple se calcula solo sobre el monto original, en cada periodo. El interés compuesto se calcula sobre el monto original más todos los intereses ganados antes: esa es justamente la razón por la que la capitalización se acelera con el tiempo.

### Un ejemplo paso a paso

Si empiezas con $1,000 a un interés compuesto anual del 10 %: después del año 1, tienes $1,100. Después del año 2, el interés se calcula sobre $1,100 (no solo sobre los $1,000 originales), lo que da $1,210. Después del año 3, se calcula sobre $1,210, lo que da $1,331: el crecimiento se acelera porque el interés de cada año se calcula sobre una base más grande.

## Ejemplo práctico

$1,000 a un interés simple del 10 % ganan exactamente $100 cada año: $1,100, $1,200, $1,300. Los mismos $1,000 a un interés compuesto del 10 % llegan a $1,100, $1,210, $1,331: una diferencia pequeña, pero creciente, que se amplía mucho en periodos más largos.

## Prueba de práctica

1. El interés compuesto se calcula sobre:
   A. Solo el monto original invertido
   B. El monto original más los intereses ganados antes
   C. Una tasa fija del gobierno
   D. Solo la aportación del año más reciente
2. Verdadero o falso: El interés simple y el interés compuesto dan resultados idénticos con el tiempo.
3. $1,000 crecen a $1,100 después del año 1 con un interés compuesto del 10 %. ¿A cuánto crecerían después del año 2?
   A. $1,100
   B. $1,200
   C. $1,210
   D. $1,300

## Clave de respuestas

1. B
2. Falso
3. C

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. El interés compuesto se acumula sobre el capital y sobre los intereses acumulados.

### Pregunta 2

Respuesta correcta: Falso. Con el tiempo, el interés compuesto crece más rápido que el interés simple.

### Pregunta 3

Respuesta correcta: C. $1,100 × 1.10 = $1,210 (un crecimiento del 10 % sobre la nueva base, más grande).

## Puntos clave

- El interés compuesto se calcula sobre el capital más los intereses acumulados.
- Esa es la diferencia clave frente al interés simple, que solo usa el monto original.
- La diferencia entre el interés compuesto y el simple se amplía en periodos más largos.
