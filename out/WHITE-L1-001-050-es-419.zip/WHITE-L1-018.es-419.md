---
id: WHITE-L1-018
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 18
locale: es-419
title: "¿Qué es un 401(k)?"
summary: "Aprende qué es un 401(k), cómo funciona normalmente y un beneficio común del empleador ligado a esta cuenta."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es un 401(k)?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir un 401(k) en palabras sencillas.
- Explicar cómo funcionan normalmente las aportaciones.
- Explicar qué es la aportación equivalente del empleador (employer match).

## Contenido principal

### Qué es un 401(k)

*(REGLA ESPECÍFICA POR REGIÓN: este es un tipo de cuenta de retiro propio de EE. UU. En América Latina existen sistemas distintos, como las AFORE en México o las AFP en varios países, con reglas propias.)* Un 401(k) es una cuenta de ahorro para el retiro patrocinada por el empleador, que permite a los empleados aportar una parte de su sueldo, muchas veces con ventajas fiscales, para su ahorro de retiro a largo plazo.

### Cómo funcionan normalmente las aportaciones

Por lo general, los empleados eligen un porcentaje o un monto de su sueldo para aportar de forma automática, que luego se invierte en las opciones que ofrece el plan del empleador (muchas veces un menú de fondos, que incluye opciones como los ETF y los fondos de inversión que vimos antes en este nivel).

### Qué es la aportación equivalente del empleador

Muchos empleadores ofrecen un "match": aportan dinero adicional según lo que aporte el empleado, hasta cierto límite. En la práctica es una compensación extra ligada específicamente a participar en el plan, y no aprovechar por completo una aportación equivalente disponible se menciona comúnmente como una oportunidad perdida.

## Ejemplo práctico

Un empleador ofrece igualar el 50 % de las aportaciones del empleado hasta el 6 % del salario. Un empleado que gana $50,000 y aporta el 6 % ($3,000) recibe $1,500 adicionales de la aportación equivalente del empleador: dinero que no recibiría si no aportara.

## Prueba de práctica

1. Un 401(k) es:
   A. Un tipo de cuenta de cheques
   B. Una cuenta de ahorro para el retiro patrocinada por el empleador
   C. Una pensión del gobierno que se paga automáticamente
   D. Un tipo de bono
2. Verdadero o falso: Todos los empleadores están obligados a ofrecer una aportación equivalente.
3. ¿Qué es una aportación equivalente del empleador?
   A. Una multa fiscal
   B. Aportaciones adicionales del empleador según lo que aporta el empleado
   C. Un tipo de préstamo
   D. Un pago fijo del gobierno

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Un 401(k) es una cuenta de retiro patrocinada por el empleador.

### Pregunta 2

Respuesta correcta: Falso. La aportación equivalente del empleador es común, pero no es obligatoria ni se ofrece en todos los casos.

### Pregunta 3

Respuesta correcta: B. La aportación equivalente es dinero adicional del empleador, ligado a las aportaciones del empleado.

## Puntos clave

- Un 401(k) es una cuenta de ahorro para el retiro patrocinada por el empleador.
- Normalmente las aportaciones son automáticas, mediante descuentos al sueldo.
- La aportación equivalente del empleador, cuando se ofrece, es en la práctica una compensación extra por participar.
