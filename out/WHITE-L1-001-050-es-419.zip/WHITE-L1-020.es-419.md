---
id: WHITE-L1-020
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 20
locale: es-419
title: "Tradicional frente a Roth: ¿qué cambia realmente en el tratamiento fiscal?"
summary: "Aprende la diferencia central de momento fiscal entre las cuentas de retiro tradicionales y las Roth."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# Tradicional frente a Roth: ¿qué cambia realmente en el tratamiento fiscal?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Explicar la diferencia central de momento fiscal entre las cuentas tradicionales y las Roth.
- Explicar cuándo se pagan impuestos en una cuenta tradicional.
- Explicar cuándo se pagan impuestos en una cuenta Roth.

## Contenido principal

### La diferencia central: cuándo se pagan los impuestos

*(REGLA ESPECÍFICA POR REGIÓN: esto describe un concepto fiscal de EE. UU.)* Tanto las cuentas tradicionales como las Roth (disponibles en versión 401(k) o IRA) ofrecen ventajas fiscales; la verdadera diferencia es CUÁNDO se aplica el beneficio fiscal, no que una sea mejor en todas las situaciones.

### Cuentas tradicionales

Las aportaciones a una cuenta tradicional muchas veces se hacen antes de impuestos, y los retiros en la jubilación generalmente pagan impuestos como ingreso en ese momento posterior.

### Cuentas Roth

Las aportaciones a una cuenta Roth se hacen con dinero que ya pagó impuestos, pero los retiros que califican en la jubilación generalmente están libres de impuestos: el impuesto se paga al principio y no después.

## Ejemplo práctico

Una aportación a una cuenta tradicional reduce el ingreso gravable hoy, y los impuestos se pagan después, al retirar. Una aportación Roth no da ningún beneficio fiscal hoy, pero los retiros que califican después generalmente están libres de impuestos: el mismo dólar, gravado en un momento distinto.

## Prueba de práctica

1. La diferencia central entre las cuentas tradicionales y las Roth es:
   A. Solo las cuentas tradicionales permiten invertir en acciones
   B. Cuándo se aplica la ventaja fiscal: ahora o después
   C. Las cuentas Roth son solo para empleadores
   D. No hay ninguna diferencia real
2. Verdadero o falso: Las aportaciones a una cuenta tradicional generalmente se hacen con dinero que ya pagó impuestos.
3. ¿Cuándo pagan impuestos, por lo general, los retiros Roth que califican?
   A. Al aportar
   B. Generalmente no pagan impuestos al retirarse, porque el impuesto se pagó al principio
   C. Dos veces: al aportar y al retirar
   D. Nunca se aportan con dinero real

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. El momento de la ventaja fiscal es la diferencia central.

### Pregunta 2

Respuesta correcta: Falso. Las aportaciones tradicionales muchas veces se hacen antes de impuestos.

### Pregunta 3

Respuesta correcta: B. En las cuentas Roth el impuesto se paga al principio, así que los retiros que califican generalmente están libres de impuestos después.

## Puntos clave

- Tanto las cuentas tradicionales como las Roth ofrecen ventajas fiscales, en momentos distintos.
- Tradicional: muchas veces con ventaja fiscal ahora y con impuestos después, al retirar.
- Roth: con impuestos ahora y generalmente libre de impuestos al hacer un retiro que califica después.
