---
id: WHITE-L1-022
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 22
locale: es-419
title: "¿Qué es el promedio del costo en dólares (dollar-cost averaging)?"
summary: "Aprende qué es el promedio del costo en dólares y por qué invertir un monto fijo de forma regular puede suavizar la volatilidad de los precios."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es el promedio del costo en dólares (dollar-cost averaging)?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir el promedio del costo en dólares en palabras sencillas.
- Explicar cómo se relaciona con la volatilidad de los precios.
- Reconocerlo como una estrategia, no como una garantía de ganancia.

## Contenido principal

### Qué es el promedio del costo en dólares

El promedio del costo en dólares (dollar-cost averaging) significa invertir un monto fijo de dinero en intervalos regulares (por ejemplo, cada mes), sin importar el precio del momento, en lugar de invertir una suma grande de una sola vez.

### Cómo se relaciona con la volatilidad

Como el monto invertido se mantiene fijo, se compran más acciones cuando los precios están más bajos y menos acciones cuando están más altos: esto promedia de forma natural el precio de compra con el tiempo, sin que el inversionista tenga que predecir los movimientos de precio.

### No es una garantía

El promedio del costo en dólares no garantiza una ganancia ni protege contra pérdidas: es una forma disciplinada de invertir con el tiempo, no una manera de eliminar todo el riesgo.

## Ejemplo práctico

Un inversionista pone $200 en una inversión cada mes. Cuando el precio está bajo, esos $200 compran más acciones; cuando el precio está alto, compran menos: a lo largo de un año, esto produce un precio de compra promedio sin que el inversionista tenga que adivinar el momento del mercado.

## Prueba de práctica

1. El promedio del costo en dólares significa:
   A. Invertir una suma grande de una sola vez
   B. Invertir un monto fijo en intervalos regulares, sin importar el precio
   C. Invertir solo cuando los precios están bajos
   D. Evitar todos los activos en papel
2. Verdadero o falso: El promedio del costo en dólares garantiza una ganancia.
3. Con el promedio del costo en dólares, ¿qué pasa con el número de acciones que se compran cuando el precio está más bajo?
   A. Se compran menos acciones
   B. Se compran más acciones con el mismo monto fijo
   C. No se compra ninguna acción
   D. El monto invertido aumenta automáticamente

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Monto fijo, intervalos regulares, sin importar el precio.

### Pregunta 2

Respuesta correcta: Falso. Es una estrategia disciplinada, no una garantía.

### Pregunta 3

Respuesta correcta: B. Un monto fijo en dólares compra más acciones cuando el precio está más bajo.

## Puntos clave

- El promedio del costo en dólares significa invertir un monto fijo en intervalos regulares.
- De forma natural compra más acciones cuando los precios están bajos y menos cuando están altos.
- Es una estrategia disciplinada, no una garantía contra pérdidas.
