---
id: WHITE-L1-023
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 23
locale: es-419
title: "¿Qué es un split (división) de acciones?"
summary: "Aprende qué cambia y qué no cambia en el valor de una empresa con un split de acciones."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es un split (división) de acciones?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir un split de acciones en palabras sencillas.
- Explicar qué cambia y qué no cambia en un split.
- Calcular un número básico de acciones y un precio después del split.

## Contenido principal

### Qué es un split de acciones

Un split de acciones divide cada acción existente en varias acciones nuevas, lo que reduce proporcionalmente el precio por acción y aumenta el número de acciones en circulación.

### Qué cambia y qué no

Aumenta el número de acciones que tiene un inversionista, y el precio por acción baja de forma proporcional. Lo que NO cambia: el valor total de lo que tiene el inversionista ni la capitalización de mercado total de la empresa: el pastel se corta en más rebanadas, pero el pastel sigue siendo del mismo tamaño.

### Por qué lo hacen las empresas

A veces las empresas dividen sus acciones para bajar el precio por acción a un rango más accesible para los inversionistas, aunque esto no cambia en absoluto el valor de fondo de la empresa.

## Ejemplo práctico

Un inversionista que tiene 10 acciones de $100 cada una ($1,000 en total) pasa por un split de 2 por 1. Ahora tiene 20 acciones de $50 cada una: siguen siendo $1,000 en total, solo que divididos en más acciones, más baratas.

## Prueba de práctica

1. Un split de acciones:
   A. Aumenta el valor de mercado total de una empresa
   B. Divide las acciones existentes en más acciones a un precio proporcionalmente más bajo
   C. Reduce el número de acciones en circulación
   D. Cambia el negocio de fondo de la empresa
2. Verdadero o falso: Un split de acciones cambia el valor total de lo que tiene un inversionista.
3. Un inversionista tiene 5 acciones de $200 cada una. Después de un split de 2 por 1, ¿cuántas acciones tiene y a qué precio?
   A. 5 acciones a $400
   B. 10 acciones a $100
   C. 2.5 acciones a $200
   D. 10 acciones a $200

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Un split divide las acciones de forma proporcional sin cambiar el valor total.

### Pregunta 2

Respuesta correcta: Falso. El valor total de lo que se tiene se mantiene igual inmediatamente después de un split.

### Pregunta 3

Respuesta correcta: B. 5 acciones × 2 = 10 acciones; $200 ÷ 2 = $100 por acción.

## Puntos clave

- Un split de acciones divide las acciones en más acciones a un precio proporcionalmente más bajo.
- El valor total de lo que se tiene y la capitalización de mercado no cambian por el split en sí.
- Las empresas dividen sus acciones principalmente para que el precio por acción sea más accesible.
