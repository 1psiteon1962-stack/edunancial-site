---
id: WHITE-L1-024
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 24
locale: es-419
title: "¿Qué son las acciones fraccionadas?"
summary: "Aprende qué son las acciones fraccionadas, cómo reducen la barrera para invertir y cómo pueden usarse para dimensionar el riesgo de forma adecuada para un principiante."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué son las acciones fraccionadas?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir una acción fraccionada en palabras sencillas.
- Explicar el problema de acceso que resuelven las acciones fraccionadas.
- Explicar cómo las acciones fraccionadas pueden usarse para dimensionar el riesgo de forma adecuada, no solo para poder pagar una acción de precio alto.

## Contenido principal

### Qué son las acciones fraccionadas

Una acción fraccionada es una porción de una sola acción, más pequeña que una acción completa, que permite a un inversionista comprar menos de una acción entera a la vez.

### El problema de acceso que resuelven

Antes de que las acciones fraccionadas estuvieran ampliamente disponibles, un inversionista necesitaba dinero suficiente para comprar al menos una acción completa: una barrera real en las acciones de precio más alto. Las acciones fraccionadas permiten que un inversionista con menos dinero obtenga de todos modos una exposición proporcional a esa misma acción.

### Un segundo uso, menos obvio: dimensionar el riesgo a propósito

Pregúntate: si le estás enseñando a alguien a invertir por primera vez —quizá a una persona joven con muy poco dinero—, ¿cuál es el verdadero peligro? No es solo "no poder pagar una acción". Es la posibilidad de una pérdida lo bastante grande como para hacerle daño de verdad. Una madre o un padre que le enseña a invertir a un adolescente, por ejemplo, podría usar una cuenta de acciones fraccionadas justamente para que una pérdida real se mantenga lo bastante pequeña como para ser una lección auténtica, y no un desastre. El tamaño de la posición, no solo lo que se puede pagar, es una decisión deliberada.

## Ejemplo práctico

Imagina a un padre que abre una pequeña cuenta de acciones fraccionadas para su hijo adolescente. ¿Por qué fraccionadas, en lugar de esperar a que el hijo pudiera pagar una acción completa? No solo para que técnicamente fuera dueño de una parte de una acción cara, sino para que, si la inversión perdía valor, la pérdida fuera lo bastante pequeña como para absorberla y aprender de ella, y no algo que pudiera atrasarlo seriamente. La lección no era solo "ya puedes darte el lujo de invertir", sino "puedes darte el lujo de equivocarte, sin peligro, mientras todavía estás aprendiendo".

## Prueba de práctica

1. Una acción fraccionada es:
   A. Una acción completa
   B. Una porción de una sola acción, más pequeña que una acción completa
   C. Un tipo de bono
   D. Un pago de dividendos garantizado
2. Verdadero o falso: Las acciones fraccionadas exigen que el inversionista tenga dinero suficiente para al menos una acción completa.
3. Además de que sean accesibles, ¿qué otra razón real podría tener alguien para elegir acciones fraccionadas para un inversionista principiante?
   A. Garantizar una ganancia
   B. Dimensionar la posición para que una posible pérdida se mantenga lo bastante pequeña como para ser una lección real y segura
   C. No perder dinero nunca
   D. Eliminar la necesidad de investigar

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Una acción fraccionada es menos de una acción completa.

### Pregunta 2

Respuesta correcta: Falso. Las acciones fraccionadas eliminan justamente ese requisito.

### Pregunta 3

Respuesta correcta: B. Dimensionar una posición para que una pérdida sea soportable y educativa, y no dañina, es un uso deliberado y real de la inversión fraccionada.

## Puntos clave

- Una acción fraccionada es una porción de una acción completa.
- Elimina la barrera de necesitar el precio de una acción completa para invertir.
- También puede usarse de forma deliberada para dimensionar una posición y que el riesgo sea adecuado, algo especialmente importante al enseñarle a un principiante.
