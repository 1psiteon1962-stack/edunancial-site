---
id: WHITE-L1-025
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 25
locale: es-419
title: "¿Qué es la utilidad por acción (UPA o EPS)?"
summary: "Aprende qué mide la utilidad por acción y cómo se calcula, como base para las lecciones de valuación más adelante."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es la utilidad por acción (UPA o EPS)?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Enunciar la fórmula de la UPA.
- Calcular una UPA básica a partir de la utilidad neta y las acciones en circulación.
- Explicar en palabras sencillas qué representa la UPA.

## Contenido principal

### La fórmula de la UPA

Utilidad por acción (UPA; en inglés, EPS) = Utilidad neta ÷ Acciones en circulación. Reparte la utilidad total de una empresa entre cada acción individual.

### Qué representa la UPA

La UPA representa cuánta utilidad le corresponde a cada acción: una forma de expresar la utilidad total de una empresa por acción, lo que facilita comparar empresas de distintos tamaños.

### Por qué esto importa más adelante

La UPA es la base de varios conceptos de valuación que se ven con más profundidad en el Nivel 2: entender ahora lo que mide prepara ese material posterior.

## Ejemplo práctico

Una empresa con $5,000,000 de utilidad neta y 1,000,000 de acciones en circulación tiene una UPA de $5,000,000 ÷ 1,000,000 = $5.00 por acción.

## Prueba de práctica

1. La UPA se calcula como:
   A. Precio de la acción ÷ utilidad neta
   B. Utilidad neta ÷ acciones en circulación
   C. Ingresos totales ÷ gastos totales
   D. Acciones en circulación ÷ utilidad neta
2. Verdadero o falso: La UPA representa la utilidad total de una empresa, no una cifra por acción.
3. Una empresa tiene $2,000,000 de utilidad neta y 500,000 acciones en circulación. ¿Cuál es su UPA?
   A. $0.25
   B. $2.50
   C. $4.00
   D. $250

## Clave de respuestas

1. B
2. Falso
3. C

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. UPA = Utilidad neta ÷ Acciones en circulación.

### Pregunta 2

Respuesta correcta: Falso. La UPA expresa específicamente la utilidad por acción.

### Pregunta 3

Respuesta correcta: C. $2,000,000 ÷ 500,000 = $4.00.

## Puntos clave

- UPA = Utilidad neta ÷ Acciones en circulación.
- Expresa la utilidad de una empresa por acción.
- Es la base de conceptos de valuación que se ven con más profundidad más adelante.
