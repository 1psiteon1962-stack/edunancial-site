---
id: WHITE-L1-026
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 26
locale: es-419
title: "¿Qué es la relación precio/utilidad (P/U o P/E)? (Versión introductoria; el método completo, en el Nivel 2)"
summary: "Aprende la fórmula básica de la relación precio/utilidad y qué estima, como introducción a la valuación que se ve con más profundidad en el Nivel 2."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es la relación precio/utilidad (P/U o P/E)? (Versión introductoria; el método completo, en el Nivel 2)

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Enunciar la fórmula básica de la relación precio/utilidad.
- Calcular una relación precio/utilidad básica a partir del precio de la acción y la UPA.
- Explicar, a nivel introductorio, qué estima esta relación.

## Contenido principal

### La fórmula básica

Relación precio/utilidad (P/U; en inglés, P/E) = Precio de la acción ÷ Utilidad por acción (UPA). Se apoya directamente en el concepto de UPA de la lección anterior.

### Qué estima

La relación P/U responde, de forma aproximada: ¿cuánto están pagando hoy los inversionistas por cada dólar de la utilidad actual de una empresa? Un número más alto significa que los inversionistas pagan más por cada dólar de utilidad actual.

### Un adelanto, no la imagen completa

*SUPUESTO (con fines didácticos):* Esta lección introductoria cubre solo la fórmula básica. Un tratamiento completo —incluido cómo comparar entre industrias y cómo las recompras de acciones pueden distorsionar la relación— se ve en el Nivel 2.

## Ejemplo práctico

Una acción cotiza a $60 por acción y tiene una UPA de $3.00. P/U = $60 ÷ $3.00 = 20: los inversionistas pagan $20 por cada $1 de la utilidad actual de esa empresa.

## Prueba de práctica

1. La fórmula de la relación P/U es:
   A. UPA ÷ Precio de la acción
   B. Precio de la acción ÷ UPA
   C. Utilidad neta ÷ Precio de la acción
   D. Acciones en circulación ÷ UPA
2. Verdadero o falso: Una relación P/U más alta significa que los inversionistas pagan menos por cada dólar de utilidad actual.
3. Una acción cotiza a $80 y tiene una UPA de $4.00. ¿Cuál es su relación P/U?
   A. 4
   B. 20
   C. 80
   D. 320

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. P/U = Precio de la acción ÷ UPA.

### Pregunta 2

Respuesta correcta: Falso. Una P/U más alta significa pagar más por cada dólar de utilidad.

### Pregunta 3

Respuesta correcta: B. $80 ÷ $4.00 = 20.

## Puntos clave

- Relación P/U = Precio de la acción ÷ UPA.
- Estima cuánto pagan los inversionistas por cada dólar de utilidad actual.
- Esta es una versión introductoria: el Nivel 2 cubre su aplicación más profunda y sus limitaciones.
