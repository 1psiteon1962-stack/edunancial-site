---
id: WHITE-L1-027
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 27
locale: es-419
title: "¿Qué es el rendimiento (yield)?"
summary: "Aprende qué mide el rendimiento en distintos activos en papel y en qué se diferencia de la ganancia por aumento de precio."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es el rendimiento (yield)?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir el rendimiento en palabras sencillas.
- Calcular un rendimiento básico a partir del ingreso y el precio.
- Distinguir el rendimiento de la ganancia por aumento de precio.

## Contenido principal

### Qué significa el rendimiento

El rendimiento (yield) generalmente mide el ingreso que genera una inversión (como los dividendos de una acción o los intereses de un bono), expresado como porcentaje de su precio.

### La fórmula básica

Rendimiento = Ingreso anual ÷ Precio actual. En una acción, el "ingreso" normalmente son los dividendos; en un bono, normalmente son los pagos de intereses.

### Rendimiento frente a aumento de precio

El rendimiento mide específicamente el ingreso, no la ganancia por precio. Una acción podría tener un rendimiento alto por sus dividendos mientras su precio se mantiene sin cambios, o un rendimiento bajo mientras su precio sube mucho: son dos fuentes separadas de rendimiento potencial, no lo mismo.

## Ejemplo práctico

Una acción cotiza a $50 y paga $2 de dividendos al año. Rendimiento = $2 ÷ $50 = 4 %. Esto es aparte y no incluye ningún cambio en el precio de la acción misma.

## Prueba de práctica

1. El rendimiento se calcula como:
   A. Aumento de precio ÷ tiempo que se mantuvo la inversión
   B. Ingreso anual ÷ precio actual
   C. Total de acciones ÷ utilidad neta
   D. Precio de la acción ÷ UPA
2. Verdadero o falso: El rendimiento mide el aumento de precio, no el ingreso.
3. Un bono paga $40 al año y tiene un precio de $1,000. ¿Cuál es su rendimiento?
   A. 0.4 %
   B. 4 %
   C. 40 %
   D. 400 %

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Rendimiento = Ingreso anual ÷ Precio actual.

### Pregunta 2

Respuesta correcta: Falso. El rendimiento mide el ingreso, no el aumento de precio.

### Pregunta 3

Respuesta correcta: B. $40 ÷ $1,000 = 4 %.

## Puntos clave

- Rendimiento = Ingreso anual ÷ Precio actual.
- Mide el ingreso (dividendos o intereses), no el aumento de precio.
- El ingreso y el aumento de precio son dos fuentes separadas de rendimiento potencial.
