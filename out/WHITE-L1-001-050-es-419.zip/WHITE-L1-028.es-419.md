---
id: WHITE-L1-028
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 28
locale: es-419
title: "¿Qué es la fecha de vencimiento de un bono?"
summary: "Aprende qué es la fecha de vencimiento y por qué los bonos con vencimientos distintos se comportan de forma distinta."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es la fecha de vencimiento de un bono?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir la fecha de vencimiento en palabras sencillas.
- Explicar qué pasa al vencimiento.
- Reconocer que el plazo al vencimiento afecta el comportamiento de un bono.

## Contenido principal

### Qué es la fecha de vencimiento

La fecha de vencimiento de un bono es la fecha en que el emisor se comprometió a devolverle por completo al tenedor el valor nominal del bono (el principal): el final del plazo del préstamo que se presentó en la lección anterior sobre bonos.

### Qué pasa al vencimiento

Al vencimiento, el tenedor recibe de vuelta el valor nominal del bono y se dejan de pagar intereses, porque el préstamo se considera totalmente pagado.

### Por qué importa el plazo al vencimiento

Los bonos con vencimientos más largos (fechas de pago más lejanas) generalmente son más sensibles a los cambios en las condiciones de las tasas de interés que los bonos con vencimientos más cortos: un concepto que se ve con más profundidad en una lección posterior sobre el riesgo de tasa de interés.

## Ejemplo práctico

Un bono a 2 años y un bono a 20 años podrían tener hoy tasas de cupón parecidas, pero el precio del bono a 20 años normalmente reaccionará de forma más marcada a los cambios futuros en las tasas de interés, simplemente porque le falta mucho más tiempo para vencer.

## Prueba de práctica

1. La fecha de vencimiento de un bono es:
   A. Cuando empiezan los pagos de intereses
   B. Cuando el emisor devuelve por completo el valor nominal del bono
   C. La fecha en que se compró el bono
   D. Una fecha que fija el tenedor del bono
2. Verdadero o falso: Los pagos de intereses continúan de forma indefinida después de que un bono vence.
3. ¿Qué tipo de bono es generalmente más sensible a los cambios en las tasas de interés?
   A. Un bono de vencimiento más corto
   B. Un bono de vencimiento más largo
   C. El plazo al vencimiento no afecta la sensibilidad
   D. Solo los bonos sin fecha de vencimiento

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. El vencimiento es cuando se devuelve por completo el valor nominal.

### Pregunta 2

Respuesta correcta: Falso. Los pagos de intereses se detienen cuando el bono vence y se paga.

### Pregunta 3

Respuesta correcta: B. Los bonos de vencimiento más largo generalmente son más sensibles a los cambios de tasa.

## Puntos clave

- La fecha de vencimiento de un bono es cuando se devuelve por completo el valor nominal.
- Los pagos de intereses se detienen al llegar al vencimiento.
- Los bonos de vencimiento más largo generalmente son más sensibles a los cambios en las tasas de interés.
