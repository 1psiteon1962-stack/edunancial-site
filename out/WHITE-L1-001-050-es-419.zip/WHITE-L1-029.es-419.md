---
id: WHITE-L1-029
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 29
locale: es-419
title: "¿Qué es el riesgo de crédito en un bono?"
summary: "Aprende qué significa el riesgo de crédito en un bono y cómo se relaciona con el hecho de que algunos bonos paguen más intereses que otros."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es el riesgo de crédito en un bono?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir el riesgo de crédito en palabras sencillas.
- Explicar cómo se relaciona el riesgo de crédito con la tasa de interés de un bono.
- Reconocer que no todos los emisores de bonos tienen el mismo riesgo de crédito.

## Contenido principal

### Qué es el riesgo de crédito

El riesgo de crédito es el riesgo de que el emisor de un bono no pueda hacer los pagos de intereses prometidos ni devolver el principal al vencimiento; dicho de otra forma, es el riesgo de incumplimiento (default).

### Cómo se relaciona con la tasa de interés

Los emisores que se consideran de mayor riesgo de crédito generalmente tienen que ofrecer una tasa de cupón más alta para atraer prestamistas, como compensación a los inversionistas por asumir ese riesgo adicional. Los emisores que se consideran de muy bajo riesgo (como los gobiernos estables) generalmente pueden pedir prestado a tasas más bajas.

### No todos los emisores son iguales

Una empresa grande y financieramente estable y una empresa más pequeña con problemas financieros que emiten bonos no tienen el mismo riesgo de crédito, aunque sus bonos se vean parecidos a simple vista: por eso existen las calificaciones de los bonos (que se ven en el Nivel 2), para ayudar a evaluar este riesgo.

## Ejemplo práctico

Un gobierno financieramente sólido podría emitir bonos a una tasa de interés baja, lo que refleja un riesgo de crédito bajo. Una empresa con dificultades financieras podría necesitar ofrecer una tasa de interés mucho más alta en sus bonos para atraer inversionistas dispuestos a asumir el riesgo adicional de incumplimiento.

## Prueba de práctica

1. El riesgo de crédito en un bono se refiere a:
   A. El riesgo de perder un certificado en papel
   B. El riesgo de que el emisor no pague los intereses o el principal como lo prometió
   C. El riesgo de un split de acciones
   D. El riesgo de una caída de todo el mercado
2. Verdadero o falso: Los emisores con mayor riesgo de crédito generalmente ofrecen tasas de interés más bajas.
3. ¿Por qué una empresa con dificultades financieras podría necesitar ofrecer una tasa de interés más alta en sus bonos?
   A. Para compensar a los inversionistas por un riesgo de incumplimiento más alto
   B. Porque el gobierno lo exige
   C. Para reducir su capitalización de mercado
   D. Los bonos siempre tienen la misma tasa, sin importar el riesgo

## Clave de respuestas

1. B
2. Falso
3. A

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. El riesgo de crédito es el riesgo de incumplimiento en los intereses o el principal.

### Pregunta 2

Respuesta correcta: Falso. Los emisores con mayor riesgo de crédito generalmente tienen que ofrecer tasas más altas.

### Pregunta 3

Respuesta correcta: A. Las tasas más altas compensan a los inversionistas por asumir el riesgo de incumplimiento.

## Puntos clave

- El riesgo de crédito es el riesgo de que un emisor incumpla con un bono.
- Un riesgo de crédito más alto generalmente significa una tasa de interés ofrecida más alta.
- No todos los emisores de bonos tienen el mismo nivel de riesgo de crédito.
