---
id: WHITE-L1-030
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 30
locale: es-419
title: "¿Qué es el riesgo de tasa de interés?"
summary: "Aprende cómo los cambios en las tasas de interés afectan el precio de los bonos existentes y por qué la relación se mueve en direcciones opuestas."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es el riesgo de tasa de interés?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir el riesgo de tasa de interés en palabras sencillas.
- Explicar la relación inversa básica entre las tasas y el precio de los bonos.
- Explicar por qué esto le importa a quien ya tiene un bono.

## Contenido principal

### Qué es el riesgo de tasa de interés

El riesgo de tasa de interés es el riesgo de que los cambios en las tasas de interés generales afecten el valor de mercado de los bonos existentes; es distinto del riesgo de crédito, que tiene que ver con la capacidad de pago del emisor.

### La relación inversa

Cuando las tasas de interés generales suben, el precio de mercado de los bonos existentes con tasas fijas más bajas generalmente baja, porque se están emitiendo bonos nuevos a la tasa actual, más alta y más atractiva. Cuando las tasas generales bajan, los bonos existentes con tasas más altas generalmente se vuelven más valiosos en comparación.

### Por qué le importa a quien ya tiene un bono

Un tenedor que necesita vender antes del vencimiento está expuesto a este movimiento de precio. Un tenedor que conserva el bono hasta el vencimiento recibe de todos modos el valor nominal: el riesgo de tasa de interés afecta principalmente el precio de mercado del bono antes del vencimiento, no el pago final en sí.

## Ejemplo práctico

Un inversionista tiene un bono que paga un 3 % de interés. Las tasas de interés generales suben al 5 %. Los bonos nuevos ahora ofrecen la tasa más atractiva del 5 %, lo que hace que el bono anterior del 3 % sea menos atractivo para un posible comprador: su precio de mercado generalmente bajaría si se vendiera antes del vencimiento.

## Prueba de práctica

1. El riesgo de tasa de interés se refiere a:
   A. El riesgo de que un emisor incumpla
   B. El riesgo de que los cambios en las tasas afecten el precio de los bonos existentes
   C. El riesgo de un split de acciones
   D. El riesgo cambiario
2. Verdadero o falso: Cuando las tasas de interés generales suben, el precio de los bonos existentes de tasa más baja generalmente también sube.
3. ¿Un tenedor que conserva el bono hasta el vencimiento recibe de todos modos el valor nominal completo, a pesar del riesgo de tasa de interés?
   A. No, pierde la diferencia
   B. Sí, el valor nominal generalmente se paga de todos modos al vencimiento
   C. Solo si las tasas bajaron
   D. Solo si el bono se vendió antes

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. El riesgo de tasa de interés afecta el precio de mercado de los bonos existentes cuando cambian las tasas.

### Pregunta 2

Respuesta correcta: Falso. El aumento de las tasas generalmente hace bajar el precio de los bonos existentes de tasa más baja.

### Pregunta 3

Respuesta correcta: B. Conservar el bono hasta el vencimiento generalmente sigue dando el valor nominal completo, sin importar las variaciones de precio intermedias.

## Puntos clave

- El riesgo de tasa de interés afecta el precio de los bonos existentes cuando cambian las tasas generales.
- El aumento de las tasas generalmente hace bajar el precio de los bonos existentes de tasa más baja, y viceversa.
- Conservar el bono hasta el vencimiento generalmente sigue dando el valor nominal, sin importar el movimiento de precio intermedio.
