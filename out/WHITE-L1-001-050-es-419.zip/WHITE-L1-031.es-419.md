---
id: WHITE-L1-031
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 31
locale: es-419
title: "¿Qué es la inflación y por qué cambia silenciosamente lo que vale tu dinero?"
summary: "Aprende qué significa la inflación y por qué reduce en silencio el poder de compra, aunque el saldo de una cuenta bancaria siga igual."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es la inflación y por qué cambia silenciosamente lo que vale tu dinero?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir la inflación en palabras sencillas.
- Explicar por qué un saldo bancario que no cambia puede de todos modos perder valor real.
- Relacionar la inflación con el costo real de tener solo efectivo.

## Contenido principal

### Qué es la inflación

La inflación es un aumento general de los precios con el tiempo, lo que significa que cada unidad de moneda compra menos que antes.

### Por qué un saldo que no cambia puede perder valor

Si los precios suben un 3 % en un año y un saldo bancario no gana intereses, ese dinero ahora puede comprar aproximadamente un 3 % menos que un año antes: la cifra en la cuenta no bajó, pero su poder de compra real sí.

### Por qué esto importa para invertir

Como la inflación reduce el poder de compra con el tiempo, tener efectivo sin ningún rendimiento no es realmente "seguro" en todos los sentidos: tiene el riesgo real de perder valor frente al aumento de los precios, una razón clave por la que mucha gente invierte en lugar de solo guardar efectivo a largo plazo.

## Ejemplo práctico

$1,000 en una cuenta que no paga intereses durante un año, con una inflación del 3 %, pueden comprar el equivalente a unos $970 de lo que podían comprar un año antes, aunque la cuenta siga mostrando $1,000.

## Prueba de práctica

1. La inflación se refiere a:
   A. Una baja de los precios con el tiempo
   B. Un aumento general de los precios con el tiempo
   C. Un tipo de bono
   D. Un impuesto del gobierno
2. Verdadero o falso: Un saldo bancario que no cambia siempre está a salvo de perder valor real.
3. ¿Por qué tener efectivo a largo plazo podría implicar un riesgo real?
   A. El efectivo nunca puede perder valor
   B. La inflación puede reducir su poder de compra con el tiempo
   C. El efectivo siempre gana intereses altos
   D. No hay ningún riesgo en tener efectivo

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. La inflación es un aumento general de los precios con el tiempo.

### Pregunta 2

Respuesta correcta: Falso. La inflación puede reducir el valor real aunque el saldo nominal no cambie.

### Pregunta 3

Respuesta correcta: B. La inflación reduce el poder de compra, un riesgo real de tener efectivo a largo plazo.

## Puntos clave

- La inflación es un aumento general de los precios que reduce el poder de compra.
- Un saldo que no cambia puede de todos modos perder valor real por la inflación.
- Tener efectivo a largo plazo implica un riesgo real que muchas veces se subestima.
