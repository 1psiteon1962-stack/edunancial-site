---
id: WHITE-L1-032
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 32
locale: es-419
title: "¿Qué es la liquidez, en palabras sencillas?"
summary: "Aprende qué significa la liquidez y por qué algunos activos pueden convertirse en efectivo más rápido que otros."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es la liquidez, en palabras sencillas?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir la liquidez en palabras sencillas.
- Comparar la liquidez de distintos tipos de activos.
- Explicar por qué la liquidez importa para la planeación financiera.

## Contenido principal

### Qué significa la liquidez

La liquidez se refiere a qué tan rápido y qué tan fácil se puede convertir un activo en efectivo sin una pérdida importante de valor.

### Comparar la liquidez entre activos

Una acción que cotiza en bolsa generalmente es muy líquida: muchas veces puede venderse en segundos durante el horario del mercado, a un precio cercano al actual. Los bienes raíces, en cambio, generalmente son mucho menos líquidos: vender una propiedad normalmente toma semanas o meses e implica costos de transacción importantes, una diferencia que se mencionó antes en este nivel.

### Por qué importa la liquidez

El dinero que podría necesitarse rápido (un fondo de emergencia, por ejemplo) generalmente debe estar en activos muy líquidos. El dinero que no se va a necesitar durante mucho tiempo puede colocarse de forma más razonable en inversiones menos líquidas, que a veces ofrecen otras ventajas a cambio.

## Ejemplo práctico

Un inversionista que necesita acceso rápido a efectivo para una emergencia generalmente querría tener ese dinero en un activo líquido, como una cuenta de ahorro o una acción fácil de vender, no atado a una propiedad que podría tardar meses en venderse.

## Prueba de práctica

1. La liquidez se refiere a:
   A. Cuánto vale un activo
   B. Qué tan rápido y fácil se puede convertir un activo en efectivo
   C. Un tipo de dividendo
   D. La tasa de interés de un bono
2. Verdadero o falso: Los bienes raíces generalmente son más líquidos que una acción que cotiza en bolsa.
3. ¿Por qué un fondo de emergencia debería estar en un activo muy líquido?
   A. La liquidez no importa en las emergencias
   B. Podría necesitarse acceso rápido al efectivo sin previo aviso
   C. Los activos poco líquidos siempre pagan intereses más altos
   D. Los fondos de emergencia siempre deben estar en bienes raíces

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. La liquidez tiene que ver con la facilidad y la rapidez para convertir en efectivo.

### Pregunta 2

Respuesta correcta: Falso. Las acciones generalmente son mucho más líquidas que los bienes raíces.

### Pregunta 3

Respuesta correcta: B. Las emergencias exigen acceso rápido, lo que favorece los activos líquidos.

## Puntos clave

- La liquidez es qué tan rápido y fácil un activo se convierte en efectivo.
- Las acciones generalmente son muy líquidas; los bienes raíces, generalmente mucho menos.
- El dinero que se necesita rápido generalmente debe estar en activos líquidos.
