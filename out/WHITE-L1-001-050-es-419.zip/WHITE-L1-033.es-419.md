---
id: WHITE-L1-033
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 33
locale: es-419
title: "¿Qué es un fondo del mercado de dinero?"
summary: "Aprende qué es un fondo del mercado de dinero y por qué generalmente se considera una opción de menor riesgo y más líquida que otros fondos."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es un fondo del mercado de dinero?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir un fondo del mercado de dinero en palabras sencillas.
- Explicar en qué invierte normalmente.
- Explicar por qué generalmente se considera de menor riesgo que un fondo de acciones.

## Contenido principal

### Qué es un fondo del mercado de dinero

Un fondo del mercado de dinero (money market fund; en varios países se conocen como fondos de deuda de corto plazo) es un tipo de fondo de inversión que invierte en instrumentos de deuda de corto plazo y generalmente de alta calidad, con el objetivo de dar estabilidad y liquidez más que un crecimiento importante.

### En qué invierte normalmente

Los fondos del mercado de dinero comúnmente tienen cosas como deuda gubernamental de corto plazo y otros préstamos de muy corto plazo y de alta calidad crediticia: inversiones elegidas en general por su estabilidad más que por su potencial de crecimiento.

### Por qué generalmente es de menor riesgo

Como tiene deuda de corto plazo y de alta calidad, un fondo del mercado de dinero generalmente se considera de menor riesgo y de valor más estable que un fondo de acciones, aunque no está completamente libre de riesgo y, como contraparte, normalmente ofrece rendimientos más modestos.

## Ejemplo práctico

Un inversionista que quiere un lugar relativamente estable para tener efectivo que podría necesitar pronto, y aun así ganar algún rendimiento, podría usar un fondo del mercado de dinero en lugar de un fondo enfocado en acciones, con más volatilidad.

## Prueba de práctica

1. Un fondo del mercado de dinero normalmente invierte en:
   A. Acciones de tecnología de alto crecimiento
   B. Instrumentos de deuda de corto plazo y de alta calidad
   C. Bienes raíces de forma directa
   D. Exclusivamente criptomonedas
2. Verdadero o falso: Los fondos del mercado de dinero generalmente se consideran de mayor riesgo que los fondos de acciones.
3. ¿Por qué podría un inversionista usar un fondo del mercado de dinero?
   A. Para maximizar el potencial de crecimiento a largo plazo
   B. Por su relativa estabilidad y liquidez
   C. Para evitar por completo cualquier tipo de riesgo
   D. Para comprar bienes raíces

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Los fondos del mercado de dinero tienen deuda de corto plazo y de alta calidad.

### Pregunta 2

Respuesta correcta: Falso. Generalmente se consideran de menor riesgo que los fondos de acciones.

### Pregunta 3

Respuesta correcta: B. La estabilidad y la liquidez son su atractivo central.

## Puntos clave

- Un fondo del mercado de dinero invierte en deuda de corto plazo y de alta calidad.
- Generalmente se considera de menor riesgo y más estable que los fondos de acciones.
- Cambia un mayor potencial de crecimiento por estabilidad y liquidez.
