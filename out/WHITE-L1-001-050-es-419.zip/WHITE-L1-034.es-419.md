---
id: WHITE-L1-034
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 34
locale: es-419
title: "¿Qué es un CD (certificado de depósito o depósito a plazo fijo)?"
summary: "Aprende qué es un CD, cómo inmoviliza el dinero a cambio de un rendimiento y cuál es la disyuntiva real de retirarlo antes de tiempo."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es un CD (certificado de depósito o depósito a plazo fijo)?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir un CD en palabras sencillas.
- Explicar la disyuntiva básica que ofrece un CD.
- Explicar qué pasa normalmente si se retira el dinero antes de tiempo.

## Contenido principal

### Qué es un CD

Un CD (certificado de depósito; en muchos países de América Latina, un depósito a plazo fijo o pagaré bancario) es un producto de ahorro que ofrecen los bancos, en el que el dinero se deposita por un periodo fijo a cambio de una tasa de interés fija, generalmente más alta que la de una cuenta de ahorro estándar.

### La disyuntiva básica

A cambio de una tasa de interés normalmente más alta y garantizada, el depositante generalmente se compromete a no retirar el dinero hasta que termine el plazo del CD: cambia liquidez (que se vio en la lección anterior) por una mejor tasa.

### Qué pasa si se retira antes de tiempo

Retirar dinero de un CD antes de que termine su plazo generalmente genera una penalización, que muchas veces reduce o elimina parte de los intereses ganados: esa penalización es el costo real de romper la disyuntiva de liquidez.

## Ejemplo práctico

Un inversionista pone $5,000 en un CD a 1 año con una tasa fija y se compromete a no tocarlos durante un año. Si necesita el dinero después de 6 meses, normalmente puede retirarlo, pero probablemente enfrentará una penalización que reduce los intereses que habría ganado.

## Prueba de práctica

1. Un CD generalmente ofrece:
   A. Liquidez total sin ningún beneficio de tasa
   B. Una tasa de interés fija a cambio de inmovilizar el dinero por un plazo determinado
   C. Propiedad de una parte de una empresa
   D. Rendimientos garantizados de alto crecimiento
2. Verdadero o falso: Retirar dinero de un CD antes de tiempo siempre es gratis, sin ninguna penalización.
3. ¿Qué cambia un CD por una tasa de interés normalmente más alta?
   A. Diversificación
   B. Liquidez: el dinero generalmente queda inmovilizado por un plazo determinado
   C. Derechos de propiedad
   D. Protección contra el riesgo de crédito

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Un CD cambia liquidez por una tasa fija, muchas veces más alta.

### Pregunta 2

Respuesta correcta: Falso. Retirar antes de tiempo generalmente genera una penalización.

### Pregunta 3

Respuesta correcta: B. La liquidez es lo que se cambia por el beneficio de la tasa.

## Puntos clave

- Un CD ofrece una tasa fija a cambio de inmovilizar el dinero por un plazo.
- Esto cambia liquidez por una tasa de interés normalmente mejor.
- Retirar antes de tiempo generalmente genera una penalización real.
