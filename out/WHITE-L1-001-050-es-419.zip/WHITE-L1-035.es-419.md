---
id: WHITE-L1-035
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 35
locale: es-419
title: "¿Qué es un fondo de emergencia y por qué va antes de invertir?"
summary: "Aprende qué es un fondo de emergencia y por qué este curso lo trata como un paso previo antes de otras inversiones."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es un fondo de emergencia y por qué va antes de invertir?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir un fondo de emergencia en palabras sencillas.
- Explicar por qué generalmente se recomienda antes de otras inversiones.
- Explicar por qué debe estar en un lugar líquido y de bajo riesgo.

## Contenido principal

### Qué es un fondo de emergencia

Un fondo de emergencia es dinero apartado específicamente para cubrir gastos inesperados o interrupciones de ingresos (la pérdida del empleo, una reparación urgente, un gasto médico), no para invertir ni para gastos planeados.

### Por qué generalmente va primero

Sin un fondo de emergencia, un gasto inesperado podría obligar a alguien a vender inversiones en un mal momento (posiblemente con pérdida) o a endeudarse con intereses altos. Tener primero este colchón protege otros planes financieros de largo plazo para que no se vean interrumpidos por emergencias de corto plazo.

### Por qué debe estar en un lugar líquido

Retomando la lección sobre liquidez que vimos antes en este nivel, un fondo de emergencia necesita estar disponible rápido, sin penalización ni riesgo de pérdida: por eso normalmente debe estar en algo como una cuenta de ahorro o un fondo del mercado de dinero, no en acciones ni en un CD con penalizaciones por retiro.

## Ejemplo práctico

Alguien que invierte todos sus ahorros en acciones, sin un fondo de emergencia, podría verse obligado a vender esas acciones con pérdida durante una caída del mercado solo para pagar una reparación inesperada del auto: justamente la situación que un fondo de emergencia busca evitar.

## Prueba de práctica

1. Un fondo de emergencia es:
   A. Dinero invertido para crecer a largo plazo
   B. Dinero apartado específicamente para gastos inesperados o interrupciones de ingresos
   C. Un tipo de cuenta de retiro
   D. Una póliza de seguro obligatoria
2. Verdadero o falso: Generalmente se recomienda invertir el fondo de emergencia en acciones para obtener el máximo crecimiento.
3. ¿Por qué se recomienda tener un fondo de emergencia antes de otras inversiones?
   A. No tiene ningún beneficio real
   B. Evita tener que vender inversiones en un mal momento durante una emergencia
   C. Garantiza ganancias en las inversiones
   D. Reemplaza la necesidad de tener seguros

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Un fondo de emergencia cubre gastos inesperados o interrupciones de ingresos.

### Pregunta 2

Respuesta correcta: Falso. Generalmente debe estar en un lugar líquido y de bajo riesgo, no en acciones.

### Pregunta 3

Respuesta correcta: B. Evita ventas forzadas de inversiones, en mal momento, durante una emergencia.

## Puntos clave

- Un fondo de emergencia cubre gastos inesperados, no inversiones planeadas.
- Generalmente va antes de otras inversiones para proteger los planes de largo plazo.
- Debe estar en un lugar líquido y de bajo riesgo, disponible sin penalización.
