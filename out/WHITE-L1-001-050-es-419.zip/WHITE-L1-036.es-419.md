---
id: WHITE-L1-036
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 36
locale: es-419
title: "¿Qué es el valor en dinero frente al valor real (poder de compra)?"
summary: "Aprende la diferencia entre la cantidad de dinero en cifras y su poder de compra real, apoyándote directamente en la lección sobre inflación."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es el valor en dinero frente al valor real (poder de compra)?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Distinguir el valor en dinero (nominal) del valor real (poder de compra).
- Explicar por qué comparar cantidades de dinero de distintas épocas puede ser engañoso.
- Aplicar esta distinción a un ejemplo básico.

## Contenido principal

### Valor en dinero (nominal) frente a valor real

El valor en dinero, o valor nominal, es simplemente la cifra que aparece en la cuenta o en el recibo de sueldo. El valor real es lo que ese dinero puede comprar de verdad, después de tomar en cuenta la inflación, que se vio en la lección anterior de este nivel.

### Por qué comparar distintas épocas puede engañar

Un ingreso de $50,000 hoy y un ingreso de $50,000 hace veinte años no son lo mismo en términos reales, porque los precios cambiaron en ese tiempo. Comparar las cifras tal cual, sin ajustarlas por inflación, puede dar una imagen engañosa del progreso financiero real.

### Aplicar la distinción

Siempre que se compare dinero de distintos momentos —un sueldo, un rendimiento de inversión, un precio histórico—, el valor real (ajustado por inflación) cuenta una historia más precisa que la cifra en dinero por sí sola.

## Ejemplo práctico

Un sueldo que subió de $50,000 a $55,000 en cinco años parece un crecimiento en términos nominales. Si la inflación de ese periodo redujo el poder de compra más o menos en la misma medida, el valor real de ese sueldo quizá casi no creció, o incluso bajó.

## Prueba de práctica

1. El valor real se refiere a:
   A. La cifra que aparece en una cuenta
   B. Lo que el dinero puede comprar de verdad, ajustado por inflación
   C. Un tipo de dividendo
   D. La capitalización de mercado de una empresa
2. Verdadero o falso: Comparar cifras de dinero de distintas décadas, tal cual, siempre da una imagen precisa del progreso financiero.
3. ¿Por qué un aumento de sueldo podría verse mejor en términos nominales de lo que es en términos reales?
   A. El valor nominal y el valor real siempre son idénticos
   B. La inflación pudo haber reducido el poder de compra ganado
   C. Los sueldos nunca se ven afectados por la inflación
   D. El valor real solo se aplica a los bonos

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. El valor real refleja el poder de compra real, no solo la cifra.

### Pregunta 2

Respuesta correcta: Falso. Las comparaciones directas entre distintas épocas pueden engañar si no se ajustan por inflación.

### Pregunta 3

Respuesta correcta: B. La inflación puede reducir el beneficio real de un aumento nominal.

## Puntos clave

- El valor nominal es la cifra en dinero; el valor real toma en cuenta el poder de compra.
- Comparar cifras de dinero de distintas épocas, tal cual, puede ser engañoso.
- El valor real da una imagen más precisa del progreso financiero real.
