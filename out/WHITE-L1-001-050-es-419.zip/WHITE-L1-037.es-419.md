---
id: WHITE-L1-037
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 37
locale: es-419
title: "¿Qué es un escenario alcista frente a un escenario bajista para una acción?"
summary: "Aprende qué significa construir un escenario alcista o un escenario bajista para una acción, y por qué importa considerar ambos."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es un escenario alcista frente a un escenario bajista para una acción?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir un escenario alcista y un escenario bajista en palabras sencillas.
- Explicar por qué importa construir ambos, no solo uno.
- Aplicar el concepto a un ejemplo hipotético básico.

## Contenido principal

### Qué es un escenario alcista

Un escenario alcista (bull case) es un argumento razonado de por qué una acción (u otra inversión) podría tener un buen desempeño, basado en factores específicos como su potencial de crecimiento, sus ventajas competitivas o tendencias favorables.

### Qué es un escenario bajista

Un escenario bajista (bear case) es un argumento razonado de por qué una acción podría tener un mal desempeño, basado en riesgos, debilidades o tendencias desfavorables específicos.

### Por qué importa considerar ambos

Construir solo un escenario alcista (o solo uno bajista) crea una visión parcial y posiblemente con exceso de confianza. Considerar de verdad ambas perspectivas —incluso con una inversión que a alguien le entusiasma— lleva a entender de forma más realista los riesgos y el potencial reales.

## Ejemplo práctico

Un inversionista que evalúa una empresa en crecimiento podría construir un escenario alcista basado en su mercado en expansión y sus productos sólidos, y al mismo tiempo un escenario bajista basado en la nueva competencia y el aumento de costos, sopesando ambos antes de decidir.

## Prueba de práctica

1. Un escenario alcista es:
   A. Un argumento razonado de por qué una inversión podría tener un mal desempeño
   B. Un argumento razonado de por qué una inversión podría tener un buen desempeño
   C. Una predicción garantizada del desempeño futuro
   D. Un tipo de bono
2. Verdadero o falso: Construir solo un escenario alcista para una inversión da una visión completa y equilibrada.
3. ¿Por qué importa considerar tanto un escenario alcista como uno bajista?
   A. No importa en absoluto
   B. Lleva a una comprensión más realista y equilibrada de una inversión
   C. Garantiza un resultado con ganancias
   D. Solo es relevante para los bonos

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Un escenario alcista argumenta un posible desempeño positivo.

### Pregunta 2

Respuesta correcta: Falso. Una visión parcial pasa por alto riesgos o debilidades reales.

### Pregunta 3

Respuesta correcta: B. Considerar ambos lleva a una visión más equilibrada y realista.

## Puntos clave

- Un escenario alcista argumenta un posible desempeño positivo; un escenario bajista, un posible desempeño negativo.
- Construir solo uno de los dos crea una visión incompleta y con exceso de confianza.
- Considerar ambos lleva a decisiones de inversión más realistas.
