---
id: WHITE-L1-038
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 38
locale: es-419
title: "¿Qué es el uso de información privilegiada y por qué es ilegal?"
summary: "Aprende qué significa el uso de información privilegiada (insider trading) y el razonamiento básico de por qué está prohibido."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es el uso de información privilegiada y por qué es ilegal?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir el uso de información privilegiada en palabras sencillas.
- Explicar el razonamiento básico de por qué está prohibido.
- Reconocerlo como un límite legal real, no solo como una pauta ética.

## Contenido principal

### Qué es el uso de información privilegiada

*(REGLA ESPECÍFICA POR REGIÓN: esta lección describe el concepto general; las leyes específicas varían según el país.)* El uso de información privilegiada (insider trading) generalmente se refiere a comprar o vender una acción con base en información relevante y no pública: información que todavía no está disponible para el público en general y que razonablemente podría afectar el precio de la acción.

### El razonamiento básico detrás de la prohibición

En general, se busca que los mercados funcionen con igualdad de condiciones en cuanto a la información. Quien opera con información no pública tiene una ventaja injusta sobre otros inversionistas que no tienen acceso a esa misma información, lo que debilita la confianza de todos los demás en que los precios del mercado son justos.

### Un límite legal real

No solo se considera algo poco ético: en muchos países, incluida la protección que establecen las leyes de valores de EE. UU., es una violación legal real que puede llevar a un proceso, no simplemente una cuestión de criterio personal.

## Ejemplo práctico

Un empleado de una empresa que se entera, antes del anuncio público, de que su empresa está por reportar resultados decepcionantes, y que vende sus acciones antes del anuncio con base en ese conocimiento no público, estaría usando información privilegiada.

## Prueba de práctica

1. El uso de información privilegiada generalmente se refiere a:
   A. Operar acciones con base en información pública
   B. Operar acciones con base en información relevante y no pública
   C. Un tipo de pago de dividendos
   D. Un formulario de divulgación obligatorio
2. Verdadero o falso: El uso de información privilegiada es solo una pauta ética, no una violación legal real.
3. ¿Por qué generalmente está prohibido el uso de información privilegiada?
   A. No tiene ninguna justificación real
   B. Crea una ventaja injusta sobre los inversionistas sin acceso a la misma información
   C. Solo es ilegal para los directivos de la empresa
   D. Solo se aplica a los bonos

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. El uso de información privilegiada implica operar con información relevante y no pública.

### Pregunta 2

Respuesta correcta: Falso. Es una violación legal real, que puede llevar a un proceso en muchas jurisdicciones, no solo una cuestión ética.

### Pregunta 3

Respuesta correcta: B. Debilita el acceso justo e igualitario a la información que mueve al mercado.

## Puntos clave

- El uso de información privilegiada significa operar con base en información relevante y no pública.
- Está prohibido porque crea una ventaja informativa injusta.
- Es una violación legal real, no solo una pauta ética.
