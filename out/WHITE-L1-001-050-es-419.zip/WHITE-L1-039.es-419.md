---
id: WHITE-L1-039
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 39
locale: es-419
title: "¿Qué es una bolsa de valores? (NYSE, Nasdaq: lo que realmente hacen)"
summary: "Aprende lo que realmente hace una bolsa de valores, más allá de ser \"donde se compran y venden acciones\"."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es una bolsa de valores? (NYSE, Nasdaq: lo que realmente hacen)

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir una bolsa de valores en palabras sencillas.
- Explicar su función central, más allá de ser "un lugar donde se negocian acciones".
- Nombrar dos ejemplos conocidos.

## Contenido principal

### Qué es una bolsa de valores

Una bolsa de valores es un mercado organizado donde compradores y vendedores se reúnen para negociar acciones de empresas que cotizan en bolsa, bajo un conjunto de reglas comunes.

### Su función central

Más allá de simplemente albergar operaciones, una bolsa permite la formación de precios (ayuda a determinar un precio actual justo al emparejar a compradores y vendedores reales) y hace cumplir los requisitos que las empresas deben cumplir para cotizar en ella, lo que agrega una capa de estructura y supervisión al mercado.

### Ejemplos conocidos

*(HECHO VERIFICADO, sujeto a cambios con el tiempo: las empresas que cotizan en cada bolsa cambian.)* La Bolsa de Valores de Nueva York (NYSE) y el Nasdaq son dos bolsas de valores conocidas, cada una con requisitos de cotización y estructuras de operación algo distintos. *(En América Latina también existen bolsas propias, como la Bolsa Mexicana de Valores, B3 en Brasil o la Bolsa de Comercio de Santiago.)*

## Ejemplo práctico

Cuando un inversionista da una orden para comprar o vender una acción, esa orden se envía a la bolsa correspondiente, que la empareja con una orden de compra o de venta equivalente a un precio acordado: el mecanismo básico detrás de "operar una acción".

## Prueba de práctica

1. Una bolsa de valores es:
   A. La mesa de operaciones interna de una sola empresa
   B. Un mercado organizado para negociar acciones de empresas que cotizan en bolsa
   C. Una agencia fiscal del gobierno
   D. Un tipo de fondo de inversión
2. Verdadero o falso: Las bolsas de valores solo albergan operaciones, sin ningún papel de requisitos de cotización ni de supervisión.
3. Nombra una bolsa de valores conocida que se mencione en esta lección.
   A. La Reserva Federal
   B. NYSE o Nasdaq
   C. El IRS
   D. La SEC

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Una bolsa es un mercado organizado para negociar acciones que cotizan en ella.

### Pregunta 2

Respuesta correcta: Falso. Las bolsas también permiten la formación de precios y hacen cumplir requisitos de cotización.

### Pregunta 3

Respuesta correcta: B. NYSE y Nasdaq son ejemplos conocidos.

## Puntos clave

- Una bolsa de valores es un mercado organizado para negociar acciones que cotizan en ella.
- Permite la formación de precios y hace cumplir requisitos de cotización.
- NYSE y Nasdaq son dos ejemplos conocidos.
