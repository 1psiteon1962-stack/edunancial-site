---
id: WHITE-L1-041
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 41
locale: es-419
title: "¿Qué es un asesor robot (robo-advisor)?"
summary: "Aprende qué hace un asesor robot y la disyuntiva básica frente a un asesor financiero humano."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es un asesor robot (robo-advisor)?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir un asesor robot en palabras sencillas.
- Explicar cómo arma normalmente un portafolio.
- Identificar una disyuntiva básica frente a un asesor humano.

## Contenido principal

### Qué es un asesor robot

Un asesor robot (robo-advisor) es un servicio automatizado que arma y administra un portafolio de inversión según las metas y la tolerancia al riesgo del inversionista, generalmente con algoritmos en lugar de un asesor humano que toma decisiones individuales.

### Cómo arma normalmente un portafolio

Un asesor robot normalmente hace una serie de preguntas sobre las metas, el horizonte de tiempo y la comodidad con el riesgo, y luego reparte el dinero de forma automática entre una mezcla de inversiones (muchas veces ETF, que se vieron antes en este nivel) que corresponde a ese perfil.

### La disyuntiva básica frente a un asesor humano

Los asesores robot generalmente ofrecen comisiones más bajas y un acceso más fácil que un asesor financiero humano, pero normalmente dan una orientación menos personalizada para situaciones financieras complejas e individuales: una disyuntiva real entre costo y personalización.

## Ejemplo práctico

Un inversionista con una meta sencilla (como el ahorro general para el retiro a largo plazo) y una tolerancia moderada al riesgo podría usar un asesor robot para armar y mantener de forma automática un portafolio adecuado, a un costo menor que el de contratar a un asesor humano.

## Prueba de práctica

1. Un asesor robot es:
   A. Un asesor financiero humano que trabaja a distancia
   B. Un servicio automatizado que arma y administra un portafolio con algoritmos
   C. Un tipo de bono
   D. Un programa de retiro del gobierno
2. Verdadero o falso: Los asesores robot generalmente cobran comisiones más altas que los asesores financieros humanos.
3. ¿Cuál es una disyuntiva básica de usar un asesor robot en lugar de un asesor humano?
   A. No existe ninguna disyuntiva
   B. Comisiones más bajas y acceso más fácil, pero normalmente una orientación menos personalizada
   C. Los asesores robot garantizan rendimientos más altos
   D. Los asesores humanos siempre son gratis

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Un asesor robot automatiza la administración del portafolio con algoritmos.

### Pregunta 2

Respuesta correcta: Falso. Los asesores robot generalmente cobran comisiones más bajas que los asesores humanos.

### Pregunta 3

Respuesta correcta: B. El menor costo y el acceso más fácil se cambian por una orientación personalizada.

## Puntos clave

- Un asesor robot automatiza el armado y la administración del portafolio.
- Normalmente reparte las inversiones según las metas y la tolerancia al riesgo.
- Generalmente cambia un costo menor por una orientación menos personalizada que la de un asesor humano.
