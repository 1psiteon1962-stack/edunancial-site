---
id: WHITE-L1-043
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 43
locale: es-419
title: "¿Qué es la asignación de activos?"
summary: "Aprende qué significa la asignación de activos y en qué se diferencia de la diversificación dentro de un solo tipo de activo."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es la asignación de activos?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir la asignación de activos en palabras sencillas.
- Distinguirla de la diversificación dentro de una categoría de activos.
- Explicar por qué muchas veces se describe como una decisión fundamental del portafolio.

## Contenido principal

### Qué es la asignación de activos

La asignación de activos se refiere a cómo divide un inversionista su portafolio total entre distintas categorías amplias de activos —como acciones, bonos y efectivo—, más que a qué inversiones específicas elegir dentro de cada categoría.

### En qué se diferencia de la diversificación

La diversificación (que se vio antes en este nivel) generalmente se refiere a repartir las inversiones dentro de una categoría, como tener muchas acciones distintas. La asignación de activos funciona un nivel más arriba: decide cuánto va a acciones en total, frente a bonos en total, frente a efectivo en total.

### Por qué es fundamental

La asignación de activos muchas veces se describe como una de las decisiones más importantes al armar un portafolio, porque la mezcla amplia entre categorías de activos (no solo qué acciones específicas se eligen) tiene un efecto importante en el riesgo total y en el rendimiento potencial.

## Ejemplo práctico

Un inversionista podría decidir una asignación de 70 % en acciones, 25 % en bonos y 5 % en efectivo: una decisión que se toma antes de elegir qué acciones o bonos específicos tener dentro de esa estructura.

## Prueba de práctica

1. La asignación de activos se refiere a:
   A. Elegir acciones individuales específicas
   B. Dividir un portafolio entre categorías amplias como acciones, bonos y efectivo
   C. Un tipo de dividendo
   D. Un programa de retiro del gobierno
2. Verdadero o falso: La asignación de activos y la diversificación dentro de una categoría significan exactamente lo mismo.
3. ¿Por qué la asignación de activos muchas veces se describe como una decisión fundamental?
   A. Tiene poco efecto en un portafolio
   B. La mezcla amplia entre categorías afecta de forma importante el riesgo y el rendimiento totales
   C. Solo importa para los bonos
   D. Reemplaza la necesidad de cualquier otra decisión de inversión

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. La asignación de activos es la división de un portafolio a nivel de categorías amplias.

### Pregunta 2

Respuesta correcta: Falso. La asignación se hace por categoría; la diversificación, dentro de cada categoría.

### Pregunta 3

Respuesta correcta: B. La mezcla amplia de categorías afecta de forma importante el comportamiento total del portafolio.

## Puntos clave

- La asignación de activos es cómo se divide un portafolio entre categorías amplias.
- Es una decisión distinta y de nivel más alto que la diversificación dentro de una categoría.
- Se considera una decisión fundamental al armar un portafolio.
