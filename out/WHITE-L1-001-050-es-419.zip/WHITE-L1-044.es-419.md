---
id: WHITE-L1-044
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 44
locale: es-419
title: "¿Qué es rebalancear un portafolio?"
summary: "Aprende qué significa rebalancear, por qué la asignación se desvía con el tiempo y la mecánica básica para corregir esa desviación."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es rebalancear un portafolio?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir el rebalanceo en palabras sencillas.
- Explicar por qué la asignación de un portafolio se desvía con el tiempo.
- Explicar la mecánica básica para corregir esa desviación.

## Contenido principal

### Qué es rebalancear

Rebalancear significa ajustar de forma periódica un portafolio para devolverlo a su asignación de activos objetivo original (que se vio en la lección anterior), después de que los movimientos del mercado lo alejaron de ese objetivo.

### Por qué la asignación se desvía con el tiempo

Si las acciones crecen más rápido que los bonos durante un periodo, un portafolio que empezó con 70 % en acciones y 30 % en bonos podría desviarse a 80 % en acciones y 20 % en bonos solo por los movimientos del mercado, aunque el inversionista nunca haya cambiado nada de forma activa.

### La mecánica básica

Rebalancear generalmente implica vender una parte de lo que creció hasta quedar sobreponderado y comprar más de lo que quedó subponderado, para acercar el portafolio otra vez a sus porcentajes objetivo originales.

## Ejemplo práctico

Un portafolio se desvía de un objetivo de 70/30 entre acciones y bonos a 80/20 después de que las acciones tienen un mejor desempeño. Rebalancear significa vender suficientes acciones y comprar suficientes bonos para acercar la mezcla otra vez al objetivo original de 70/30.

## Prueba de práctica

1. Rebalancear significa:
   A. Elegir nuevas acciones individuales
   B. Ajustar un portafolio para devolverlo a su asignación objetivo original
   C. Cerrar una cuenta de inversión
   D. Aumentar el riesgo total de forma permanente
2. Verdadero o falso: La asignación de un portafolio se mantiene exactamente igual con el tiempo sin hacer nada.
3. Si las acciones crecen más rápido que los bonos, ¿qué pasa normalmente con la asignación a acciones de un portafolio si no se rebalancea?
   A. Baja automáticamente
   B. Sube y queda sobreponderada en relación con el objetivo original
   C. Se mantiene exactamente igual
   D. En su lugar, los bonos suben automáticamente

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Rebalancear devuelve un portafolio a su mezcla objetivo original.

### Pregunta 2

Respuesta correcta: Falso. Los movimientos del mercado hacen que la asignación se desvíe con el tiempo.

### Pregunta 3

Respuesta correcta: B. Si las acciones crecen más rápido, su parte del portafolio aumenta si no se hace nada.

## Puntos clave

- Rebalancear devuelve un portafolio a su asignación objetivo original.
- La asignación se desvía con el tiempo solo por los movimientos del mercado.
- Rebalancear implica vender los activos sobreponderados y comprar los subponderados.
