---
id: WHITE-L1-045
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 45
locale: es-419
title: "¿Qué es un fondo con fecha objetivo (target-date fund)?"
summary: "Aprende qué hace de forma automática un fondo con fecha objetivo y por qué su asignación cambia a medida que se acerca la fecha objetivo."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es un fondo con fecha objetivo (target-date fund)?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir un fondo con fecha objetivo en palabras sencillas.
- Explicar cómo cambia su asignación con el tiempo.
- Explicar por qué esto se relaciona con el concepto de rebalanceo.

## Contenido principal

### Qué es un fondo con fecha objetivo

Un fondo con fecha objetivo (target-date fund; en algunos sistemas de pensiones de América Latina existen fondos de "ciclo de vida" con una lógica parecida) es un fondo construido alrededor de una fecha futura específica (muchas veces un año de retiro planeado), que administra de forma automática su propia asignación de activos para ajustarse al horizonte de tiempo del inversionista.

### Cómo cambia su asignación con el tiempo

Un fondo con fecha objetivo normalmente empieza con una asignación más alta en acciones (por su potencial de crecimiento, dado el horizonte largo) y poco a poco se mueve hacia más bonos y efectivo a medida que se acerca la fecha objetivo (para tener más estabilidad cuando la meta está más cerca), de forma automática, sin que el inversionista tenga que hacer ese ajuste a mano.

### La relación con el rebalanceo

En esencia, un fondo con fecha objetivo automatiza en un solo producto tanto el rebalanceo como la estrategia de asignación que cambia poco a poco: el inversionista no necesita rebalancearlo de forma periódica por su cuenta, como lo haría con un portafolio armado a mano.

## Ejemplo práctico

Un inversionista que planea jubilarse en 30 años podría elegir un fondo con fecha objetivo para ese año. Al principio, tiene sobre todo acciones; a medida que se acerca el año objetivo, se mueve de forma automática hacia una mezcla más conservadora de bonos y efectivo.

## Prueba de práctica

1. Un fondo con fecha objetivo está construido alrededor de:
   A. La acción de una sola empresa
   B. Una fecha futura específica, muchas veces un año de retiro planeado
   C. Exclusivamente un tipo de bono
   D. Una fecha límite del gobierno para presentar impuestos
2. Verdadero o falso: La asignación de un fondo con fecha objetivo se mantiene exactamente igual de principio a fin.
3. ¿Qué pasa generalmente con la asignación de un fondo con fecha objetivo a medida que se acerca la fecha objetivo?
   A. Se mueve hacia más acciones
   B. Se mueve hacia más bonos y efectivo, para tener estabilidad
   C. Se vuelve de inmediato todo efectivo
   D. No cambia nada

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Un fondo con fecha objetivo está construido alrededor de una fecha futura específica.

### Pregunta 2

Respuesta correcta: Falso. Su asignación cambia de forma automática con el tiempo.

### Pregunta 3

Respuesta correcta: B. Se vuelve poco a poco más conservador a medida que se acerca la fecha.

## Puntos clave

- Un fondo con fecha objetivo está construido alrededor de una fecha futura específica.
- Su asignación cambia de forma automática, de un enfoque de crecimiento a uno más conservador, con el tiempo.
- Automatiza en un solo producto tanto el cambio de asignación como el rebalanceo.
