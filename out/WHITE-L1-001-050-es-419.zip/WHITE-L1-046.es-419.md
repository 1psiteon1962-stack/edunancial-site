---
id: WHITE-L1-046
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 46
locale: es-419
title: "¿Qué es una recompra de acciones? (Versión introductoria; un análisis más profundo, en el Nivel 2)"
summary: "Aprende a nivel introductorio qué es una recompra de acciones y por qué puede afectar las cifras por acción sin cambiar el negocio."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es una recompra de acciones? (Versión introductoria; un análisis más profundo, en el Nivel 2)

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir una recompra de acciones en palabras sencillas.
- Explicar el efecto mecánico básico sobre las acciones en circulación.
- Reconocer que en el Nivel 2 se ve con más profundidad su efecto sobre las razones financieras.

## Contenido principal

### Qué es una recompra de acciones

Una recompra de acciones ocurre cuando una empresa vuelve a comprar sus propias acciones en el mercado abierto, lo que reduce el número de acciones en circulación (un concepto que se presentó antes en este nivel).

### El efecto mecánico básico

Con menos acciones en circulación y la misma utilidad total de la empresa, cada acción que queda representa una rebanada un poco más grande de la empresa, lo que se conecta con la UPA (utilidad por acción) que vimos antes en este nivel.

### Un adelanto del Nivel 2

*SUPUESTO (con fines didácticos):* Esta lección introductoria cubre solo la mecánica básica. El Nivel 2 explica con más profundidad cómo las recompras pueden hacer que las cifras por acción, como la UPA y la relación P/U, se vean mejor sin que el negocio de fondo realmente mejore.

## Ejemplo práctico

Una empresa con 1,000,000 de acciones en circulación recompra 100,000 acciones y le quedan 900,000. Con la misma utilidad neta total, la UPA sube simplemente porque esa utilidad ahora se divide entre menos acciones.

## Prueba de práctica

1. Una recompra de acciones significa:
   A. Que una empresa emite acciones completamente nuevas
   B. Que una empresa vuelve a comprar sus propias acciones en el mercado
   C. Un split de acciones
   D. Un pago de dividendos
2. Verdadero o falso: Una recompra aumenta el número total de acciones en circulación.
3. Con la misma utilidad neta, ¿qué pasa con la UPA después de que una recompra reduce las acciones en circulación?
   A. La UPA baja
   B. La UPA sube, porque la utilidad ahora se divide entre menos acciones
   C. La UPA se mantiene exactamente igual
   D. La UPA se vuelve cero

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Una recompra es cuando una empresa vuelve a comprar sus propias acciones.

### Pregunta 2

Respuesta correcta: Falso. Una recompra reduce, no aumenta, las acciones en circulación.

### Pregunta 3

Respuesta correcta: B. Menos acciones que dividen la misma utilidad suben la UPA de forma mecánica.

## Puntos clave

- Una recompra es cuando una empresa vuelve a comprar sus propias acciones, lo que reduce las acciones en circulación.
- Esto sube la UPA de forma mecánica, aunque la utilidad total no cambie.
- El Nivel 2 explica con más profundidad cómo esto puede distorsionar las razones por acción.
