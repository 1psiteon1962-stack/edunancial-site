---
id: WHITE-L1-047
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 47
locale: es-419
title: "¿Qué es una trampa bajista o una trampa de valor? (Por qué \"barato\" puede ser una señal de alerta)"
summary: "Aprende qué es una trampa de valor y por qué un precio bajo, por sí solo, no significa que una acción sea una ganga."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es una trampa bajista o una trampa de valor? (Por qué "barato" puede ser una señal de alerta)

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir una trampa de valor en palabras sencillas.
- Explicar por qué un precio bajo, por sí solo, no indica una buena oportunidad.
- Conectar este concepto con la lección sobre la relación P/U.

## Contenido principal

### Qué es una trampa de valor

Una trampa de valor (value trap) es una acción que parece barata según indicadores sencillos (como una relación P/U baja, que vimos antes en este nivel), pero que en realidad está barata por una razón real y duradera: el deterioro de los fundamentos del negocio, no un error temporal de precio.

### Por qué un precio bajo no basta

Que el precio o una razón de una acción estén más bajos que antes no significa automáticamente que sea una ganga. A veces un precio más bajo refleja con precisión una caída real y continua en las perspectivas del negocio de la empresa: el mercado está valuando correctamente un problema auténtico, no cometiendo un error.

### La relación con la P/U

Una relación P/U baja puede significar que una acción está subvaluada, o puede significar que el mercado espera que caigan las utilidades futuras, lo que hace que el precio bajo actual sea adecuado y no una ganga. Distinguir entre ambos casos exige ver más allá de la razón por sí sola.

## Ejemplo práctico

El precio de una acción baja de forma importante y su relación P/U se ve atractivamente baja en comparación con su historia. Si esa caída refleja un deterioro real y continuo del negocio central de la empresa, y no una reacción exagerada temporal, comprarla como "ganga" podría ser caer en una trampa de valor.

## Prueba de práctica

1. Una trampa de valor es:
   A. Una acción que de verdad está subvaluada y es una buena oportunidad
   B. Una acción que parece barata, pero está barata por una razón real y duradera
   C. Un tipo de bono
   D. Una inversión con ganancias garantizadas
2. Verdadero o falso: Una relación P/U baja siempre significa que una acción es una ganga.
3. ¿Por qué un precio bajo podría reflejar con precisión un problema real y no una ganga?
   A. Los precios nunca reflejan problemas reales
   B. El mercado podría estar valuando correctamente un deterioro en las perspectivas del negocio
   C. Los precios bajos siempre son errores
   D. Esto nunca pasa en los mercados reales

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Una trampa de valor parece barata, pero refleja un problema real y duradero.

### Pregunta 2

Respuesta correcta: Falso. Una P/U baja puede reflejar una caída real y merecida, no solo una ganga.

### Pregunta 3

Respuesta correcta: B. Los mercados pueden valuar correctamente problemas auténticos y continuos.

## Puntos clave

- Una trampa de valor parece barata, pero está barata por una razón real y duradera.
- Un precio bajo o una razón baja, por sí solos, no garantizan una ganga.
- Una P/U baja puede reflejar una subvaluación o una caída auténtica y merecida.
