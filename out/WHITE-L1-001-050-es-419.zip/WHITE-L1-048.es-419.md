---
id: WHITE-L1-048
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 48
locale: es-419
title: "¿Qué es el rendimiento ponderado por dinero frente al rendimiento ponderado por tiempo? (Por qué dos personas pueden tener rendimientos distintos en la \"misma\" inversión)"
summary: "Aprende por qué dos inversionistas en el mismo fondo pueden tener rendimientos personales realmente distintos, según cuándo agregaron o retiraron dinero."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# ¿Qué es el rendimiento ponderado por dinero frente al rendimiento ponderado por tiempo? (Por qué dos personas pueden tener rendimientos distintos en la "misma" inversión)

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Definir en palabras sencillas el rendimiento ponderado por tiempo y el rendimiento ponderado por dinero.
- Explicar por qué pueden dar cifras distintas para el mismo fondo.
- Reconocer por qué el momento de las aportaciones importa para el rendimiento personal.

## Contenido principal

### Rendimiento ponderado por tiempo

El rendimiento ponderado por tiempo mide cómo se desempeñó la inversión en sí durante un periodo, sin importar cuándo se agregó o se retiró dinero: es la cifra que normalmente reporta el propio fondo.

### Rendimiento ponderado por dinero

El rendimiento ponderado por dinero mide el rendimiento personal real de un inversionista individual, que depende mucho de CUÁNDO agregó o retiró dinero: el mismo fondo puede dar rendimientos ponderados por dinero muy distintos para distintos inversionistas, según el momento personal de cada uno.

### Por qué pueden ser distintos

*EJEMPLO ILUSTRATIVO:* Si un inversionista agrega una suma grande justo antes de una caída, su rendimiento personal ponderado por dinero será peor que el rendimiento ponderado por tiempo del propio fondo en ese periodo, aunque esté invertido exactamente en el mismo fondo que alguien que invirtió antes.

## Ejemplo práctico

Un fondo reporta un rendimiento ponderado por tiempo del 10 % en el año. Un inversionista que agregó una suma grande justo antes de una caída breve dentro de ese año, y luego mantuvo la inversión durante la recuperación, podría tener un rendimiento personal ponderado por dinero notablemente distinto de ese 10 % reportado: el mismo fondo, una experiencia personal muy distinta según el momento.

## Prueba de práctica

1. El rendimiento ponderado por tiempo mide:
   A. El rendimiento personal de un inversionista individual según su momento
   B. El desempeño propio de la inversión, sin importar el momento de las aportaciones
   C. Solo el ingreso por dividendos
   D. La capitalización de mercado de una empresa
2. Verdadero o falso: El rendimiento ponderado por dinero no se ve afectado por cuándo un inversionista agrega o retira dinero.
3. ¿Por qué dos inversionistas en el mismo fondo pueden tener rendimientos personales distintos?
   A. Los fondos reportan cifras distintas a cada inversionista
   B. Su rendimiento personal ponderado por dinero depende del momento de sus aportaciones
   C. Esto nunca pasa en realidad
   D. Solo las comisiones del fondo son distintas entre inversionistas

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. El rendimiento ponderado por tiempo mide el desempeño propio del fondo, sin importar el momento de las aportaciones.

### Pregunta 2

Respuesta correcta: Falso. El rendimiento ponderado por dinero depende específicamente del momento de las aportaciones.

### Pregunta 3

Respuesta correcta: B. El momento personal de las aportaciones explica las diferencias en el rendimiento ponderado por dinero.

## Puntos clave

- El rendimiento ponderado por tiempo mide el desempeño propio de la inversión.
- El rendimiento ponderado por dinero mide el rendimiento personal de un individuo, que depende del momento de sus aportaciones.
- Dos inversionistas en el mismo fondo pueden tener rendimientos personales realmente distintos.
