---
id: WHITE-L1-049
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 49
locale: es-419
title: "Cómo leer un estado de cuenta de inversión: ¿qué estás viendo realmente?"
summary: "Aprende a leer las secciones centrales de un estado de cuenta de una casa de bolsa, uniendo términos de todo este nivel."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# Cómo leer un estado de cuenta de inversión: ¿qué estás viendo realmente?

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Identificar las secciones centrales de un estado de cuenta típico de una casa de bolsa.
- Explicar qué te dice realmente cada sección.
- Conectar los términos del estado de cuenta con conceptos que vimos antes en este nivel.

## Contenido principal

### Las secciones centrales de un estado de cuenta

Un estado de cuenta típico de una casa de bolsa generalmente incluye: las posiciones de la cuenta (qué se tiene y cuánto), el historial de movimientos (compras, ventas y dividendos recientes) y un resumen de desempeño, aunque el formato exacto varía según la casa de bolsa.

### Qué te dice cada sección

La sección de posiciones muestra lo que tienes actualmente y su valor de mercado. El historial de movimientos muestra la actividad reciente, incluidos los pagos de dividendos (que vimos antes en este nivel). El resumen de desempeño muchas veces reporta algo como un rendimiento ponderado por tiempo (que vimos en la lección anterior), no necesariamente la experiencia personal ponderada por dinero del inversionista.

### Conectar con los conceptos de este nivel

Leer bien un estado de cuenta significa reconocer términos que ya vimos: las acciones que tienes, el valor de mercado, los dividendos recibidos y la diferencia entre el rendimiento reportado del fondo y el rendimiento personal real de cada quien, según el momento de sus propias aportaciones.

## Ejemplo práctico

Un inversionista revisa su estado de cuenta y ve que tiene acciones de un ETF, nota un pago de dividendos reciente en el historial de movimientos y ve un rendimiento reportado en lo que va del año. Reconoce que esa cifra probablemente refleja el desempeño ponderado por tiempo, no necesariamente su rendimiento personal exacto, si agregó dinero a mitad del año.

## Prueba de práctica

1. La sección de posiciones de un estado de cuenta normalmente muestra:
   A. Solo las comisiones de la casa de bolsa
   B. Lo que se tiene actualmente y su valor de mercado
   C. Solo la declaración de impuestos del inversionista
   D. Una lista de empresas sin relación
2. Verdadero o falso: El resumen de desempeño de un estado de cuenta siempre refleja el rendimiento personal exacto, ponderado por dinero, del inversionista.
3. ¿Qué incluye normalmente la sección de historial de movimientos?
   A. Solo las operaciones planeadas a futuro
   B. Compras, ventas y pagos de dividendos recientes
   C. Los estados financieros completos de una empresa
   D. Declaraciones de impuestos ante el gobierno

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Las posiciones muestran lo que se tiene actualmente y su valor de mercado.

### Pregunta 2

Respuesta correcta: Falso. El desempeño reportado muchas veces está ponderado por tiempo, no es necesariamente el rendimiento personal ponderado por dinero del inversionista.

### Pregunta 3

Respuesta correcta: B. El historial de movimientos cubre la actividad reciente de la cuenta.

## Puntos clave

- Un estado de cuenta de una casa de bolsa normalmente incluye posiciones, historial de movimientos y un resumen de desempeño.
- El desempeño reportado muchas veces está ponderado por tiempo, no es automáticamente el rendimiento personal del inversionista.
- Leer bien un estado de cuenta usa conceptos que se vieron a lo largo de este nivel.
