---
id: WHITE-L1-050
track: WHITE
officialTrackName: Paper Assets
level: 1
lessonNumber: 50
locale: es-419
title: "Proyecto final: cómo armar tu primer portafolio sencillo, paso a paso"
summary: "Aplica todo lo de WHITE Nivel 1 recorriendo, de principio a fin, cómo armar un primer portafolio de inversión sencillo."
version: "1.0"
author: Waldemar M. Caban, JD MA
date: 2026-08-08
---

# Proyecto final: cómo armar tu primer portafolio sencillo, paso a paso

## Objetivos de aprendizaje

Al terminar esta lección, deberías poder:

- Aplicar los conceptos centrales de WHITE Nivel 1 a un escenario conectado.
- Identificar qué concepto de este nivel se aplica en cada paso.
- Explicar cómo encajan las piezas de armar un portafolio como un todo.

## Contenido principal

### El escenario

Jaime quiere empezar a invertir por primera vez. Quiere entender lo que realmente está haciendo en cada paso, no solo seguir instrucciones a ciegas.

### El recorrido

Primero, Jaime se asegura de tener un fondo de emergencia (Lección 35) en un lugar líquido y de bajo riesgo antes de invertir cualquier otra cosa. Abre una cuenta en una casa de bolsa (Lección 21), entendiendo que es distinta de una cuenta de retiro, y por separado revisa si su empleador ofrece una aportación equivalente en un 401(k) (Lección 18) que valga la pena aprovechar primero.

Decide invertir en un ETF (Lección 9) en lugar de elegir acciones individuales, porque valora la diversificación (Lección 13) que le da. Revisa su índice de gastos (Lección 12), entendiendo que las pequeñas diferencias de porcentaje se acumulan con el tiempo. Decide usar el promedio del costo en dólares (Lección 22), invirtiendo un monto fijo cada mes en lugar de tratar de adivinar el momento del mercado.

Define una asignación de activos (Lección 43) con mayoría en acciones, dado su horizonte de tiempo largo, y entiende que tendrá que rebalancear (Lección 44) de forma periódica a medida que el mercado cambie esa mezcla. Sabe que su estado de cuenta (Lección 49) mostrará posiciones, movimientos y una cifra de desempeño que quizá no coincida exactamente con su rendimiento personal ponderado por dinero (Lección 48), porque está aportando poco a poco con el tiempo.

### Por qué esto importa

En un portafolio real, ninguna de estas decisiones ocurre de forma aislada: se conectan como un solo proceso, basado en entender, no solo en seguir pasos a ciegas.

## Ejemplo práctico

Si Jaime invierte $300 al mes con el promedio del costo en dólares en un ETF diversificado con un índice de gastos bajo, dentro de una cuenta estándar en una casa de bolsa, después de haber formado su fondo de emergencia y de aprovechar cualquier aportación equivalente disponible de su empleador, habrá aplicado casi todos los conceptos importantes de este nivel en un solo plan conectado.

## Prueba de práctica

1. ¿Por qué Jaime se aseguró de tener un fondo de emergencia antes de seguir invirtiendo?
   A. En realidad no es necesario
   B. Protege sus otros planes financieros de verse interrumpidos por gastos inesperados
   C. Los fondos de emergencia garantizan rendimientos de inversión
   D. No tiene ninguna relación con invertir
2. Verdadero o falso: El desempeño reportado de la cuenta de Jaime siempre coincidirá exactamente con su rendimiento personal ponderado por dinero.
3. ¿Por qué Jaime eligió un ETF en lugar de elegir acciones individuales?
   A. Los ETF garantizan rendimientos más altos
   B. Valoró la diversificación que le da
   C. Los ETF no tienen índice de gastos
   D. Las acciones individuales son ilegales para principiantes

## Clave de respuestas

1. B
2. Falso
3. B

## Respuestas y explicaciones

### Pregunta 1

Respuesta correcta: B. Un fondo de emergencia protege los planes de largo plazo de las interrupciones de corto plazo, como se vio en la Lección 35.

### Pregunta 2

Respuesta correcta: Falso. El desempeño reportado muchas veces está ponderado por tiempo, no es su rendimiento personal exacto ponderado por dinero, como se vio en las Lecciones 48 y 49.

### Pregunta 3

Respuesta correcta: B. La diversificación fue la razón que dio Jaime, lo que se conecta con la Lección 13.

## Puntos clave

- Armar un primer portafolio conecta casi todos los conceptos de este nivel en un solo proceso.
- El orden importa: primero el fondo de emergencia, luego el tipo de cuenta, luego la elección de inversión y luego la administración continua.
- Este proyecto final marca el cierre de WHITE Nivel 1; el Nivel 2 se apoya en esta base con conceptos más profundos de valuación y filosofía de inversión.
