---
id: WHITE-L2-001
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 1
title: "Le paradoxe du choix : pourquoi plus d'options peut rendre l'investissement plus difficile"
summary: "Comprends pourquoi des milliers de choix de placements peuvent paralyser au lieu d'aider, et comment un cadre fondé sur tes objectifs rend le choix gérable."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-001
### Le paradoxe du choix : pourquoi plus d'options peut rendre l'investissement plus difficile

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le concept du « paradoxe du choix » appliqué à l'investissement.
- Nommer les raisons pour lesquelles un grand nombre d'options de placement peut créer une paralysie décisionnelle.
- Décrire une approche générale pour réduire les choix sans ignorer les facteurs importants.

**2. Contenu principal**
Le niveau 1 a présenté les actifs papier individuels — actions, obligations, fonds communs de placement, FNB (fonds négociés en Bourse) — comme des pièces distinctes sur l'échiquier. Une nouvelle investisseuse qui ouvre un compte de courtage aujourd'hui fait face à des milliers d'actions, des milliers de fonds et plusieurs types de comptes, souvent avant même de faire un seul achat. Cette abondance de choix, au lieu de permettre des décisions confiantes, produit souvent l'effet contraire : un phénomène psychologique bien documenté où trop d'options mènent à l'hésitation, à l'anxiété ou à l'évitement complet de la décision. On l'appelle parfois le « paradoxe du choix ».

Le niveau 2 commence en nommant directement ce phénomène, parce que le reconnaître est la première étape pour le gérer. Une investisseuse dépassée par les choix peut se replier sur l'inaction (laisser son argent non investi pendant des années) ou faire un choix impulsif juste pour se débarrasser de l'inconfort de décider; aucune de ces réactions ne sert bien ses objectifs à long terme.

Une réponse pratique, ce n'est pas d'éliminer le choix, mais de bâtir un cadre pour le réduire de façon réfléchie : commencer par les objectifs et l'horizon de placement, puis la philosophie (présentée dans les prochaines leçons), puis les véhicules précis. Ce niveau est structuré pour bâtir exactement ce cadre, pièce par pièce, pour qu'à la leçon 48, l'apprenant ait une façon organisée d'aborder l'abondance de choix au lieu d'en être paralysé.

**3. Exemple pratique**
En ouvrant son premier compte de courtage, Priyanka trouve un outil de recherche qui affiche des milliers de fonds et d'actions. Dépassée, elle est sur le point de fermer l'application et de laisser son argent en liquidités indéfiniment — le résultat de la paralysie. Elle se rappelle plutôt cette leçon et décide d'abord d'écrire son objectif réel (une épargne-retraite à long terme, dans plusieurs décennies) et son horizon de placement, avant de regarder un seul fonds.

Avec ce point d'ancrage, elle réduit énormément sa recherche : elle cherche maintenant des options à long terme et largement diversifiées, adaptées à un horizon de plusieurs décennies, au lieu d'évaluer des milliers de choix avec le même poids. La liste écrasante n'a pas rapetissé, mais sa façon filtrée de l'aborder est devenue gérable.

**4. Quiz de pratique**
1. Qu'est-ce que le « paradoxe du choix », selon cette leçon?
   a) Avoir trop peu d'options de placement
   b) Avoir tellement d'options que la prise de décision devient plus difficile, pas plus facile
   c) Un type d'obligation
   d) Une loi fiscale
2. Quelles sont deux réactions courantes et peu utiles quand on est dépassé par les choix?
   a) Une recherche attentive et de la patience
   b) L'inaction complète ou des décisions impulsives pour fuir l'inconfort
   c) La diversification et le rééquilibrage
   d) L'investissement périodique d'un montant fixe
3. Vrai ou faux : La solution au paradoxe du choix, c'est de n'avoir aucune option de placement disponible.
4. Qu'a fait Priyanka pour rendre l'abondance de choix gérable?
   a) Elle a fermé son compte pour de bon
   b) Elle a d'abord ancré sa recherche dans ses objectifs et son horizon de placement
   c) Elle a choisi le premier fonds qu'elle a vu
   d) Elle a complètement ignoré ses objectifs

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Le paradoxe du choix décrit comment une abondance d'options peut rendre les décisions plus difficiles plutôt que plus faciles.
2. L'inaction complète et les choix impulsifs causés par l'anxiété sont deux réactions courantes et peu utiles quand on est dépassé.
3. La solution est un cadre structuré pour réduire les choix, pas l'élimination du choix lui-même.
4. En ancrant sa recherche dans ses objectifs réels et son horizon de placement, Priyanka a pu transformer une liste écrasante en liste gérable.

**7. Points clés à retenir**
- L'abondance de choix de placement peut créer une paralysie ou des décisions impulsives plutôt que des gestes confiants.
- Reconnaître ce phénomène est la première étape pour bien le gérer.
- Un cadre — d'abord les objectifs et l'horizon de placement, puis la philosophie, puis les véhicules précis — réduit le choix de façon réfléchie.
- Ce niveau est structuré pour bâtir exactement ce cadre, pièce par pièce.
