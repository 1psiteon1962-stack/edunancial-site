---
id: WHITE-L2-002
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 2
title: "Les philosophies de placement comme lentilles : un survol"
summary: "Découvre les quatre grandes philosophies de placement — valeur, croissance, revenu et gestion passive — et pourquoi on les voit comme des lentilles plutôt que des catégories rigides."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-002
### Les philosophies de placement comme lentilles : un survol

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le concept d'une « philosophie de placement » comme lentille pour évaluer des occasions.
- Nommer les quatre philosophies vues dans ce niveau : valeur, croissance, revenu et gestion passive (indicielle).
- Expliquer pourquoi les philosophies fonctionnent comme des lentilles plutôt que comme des catégories rigides.

**2. Contenu principal**
Une philosophie de placement est une lentille générale — un ensemble cohérent de questions et de priorités — à travers laquelle un investisseur évalue des occasions. Ce niveau couvre quatre philosophies dont on parle souvent : l'investissement axé sur la valeur (leçon 3), l'investissement axé sur la croissance (leçon 4), l'investissement axé sur le revenu (leçon 5) et l'investissement passif ou indiciel (leçon 6).

Les voir comme des « lentilles » plutôt que comme des catégories fixes est un choix volontaire. Bien des investisseurs et des fonds réels combinent des éléments de plus d'une lentille, et le même actif peut sembler attrayant ou non selon la lentille qu'on lui applique. Une action qui se négocie à un prix bas par rapport à ses bénéfices peut plaire à un investisseur axé sur la valeur, alors qu'un investisseur axé sur la croissance, concentré sur le potentiel d'expansion future d'une entreprise, l'ignorera — même s'ils regardent exactement la même entreprise.

Comprendre ces lentilles, ce n'est pas choisir « la bonne » et rejeter les autres. C'est reconnaître quelle lentille (ou quel mélange de lentilles) correspond aux objectifs, à la tolérance au risque et à l'horizon de placement de l'investisseur — ce qui se rattache directement au cadre de la leçon 1 pour réduire le choix.

**3. Exemple pratique**
Deux investisseurs regardent la même entreprise : un service public bien établi, avec une croissance modeste, mais une longue histoire de dividendes réguliers. Une investisseuse axée sur le revenu est attirée par l'entreprise précisément pour son historique de dividendes et son potentiel de flux de trésorerie. Un investisseur axé sur la croissance laisse passer la même entreprise, parce qu'il trouve ses perspectives de croissance modestes peu attrayantes comparativement à des options qui grandissent plus vite.

Aucun des deux n'a tort : ils appliquent des lentilles différentes aux mêmes faits, selon leurs propres objectifs. Ça montre pourquoi « le meilleur placement » n'est pas une réponse fixe et universelle; il dépend beaucoup de la lentille (et de l'investisseur) qui l'évalue.

**4. Quiz de pratique**
1. Selon cette leçon, qu'est-ce qu'une philosophie de placement?
   a) Une formule garantie pour faire des profits
   b) Une lentille ou un ensemble cohérent de priorités pour évaluer des occasions
   c) Un type d'obligation
   d) Un règlement gouvernemental
2. Pourquoi cette leçon décrit-elle les philosophies comme des « lentilles » plutôt que des catégories fixes?
   a) Parce que les lentilles sont un type de placement
   b) Parce que les investisseurs en combinent souvent plus d'une, et que le même actif peut paraître différent selon la lentille
   c) Parce qu'une seule lentille est toujours la bonne
   d) Parce que les lentilles n'ont aucun rapport avec l'investissement
3. Vrai ou faux : La même entreprise doit toujours paraître aussi attrayante pour tous les types d'investisseurs.
4. Pourquoi l'investisseuse axée sur le revenu et l'investisseur axé sur la croissance sont-ils arrivés à des conclusions différentes sur le même service public?
   a) Ils regardaient des entreprises différentes
   b) Ils appliquaient des lentilles différentes, qui reflétaient des objectifs et des priorités différents
   c) L'un des deux a fait une erreur de fait
   d) On ne peut pas évaluer les services publics

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une philosophie de placement est une lentille ou un ensemble cohérent de priorités qu'on utilise pour évaluer des occasions.
2. Les philosophies fonctionnent comme des lentilles parce que les investisseurs les combinent souvent, et que le même actif peut paraître différent selon la lentille appliquée.
3. La même entreprise peut, avec raison, plaire différemment à des investisseurs qui appliquent des lentilles et des priorités différentes.
4. Les deux investisseurs ont appliqué des lentilles différentes au même ensemble de faits, ce qui reflétait leurs objectifs différents.

**7. Points clés à retenir**
- Une philosophie de placement est une lentille cohérente pour évaluer des occasions, pas une formule garantie.
- Ce niveau couvre quatre lentilles souvent discutées : valeur, croissance, revenu et gestion passive (indicielle).
- Le même actif peut paraître différent selon la lentille appliquée.
- Comprendre ces lentilles aide un investisseur à trouver celle (ou le mélange) qui correspond à ses objectifs et à son horizon de placement.
