---
id: WHITE-L2-003
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 3
title: "La lentille de la valeur : acheter des actifs pour moins que ce qu'ils valent"
summary: "Comprends le principe de l'investissement axé sur la valeur, ses mesures courantes et le piège de valeur, un actif bon marché pour une bonne raison."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-003
### La lentille de la valeur : acheter des actifs pour moins que ce qu'ils valent

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le principe général de l'investissement axé sur la valeur.
- Nommer les mesures courantes associées à la lentille de la valeur.
- Reconnaître les risques et les critiques associés à cette approche.

**2. Contenu principal**
L'investissement axé sur la valeur consiste généralement à chercher des actifs qui semblent se négocier à un prix inférieur à une estimation de leur valeur sous-jacente ou « intrinsèque », en partant du principe que le prix du marché finira par se rapprocher de cette valeur estimée. Les mesures courantes associées à cette lentille comprennent, entre autres, le ratio cours-bénéfice (qui compare le prix d'une action aux bénéfices de l'entreprise) et le ratio cours-valeur comptable (qui compare le prix à la valeur comptable de l'actif net de l'entreprise). Mais aucune mesure à elle seule ne raconte toute l'histoire, et les investisseurs axés sur la valeur combinent habituellement plusieurs facteurs avec une recherche plus large sur les données fondamentales d'une entreprise.

Un risque central de cette lentille est le « piège de valeur » : un actif qui semble bon marché selon ces mesures, mais qui l'est pour une raison légitime et durable (une entreprise en déclin, un produit dépassé, des données fondamentales qui se détériorent). Son prix pourrait alors ne jamais remonter pour refléter une valeur intrinsèque supposément plus élevée. Distinguer une vraie occasion de valeur d'un piège de valeur exige généralement de comprendre *pourquoi* l'actif a ce prix, et pas seulement de remarquer qu'une mesure semble favorable prise isolément.

**3. Exemple pratique**
En appliquant la lentille de la valeur, Rosalind repère une entreprise qui se négocie à un ratio cours-bénéfice bas par rapport aux autres entreprises de son secteur. Au lieu d'acheter tout de suite à partir de cette seule mesure, elle fait plus de recherches et découvre que l'entreprise a un problème temporaire et réglable (un règlement juridique ponctuel qui a touché ses bénéfices récents) plutôt qu'un déclin structurel de ses activités. Ça appuie l'idée qu'il s'agit d'une vraie occasion de valeur plutôt que d'un piège de valeur.

Son collègue, qui applique la même lentille avec moins de soin, achète une autre entreprise au ratio cours-bénéfice encore plus bas sans faire plus de recherches, pour découvrir plus tard que les activités principales de l'entreprise étaient en déclin réel et continu — un exemple du piège de valeur contre lequel cette leçon met en garde.

**4. Quiz de pratique**
1. Quel est le principe général de l'investissement axé sur la valeur?
   a) Acheter seulement des entreprises en croissance rapide
   b) Chercher des actifs qui se négocient à un prix inférieur à une valeur intrinsèque estimée
   c) Éviter toute recherche
   d) Se concentrer uniquement sur les dividendes
2. Qu'est-ce qu'un « piège de valeur »?
   a) Une occasion rentable garantie
   b) Un actif qui semble bon marché selon certaines mesures, mais qui l'est pour une raison légitime et durable
   c) Un type d'obligation
   d) Une pénalité fiscale
3. Vrai ou faux : Un ratio cours-bénéfice bas suffit à lui seul à prouver qu'un actif est un bon placement de valeur.
4. Pourquoi l'approche de Rosalind lui a-t-elle évité un piège de valeur possible, contrairement à celle de son collègue?
   a) Elle a complètement ignoré le ratio cours-bénéfice
   b) Elle a cherché la raison du prix bas avant de décider
   c) Elle a acheté sans aucune recherche
   d) Elle a seulement regardé l'historique des dividendes

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'investissement axé sur la valeur cherche des actifs dont le prix est inférieur à une valeur intrinsèque estimée, en s'attendant à ce que le marché finisse par refléter cette valeur.
2. Un piège de valeur est un actif qui semble bon marché selon certaines mesures, mais pour une raison légitime et durable qui pourrait empêcher son prix de remonter.
3. Une seule mesure favorable ne confirme pas, à elle seule, qu'on est devant une vraie occasion de valeur plutôt qu'un piège de valeur.
4. La recherche plus poussée de Rosalind sur la raison du prix bas lui a permis de distinguer une vraie occasion d'un piège possible.

**7. Points clés à retenir**
- L'investissement axé sur la valeur cherche des actifs dont le prix est inférieur à une valeur intrinsèque estimée.
- Les mesures courantes comprennent le ratio cours-bénéfice et le ratio cours-valeur comptable, mais aucune mesure ne suffit à elle seule.
- Un « piège de valeur » est un actif qui semble bon marché parce qu'il l'est pour une raison légitime et durable.
- Distinguer une vraie valeur d'un piège exige de comprendre la raison sous-jacente du prix bas.
