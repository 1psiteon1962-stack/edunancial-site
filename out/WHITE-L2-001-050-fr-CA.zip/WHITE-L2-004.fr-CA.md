---
id: WHITE-L2-004
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 4
title: "La lentille de la croissance : payer plus cher pour le potentiel futur"
summary: "Comprends le principe de l'investissement axé sur la croissance, en quoi il diffère de la valeur et pourquoi une vraie croissance peut quand même décevoir le marché."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-004
### La lentille de la croissance : payer plus cher pour le potentiel futur

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le principe général de l'investissement axé sur la croissance.
- Comparer la lentille de la croissance à la lentille de la valeur.
- Nommer les risques liés au fait de payer une prime pour une croissance future attendue.

**2. Contenu principal**
L'investissement axé sur la croissance consiste généralement à chercher des actifs dont on s'attend à ce que les revenus, les bénéfices ou la présence sur le marché croissent plus vite que la moyenne. Les investisseurs sont souvent prêts à payer un prix plus élevé par rapport aux bénéfices actuels (un ratio cours-bénéfice plus élevé, contrairement à la lentille de la valeur de la leçon 3) en espérant que cette croissance future se concrétise.

Là où la lentille de la valeur demande « est-ce que le prix est inférieur à ce que ça vaut actuellement? », la lentille de la croissance demande « est-ce que ça risque de valoir beaucoup plus à l'avenir, ce qui justifierait le prix plus élevé d'aujourd'hui? ». Les deux lentilles impliquent d'estimer quelque chose d'incertain à propos de l'avenir, mais l'investissement axé sur la croissance accorde plus de poids à la trajectoire et au potentiel d'expansion d'une entreprise qu'à ses données fondamentales actuelles et mesurables.

Un risque central de cette lentille, c'est que les attentes de croissance ne se concrétisent pas, ou qu'elles se concrétisent plus lentement que ce que le prix suppose déjà. Une entreprise peut faire croître ses activités de façon importante et voir quand même le prix de son action baisser, si la croissance obtenue est inférieure à ce qui était déjà intégré au prix.

**3. Exemple pratique**
En appliquant la lentille de la croissance, Marcus investit dans une entreprise dont le ratio cours-bénéfice actuel est élevé, en se fondant sur une forte croissance prévue des revenus grâce à une gamme de produits en expansion. Deux ans plus tard, les revenus de l'entreprise augmentent bel et bien, mais à un rythme plus lent que ce que le marché avait intégré au départ, et le prix de l'action baisse malgré une vraie croissance des activités.

L'expérience de Marcus illustre le risque propre à la lentille de la croissance : l'entreprise n'a pas échoué, mais le prix supposait déjà un niveau de croissance qui n'a pas été entièrement atteint, ce qui a déçu les investisseurs qui avaient acheté en s'attendant à une trajectoire plus rapide.

**4. Quiz de pratique**
1. À quoi l'investissement axé sur la croissance donne-t-il généralement la priorité?
   a) Aux données fondamentales actuelles et mesurables plutôt qu'à la trajectoire future
   b) À la trajectoire de croissance future attendue d'une entreprise, souvent à un prix actuel plus élevé
   c) À éviter toute prime de prix
   d) Uniquement à l'historique des dividendes
2. Quel risque est particulièrement associé à la lentille de la croissance?
   a) Aucun — l'investissement axé sur la croissance ne comporte aucun risque
   b) Les attentes de croissance pourraient ne pas se concrétiser aussi vite que le prix le suppose
   c) L'entreprise ne peut jamais croître
   d) Il garantit toujours une perte
3. Vrai ou faux : Une entreprise qui fait réellement croître ses activités verra toujours le prix de son action monter.
4. Pourquoi le placement de Marcus a-t-il perdu de la valeur malgré la vraie croissance des revenus de l'entreprise?
   a) Les revenus de l'entreprise avaient en fait baissé
   b) La croissance obtenue était inférieure à ce que le prix supposait déjà
   c) Il a vendu au mauvais moment pour des raisons sans rapport
   d) L'entreprise a fait faillite

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'investissement axé sur la croissance donne la priorité à la croissance future attendue et accepte souvent un prix actuel plus élevé en conséquence.
2. Le risque principal de la lentille de la croissance, c'est que la croissance attendue ne se concrétise pas aussi complètement ou aussi vite que le prix le suppose.
3. Le prix des actions reflète des attentes; même une vraie croissance peut donc décevoir si elle est inférieure à ce qui était déjà intégré au prix.
4. Le résultat de Marcus vient d'une croissance inférieure aux attentes précédentes du marché, pas d'un échec réel de l'entreprise.

**7. Points clés à retenir**
- L'investissement axé sur la croissance cherche des actifs dont on attend une forte croissance, souvent à un prix actuel plus élevé.
- La lentille de la croissance se distingue de celle de la valeur en donnant la priorité à la trajectoire future plutôt qu'aux données fondamentales actuelles.
- Un risque clé, c'est que la croissance attendue ne se concrétise pas aussi complètement ou aussi vite que le prix le suppose.
- Une vraie croissance des activités ne garantit pas la hausse du prix de l'action si elle est inférieure aux attentes précédentes.
