---
id: WHITE-L2-005
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 5
title: "La lentille du revenu : investir pour le flux de trésorerie"
summary: "Comprends le principe de l'investissement axé sur le revenu, ses sources courantes et le piège du dividende, un rendement élevé qui cache des difficultés."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-005
### La lentille du revenu : investir pour le flux de trésorerie

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le principe général de l'investissement axé sur le revenu.
- Nommer les actifs papier courants qui produisent un revenu.
- Comparer les priorités de la lentille du revenu à celles des lentilles de la valeur et de la croissance.

**2. Contenu principal**
L'investissement axé sur le revenu donne généralement la priorité aux actifs qui produisent un flux de trésorerie régulier — des dividendes d'actions (leçon 21), des intérêts d'obligations (leçons 9 à 12) ou des distributions de certains fonds — plutôt qu'à des actifs dont on attend une forte hausse de prix, mais qui produisent peu ou pas de flux de trésorerie actuel. Cette lentille plaît souvent aux investisseurs qui cherchent un revenu d'appoint ou un revenu de retraite, ce qui fait écho à la discussion du parcours RED sur le flux de trésorerie par rapport à la plus-value en immobilier (RED-L2-006), une vraie structure parallèle entre les couleurs.

Là où la lentille de la croissance accepte un prix plus élevé pour un potentiel futur, et où la lentille de la valeur cherche un rabais par rapport à la valeur actuelle, la lentille du revenu donne la priorité à la fiabilité et à l'importance des distributions continues, en acceptant parfois une hausse de prix plus lente en échange de ce flux de revenu stable.

Un risque associé à cette lentille : un revenu actuel élevé peut parfois signaler des difficultés dans l'entreprise plutôt que de la solidité. Une entreprise dont les perspectives déclinent peut maintenir temporairement un dividende élevé même si sa capacité à le maintenir s'affaiblit, ce qu'on appelle parfois un « piège du dividende », en écho au concept du piège de valeur de la leçon 3.

**3. Exemple pratique**
Cherchant un revenu d'appoint pour sa semi-retraite, Béatrice bâtit un portefeuille axé sur des entreprises et des fonds qui ont un long historique de dividendes réguliers, en donnant la priorité à la constance plutôt qu'au rendement actuel le plus élevé possible. Elle évite précisément une entreprise qui offre un rendement en dividendes inhabituellement élevé, après avoir découvert que ce rendement était surtout élevé parce que le prix de l'action avait beaucoup baissé à cause de vraies difficultés dans l'entreprise — un piège du dividende possible plutôt qu'un signe d'occasion exceptionnelle.

**4. Quiz de pratique**
1. À quoi l'investissement axé sur le revenu donne-t-il généralement la priorité?
   a) Seulement à une hausse de prix rapide
   b) À un flux de trésorerie régulier provenant de dividendes, d'intérêts ou de distributions
   c) À éviter tout flux de trésorerie
   d) Seulement aux entreprises très jeunes et non éprouvées
2. Qu'est-ce qu'un « piège du dividende »?
   a) Un dividende rentable garanti
   b) Un dividende inhabituellement élevé qui peut signaler des difficultés dans l'entreprise plutôt qu'une occasion
   c) Un type de cote d'obligation
   d) Un avantage fiscal
3. Vrai ou faux : Un rendement en dividendes actuel très élevé est toujours le signe d'une entreprise saine et solide.
4. Pourquoi Béatrice a-t-elle évité l'entreprise au rendement en dividendes inhabituellement élevé?
   a) Elle n'aimait pas les dividendes en général
   b) Sa recherche suggérait que le rendement élevé venait de difficultés de l'entreprise, un piège du dividende possible
   c) L'entreprise n'avait aucun historique de dividendes
   d) Elle préférait plutôt l'investissement axé sur la croissance

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'investissement axé sur le revenu donne la priorité à un flux de trésorerie régulier provenant de dividendes, d'intérêts ou de distributions.
2. Un piège du dividende est un rendement inhabituellement élevé qui peut refléter des difficultés de l'entreprise plutôt qu'une vraie occasion.
3. Un rendement inhabituellement élevé peut parfois refléter la baisse du prix d'une action causée par des problèmes sous-jacents, et non de la solidité.
4. La recherche de Béatrice sur la raison du rendement élevé a révélé un piège du dividende possible, ce qui l'a poussée à l'éviter.

**7. Points clés à retenir**
- L'investissement axé sur le revenu donne la priorité au flux de trésorerie régulier plutôt qu'à une hausse de prix rapide.
- Les sources de revenu courantes comprennent les dividendes d'actions, les intérêts d'obligations et les distributions de fonds.
- Cette lentille est parallèle à la discussion du parcours RED sur le flux de trésorerie, ce qui illustre un vrai modèle commun entre les couleurs.
- Un « piège du dividende » — un rendement inhabituellement élevé qui cache des difficultés — est un risque clé à étudier avant d'investir.
