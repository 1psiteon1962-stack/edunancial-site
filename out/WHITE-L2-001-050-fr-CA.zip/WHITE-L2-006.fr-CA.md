---
id: WHITE-L2-006
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 6
title: "La lentille passive ou indicielle : posséder tout le marché"
summary: "Comprends le principe de l'investissement indiciel, en quoi il diffère des approches actives et quels avantages et critiques il suscite."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-006
### La lentille passive ou indicielle : posséder tout le marché

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le principe général de l'investissement passif ou indiciel.
- Comparer l'investissement passif aux lentilles actives vues aux leçons 3 à 5.
- Nommer les avantages généraux et les critiques de cette approche.

**2. Contenu principal**
L'investissement passif ou indiciel consiste généralement à posséder un large panier d'actifs — souvent un indice de marché complet — plutôt qu'à essayer de choisir les gagnants individuels par une analyse de valeur, de croissance ou de revenu. Le principe repose sur des données, souvent discutées dans la recherche financière, selon lesquelles il est difficile de battre de façon fiable un large indice de marché sur de longues périodes en choisissant activement des titres, surtout après avoir tenu compte des frais et des coûts de transaction.

Alors que les approches axées sur la valeur, la croissance et le revenu (leçons 3 à 5) sont toutes des approches « actives » qui exigent d'analyser et de choisir des actifs précis, l'investissement passif accepte généralement les rendements moyens du marché en échange d'une large diversification, de frais habituellement plus bas (leçon 15) et d'une dépendance moindre au fait que le jugement d'un analyste ou d'un investisseur en particulier soit juste.

Les critiques de l'investissement passif comprennent l'idée qu'il garantit des résultats « moyens » par définition (il ne bat jamais le marché, puisqu'il le suit), et des questions sur la structure du marché si l'investissement indiciel devient extrêmement dominant — un sujet de discussion financière toujours ouvert, sans consensus établi.

**3. Exemple pratique**
Après avoir appris les quatre lentilles, Dmitri réfléchit à sa propre situation : peu de temps pour étudier des entreprises individuelles, un long horizon de placement et un certain scepticisme, fondé sur la recherche qu'il a lue, quant à sa capacité de battre le marché de façon fiable en choisissant activement des actions. Il choisit de bâtir le cœur de son portefeuille autour de fonds indiciels larges, en acceptant les rendements moyens du marché en échange de la simplicité, de la diversification et de coûts continus plus bas — un choix réfléchi qui reflète sa situation précise et sa lecture des données, et non un choix par défaut faute d'options.

**4. Quiz de pratique**
1. En quoi consiste généralement l'investissement passif ou indiciel?
   a) Choisir un petit nombre d'actions individuelles gagnantes
   b) Posséder un large panier d'actifs, souvent en suivant un indice de marché complet
   c) Éviter la diversification
   d) Obtenir un rendement garanti supérieur au marché
2. Selon la recherche souvent discutée, quel principe appuie l'approche passive?
   a) Le choix actif de titres bat le marché de façon fiable pour la plupart des investisseurs avec le temps
   b) Il est difficile de battre de façon fiable un large indice en choisissant activement des titres, surtout après les frais
   c) L'investissement passif n'offre aucune diversification
   d) L'investissement actif et passif donnent toujours des rendements identiques
3. Vrai ou faux : Par définition, l'investissement passif garantit des rendements supérieurs à la moyenne du marché.
4. Pourquoi Dmitri a-t-il choisi l'investissement passif pour le cœur de son portefeuille?
   a) Il avait un temps illimité pour étudier des actions individuelles
   b) Son peu de temps pour la recherche, son long horizon et sa lecture des données favorisaient cette approche
   c) Il n'aimait pas la diversification
   d) Il voulait les frais les plus élevés possible

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'investissement passif consiste généralement à posséder un large panier d'actifs, souvent en suivant un indice de marché, plutôt qu'à choisir des gagnants individuels.
2. La recherche souvent discutée suggère qu'il est difficile de battre le marché de façon fiable par un choix actif, surtout après les frais.
3. L'investissement passif suit le marché par conception; par définition, il produit donc des rendements moyens du marché, pas supérieurs à la moyenne.
4. La situation précise de Dmitri et son examen de la recherche l'ont mené à un choix réfléchi et éclairé en faveur de l'investissement passif.

**7. Points clés à retenir**
- L'investissement passif ou indiciel possède un large panier d'actifs plutôt que de choisir des gagnants individuels.
- Cette approche repose sur des données selon lesquelles il est difficile de battre le marché de façon fiable par un choix actif, surtout après les frais.
- L'investissement passif offre la diversification et des frais habituellement plus bas, mais accepte par conception les rendements moyens du marché.
- Le choix entre l'approche passive et active devrait refléter le temps, les compétences et la lecture des données de chaque investisseur, pas un choix par défaut.
