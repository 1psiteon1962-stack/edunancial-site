---
id: WHITE-L2-007
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 7
title: "Combiner les lentilles : pourquoi les investisseurs mélangent les philosophies"
summary: "Vois pourquoi bien des investisseurs combinent plusieurs philosophies, avec des exemples comme l'approche noyau et satellites, et pourquoi chaque partie doit avoir sa raison d'être."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-007
### Combiner les lentilles : pourquoi les investisseurs mélangent les philosophies

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi bien des investisseurs réels combinent plus d'une philosophie.
- Décrire des exemples d'approches combinées.
- Renforcer l'idée qu'aucune lentille n'est la « bonne » dans tous les cas.

**2. Contenu principal**
Après avoir vu une à une les lentilles de la valeur, de la croissance, du revenu et de la gestion passive (leçons 3 à 6), cette leçon rend explicite ce qui était sous-entendu depuis le début : bien des investisseurs et des fonds réels combinent des éléments de plus d'une lentille plutôt que de s'en tenir rigidement à une seule. Une approche « noyau et satellites », par exemple, peut bâtir la plus grande partie d'un portefeuille autour de fonds indiciels passifs (le « noyau »), tout en consacrant une plus petite partie à des occasions de valeur ou de croissance choisies activement (les « satellites »). Une approche de « croissance à prix raisonnable » combine explicitement des considérations de croissance et de valeur, en cherchant des entreprises aux fortes perspectives de croissance qui ne sont pas, en même temps, beaucoup trop chères.

Cette leçon renforce l'idée de la leçon 2 selon laquelle les philosophies sont des lentilles, pas des boîtes rigides : un investisseur n'est pas obligé de s'engager pour toujours dans une seule approche, et les stratégies de bien des investisseurs réfléchis évoluent ou se combinent avec le temps, à mesure que leurs objectifs, leurs connaissances et les conditions du marché changent.

**3. Exemple pratique**
Après avoir appris les quatre lentilles une à une, Aiko décide que sa stratégie combinera des éléments de façon réfléchie plutôt que de n'en choisir qu'une. Elle bâtit la majorité de son portefeuille avec des fonds indiciels passifs à faibles frais (le noyau), tout en consacrant une plus petite part, clairement définie, à des entreprises qui versent des dividendes et qu'elle étudie elle-même, en appliquant la lentille du revenu à cette partie précise.

L'approche d'Aiko reflète un mélange réfléchi plutôt que de la confusion : elle peut expliquer clairement pourquoi chaque partie de son portefeuille existe et quelle lentille guide chaque partie, au lieu de mélanger des approches au hasard sans logique cohérente.

**4. Quiz de pratique**
1. Qu'est-ce qu'une approche « noyau et satellites »?
   a) Une seule philosophie rigide appliquée à tout le portefeuille
   b) Un mélange qui combine un « noyau » passif et des positions « satellites » choisies activement
   c) Un type d'obligation
   d) Un statut de déclaration fiscale
2. Qu'est-ce que la « croissance à prix raisonnable » combine?
   a) Seulement l'investissement passif
   b) Des considérations de croissance et de valeur ensemble
   c) Seulement l'investissement axé sur le revenu
   d) Aucune philosophie précise
3. Vrai ou faux : Les investisseurs doivent s'engager pour toujours dans une seule lentille et ne jamais combiner ni faire évoluer leur approche.
4. Qu'est-ce qui distinguait l'approche combinée d'Aiko d'un mélange au hasard?
   a) Elle pouvait expliquer clairement la logique et la lentille qui guidaient chaque partie de son portefeuille
   b) Elle choisissait ses placements au hasard, sans plan
   c) Elle utilisait une seule lentille pour tout son portefeuille
   d) Elle évitait toute recherche

**5. Corrigé**
1. b  2. b  3. Faux  4. a

**6. Réponses et explications**
1. Une approche noyau et satellites combine un noyau passif avec des positions satellites gérées activement.
2. La « croissance à prix raisonnable » combine explicitement un potentiel de croissance avec une discipline de prix axée sur la valeur.
3. Les investisseurs combinent souvent leurs approches ou les font évoluer avec le temps, au lieu de s'engager rigidement dans une seule.
4. La logique claire d'Aiko pour chaque partie de son portefeuille distinguait son mélange réfléchi d'un mélange non structuré.

**7. Points clés à retenir**
- Bien des investisseurs réels combinent des éléments des philosophies de valeur, de croissance, de revenu et de gestion passive plutôt que d'en choisir une seule.
- L'approche « noyau et satellites » et la « croissance à prix raisonnable » sont des exemples courants d'approches combinées.
- Aucune lentille n'est la bonne dans tous les cas; les combiner reflète une adaptation réfléchie aux objectifs et à la situation.
- Une stratégie combinée cohérente exige de pouvoir expliquer la logique derrière chaque partie d'un portefeuille.
