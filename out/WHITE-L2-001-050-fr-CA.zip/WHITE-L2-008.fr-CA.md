---
id: WHITE-L2-008
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 8
title: "Actions ou obligations : deux pièces, des rôles différents"
summary: "Comprends la différence fondamentale entre posséder une action et détenir une obligation, et pourquoi bien des investisseurs gardent les deux dans leur portefeuille."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-008
### Actions ou obligations : deux pièces, des rôles différents

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer la différence juridique et financière fondamentale entre posséder une action et détenir une obligation.
- Décrire comment les actions et les obligations se comportent généralement de façon différente dans un portefeuille.
- Expliquer pourquoi les investisseurs détiennent souvent les deux plutôt qu'un seul type.

**2. Contenu principal**
Une action représente une part de propriété dans une entreprise. Elle donne à son détenteur un droit sur les profits futurs (possiblement sous forme de dividendes) et sur la valeur résiduelle de l'entreprise, avec des rendements qui peuvent varier beaucoup et qui ne sont pas garantis. Une obligation représente un prêt que l'investisseur fait à l'émetteur (une entreprise ou un gouvernement); l'émetteur est généralement tenu de faire des paiements d'intérêts précis et de rembourser le capital à l'échéance, peu importe la rentabilité de ses activités une année donnée — même si sa capacité réelle à faire ces paiements n'est pas garantie, c'est pourquoi le risque de crédit (leçon 12) est important.

Cette différence façonne la façon dont chacune se comporte généralement dans un portefeuille : les obligations offrent généralement un revenu plus prévisible (mais pas sans risque) et tendent à être moins volatiles que les actions dans des conditions de marché normales, alors que les actions offrent généralement un potentiel de croissance à long terme plus élevé, avec une plus grande volatilité et aucun paiement garanti. Bien des investisseurs détiennent les deux précisément parce que leurs comportements différents peuvent aider à équilibrer le profil global de risque et de rendement d'un portefeuille — une notion approfondie à la leçon 16 sur la répartition de l'actif.

**3. Exemple pratique**
En examinant le comportement de son portefeuille pendant une période de volatilité boursière, Felix remarque que ses obligations ont connu de plus petites variations de prix que ses actions pendant la même période, ce qui correspond aux tendances générales décrites dans cette leçon (sans que ce soit garanti pour chaque obligation dans chaque situation). Cette expérience l'aide à comprendre concrètement pourquoi son portefeuille combine des actions et des obligations plutôt qu'un seul type : chaque pièce joue un rôle différent, et leurs comportements habituels différents travaillent ensemble au lieu de se répéter.

**4. Quiz de pratique**
1. Que représente le fait de posséder une action?
   a) Un prêt à l'entreprise
   b) Une part de propriété dans une entreprise
   c) Une obligation gouvernementale
   d) Un compte d'épargne
2. Que représente le fait de détenir une obligation?
   a) Une part de propriété dans une entreprise
   b) Un prêt de l'investisseur à l'émetteur, avec des obligations de paiement précises
   c) Un type d'immobilier
   d) Un profit garanti
3. Vrai ou faux : Les obligations sont des placements entièrement sans risque, avec des paiements garantis en toutes circonstances.
4. Pourquoi bien des investisseurs détiennent-ils à la fois des actions et des obligations?
   a) Elles se comportent de façon identique, donc ça n'a pas d'importance
   b) Leurs comportements habituels différents peuvent aider à équilibrer le profil global de risque et de rendement d'un portefeuille
   c) La loi l'exige
   d) Les obligations garantissent des rendements plus élevés que les actions

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une action représente une part de propriété dans une entreprise, avec des rendements liés à sa performance.
2. Une obligation représente un prêt à l'émetteur, avec des obligations précises de paiement des intérêts et de remboursement du capital.
3. Les paiements d'une obligation dépendent de la capacité de l'émetteur à payer; les obligations comportent donc un risque de crédit, pas une garantie.
4. Les actions et les obligations tendent à se comporter différemment, et les combiner peut aider à équilibrer le risque et le rendement global d'un portefeuille.

**7. Points clés à retenir**
- Une action représente une part de propriété dans une entreprise; une obligation représente un prêt avec des obligations de paiement précises.
- Les obligations offrent généralement un revenu plus prévisible et moins de volatilité; les actions offrent généralement plus de potentiel de croissance et plus de volatilité.
- Aucune n'est sans risque : les paiements d'une obligation dépendent de la capacité de l'émetteur à payer.
- Bien des investisseurs détiennent les deux parce que leurs comportements habituels différents peuvent aider à équilibrer le risque et le rendement global du portefeuille.
