---
id: WHITE-L2-009
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 9
title: "Les bases des obligations : valeur nominale, coupon et échéance"
summary: "Apprends les trois éléments qui définissent une obligation — valeur nominale, taux du coupon et échéance — et calcule un paiement d'intérêts annuel simple."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-009
### Les bases des obligations : valeur nominale, coupon et échéance

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir la valeur nominale, le taux du coupon et la date d'échéance d'une obligation.
- Expliquer comment ces trois éléments se combinent pour définir les conditions de base d'une obligation.
- Calculer un paiement de coupon annuel simple à partir de la valeur nominale et du taux du coupon.

**2. Contenu principal**
Chaque obligation a trois éléments fondamentaux qui la définissent. La valeur nominale (aussi appelée valeur au pair) est le montant que l'émetteur s'engage à rembourser au détenteur de l'obligation à l'échéance — souvent un chiffre rond, comme 1 000 $ par obligation, même si ça varie. Le taux du coupon est le taux d'intérêt annuel déclaré que l'émetteur paie sur la valeur nominale, habituellement versé en paiements périodiques (souvent semestriels). La date d'échéance est la date précise à laquelle l'émetteur doit rembourser la valeur nominale au complet.

Ensemble, ces trois éléments définissent la structure de base des flux de trésorerie d'une obligation : un investisseur qui achète une obligation sait généralement, dès l'achat, exactement quels paiements d'intérêts attendre et quand le capital sera remboursé — à condition que l'émetteur ne fasse pas défaut (leçon 12). Cette prévisibilité est une des principales raisons pour lesquelles on associe souvent les obligations à la lentille du revenu (leçon 5) et à la stabilité d'un portefeuille (leçon 8).

**3. Exemple pratique**
Une investisseuse achète une obligation d'une valeur nominale de 1 000 $, avec un taux du coupon annuel de 4 % et une échéance de 10 ans. L'obligation versera donc 40 $ d'intérêts par année (souvent divisés en deux paiements semestriels de 20 $), et l'émetteur remboursera la pleine valeur nominale de 1 000 $ à l'échéance de l'obligation, dans 10 ans — à condition qu'aucun défaut ne survienne d'ici là.

Comprendre ces trois chiffres donne à l'investisseuse une image claire, dès le départ, des flux de trésorerie attendus de l'obligation pendant toute sa durée, contrairement à une action, dont les dividendes futurs et la valeur finale sont beaucoup moins certains.

**4. Quiz de pratique**
1. Qu'est-ce que la « valeur nominale » d'une obligation?
   a) Le prix de négociation actuel
   b) Le montant que l'émetteur rembourse au détenteur à l'échéance
   c) Le rendement en dividendes
   d) La capitalisation boursière de l'action
2. Que représente le « taux du coupon »?
   a) La date d'échéance de l'obligation
   b) Le taux d'intérêt annuel déclaré payé sur la valeur nominale
   c) Le prix de l'action de l'entreprise
   d) Une déduction fiscale
3. Vrai ou faux : La valeur nominale, le taux du coupon et la date d'échéance d'une obligation n'ont aucun lien avec ses flux de trésorerie attendus.
4. Dans l'exemple pratique, combien d'intérêts annuels l'obligation verse-t-elle?
   a) 4 $
   b) 40 $
   c) 400 $
   d) 1 000 $

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La valeur nominale est le montant que l'émetteur s'engage à rembourser à l'échéance.
2. Le taux du coupon est le taux d'intérêt annuel déclaré payé sur la valeur nominale de l'obligation.
3. Ensemble, ces éléments définissent directement la structure des flux de trésorerie attendus d'une obligation pendant toute sa durée.
4. Un taux du coupon de 4 % sur une obligation d'une valeur nominale de 1 000 $ donne 40 $ d'intérêts par année.

**7. Points clés à retenir**
- La valeur nominale est le montant remboursé à l'échéance; le taux du coupon est le taux d'intérêt annuel déclaré; la date d'échéance est le moment où le capital est remboursé.
- Ensemble, ces trois éléments définissent la structure de base des flux de trésorerie d'une obligation, connue dès le départ.
- Cette prévisibilité (en l'absence de défaut) est une des principales raisons pour lesquelles les obligations appuient la lentille du revenu et la stabilité du portefeuille.
- Calculer le paiement de coupon d'une obligation, c'est simplement multiplier la valeur nominale par le taux du coupon.
