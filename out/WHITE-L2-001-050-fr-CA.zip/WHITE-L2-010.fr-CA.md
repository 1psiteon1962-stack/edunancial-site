---
id: WHITE-L2-010
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 10
title: "Comment les taux d'intérêt et le prix des obligations interagissent"
summary: "Comprends pourquoi le prix des obligations existantes baisse quand les taux montent, et l'inverse, et pourquoi les obligations à long terme sont plus sensibles."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-010
### Comment les taux d'intérêt et le prix des obligations interagissent

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer la relation inverse générale entre les taux d'intérêt et le prix des obligations existantes.
- Décrire de façon conceptuelle pourquoi cette relation existe.
- Reconnaître comment la durée jusqu'à l'échéance d'une obligation influence sa sensibilité aux changements de taux.

**2. Contenu principal**
Le prix des obligations existantes et les taux d'intérêt en vigueur évoluent généralement dans des directions opposées — une relation fondamentale et largement observée sur les marchés des titres à revenu fixe. Quand les taux d'intérêt en vigueur montent, les nouvelles obligations offrent des taux du coupon plus élevés pour suivre, ce qui rend les obligations existantes, dont le coupon plus bas est déjà fixé, relativement moins attrayantes; leur prix sur le marché baisse généralement pour compenser un acheteur potentiel pour ce paiement relativement plus faible. Quand les taux en vigueur baissent, les obligations existantes, dont le coupon plus élevé est déjà fixé, deviennent relativement plus attrayantes, et leur prix sur le marché monte généralement.

Ça ne touche pas les paiements promis d'une obligation détenue jusqu'à l'échéance (en l'absence de défaut) : l'émetteur doit toujours la valeur nominale et les paiements de coupon d'origine, peu importe les variations du prix sur le marché entre-temps. C'est surtout important pour un investisseur qui pourrait avoir besoin ou envie de vendre une obligation avant l'échéance, ou pour quiconque évalue un fonds d'obligations, dont le prix des parts reflète la valeur marchande actuelle des obligations qu'il détient.

En général, les obligations dont l'échéance est plus longue sont plus sensibles aux changements de taux d'intérêt que celles dont l'échéance est plus courte, puisqu'un changement de taux touche plus fortement, en valeur actualisée, une plus longue série de paiements fixes futurs.

**3. Exemple pratique**
Un investisseur détient une obligation qui verse un coupon de 3 %. Peu après l'achat, les taux d'intérêt en vigueur montent, et les nouvelles obligations semblables offrent maintenant un coupon de 5 %. Si cet investisseur devait vendre son obligation à 3 % avant l'échéance, il devrait généralement accepter un prix plus bas que celui qu'il a payé, puisqu'un acheteur rationnel préférerait une nouvelle obligation à 5 %, à moins d'obtenir un rabais sur l'ancienne obligation qui rapporte moins.

Si, au contraire, cet investisseur garde l'obligation jusqu'à l'échéance, il reçoit quand même ses paiements de coupon de 3 % d'origine et la pleine valeur nominale à l'échéance, sans être touché par cette variation de prix entre-temps — ce qui montre pourquoi cette relation compte différemment selon qu'une obligation est détenue jusqu'à l'échéance ou possiblement vendue plus tôt.

**4. Quiz de pratique**
1. Qu'arrive-t-il généralement au prix des obligations existantes quand les taux d'intérêt montent?
   a) Il monte généralement
   b) Il baisse généralement
   c) Il n'est pas touché
   d) Les obligations font automatiquement défaut
2. Pourquoi cette relation inverse existe-t-elle généralement?
   a) Les obligations existantes au coupon plus bas deviennent moins attrayantes que les nouvelles obligations au coupon plus élevé
   b) Le prix des obligations est fixé au hasard
   c) Les taux d'intérêt n'ont aucun effet sur l'attrait des obligations
   d) Toutes les obligations versent le même taux du coupon
3. Vrai ou faux : Les paiements promis d'une obligation détenue jusqu'à l'échéance sont directement touchés par les variations de prix sur le marché entre-temps.
4. Quelles obligations sont généralement plus sensibles aux changements de taux d'intérêt?
   a) Les obligations à échéance plus courte
   b) Les obligations à échéance plus longue
   c) Toutes les obligations sont aussi sensibles
   d) Les obligations ne sont pas sensibles aux taux

**5. Corrigé**
1. b  2. a  3. Faux  4. b

**6. Réponses et explications**
1. La hausse des taux d'intérêt fait généralement baisser le prix des obligations existantes (au coupon plus bas).
2. Les obligations existantes au coupon plus bas deviennent moins attrayantes que les nouvelles obligations au coupon plus élevé, ce qui pousse leur prix vers le bas.
3. Une obligation détenue jusqu'à l'échéance reçoit quand même les paiements promis au départ, peu importe les variations de prix entre-temps.
4. Les obligations à échéance plus longue sont généralement plus sensibles aux changements de taux d'intérêt que celles à échéance plus courte.

**7. Points clés à retenir**
- Le prix des obligations existantes et les taux d'intérêt en vigueur évoluent généralement dans des directions opposées.
- Cette relation vient du fait que le taux du coupon des nouvelles obligations change pour suivre les taux en vigueur.
- Une obligation détenue jusqu'à l'échéance reçoit quand même ses paiements promis au départ, peu importe les variations de prix entre-temps.
- Les obligations à échéance plus longue sont généralement plus sensibles aux changements de taux d'intérêt que celles à échéance plus courte.
