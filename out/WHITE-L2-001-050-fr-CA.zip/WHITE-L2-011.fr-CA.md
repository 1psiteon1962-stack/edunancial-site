---
id: WHITE-L2-011
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 11
title: "Les débentures et la dette non garantie : un regard plus attentif"
summary: "Comprends ce qu'est une débenture, en quoi la dette non garantie diffère de la dette garantie et pourquoi elle comporte habituellement plus de risque."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-011
### Les débentures et la dette non garantie : un regard plus attentif

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle une débenture.
- Faire la différence entre une dette non garantie et une dette garantie.
- Expliquer pourquoi la dette non garantie comporte généralement un risque différent de la dette garantie.

**2. Contenu principal**
Une débenture est un type d'obligation qui n'est pas garantie par un bien précis. La promesse de paiement de l'émetteur repose sur sa solvabilité générale et sur sa capacité à générer des revenus futurs, plutôt que sur un bien précis donné en garantie de la dette. Ça contraste avec la dette garantie, où des biens précis sont donnés en garantie (en écho à la discussion du parcours RED sur les prêts hypothécaires, où la propriété elle-même garantit le prêt).

Comme les détenteurs de débentures n'ont un droit que sur les biens généraux et la solvabilité de l'émetteur, plutôt que sur un bien précis donné en garantie, les débentures comportent généralement un peu plus de risque qu'une dette garantie comparable du même émetteur. En cas de défaut ou de faillite, les détenteurs de débentures non garanties sont habituellement remboursés après que les créanciers garantis ont été payés à partir de leurs garanties précises, mais avant les détenteurs d'actions dans la plupart des structures de capital standards.

C'est un écho utile, entre les couleurs, des notions de prêt garanti du parcours RED (prêts hypothécaires, charges), appliquées ici dans le contexte WHITE (actifs papier) : le principe des droits garantis ou non garantis revient dans différentes catégories d'actifs.

**3. Exemple pratique**
En comparant deux obligations de la même entreprise, Halima remarque que l'une est une obligation garantie par des équipements précis de l'entreprise, alors que l'autre est une débenture non garantie, appuyée seulement par la solvabilité générale de l'entreprise. La débenture offre un taux du coupon un peu plus élevé que l'obligation garantie, pour compenser les investisseurs pour son risque relativement plus élevé si l'entreprise connaît des difficultés financières, puisque, dans ce scénario, les détenteurs de débentures auraient un droit plus faible sur des biens précis que les détenteurs de l'obligation garantie.

**4. Quiz de pratique**
1. Qu'est-ce qui appuie une débenture?
   a) Un bien précis donné en garantie
   b) La solvabilité générale de l'émetteur, sans garantie précise
   c) Uniquement de l'immobilier
   d) Une garantie gouvernementale
2. En cas de défaut, comment les détenteurs de débentures sont-ils généralement traités par rapport aux créanciers garantis?
   a) Ils sont remboursés en premier, avant les créanciers garantis
   b) Ils sont habituellement remboursés après que les créanciers garantis ont été payés à partir de leurs garanties
   c) Ils ne reçoivent rien, peu importe les circonstances
   d) Il n'y a aucune différence de traitement
3. Vrai ou faux : Les débentures et les obligations garanties d'un même émetteur comportent exactement le même niveau de risque.
4. Pourquoi la débenture de l'exemple pratique offrait-elle un taux du coupon plus élevé que l'obligation garantie?
   a) C'était un placement plus sûr
   b) Ça compensait les investisseurs pour un risque relativement plus élevé, faute de garantie précise
   c) Elle avait une échéance plus courte
   d) Elle était garantie par le gouvernement

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une débenture est appuyée par la solvabilité générale de l'émetteur plutôt que par un bien précis donné en garantie.
2. En cas de défaut, les détenteurs de débentures sont habituellement remboursés après que les créanciers garantis ont récupéré leur argent à partir de leurs garanties précises.
3. Les débentures comportent généralement plus de risque qu'une dette garantie comparable du même émetteur, faute de garantie précise.
4. Le taux du coupon plus élevé compensait les détenteurs de débentures pour leur droit relativement plus faible en cas de défaut possible.

**7. Points clés à retenir**
- Une débenture est une obligation non garantie, appuyée par la solvabilité générale de l'émetteur, et non par une garantie précise.
- La dette garantie est appuyée par des biens précis donnés en garantie, en écho aux notions du parcours RED.
- Les débentures comportent généralement plus de risque, et souvent un rendement plus élevé, qu'une dette garantie comparable.
- En cas de défaut, les créanciers garantis sont habituellement payés à partir de leurs garanties avant que les détenteurs de débentures non garanties soient remboursés.
