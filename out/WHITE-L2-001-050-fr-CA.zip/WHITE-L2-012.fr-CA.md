---
id: WHITE-L2-012
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 12
title: "Les cotes des obligations et le risque de crédit"
summary: "Comprends à quoi servent les cotes de crédit, la différence entre les obligations de qualité supérieure et à rendement élevé, et le lien entre le risque de crédit et le rendement."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-012
### Les cotes des obligations et le risque de crédit

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le but général des cotes de crédit des obligations.
- Faire la différence, de façon conceptuelle, entre les obligations de qualité supérieure et les obligations à rendement élevé (spéculatives).
- Expliquer comment le risque de crédit interagit avec le rendement.

**2. Contenu principal**
Les agences de notation évaluent les émetteurs d'obligations (et parfois des émissions précises) et leur attribuent une cote, qui reflète une estimation de la capacité et de la volonté de l'émetteur à respecter ses obligations de remboursement. Ces cotes sont généralement regroupées en deux grandes catégories : les obligations de qualité supérieure (*investment-grade*, qui indiquent un risque de crédit évalué relativement plus faible) et les obligations à rendement élevé ou « de qualité spéculative » (parfois appelées de façon informelle « obligations pourries », qui indiquent un risque de crédit évalué relativement plus élevé).

Les cotes sont des évaluations, pas des garanties : un émetteur très bien coté peut quand même faire défaut, et un émetteur moins bien coté peut quand même respecter entièrement ses obligations. Les cotes sont une donnée parmi d'autres pour évaluer le risque de crédit; elles ne remplacent pas la compréhension de la situation financière réelle d'un émetteur.

Le risque de crédit interagit directement avec le rendement : les obligations perçues comme plus à risque de défaut doivent généralement offrir des rendements plus élevés pour attirer des investisseurs prêts à accepter ce risque, alors que les obligations perçues comme plus sûres offrent généralement des rendements plus bas. C'est une application précise d'une relation risque-rendement plus large qui revient partout dans les actifs papier.

**3. Exemple pratique**
En comparant deux obligations, Teo remarque que l'une a une cote élevée de qualité supérieure et offre un rendement modeste, alors que l'autre a une cote de rendement élevé (qualité spéculative) et offre un rendement beaucoup plus élevé. Au lieu de supposer que l'obligation à rendement plus élevé est simplement une « meilleure affaire », Teo reconnaît que ce rendement plus élevé existe précisément pour compenser un risque de crédit évalué plus élevé — et il étudie davantage la situation financière réelle de l'émetteur avant de décider si ce risque ajouté convient à sa propre tolérance au risque et à ses objectifs.

**4. Quiz de pratique**
1. Qu'évaluent généralement les cotes de crédit des obligations?
   a) L'orientation générale du marché boursier
   b) La capacité et la volonté d'un émetteur à respecter ses obligations de remboursement
   c) Seulement la date d'échéance de l'obligation
   d) La valeur des propriétés immobilières
2. Qu'indique généralement une obligation « à rendement élevé » ou de qualité spéculative?
   a) Un risque de crédit évalué plus faible
   b) Un risque de crédit évalué plus élevé
   c) Un remboursement garanti
   d) Aucun risque de défaut
3. Vrai ou faux : Une cote de crédit d'obligation garantit que l'émetteur ne fera jamais défaut.
4. Pourquoi l'obligation à rendement élevé de l'exemple pratique offrait-elle un rendement beaucoup plus élevé que l'obligation de qualité supérieure?
   a) Elle était sans risque
   b) Le rendement plus élevé compense un risque de crédit évalué plus élevé
   c) Elle avait une échéance plus courte
   d) Elle était garantie par de l'immobilier

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Les cotes des obligations évaluent la capacité et la volonté d'un émetteur à respecter ses obligations de remboursement.
2. Une cote de rendement élevé ou de qualité spéculative indique un risque de crédit évalué relativement plus élevé.
3. Les cotes sont des évaluations, pas des garanties; même des émetteurs très bien cotés peuvent faire défaut.
4. Le rendement plus élevé de l'obligation spéculative compense les investisseurs qui acceptent un risque de crédit évalué plus élevé.

**7. Points clés à retenir**
- Les cotes de crédit des obligations évaluent la capacité et la volonté d'un émetteur à respecter ses obligations de remboursement.
- Les cotes sont généralement regroupées en catégories de qualité supérieure et de rendement élevé (qualité spéculative).
- Les cotes sont des évaluations, pas des garanties de remboursement ou d'absence de défaut.
- Un risque de crédit évalué plus élevé correspond généralement à un rendement exigé plus élevé, ce qui reflète une relation risque-rendement fondamentale.
