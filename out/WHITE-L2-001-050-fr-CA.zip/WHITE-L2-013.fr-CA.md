---
id: WHITE-L2-013
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 13
title: "Fonds communs de placement ou FNB : les différences de structure"
summary: "Compare les fonds communs de placement et les FNB sur le plan de la négociation, du prix et des montants minimums, et vois pourquoi les deux peuvent suivre la même stratégie."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-013
### Fonds communs de placement ou FNB : les différences de structure

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Comparer les fonds communs de placement et les FNB sur le plan des mécanismes de négociation, du prix et des montants minimums habituels.
- Expliquer comment chaque structure influence l'expérience pratique d'un investisseur.
- Reconnaître que les deux peuvent poursuivre des stratégies de placement sous-jacentes semblables.

**2. Contenu principal**
Les fonds communs de placement et les fonds négociés en Bourse (FNB, ou *ETF* en anglais) mettent tous les deux en commun l'argent des investisseurs dans un panier diversifié d'actifs sous-jacents, mais leurs structures diffèrent sur le plan pratique. Les parts d'un fonds commun de placement sont habituellement achetées et vendues une fois par jour, à un seul prix calculé (la valeur liquidative, ou VL) établi après la fermeture des marchés, et certains fonds communs exigent un placement minimum. Les parts d'un FNB, au contraire, se négocient habituellement tout au long de la journée en Bourse, comme une action, avec un prix qui varie continuellement selon l'offre et la demande (et qui suit généralement de près la valeur des actifs sous-jacents, sans être parfait à chaque instant), et souvent sans exigence de placement minimum au-delà du prix d'une seule part (ou d'une fraction de part, là où c'est possible).

Les deux structures peuvent poursuivre des stratégies sous-jacentes semblables : un fonds commun et un FNB peuvent chacun suivre le même indice, ou chacun poursuivre une stratégie de valeur ou de croissance gérée activement. Le choix entre les deux dépend souvent de la souplesse de négociation, de la structure des coûts (leçon 15) et de la disponibilité de fonds précis, plutôt que d'une structure supérieure en tout pour chaque stratégie.

**3. Exemple pratique**
En comparant deux fonds qui suivent le même large indice de marché, l'un structuré comme un fonds commun de placement et l'autre comme un FNB, Renée remarque que le fonds commun ne permet des transactions qu'au prix de la VL de fin de journée, alors que le FNB peut être acheté ou vendu à n'importe quel moment pendant les heures de marché, à son prix de négociation actuel. Pour sa situation précise — de petits achats occasionnels au cours du mois plutôt qu'une grosse transaction —, elle trouve que la souplesse du FNB et l'absence de placement minimum répondent mieux à ses besoins pratiques, même si les deux fonds suivent exactement le même indice sous-jacent.

**4. Quiz de pratique**
1. Quand le prix des parts d'un fonds commun de placement est-il habituellement établi et quand se négocient-elles?
   a) Continuellement tout au long de la journée
   b) Une fois par jour, à une valeur liquidative calculée après la fermeture des marchés
   c) Jamais — on ne peut pas les négocier
   d) Seulement une fois par année
2. Comment les parts d'un FNB se négocient-elles habituellement?
   a) Seulement une fois par jour
   b) Tout au long de la journée en Bourse, comme une action
   c) Seulement par l'entremise d'une banque
   d) On ne peut pas les acheter ni les vendre
3. Vrai ou faux : Les fonds communs de placement et les FNB ne peuvent jamais poursuivre une stratégie de placement sous-jacente identique ou semblable.
4. Pourquoi Renée a-t-elle préféré la structure du FNB pour sa situation précise?
   a) C'était la seule option disponible
   b) Sa souplesse de négociation pendant la journée et l'absence de minimum convenaient à ses achats plus petits et plus fréquents
   c) Le fonds commun était illégal
   d) Les FNB garantissent des rendements plus élevés

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Le prix des fonds communs de placement est habituellement établi, et leurs parts négociées, une fois par jour, à une VL calculée après la fermeture des marchés.
2. Les FNB se négocient habituellement tout au long de la journée en Bourse, avec un prix qui varie continuellement.
3. Les deux structures peuvent poursuivre des stratégies sous-jacentes semblables, voire identiques, comme suivre le même indice.
4. La façon pratique dont Renée fait ses transactions était mieux servie par la souplesse du FNB pendant la journée et l'absence de placement minimum.

**7. Points clés à retenir**
- Les fonds communs de placement se négocient une fois par jour à une VL calculée; les FNB se négocient toute la journée comme des actions.
- Les FNB n'ont souvent pas d'exigence de placement minimum au-delà du prix d'une seule part; certains fonds communs ont des minimums.
- Les deux structures peuvent poursuivre des stratégies de placement sous-jacentes semblables ou identiques.
- Le bon choix dépend souvent des besoins de souplesse de négociation et de la structure des coûts, pas d'une supériorité universelle.
