---
id: WHITE-L2-014
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 14
title: "Le fonctionnement des FNB : création, rachat et écart de suivi"
summary: "Comprends de façon conceptuelle comment le mécanisme de création et de rachat garde le prix d'un FNB près de sa valeur, et ce qu'est l'écart de suivi."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-014
### Le fonctionnement des FNB : création, rachat et écart de suivi

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer de façon conceptuelle comment le mécanisme de création et de rachat des FNB aide à garder leur prix aligné sur la valeur sous-jacente.
- Définir en termes généraux l'« écart de suivi ».
- Reconnaître que ce mécanisme fonctionne surtout en coulisse pour l'investisseur moyen.

**2. Contenu principal**
Dans la suite de la comparaison de la leçon précédente, cette leçon explique de façon conceptuelle pourquoi le prix des FNB suit généralement de près la valeur de leurs actifs sous-jacents tout au long de la journée. Des participants institutionnels spécialisés (souvent appelés « participants autorisés ») peuvent créer de nouvelles parts de FNB en remettant au fonds un panier des actifs sous-jacents, ou racheter des parts de FNB en recevant en retour les actifs sous-jacents, par gros blocs. Ce mécanisme crée un incitatif fondé sur l'arbitrage : si le prix de négociation d'un FNB s'éloigne trop de sa valeur sous-jacente, ces participants peuvent faire un profit en créant ou en rachetant des parts, ce qui tend à ramener le prix du FNB vers sa valeur sous-jacente.

Pour la plupart des investisseurs ordinaires, ce mécanisme se passe complètement en coulisse et n'exige aucun geste direct ni aucune connaissance particulière pour utiliser efficacement un FNB. Il aide simplement à expliquer pourquoi le prix des FNB reste généralement assez proche de leur valeur sous-jacente pendant la journée de négociation, au lieu de s'en éloigner au hasard.

L'« écart de suivi » désigne la mesure dans laquelle la performance réelle d'un FNB (ou d'un fonds commun indiciel) s'écarte de celle de son indice cible au fil du temps — idéalement petit, mais jamais garanti d'être exactement nul, à cause des frais, des coûts de transaction et d'autres facteurs structurels.

**3. Exemple pratique**
En étudiant deux FNB qui suivent le même indice, Kwame remarque que l'un a toujours eu un écart de suivi plus petit que l'autre au fil du temps; autrement dit, ses rendements réels se sont rapprochés davantage de ceux de l'indice sous-jacent. Sans avoir besoin de comprendre tout le fonctionnement des participants autorisés et du processus de création et de rachat, Kwame utilise cette comparaison de l'écart de suivi comme un facteur pratique parmi d'autres (avec le ratio des frais, vu à la prochaine leçon) pour choisir entre deux FNB par ailleurs semblables.

**4. Quiz de pratique**
1. Quel est le but général du mécanisme de création et de rachat des FNB?
   a) Garantir un prix précis
   b) Aider à garder le prix de négociation d'un FNB aligné sur la valeur de ses actifs sous-jacents
   c) Éliminer tous les frais
   d) Empêcher toute négociation pendant la journée
2. Qu'est-ce que l'« écart de suivi »?
   a) Un type de défaut d'obligation
   b) La mesure dans laquelle la performance réelle d'un fonds s'écarte de celle de son indice cible
   c) Un placement minimum de fonds commun
   d) Une pénalité fiscale
3. Vrai ou faux : Les investisseurs ordinaires doivent comprendre personnellement le mécanisme de création et de rachat, et y participer, pour utiliser efficacement les FNB.
4. Comment Kwame a-t-il utilisé l'écart de suivi dans sa décision?
   a) Il l'a complètement ignoré
   b) Il l'a utilisé comme un facteur pratique pour comparer deux FNB semblables
   c) Il a supposé que l'écart de suivi était toujours exactement nul
   d) Il a seulement tenu compte du nom du fonds

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Le mécanisme de création et de rachat aide à garder le prix de négociation d'un FNB aligné sur la valeur de ses actifs sous-jacents grâce à un processus fondé sur l'arbitrage.
2. L'écart de suivi mesure à quel point les rendements réels d'un fonds correspondent à ceux de son indice cible.
3. Ce mécanisme fonctionne en coulisse grâce aux participants autorisés; les investisseurs ordinaires n'ont pas besoin d'y participer directement.
4. Kwame a utilisé l'écart de suivi comme un facteur de comparaison pratique, avec le ratio des frais, pour choisir entre des FNB semblables.

**7. Points clés à retenir**
- Les participants autorisés utilisent un mécanisme de création et de rachat qui aide à garder le prix des FNB aligné sur leur valeur sous-jacente.
- Ce processus est en grande partie invisible pour les investisseurs ordinaires, mais il explique le comportement du prix des FNB pendant la journée.
- L'écart de suivi mesure à quel point la performance réelle d'un fonds correspond à son indice cible.
- Un plus petit écart de suivi est généralement préférable, même s'il n'est jamais garanti d'être exactement nul.
