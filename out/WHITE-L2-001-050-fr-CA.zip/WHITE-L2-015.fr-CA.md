---
id: WHITE-L2-015
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 15
title: "Les ratios des frais : le coût discret qui se compose"
summary: "Comprends ce qu'est le ratio des frais d'un fonds, pourquoi il passe facilement inaperçu et comment une petite différence peut devenir énorme sur plusieurs décennies."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-015
### Les ratios des frais : le coût discret qui se compose

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir le ratio des frais et expliquer comment il est prélevé.
- Expliquer pourquoi de petites différences de ratio des frais peuvent se composer de façon importante sur de longues périodes.
- Comparer les ratios des frais comme un facteur parmi d'autres pour évaluer un fonds.

**2. Contenu principal**
Le ratio des frais (souvent appelé ratio des frais de gestion, ou RFG, au Canada) correspond aux frais annuels qu'un fonds prélève, exprimés en pourcentage de l'actif, pour couvrir ses coûts d'exploitation. Il est généralement déduit automatiquement et graduellement des rendements du fonds, au lieu d'être facturé comme un montant séparé et visible — ce qui fait que les investisseurs sous-estiment facilement son effet à long terme, puisqu'ils ne voient jamais de facture explicite.

Comme ces frais se composent avec le temps, en même temps que le placement lui-même, des différences qui semblent petites (par exemple 0,05 % contre 0,75 % par année) peuvent s'accumuler en une différence importante dans la valeur finale du portefeuille sur de longues périodes, surtout sur des horizons de la durée d'une retraite, comme ceux que planifient bien des investisseurs du parcours WHITE. C'est une application directe de la notion de composition vue au niveau 1, appliquée ici à un coût discret plutôt qu'à un gain visible.

Le ratio des frais n'est pas le seul facteur pour choisir un fonds — l'écart de suivi (leçon 14), la stratégie et la lentille précises (leçons 2 à 7) et les objectifs de l'investisseur comptent aussi —, mais il mérite une attention réfléchie précisément parce que son effet est facile à oublier.

**3. Exemple pratique**
En comparant deux fonds qui suivent le même large indice, le fonds A a un ratio des frais annuel de 0,05 % et le fonds B, un ratio des frais annuel de 0,75 %. En modélisant un placement hypothétique à long terme détenu pendant plusieurs décennies, un investisseur peut voir que cette différence qui semble petite se compose en une différence importante dans la valeur finale du portefeuille sur cette période, uniquement à cause de la différence de coûts continus — en supposant une performance sous-jacente par ailleurs semblable, puisque les deux fonds suivent exactement le même indice.

Cet exercice aide l'investisseur à comprendre pourquoi le ratio des frais, même s'il est discret et facile à oublier, mérite la même attention réfléchie que les décisions de placement plus visibles.

**4. Quiz de pratique**
1. Qu'est-ce qu'un ratio des frais?
   a) Des frais d'achat uniques
   b) Les frais annuels qu'un fonds prélève, en pourcentage de l'actif, pour couvrir ses coûts d'exploitation
   c) Un impôt gouvernemental
   d) Un rendement garanti
2. Pourquoi de petites différences de ratio des frais peuvent-elles compter beaucoup sur de longues périodes?
   a) Elles ne comptent pas du tout
   b) Le coût se compose avec le temps, en même temps que le placement lui-même
   c) Les ratios des frais ne sont prélevés qu'une seule fois
   d) Ils sont toujours identiques d'un fonds à l'autre
3. Vrai ou faux : Le ratio des frais est habituellement facturé à l'investisseur sous forme de facture séparée et très visible.
4. Qu'est-ce que l'exemple pratique a démontré à propos du fonds A et du fonds B?
   a) Leur différence de ratio des frais n'a eu aucun effet avec le temps
   b) Une différence de ratio des frais qui semblait petite s'est composée en une différence importante de valeur finale
   c) Le fonds B a toujours fait mieux que le fonds A malgré ses frais plus élevés
   d) Les ratios des frais n'ont aucune importance pour les fonds indiciels

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Un ratio des frais, ce sont les frais annuels, calculés selon l'actif, qu'un fonds prélève pour couvrir ses coûts d'exploitation.
2. Comme ces frais se composent avec le temps en même temps que le placement, même de petites différences peuvent s'accumuler de façon importante.
3. Les ratios des frais sont généralement déduits discrètement des rendements du fonds, au lieu d'être facturés séparément et de façon visible.
4. L'exemple pratique a montré comment une petite différence de ratio des frais se compose en un écart important sur une longue période.

**7. Points clés à retenir**
- Le ratio des frais, ce sont les frais annuels, en pourcentage, qu'un fonds prélève pour ses coûts d'exploitation.
- Comme il est déduit discrètement au lieu d'être facturé de façon visible, son effet à long terme est facile à sous-estimer.
- De petites différences de ratio des frais se composent de façon importante sur de longues périodes.
- Le ratio des frais est un facteur important parmi d'autres : la stratégie, l'écart de suivi et les objectifs personnels comptent aussi.
