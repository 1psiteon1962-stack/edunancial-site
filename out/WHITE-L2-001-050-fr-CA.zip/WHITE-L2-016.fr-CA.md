---
id: WHITE-L2-016
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 16
title: "La répartition de l'actif : combiner actions, obligations et liquidités"
summary: "Comprends ce qu'est la répartition de l'actif, son lien avec la tolérance au risque et l'horizon de placement, et pourquoi il n'existe pas de formule universelle."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-016
### La répartition de l'actif : combiner actions, obligations et liquidités

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle la répartition de l'actif.
- Expliquer le lien entre la répartition de l'actif, la tolérance au risque et l'horizon de placement.
- Reconnaître qu'il n'existe pas de formule de répartition universelle.

**2. Contenu principal**
La répartition de l'actif désigne la façon dont un investisseur divise son portefeuille entre de grandes catégories d'actifs — souvent les actions, les obligations et les liquidités (ou équivalents de trésorerie) —, ce qui reprend la discussion de la leçon 8 sur les comportements différents de ces catégories. Selon une recherche souvent discutée, la répartition de l'actif est l'un des principaux facteurs qui déterminent le risque global et le profil de rendement à long terme d'un portefeuille, sans doute plus que le choix de titres précis dans chaque catégorie.

En général, une plus grande part en actions est associée à un potentiel de rendement à long terme plus élevé, avec plus de volatilité, alors qu'une plus grande part en obligations et en liquidités est associée à plus de stabilité et à une volatilité attendue plus faible, avec un potentiel de rendement à long terme habituellement plus bas. La « bonne » répartition dépend de l'horizon de placement précis (leçon 27) et de la tolérance au risque (leçon 26) de chaque investisseur. Il n'existe pas de formule universelle, malgré certaines règles empiriques populaires qui simplifient trop cette décision très personnelle.

**3. Exemple pratique**
Deux investisseurs d'âges différents réfléchissent à leur répartition de l'actif. Une femme de 25 ans, qui a des décennies devant elle avant la retraite et qui se dit très tolérante à la volatilité à court terme, place une grande majorité de son portefeuille en actions, en acceptant plus de volatilité en échange d'un potentiel de croissance à long terme plus élevé sur son long horizon. Un homme de 62 ans, qui prendra sa retraite d'ici quelques années, choisit un mélange plus équilibré entre actions et obligations, en donnant la priorité à plus de stabilité, vu l'horizon plus court qu'il lui reste avant de commencer à tirer un revenu de son portefeuille.

Aucune des deux répartitions n'est la « bonne » dans tous les cas : chacune reflète l'horizon de placement et la tolérance au risque propres à chaque investisseur.

**4. Quiz de pratique**
1. À quoi la répartition de l'actif se rapporte-t-elle généralement?
   a) Seulement au choix d'actions individuelles
   b) À la façon dont un portefeuille est divisé entre de grandes catégories comme les actions, les obligations et les liquidités
   c) À un type de déclaration fiscale
   d) À un seul fonds précis
2. La répartition de l'actif est largement considérée comme un facteur important de quoi?
   a) De rien d'important
   b) Du risque global et du profil de rendement à long terme d'un portefeuille
   c) Seulement des variations de prix quotidiennes à court terme
   d) Des taux d'imposition
3. Vrai ou faux : Il existe une seule formule de répartition de l'actif universelle qui convient à chaque investisseur.
4. Pourquoi les deux investisseurs de l'exemple pratique ont-ils choisi des répartitions différentes?
   a) L'un des deux a fait une erreur
   b) Leurs horizons de placement et leurs tolérances au risque différents demandaient des répartitions différentes
   c) La répartition de l'actif n'a pas vraiment d'importance
   d) La loi les obligeait à avoir des répartitions différentes

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La répartition de l'actif désigne la façon dont un portefeuille est divisé entre de grandes catégories comme les actions, les obligations et les liquidités.
2. La répartition de l'actif est largement considérée comme un facteur important du risque global et du profil de rendement à long terme d'un portefeuille.
3. La bonne répartition dépend de l'horizon de placement et de la tolérance au risque de chaque personne; il n'y a pas de formule universelle.
4. Les horizons de placement et les tolérances au risque différents des deux investisseurs les ont menés, avec raison, à des répartitions différentes.

**7. Points clés à retenir**
- La répartition de l'actif, c'est la façon dont un portefeuille est divisé entre actions, obligations et liquidités.
- Elle est largement considérée comme l'un des principaux facteurs du risque et du rendement global d'un portefeuille.
- Une plus grande part en actions veut généralement dire plus de potentiel de rendement et plus de volatilité; une plus grande part en obligations et en liquidités veut généralement dire plus de stabilité.
- La bonne répartition dépend de l'horizon de placement et de la tolérance au risque de chaque personne; il n'y a pas de formule universelle.
