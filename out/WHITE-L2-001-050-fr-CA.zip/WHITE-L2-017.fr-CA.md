---
id: WHITE-L2-017
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 17
title: "La diversification à l'intérieur des actifs papier"
summary: "Distingue la diversification à l'intérieur d'une catégorie d'actifs de la répartition entre catégories, et vois pourquoi un grand nombre de titres ne garantit pas la diversification."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-017
### La diversification à l'intérieur des actifs papier

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Faire la différence entre la diversification à l'intérieur d'une catégorie d'actifs et la répartition de l'actif entre les catégories.
- Expliquer le but général de la diversification.
- Nommer des exemples de diversification à l'intérieur des actions et à l'intérieur des obligations.

**2. Contenu principal**
Alors que la répartition de l'actif (leçon 16) porte sur la façon dont un portefeuille se divise entre de grandes catégories, la diversification porte sur la façon dont un portefeuille répartit le risque à l'intérieur d'une catégorie donnée, en écho à la discussion du parcours RED sur la diversification immobilière (RED-L2-038). Pour les actions, ça peut vouloir dire détenir de nombreuses entreprises différentes, dans différents secteurs (leçon 24) et différentes régions (leçon 25), plutôt que de se concentrer fortement dans quelques entreprises seulement. Pour les obligations, ça peut vouloir dire détenir des titres d'émetteurs de qualité de crédit, d'échéance et de type différents, plutôt que de se concentrer sur un seul émetteur ou une seule obligation.

Le but général de la diversification est de réduire l'effet de la mauvaise performance d'un seul placement sur l'ensemble du portefeuille : si une entreprise ou un émetteur d'obligations a des difficultés, un portefeuille bien diversifié en ressent un effet relativement plus petit qu'un portefeuille concentré. Ça n'élimine pas le risque de l'ensemble du marché (une baisse générale du marché touche quand même un portefeuille diversifié), mais ça réduit le risque propre à une entreprise ou à un émetteur.

**3. Exemple pratique**
En examinant ses actions, Amara se rend compte qu'il détient vingt entreprises différentes, mais que dix-huit d'entre elles sont concentrées dans un seul secteur d'activité. Reconnaissant qu'il s'agit d'une diversification insuffisante malgré le nombre apparemment élevé de titres, il restructure son portefeuille pour répartir son exposition aux actions entre plusieurs secteurs, ce qui réduit sa vulnérabilité à un ralentissement qui toucherait ce secteur en particulier — même si son nombre total de titres individuels n'a pas besoin de changer beaucoup pour obtenir cette amélioration.

**4. Quiz de pratique**
1. Selon cette leçon, en quoi la diversification diffère-t-elle de la répartition de l'actif?
   a) Ce sont des notions identiques
   b) La répartition de l'actif divise entre de grandes catégories; la diversification répartit le risque à l'intérieur d'une catégorie
   c) La diversification ne s'applique qu'à l'immobilier
   d) La répartition de l'actif ne s'applique qu'aux obligations
2. Quel est le but général de la diversification?
   a) Garantir un profit
   b) Réduire l'effet de la mauvaise performance d'un seul placement sur l'ensemble du portefeuille
   c) Éliminer tout risque de marché
   d) Concentrer le risque dans une seule entreprise
3. Vrai ou faux : Détenir vingt actions garantit automatiquement une diversification suffisante, peu importe la concentration par secteur.
4. Quel problème Amara a-t-il repéré dans son propre portefeuille?
   a) Trop peu de titres au total
   b) Une forte concentration dans un seul secteur d'activité malgré un nombre de titres apparemment élevé
   c) Trop d'obligations
   d) Aucune action

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La répartition de l'actif porte sur la division entre de grandes catégories; la diversification porte sur la répartition du risque à l'intérieur d'une catégorie donnée.
2. La diversification réduit l'effet relatif de la mauvaise performance d'un seul placement sur l'ensemble du portefeuille.
3. Un grand nombre de titres concentrés dans un seul secteur ne permet pas d'obtenir une diversification suffisante.
4. Les titres d'Amara, malgré leur nombre, étaient fortement concentrés dans un seul secteur, ce qui minait une vraie diversification.

**7. Points clés à retenir**
- La diversification répartit le risque à l'intérieur d'une catégorie d'actifs, ce qui la distingue de la répartition de l'actif entre grandes catégories.
- Elle réduit le risque propre à une entreprise ou à un émetteur, sans éliminer le risque général du marché.
- Un grand nombre de titres ne garantit pas la diversification s'ils sont concentrés dans des secteurs ou des émetteurs semblables.
- Cette notion fait écho à la discussion sur la diversification du parcours RED, appliquée ici aux actifs papier.
