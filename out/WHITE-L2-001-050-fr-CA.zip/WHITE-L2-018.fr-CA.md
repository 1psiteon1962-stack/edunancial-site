---
id: WHITE-L2-018
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 18
title: "Le rééquilibrage : garder le portefeuille sur la cible"
summary: "Comprends pourquoi la répartition d'un portefeuille dérive avec le temps et comment le rééquilibrage, selon un calendrier ou des seuils, la ramène vers la cible."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-018
### Le rééquilibrage : garder le portefeuille sur la cible

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le concept général du rééquilibrage d'un portefeuille.
- Décrire pourquoi la répartition d'un portefeuille peut dériver avec le temps sans rééquilibrage.
- Nommer des approches courantes de rééquilibrage.

**2. Contenu principal**
Comme les différentes catégories d'actifs ont des performances différentes avec le temps, la répartition réelle d'un portefeuille s'éloigne naturellement de sa répartition cible d'origine (leçon 16), puisque certains placements grandissent plus vite que d'autres. Le rééquilibrage est le processus périodique qui consiste à ramener un portefeuille vers sa répartition cible, habituellement en vendant une partie des placements qui ont grandi au-delà de leur pourcentage cible et en achetant davantage de ceux qui sont tombés sous leur pourcentage cible.

Les approches de rééquilibrage courantes comprennent le rééquilibrage selon un calendrier (revoir et ajuster à des intervalles fixes, par exemple chaque année) et le rééquilibrage selon des seuils (ajuster dès qu'une part s'écarte de sa cible au-delà d'un pourcentage précis, peu importe le moment). Le rééquilibrage sert autant à gérer le risque qu'à chercher du rendement : sans lui, un portefeuille peut devenir graduellement plus audacieux (si les actions ont mieux performé et dominent maintenant la répartition) ou plus prudent (si c'est l'inverse) que prévu au départ, sans que l'investisseur ait pris de décision volontaire en ce sens.

**3. Exemple pratique**
Sanjay avait fixé au départ une répartition cible de 70 % en actions et de 30 % en obligations. Après plusieurs années de forte performance des actions, il vérifie son portefeuille et découvre qu'il est passé à 82 % en actions et 18 % en obligations — non pas parce qu'il a décidé de devenir plus audacieux, mais simplement parce que les actions ont grandi plus vite que les obligations pendant cette période.

Reconnaissant que cette dérive ne correspond pas à sa tolérance au risque et à son plan d'origine, Sanjay rééquilibre son portefeuille en vendant une partie de ses actions et en achetant des obligations, ce qui le ramène plus près de sa cible d'origine de 70/30 — un geste réfléchi et discipliné plutôt que de simplement « surfer sur la vague » de la performance récente des actions.

**4. Quiz de pratique**
1. Pourquoi la répartition d'un portefeuille dérive-t-elle avec le temps sans rééquilibrage?
   a) Elle ne dérive jamais
   b) Les différentes catégories d'actifs ont des performances différentes, ce qui fait grandir certaines plus vite que d'autres
   c) Toutes les catégories d'actifs grandissent toujours exactement au même rythme
   d) Le rééquilibrage se fait automatiquement sans aucun geste
2. En quoi consiste généralement le rééquilibrage?
   a) Ignorer complètement le portefeuille
   b) Vendre les placements qui dépassent leur part cible et acheter ceux qui sont sous leur cible
   c) Toujours acheter, sans jamais vendre
   d) Éliminer toutes les obligations
3. Vrai ou faux : La répartition d'un portefeuille reste toujours exactement à sa cible d'origine, sans aucun geste de l'investisseur.
4. Pourquoi le portefeuille de Sanjay est-il passé à 82 % en actions sans décision active de sa part?
   a) Il avait volontairement choisi cette répartition
   b) Les actions ont grandi plus vite que les obligations pendant cette période, ce qui a déplacé naturellement la répartition
   c) Ses obligations avaient été vendues automatiquement
   d) Sa cible d'origine était déjà de 82 % en actions

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Les performances différentes des catégories d'actifs font dériver la répartition réelle d'un portefeuille par rapport à sa cible d'origine avec le temps.
2. Le rééquilibrage consiste à vendre les placements au-dessus de leur cible et à acheter ceux sous leur cible pour rétablir la répartition prévue.
3. Sans rééquilibrage actif, la répartition dérive naturellement à cause des performances différentes des catégories d'actifs.
4. La répartition de Sanjay a dérivé uniquement à cause de la différence de performance entre les actions et les obligations, pas d'une décision active.

**7. Points clés à retenir**
- La répartition d'un portefeuille dérive naturellement avec le temps, puisque les catégories d'actifs ont des performances différentes.
- Le rééquilibrage ramène un portefeuille vers sa répartition cible d'origine.
- Les approches courantes comprennent le rééquilibrage selon un calendrier et selon des seuils.
- Le rééquilibrage gère le risque en empêchant une dérive de la répartition non voulue, qui se produit sans décision volontaire de l'investisseur.
