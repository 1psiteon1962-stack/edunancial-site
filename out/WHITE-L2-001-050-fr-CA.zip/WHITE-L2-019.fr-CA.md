---
id: WHITE-L2-019
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 19
title: "L'investissement périodique d'un montant fixe : investir malgré la volatilité"
summary: "Comprends comment investir le même montant à intervalles réguliers peut réduire ton coût moyen par part et enlever la pression de choisir le bon moment."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-019
### L'investissement périodique d'un montant fixe : investir malgré la volatilité

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle l'investissement périodique d'un montant fixe (*dollar-cost averaging*).
- Expliquer comment cette stratégie interagit avec la volatilité du marché.
- Reconnaître l'attrait psychologique et pratique de cette approche.

**2. Contenu principal**
L'investissement périodique d'un montant fixe (souvent appelé méthode de l'achat périodique par sommes fixes) consiste à investir un montant fixe en dollars à intervalles réguliers (par exemple chaque mois), peu importe le prix de l'actif à chaque intervalle, plutôt que d'investir une somme forfaitaire d'un coup ou d'essayer de choisir le moment de ses achats selon des prix qu'on croit favorables. Comme le montant fixe achète plus de parts quand les prix sont bas et moins de parts quand ils sont élevés, cette approche peut donner un coût moyen par part plus bas avec le temps, comparativement à l'investissement du même montant total à un seul moment, possiblement mal choisi — même si cet avantage n'est pas garanti dans tous les scénarios, surtout dans un marché qui monte de façon constante (on y revient à la prochaine leçon).

Au-delà de l'effet purement mathématique, cette approche a un attrait psychologique et pratique important : elle enlève la pression d'essayer de trouver le moment « parfait » pour investir (en écho au paradoxe du choix de la leçon 1), et elle correspond naturellement à la façon dont bien des gens reçoivent réellement leur argent — par des paies régulières. C'est donc une approche par défaut pratique pour les cotisations continues, comme les cotisations à un compte de retraite prélevées sur chaque paie.

**3. Exemple pratique**
En versant un montant fixe dans son compte de retraite à chaque paie pendant une année volatile, Layla finit par acheter plus de parts les mois où les prix baissent et moins de parts les mois où ils montent, sans avoir à prendre elle-même de décision sur le moment. En examinant ses résultats à la fin de l'année, elle constate que son coût moyen par part est plus bas que le niveau de prix moyen de l'année — une conséquence mathématique de son rythme d'achat constant et sans émotion à travers les hauts et les bas du marché. Elle reconnaît aussi que ce résultat reflète le profil de cette année volatile précise, pas une garantie pour chaque année à venir.

**4. Quiz de pratique**
1. En quoi consiste généralement l'investissement périodique d'un montant fixe?
   a) Investir une somme forfaitaire d'un coup
   b) Investir un montant fixe en dollars à intervalles réguliers, peu importe le prix
   c) Investir seulement quand les prix baissent
   d) Éviter complètement d'investir
2. Pourquoi l'investissement périodique d'un montant fixe peut-il, dans certains scénarios, donner un coût moyen par part plus bas?
   a) Il garantit toujours le prix le plus bas possible
   b) Un montant fixe achète plus de parts quand les prix sont bas et moins quand ils sont élevés
   c) Il n'a aucun lien avec le prix
   d) Il ne fonctionne que si les prix montent toujours
3. Vrai ou faux : L'investissement périodique d'un montant fixe garantit de meilleurs résultats qu'un placement forfaitaire dans tous les scénarios de marché possibles.
4. Quel attrait pratique cette approche a-t-elle au-delà de son effet mathématique?
   a) Elle exige de grosses sommes d'argent au départ
   b) Elle enlève la pression du choix du moment et correspond naturellement aux cotisations faites à chaque paie
   c) Elle élimine tout risque de placement
   d) Elle exige des décisions de négociation actives chaque jour

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'investissement périodique d'un montant fixe consiste à investir un montant fixe à intervalles réguliers, peu importe le prix à chaque intervalle.
2. Acheter plus de parts à des prix bas et moins à des prix élevés peut réduire le coût moyen par part, même si ce n'est pas garanti pour tous les profils de marché.
3. L'avantage de cette approche par rapport à une somme forfaitaire dépend du profil de prix qui se produit, sans garantie dans tous les scénarios.
4. Cette approche enlève la pression du choix du moment et correspond naturellement à la façon dont bien des gens reçoivent et investissent leur argent, par des paies régulières.

**7. Points clés à retenir**
- L'investissement périodique d'un montant fixe investit le même montant à intervalles réguliers, peu importe le prix.
- Il peut réduire le coût moyen par part dans des marchés volatils ou en baisse, sans garantie dans tous les scénarios.
- Il enlève la pression du choix du moment, ce qui répond au paradoxe du choix vu à la leçon 1.
- Il correspond naturellement aux revenus réguliers, comme les cotisations de retraite prélevées sur chaque paie.
