---
id: WHITE-L2-020
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 20
title: "Somme forfaitaire ou investissement périodique : les compromis"
summary: "Compare l'investissement d'une somme forfaitaire et l'investissement périodique, ce que montre la recherche historique et pourquoi ton tempérament compte aussi."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-020
### Somme forfaitaire ou investissement périodique : les compromis

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Comparer directement l'investissement d'une somme forfaitaire et l'investissement périodique d'un montant fixe.
- Expliquer les conclusions générales de la recherche sur leur performance historique relative.
- Reconnaître les facteurs psychologiques qui peuvent compter plus que les considérations purement mathématiques.

**2. Contenu principal**
Dans la suite de la leçon précédente, cette leçon compare directement l'investissement d'une somme forfaitaire (investir un gros montant d'un coup) et l'investissement périodique d'un montant fixe. Selon une recherche souvent discutée, en moyenne, sur les périodes historiques, l'investissement d'une somme forfaitaire a souvent fait mieux que l'investissement périodique quand l'investisseur avait déjà le montant complet disponible. C'est surtout parce que les marchés ont historiquement eu tendance à monter sur la plupart des longues périodes; « attendre » pour investir graduellement une somme forfaitaire a donc plus souvent voulu dire manquer du temps sur le marché qu'éviter une baisse.

Par contre, cette moyenne historique ne veut pas dire que l'investissement d'une somme forfaitaire fait toujours mieux pendant chaque période précise, et elle ne tient pas compte d'un facteur psychologique important : un investisseur qui ressentirait beaucoup d'anxiété ou de regret en investissant une grosse somme juste avant une baisse du marché pourrait réellement profiter — dans son comportement réel et sa capacité à s'en tenir à son plan — de l'expérience émotionnelle plus douce de l'investissement périodique, même si cette stratégie n'est pas, en moyenne, mathématiquement optimale.

Ce qu'il faut retenir au niveau 2, c'est que le « bon » choix entre ces approches dépend non seulement des moyennes historiques, mais aussi du tempérament de l'investisseur et de la probabilité qu'il suive réellement son plan avec l'une ou l'autre approche.

**3. Exemple pratique**
Owen vient de recevoir un gros héritage et se demande s'il doit l'investir d'un coup ou l'étaler sur plusieurs mois. Il examine la recherche générale selon laquelle l'investissement d'une somme forfaitaire a, en moyenne, donné de meilleurs résultats historiques dans la plupart des périodes, mais il évalue aussi honnêtement son propre tempérament : il reconnaît qu'il ressentirait probablement beaucoup d'anxiété et de doute s'il investissait tout tout de suite et que le marché baissait peu après.

Owen choisit finalement une voie mitoyenne : il investit la majorité tout de suite et étale le reste sur plusieurs mois, en reconnaissant explicitement qu'il donne la priorité à sa propre capacité psychologique de s'en tenir au plan plutôt qu'au résultat moyen historique strict — un compromis personnalisé et éclairé, au lieu de suivre aveuglément l'une ou l'autre approche.

**4. Quiz de pratique**
1. Que suggère la recherche souvent discutée au sujet de la performance historique moyenne?
   a) L'investissement périodique fait toujours mieux que l'investissement d'une somme forfaitaire
   b) L'investissement d'une somme forfaitaire a, en moyenne, souvent fait mieux que l'investissement périodique dans l'histoire
   c) Les deux approches donnent toujours des résultats identiques
   d) Aucune des deux approches n'a jamais été étudiée
2. Pourquoi l'investissement périodique pourrait-il quand même profiter à certains investisseurs, même si la moyenne historique favorise la somme forfaitaire?
   a) Il garantit un rendement plus élevé
   b) Il peut mieux correspondre à la capacité psychologique d'un investisseur de s'en tenir à son plan
   c) Il n'a aucune dimension psychologique
   d) La loi l'exige
3. Vrai ou faux : L'investissement d'une somme forfaitaire fait mieux que l'investissement périodique dans chaque période historique, sans exception.
4. Quel compromis Owen a-t-il finalement privilégié dans sa décision?
   a) S'en tenir strictement au résultat moyen historique seulement
   b) Sa propre capacité psychologique de s'en tenir au plan, en tenant compte aussi de la recherche historique
   c) Ignorer complètement la recherche
   d) Ne pas investir du tout

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La recherche suggère généralement que l'investissement d'une somme forfaitaire a, en moyenne, fait mieux que l'investissement périodique dans l'histoire, mais pas dans chaque période.
2. L'investissement périodique peut mieux soutenir la capacité psychologique de certains investisseurs à s'en tenir à leur plan, même s'il n'est pas optimal en moyenne sur le plan mathématique.
3. Les moyennes historiques ne veulent pas dire que l'investissement d'une somme forfaitaire fait mieux pendant chaque période précise.
4. Owen a volontairement équilibré la recherche historique avec une évaluation honnête de son propre tempérament.

**7. Points clés à retenir**
- L'investissement d'une somme forfaitaire a, en moyenne, fait mieux que l'investissement périodique dans la plupart des périodes historiques, à cause de la tendance générale des marchés à monter à long terme.
- Cette moyenne ne garantit pas que la somme forfaitaire fera mieux pendant chaque période précise.
- L'investissement périodique peut mieux soutenir la capacité psychologique de certains investisseurs à suivre leur plan.
- Le bon choix dépend à la fois de la recherche historique et d'une évaluation honnête de son propre tempérament.
