---
id: WHITE-L2-021
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 21
title: "Les dividendes : le flux de trésorerie de la propriété"
summary: "Comprends ce qu'est un dividende, pourquoi certaines entreprises en versent et d'autres non, et les dates clés à connaître avant d'acheter."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-021
### Les dividendes : le flux de trésorerie de la propriété

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle un dividende.
- Expliquer pourquoi les entreprises choisissent de verser ou de ne pas verser de dividendes.
- Nommer les dates et les termes clés liés aux dividendes.

**2. Contenu principal**
Un dividende est une partie des profits d'une entreprise distribuée aux actionnaires, habituellement en argent, pour leur remettre de la valeur directement plutôt que de garder et de réinvestir tous les profits dans l'entreprise. Ce ne sont pas toutes les entreprises qui versent des dividendes : bien des entreprises axées sur la croissance (leçon 4) choisissent de réinvestir tous leurs profits dans l'expansion de leurs activités plutôt que de distribuer de l'argent, en se disant que le réinvestissement créera plus de valeur pour les actionnaires avec le temps qu'une distribution en argent.

Les entreprises qui versent des dividendes ont généralement un « rendement en dividendes » (le dividende annuel par action divisé par le prix actuel de l'action, exprimé en pourcentage), et le versement des dividendes comporte plusieurs dates clés : la date de déclaration (quand l'entreprise annonce le dividende), la date ex-dividende (la date limite qui détermine quels actionnaires ont droit au prochain paiement) et la date de paiement (quand l'argent est réellement versé).

Les dividendes ne sont pas garantis et peuvent être réduits ou éliminés par une entreprise qui a des difficultés financières, ce qui nous ramène directement au risque du « piège du dividende » vu à la leçon 5.

**3. Exemple pratique**
Consuela détient des actions d'une entreprise qui verse un dividende trimestriel régulier. Elle reçoit un paiement en argent déposé dans son compte de courtage quatre fois par année, qui représente sa part proportionnelle des profits distribués par l'entreprise selon le nombre d'actions qu'elle possède. Elle vérifie la date ex-dividende avant de faire un achat supplémentaire prévu, en comprenant qu'acheter des actions à cette date ou après voudrait dire qu'elle n'aurait pas droit au prochain paiement trimestriel, seulement aux paiements suivants.

**4. Quiz de pratique**
1. Qu'est-ce qu'un dividende?
   a) Un type de paiement d'obligation
   b) Une partie des profits d'une entreprise distribuée aux actionnaires, habituellement en argent
   c) Un remboursement d'impôt gouvernemental
   d) Un rendement annuel garanti
2. Pourquoi une entreprise axée sur la croissance pourrait-elle choisir de ne pas verser de dividendes?
   a) Il est illégal pour les entreprises en croissance de verser des dividendes
   b) Elle peut préférer réinvestir tous ses profits dans l'expansion de ses activités
   c) Les dividendes ne concernent que l'immobilier
   d) Elle n'a aucun profit
3. Vrai ou faux : Les dividendes sont garantis et ne peuvent jamais être réduits ni éliminés.
4. Que détermine la date ex-dividende?
   a) Le prix de l'action de l'entreprise pour toujours
   b) Quels actionnaires ont droit au prochain paiement de dividende
   c) Le taux d'imposition de l'entreprise
   d) La date d'échéance de l'obligation

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Un dividende est une distribution des profits d'une entreprise aux actionnaires, habituellement versée en argent.
2. Les entreprises axées sur la croissance préfèrent souvent réinvestir leurs profits dans l'expansion plutôt que de distribuer de l'argent.
3. Les dividendes ne sont pas garantis et peuvent être réduits ou éliminés en cas de difficultés financières.
4. La date ex-dividende est la date limite qui détermine l'admissibilité des actionnaires à un prochain paiement de dividende.

**7. Points clés à retenir**
- Un dividende est une partie des profits d'une entreprise distribuée aux actionnaires, habituellement en argent.
- Les entreprises axées sur la croissance réinvestissent souvent leurs profits au lieu de verser des dividendes.
- Les dates clés comprennent la date de déclaration, la date ex-dividende et la date de paiement.
- Les dividendes ne sont pas garantis et se rattachent directement au risque du « piège du dividende » de la leçon 5.
