---
id: WHITE-L2-022
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 22
title: "Le réinvestissement des dividendes : la composition en mouvement"
summary: "Comprends comment un régime de réinvestissement des dividendes fait travailler la composition, et pourquoi le choix de réinvestir ou d'encaisser dépend de ton étape de vie."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-022
### Le réinvestissement des dividendes : la composition en mouvement

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le concept général d'un régime de réinvestissement des dividendes (RRD).
- Décrire comment le réinvestissement des dividendes interagit avec la composition.
- Comparer le réinvestissement des dividendes au fait de les recevoir en argent.

**2. Contenu principal**
Un régime de réinvestissement des dividendes (RRD, ou *DRIP* en anglais) utilise automatiquement les dividendes pour acheter des actions supplémentaires (ou des fractions d'actions) du même placement, au lieu de déposer le dividende comme argent dépensable. C'est une application directe et concrète de la notion de composition : chaque dividende réinvesti achète plus d'actions, qui peuvent ensuite générer leurs propres dividendes futurs, qui peuvent à leur tour acheter encore plus d'actions — un cycle qui peut accélérer de façon importante la croissance d'un portefeuille sur de longues périodes, surtout pour les jeunes investisseurs qui ont des décennies devant eux avant d'avoir besoin du revenu.

Le choix de réinvestir les dividendes ou de les recevoir en argent dépend de la situation de chaque investisseur. Un investisseur encore en phase d'accumulation, qui n'a pas besoin du revenu en ce moment, profite souvent du réinvestissement automatique. Un investisseur en phase de décaissement — par exemple une personne retraitée qui compte sur ses revenus de dividendes pour ses dépenses de subsistance (en écho à la lentille du revenu de la leçon 5) — peut préférer recevoir ses dividendes en argent plutôt que les réinvestir.

**3. Exemple pratique**
À plusieurs décennies de sa retraite, Deshawn met en place le réinvestissement automatique des dividendes dans ses comptes de placement, ce qui permet à chaque dividende d'acheter automatiquement des actions supplémentaires au lieu de rester en liquidités non investies. Au fil des années, il remarque que son nombre d'actions augmente non seulement grâce à ses propres cotisations supplémentaires, mais aussi grâce à l'effet de composition des dividendes réinvestis, qui achètent plus d'actions, qui génèrent ensuite leurs propres dividendes — une démonstration visible et concrète de la composition en mouvement.

Son oncle retraité, au contraire, fait déposer ses dividendes en argent dans son compte chèques chaque trimestre et s'en sert pour couvrir une partie de ses dépenses de subsistance au lieu de les réinvestir — un choix différent, mais tout aussi approprié, vu son étape de vie et ses besoins de revenu différents.

**4. Quiz de pratique**
1. Que fait généralement un régime de réinvestissement des dividendes (RRD)?
   a) Il dépose automatiquement les dividendes comme argent dépensable
   b) Il utilise automatiquement les dividendes pour acheter des actions supplémentaires
   c) Il élimine tous les dividendes
   d) Il convertit les dividendes en obligations
2. Pourquoi un investisseur en phase d'accumulation pourrait-il profiter du réinvestissement des dividendes?
   a) Il a besoin du revenu tout de suite
   b) Ça peut accélérer la croissance du portefeuille grâce à la composition sur une longue période
   c) Ça garantit un rendement précis
   d) Ça n'a aucun lien avec la composition
3. Vrai ou faux : Chaque investisseur devrait toujours réinvestir ses dividendes, peu importe son étape de vie ou ses besoins de revenu.
4. Pourquoi l'oncle de Deshawn a-t-il choisi de recevoir ses dividendes en argent plutôt que de les réinvestir?
   a) Il n'aimait pas la composition
   b) Comme retraité, il compte sur les revenus de dividendes pour ses dépenses de subsistance
   c) Ses placements ne versaient pas de dividendes
   d) Le réinvestissement ne lui était pas offert

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Un RRD utilise automatiquement les dividendes pour acheter des actions supplémentaires au lieu de verser de l'argent.
2. Le réinvestissement permet aux dividendes de se composer en achetant plus d'actions qui génèrent d'autres dividendes avec le temps.
3. Le bon choix dépend de l'étape de vie et des besoins de revenu actuels de l'investisseur; ce n'est pas une règle universelle.
4. Comme retraité qui compte sur ses revenus de dividendes, l'oncle de Deshawn a choisi avec raison de les recevoir en argent plutôt que de les réinvestir.

**7. Points clés à retenir**
- Un RRD réinvestit automatiquement les dividendes dans des actions supplémentaires.
- Ça crée un cycle de composition : les dividendes réinvestis achètent des actions qui génèrent d'autres dividendes.
- Les investisseurs en phase d'accumulation profitent souvent du réinvestissement; ceux qui ont besoin d'un revenu actuel peuvent préférer les dividendes en argent.
- Le bon choix dépend de l'étape de vie et des besoins de revenu précis de l'investisseur.
