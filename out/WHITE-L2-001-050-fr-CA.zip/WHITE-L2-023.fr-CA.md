---
id: WHITE-L2-023
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 23
title: "La capitalisation boursière : petite, moyenne et grande capitalisation"
summary: "Apprends à calculer la capitalisation boursière, à distinguer les petites, moyennes et grandes capitalisations, et les tendances générales de risque et de rendement de chacune."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-023
### La capitalisation boursière : petite, moyenne et grande capitalisation

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle la capitalisation boursière.
- Distinguer de façon générale les entreprises à petite, moyenne et grande capitalisation.
- Expliquer les tendances générales de risque et de rendement associées à chaque catégorie.

**2. Contenu principal**
La capitalisation boursière se calcule en multipliant le prix actuel de l'action d'une entreprise par le nombre total d'actions en circulation. Elle mesure la valeur marchande totale de l'entreprise, telle que perçue par les investisseurs à un moment donné. On regroupe couramment les entreprises en grandes catégories — petite, moyenne et grande capitalisation — selon des fourchettes de capitalisation boursière, mais les seuils exacts en dollars qui définissent ces catégories varient selon la source et changent avec le temps. Les limites précises sont donc moins importantes que la compréhension de la tendance générale.

En général, les entreprises à grande capitalisation tendent à être plus établies, avec un historique d'exploitation plus long, et elles affichent souvent une volatilité un peu plus faible que les plus petites entreprises, sans nécessairement avoir un potentiel de croissance à long terme plus faible. Les entreprises à petite capitalisation tendent à être plus tôt dans leur trajectoire de croissance; elles peuvent offrir un potentiel de croissance à long terme plus élevé, mais généralement avec plus de volatilité et de risque, y compris une plus grande probabilité d'échec pour chaque petite entreprise prise individuellement. Les entreprises à moyenne capitalisation se situent généralement entre ces deux tendances.

Ce sont des tendances générales, pas des règles fixes : chaque entreprise, peu importe sa catégorie, peut se comporter autrement que la tendance générale.

**3. Exemple pratique**
En bâtissant une répartition diversifiée en actions, Yara inclut volontairement une exposition aux entreprises à grande, moyenne et petite capitalisation, plutôt que de se concentrer dans une seule catégorie. Elle reconnaît que cette répartition lui donne accès aux tendances de risque et de rendement généralement différentes de chaque catégorie — une certaine stabilité et une performance établie avec les titres à grande capitalisation, et un potentiel de croissance plus élevé (avec plus de volatilité) avec les plus petites entreprises —, au lieu de tout miser sur la tendance générale d'une seule catégorie.

**4. Quiz de pratique**
1. Comment calcule-t-on généralement la capitalisation boursière?
   a) Les revenus totaux de l'entreprise
   b) Le prix actuel de l'action multiplié par le nombre total d'actions en circulation
   c) La dette totale de l'entreprise
   d) Le rendement en dividendes de l'entreprise
2. Quelle est une tendance générale associée aux entreprises à petite capitalisation?
   a) Une volatilité plus faible et un potentiel de croissance plus faible
   b) Un potentiel de croissance plus élevé, avec plus de volatilité et de risque
   c) Des rendements plus élevés garantis
   d) Aucun risque d'échec
3. Vrai ou faux : Toutes les entreprises à petite capitalisation se comportent toujours exactement selon la tendance générale des petites capitalisations.
4. Pourquoi Yara a-t-elle inclus une exposition aux trois catégories de capitalisation?
   a) Pour éliminer la diversification
   b) Pour avoir accès aux tendances de risque et de rendement généralement différentes de chaque catégorie
   c) Un règlement l'y obligeait
   d) Les catégories de capitalisation n'ont aucune vraie différence

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La capitalisation boursière se calcule en multipliant le prix de l'action par le nombre total d'actions en circulation.
2. Les entreprises à petite capitalisation affichent généralement un potentiel de croissance plus élevé, avec plus de volatilité et de risque.
3. Ce sont des tendances générales; chaque entreprise, peu importe sa catégorie, peut se comporter autrement.
4. L'approche diversifiée de Yara entre les catégories de capitalisation visait à profiter de leurs caractéristiques générales de risque et de rendement différentes.

**7. Points clés à retenir**
- La capitalisation boursière mesure la valeur marchande totale d'une entreprise à partir du prix de l'action et du nombre d'actions en circulation.
- On regroupe couramment les entreprises en catégories de petite, moyenne et grande capitalisation.
- Les grandes capitalisations montrent généralement plus de stabilité; les petites capitalisations, généralement plus de potentiel de croissance et de risque.
- Ce sont des tendances générales, pas des règles fixes pour une entreprise en particulier.
