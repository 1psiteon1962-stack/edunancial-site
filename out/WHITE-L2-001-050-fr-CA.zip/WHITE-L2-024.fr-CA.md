---
id: WHITE-L2-024
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 24
title: "La diversification par secteur et par industrie"
summary: "Comprends ce que sont les secteurs et les industries, pourquoi la concentration sectorielle est un risque caché et comment la diversification par secteur complète le reste."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-024
### La diversification par secteur et par industrie

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir le secteur et l'industrie comme notions de classement.
- Expliquer le risque de la concentration sectorielle.
- Décrire comment la diversification par secteur complète la diversification plus large (leçon 17).

**2. Contenu principal**
On regroupe couramment les entreprises en grands secteurs (comme la technologie, la santé, les services financiers, l'énergie, et d'autres) et en industries plus précises à l'intérieur de ces secteurs, selon la partie de l'économie dans laquelle elles exercent leurs activités. Dans la suite de la discussion sur la diversification de la leçon 17, la concentration au niveau des secteurs est un risque précis à surveiller directement : un portefeuille qui semble détenir beaucoup d'entreprises différentes peut quand même être fortement exposé au sort d'un seul secteur si ces entreprises viennent surtout de la même partie de l'économie.

Les différents secteurs peuvent avoir des performances très différentes selon les conditions économiques générales : certains secteurs tendent à faire relativement mieux pendant les périodes d'expansion économique, alors que d'autres peuvent mieux résister pendant les ralentissements, même si ces modèles sont des tendances générales plutôt que des règles fixes. La diversification par secteur consiste à répartir volontairement son exposition entre plusieurs secteurs, ce qui réduit la vulnérabilité du portefeuille aux difficultés propres à un seul secteur.

**3. Exemple pratique**
En examinant son portefeuille avec un outil de répartition par secteur, Hassan découvre que, même s'il détient des actions de quinze entreprises différentes, plus de 60 % de la valeur de son portefeuille est concentrée dans le seul secteur de la technologie — une concentration qu'il n'avait pas remarquée en comptant simplement ses titres individuels. Il ajuste son approche pour l'avenir en ajoutant volontairement une exposition à d'autres secteurs, comme la santé, les services financiers et les biens de consommation de base, ce qui réduit sa dépendance au sort économique d'un seul secteur.

**4. Quiz de pratique**
1. À quoi le terme « secteur » se rapporte-t-il généralement?
   a) Le prix de l'action d'une seule entreprise
   b) Une grande partie de l'économie dans laquelle les entreprises exercent leurs activités
   c) Un type d'obligation
   d) Un organisme gouvernemental
2. Quel risque la concentration sectorielle crée-t-elle, même avec de nombreux titres individuels?
   a) Aucun risque
   b) Une forte exposition au sort d'un seul secteur, malgré un nombre de titres qui semble diversifié
   c) Des rendements plus élevés garantis
   d) L'élimination de tout risque de portefeuille
3. Vrai ou faux : Compter le nombre de titres individuels suffit à confirmer une diversification suffisante.
4. Qu'est-ce que la répartition par secteur d'Hassan a révélé qu'un simple décompte des titres n'avait pas montré?
   a) Il avait trop peu de titres
   b) Plus de 60 % de son portefeuille était concentré dans un seul secteur
   c) Il ne possédait aucune action
   d) Son portefeuille était parfaitement diversifié

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Un secteur désigne une grande partie de l'économie dans laquelle les entreprises exercent leurs activités.
2. Même de nombreux titres individuels peuvent être fortement concentrés dans un seul secteur, ce qui crée une vulnérabilité précise.
3. Un simple décompte des titres ne confirme pas une vraie diversification si ces titres se regroupent dans un seul secteur.
4. L'analyse par secteur d'Hassan a révélé une concentration que le simple décompte de ses titres avait cachée.

**7. Points clés à retenir**
- Le secteur et l'industrie décrivent les parties larges et précises de l'économie dans lesquelles les entreprises exercent leurs activités.
- La concentration sectorielle peut exister même avec un nombre de titres individuels qui semble élevé.
- Les différents secteurs peuvent avoir des performances différentes selon les conditions économiques, en tant que tendances générales.
- Une diversification sectorielle volontaire réduit la vulnérabilité aux difficultés propres à un seul secteur.
