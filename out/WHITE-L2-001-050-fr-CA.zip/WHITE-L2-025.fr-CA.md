---
id: WHITE-L2-025
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 25
title: "L'exposition internationale et nationale"
summary: "Comprends ce qu'apporte l'exposition internationale à un portefeuille, ses risques propres et pourquoi le risque de change est un facteur distinct à considérer."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-025
### L'exposition internationale et nationale

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le concept général de l'exposition internationale par rapport à l'exposition nationale.
- Nommer les avantages et les risques possibles de l'exposition internationale.
- Reconnaître le risque de change comme un élément distinct à considérer pour les placements internationaux.

**2. Contenu principal**
L'exposition nationale désigne les placements dans des entreprises établies dans le pays d'origine de l'investisseur; l'exposition internationale désigne les placements dans des entreprises établies ailleurs. Ajouter une exposition internationale peut prolonger au-delà des frontières les notions de diversification des leçons 17 et 24, puisque les économies des différents pays n'évoluent pas toujours parfaitement au même rythme, ce qui peut adoucir la performance globale du portefeuille — même si cet avantage n'est pas garanti dans chaque période, surtout pendant les ralentissements qui touchent le monde entier en même temps.

L'investissement international ajoute des éléments à considérer qui n'existent pas dans l'investissement purement national : le risque de change (les variations des taux de change peuvent toucher les rendements d'un investisseur dont la monnaie d'origine diffère de celle du placement, indépendamment de la performance réelle du placement sous-jacent), des normes réglementaires et comptables différentes d'un pays à l'autre, et parfois des considérations de stabilité politique et économique différentes, qui varient beaucoup selon le pays ou la région.

**3. Exemple pratique**
En ajoutant une exposition aux actions internationales à son portefeuille jusque-là entièrement national, Camila remarque que, même quand les entreprises étrangères sous-jacentes performent bien dans leur monnaie locale, ses rendements réels (convertis dans sa monnaie d'origine) peuvent être différents à cause des variations des taux de change pendant la période où elle a détenu le placement. Elle étudie cette dynamique du risque de change avant d'investir davantage et l'intègre comme un élément distinct dans son évaluation globale du risque, séparément de la performance d'affaires des entreprises étrangères elles-mêmes.

**4. Quiz de pratique**
1. Qu'est-ce que l'« exposition nationale »?
   a) Des placements seulement dans des entreprises étrangères
   b) Des placements dans des entreprises établies dans le pays d'origine de l'investisseur
   c) Un type d'obligation
   d) Un programme gouvernemental
2. Qu'est-ce que le « risque de change »?
   a) Le risque que le prix de l'action d'une entreprise baisse
   b) Le risque que les variations des taux de change touchent les rendements, indépendamment de la performance du placement sous-jacent
   c) Un type de dividende
   d) Une taxe sur l'immobilier
3. Vrai ou faux : La diversification internationale garantit toujours une performance globale plus stable du portefeuille pendant chaque période de marché.
4. Qu'est-ce que Camila a découvert à propos de son exposition aux actions internationales?
   a) Les variations des taux de change n'avaient aucun effet sur ses rendements réels
   b) Les variations des taux de change pouvaient toucher ses rendements indépendamment de la performance réelle des entreprises étrangères
   c) L'investissement international éliminait tout risque
   d) Elle ne pouvait pas du tout investir à l'international

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'exposition nationale désigne les placements dans des entreprises établies dans le pays d'origine de l'investisseur.
2. Le risque de change désigne les variations des taux de change qui touchent les rendements indépendamment de la performance réelle du placement sous-jacent.
3. L'effet adoucissant de la diversification internationale n'est pas garanti dans chaque période, surtout pendant les ralentissements mondiaux simultanés.
4. Les rendements réels de Camila ont été touchés par les variations des taux de change, séparément de la performance d'affaires des entreprises étrangères.

**7. Points clés à retenir**
- L'exposition nationale couvre les placements dans le pays d'origine; l'exposition internationale couvre les placements étrangers.
- L'exposition internationale peut prolonger les avantages de la diversification au-delà des frontières, sans garantie dans chaque période.
- Le risque de change est un élément distinct propre à l'investissement international.
- Les conditions réglementaires, comptables, politiques et économiques varient aussi selon le pays ou la région.
