---
id: WHITE-L2-026
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 26
title: "La volatilité et la tolérance au risque"
summary: "Distingue la volatilité d'une perte permanente, et la tolérance au risque de la capacité de prendre des risques, pour choisir une répartition que tu pourras vraiment tenir."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-026
### La volatilité et la tolérance au risque

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle la volatilité.
- Faire la différence entre la volatilité et la notion de perte permanente.
- Expliquer le concept général de la tolérance au risque et son rôle dans les décisions de portefeuille.

**2. Contenu principal**
La volatilité désigne l'ampleur et la fréquence des variations de prix d'un placement avec le temps : un actif très volatil monte et descend de façon plus marquée et plus fréquente qu'un actif peu volatil. Il est important de distinguer la volatilité de la perte permanente : un actif volatil qui finit par se redresser et croître a connu de la volatilité, pas nécessairement une perte permanente, alors qu'un actif qui baisse et ne se redresse jamais (comme une entreprise qui ferme ses portes) représente une vraie perte permanente.

La tolérance au risque désigne la volonté et la capacité psychologique d'un investisseur à supporter la volatilité sans abandonner son plan de placement — par exemple, sans vendre en panique pendant une baisse. Elle est distincte de la capacité de prendre des risques, qui désigne la capacité financière d'un investisseur à supporter des pertes compte tenu de sa situation précise (horizon de placement, stabilité du revenu, autres ressources), peu importe son niveau de confort émotionnel. Une répartition de l'actif réfléchie (leçon 16) tient compte des deux : un investisseur peut avoir une grande capacité de prendre des risques (des décennies avant la retraite, un revenu stable), mais une faible tolérance au risque (beaucoup d'anxiété pendant les baisses), et un plan responsable tient compte des deux réalités, pas seulement de la plus favorable.

**3. Exemple pratique**
Même si elle a des décennies devant elle avant la retraite et un revenu stable (ce qui suggère une grande capacité de prendre des risques), Beatriz reconnaît honnêtement qu'elle a déjà vendu des placements en panique pendant des baisses passées, ce qui reflète une tolérance au risque plus faible que ce que sa seule situation financière laisserait croire. Au lieu de choisir une répartition fondée uniquement sur sa capacité financière à supporter la volatilité, elle choisit une répartition un peu plus prudente que ce qu'un calcul basé seulement sur sa capacité suggérerait, en donnant la priorité à une répartition qu'elle pourra vraiment tenir pendant les baisses du marché plutôt qu'à une répartition optimale en théorie, mais intenable en pratique pour elle.

**4. Quiz de pratique**
1. À quoi la volatilité se rapporte-t-elle généralement?
   a) À une perte permanente et irrécupérable
   b) À l'ampleur et à la fréquence des variations de prix avec le temps
   c) À un type d'obligation
   d) À un rendement garanti
2. Quelle est la différence entre la tolérance au risque et la capacité de prendre des risques?
   a) Ce sont des notions identiques
   b) La tolérance au risque est la volonté psychologique de supporter la volatilité; la capacité est l'aptitude financière à supporter des pertes
   c) La capacité de prendre des risques ne s'applique qu'aux obligations
   d) La tolérance au risque n'a aucun rapport avec l'investissement
3. Vrai ou faux : Un actif volatil qui finit par se redresser et croître a nécessairement subi une perte permanente.
4. Pourquoi Beatriz a-t-elle choisi une répartition plus prudente que ce que sa seule capacité de prendre des risques aurait suggéré?
   a) Elle n'avait aucune capacité financière de prendre des risques
   b) Sa tolérance psychologique au risque plus faible, démontrée par ses ventes en panique passées, justifiait une répartition plus tenable
   c) Elle n'aimait aucune forme d'investissement
   d) Son employeur l'exigeait

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La volatilité décrit l'ampleur et la fréquence des variations de prix, pas nécessairement une perte permanente.
2. La tolérance au risque est la volonté psychologique de supporter la volatilité; la capacité de prendre des risques est l'aptitude financière à supporter des pertes.
3. Un actif volatil qui se redresse et croît a connu de la volatilité, pas nécessairement une perte permanente.
4. L'évaluation honnête de Beatriz de sa tolérance au risque plus faible, malgré une grande capacité, l'a menée à un choix de répartition plus tenable.

**7. Points clés à retenir**
- La volatilité décrit l'ampleur et la fréquence des variations de prix, ce qui est différent d'une perte permanente.
- La tolérance au risque est la volonté psychologique de supporter la volatilité; la capacité de prendre des risques est l'aptitude financière à supporter des pertes.
- Un plan responsable tient compte à la fois de la tolérance et de la capacité, pas seulement de la plus favorable des deux.
- Une répartition optimale en théorie, mais intenable pour la psychologie d'un investisseur, n'est peut-être pas le bon choix.
