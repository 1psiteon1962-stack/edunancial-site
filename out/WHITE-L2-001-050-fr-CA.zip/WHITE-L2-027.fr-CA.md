---
id: WHITE-L2-027
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 27
title: "L'horizon de placement et son effet sur la stratégie"
summary: "Comprends comment le temps avant d'avoir besoin de ton argent influence le niveau de risque approprié, et pourquoi chaque objectif peut avoir son propre horizon."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-027
### L'horizon de placement et son effet sur la stratégie

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle l'horizon de placement.
- Expliquer comment l'horizon de placement influence généralement le niveau de risque approprié.
- Reconnaître qu'un investisseur peut avoir plusieurs horizons de placement distincts pour différents objectifs.

**2. Contenu principal**
L'horizon de placement désigne la période qui reste avant qu'un investisseur s'attende à avoir besoin d'un montant investi donné ou à l'utiliser. C'est l'un des facteurs les plus importants pour façonner une stratégie appropriée (leçons 16 et 26) : un horizon plus long donne généralement à l'investisseur plus de capacité à supporter la volatilité à court terme, puisqu'il a plus de temps pour qu'une baisse temporaire puisse se redresser avant d'avoir réellement besoin de l'argent. Un horizon plus court exige généralement un positionnement plus prudent, puisqu'il reste moins de temps pour se remettre d'une baisse mal tombée avant d'avoir besoin des fonds.

Fait important : un investisseur a souvent plusieurs horizons de placement distincts en même temps, pour différents objectifs financiers — une épargne-retraite dans plusieurs décennies, un fonds pour la mise de fonds d'une maison dont il aura besoin dans trois ans, et un fonds d'urgence dont il pourrait avoir besoin à tout moment, sans préavis. Chacun de ces montants peut, avec raison, justifier une stratégie différente, puisque leurs horizons sont fondamentalement différents, même s'ils appartiennent à la même personne.

**3. Exemple pratique**
En examinant l'ensemble de ses finances, Georgia reconnaît qu'elle gère de l'argent qui a plusieurs horizons très différents en même temps : une épargne-retraite qu'elle ne compte pas toucher avant plus de trente ans, un fonds pour la mise de fonds d'une maison qu'elle prévoit utiliser d'ici deux ans et un fonds d'urgence dont elle pourrait avoir besoin à tout moment. Au lieu d'appliquer une seule stratégie à tout cet argent, Georgia place son épargne-retraite de façon audacieuse en actions, vu le long horizon, garde son fonds de mise de fonds dans des placements plus prudents et stables, vu le court horizon, et garde son fonds d'urgence en liquidités facilement accessibles, en reconnaissant que l'horizon distinct de chaque montant exige une approche distincte.

**4. Quiz de pratique**
1. À quoi l'horizon de placement se rapporte-t-il généralement?
   a) Au montant total investi
   b) À la période qui reste avant qu'un investisseur s'attende à avoir besoin de l'argent investi ou à l'utiliser
   c) À un type d'obligation
   d) À une date limite de déclaration de revenus
2. Comment un horizon de placement plus long influence-t-il généralement le niveau de risque approprié?
   a) Il exige généralement un positionnement plus prudent
   b) Il donne généralement plus de capacité à supporter la volatilité à court terme
   c) Il n'a aucun effet sur la stratégie
   d) Il oblige à éviter toutes les actions
3. Vrai ou faux : Un investisseur ne peut jamais avoir qu'un seul horizon de placement pour tout son argent.
4. Pourquoi Georgia a-t-elle utilisé des stratégies différentes pour son épargne-retraite, son fonds de maison et son fonds d'urgence?
   a) Un règlement l'y obligeait
   b) Chaque montant avait un horizon fondamentalement différent qui justifiait une approche différente
   c) Les trois montants avaient le même horizon
   d) Elle n'aimait pas la diversification

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'horizon de placement est la période qui reste avant qu'un investisseur s'attende à avoir besoin de l'argent investi ou à l'utiliser.
2. Un horizon plus long donne généralement plus de capacité à supporter la volatilité à court terme avant d'avoir besoin des fonds.
3. Les gens ont souvent plusieurs horizons de placement distincts en même temps, pour différents objectifs financiers.
4. Les horizons différents de chacun des objectifs financiers de Georgia justifiaient, avec raison, des stratégies nettement différentes.

**7. Points clés à retenir**
- L'horizon de placement est la période qui reste avant qu'on prévoie avoir besoin de l'argent investi.
- Un horizon plus long permet généralement plus de volatilité; un horizon plus court exige généralement un positionnement plus prudent.
- Une même personne peut avoir plusieurs horizons de placement distincts en même temps, pour différents objectifs.
- Chaque montant distinct peut, avec raison, justifier sa propre stratégie selon son propre horizon de placement.
