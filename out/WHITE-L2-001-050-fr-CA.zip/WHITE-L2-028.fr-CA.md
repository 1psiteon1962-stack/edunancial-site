---
id: WHITE-L2-028
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 28
title: "Les biais comportementaux : la peur, l'avidité et l'instinct grégaire"
summary: "Reconnais comment la peur, l'avidité et l'effet de troupeau mènent à des décisions mal synchronisées, et pourquoi un plan écrit d'avance t'aide à tenir le cap."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-028
### Les biais comportementaux : la peur, l'avidité et l'instinct grégaire

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Nommer les biais comportementaux courants qui touchent les décisions des investisseurs.
- Expliquer comment la peur et l'avidité peuvent mener à des décisions mal synchronisées.
- Décrire l'instinct grégaire et ses risques généraux.

**2. Contenu principal**
La recherche en finance comportementale a repéré plusieurs modèles psychologiques récurrents qui peuvent éloigner les investisseurs de leurs propres plans à long terme. La vente motivée par la peur survient souvent pendant les baisses du marché, quand un investisseur vend à un creux justement à cause de son inconfort émotionnel, ce qui peut transformer une expérience de volatilité temporaire (leçon 26) en perte permanente et concrétisée. L'achat motivé par l'avidité survient souvent pendant les hausses de prix rapides, quand un investisseur achète de façon agressive près d'un sommet du marché justement par peur de manquer quelque chose, plutôt qu'en fonction de sa thèse de placement ou de sa stratégie de départ.

L'instinct grégaire (ou effet de troupeau) désigne la tendance à suivre le comportement de la foule — acheter parce que tout le monde semble acheter, ou vendre parce que tout le monde semble vendre — plutôt que de se fier à une analyse indépendante ou à son propre plan établi. Ça peut amplifier les extrêmes du marché, puisque les achats de troupeau peuvent pousser les prix bien au-dessus de ce que les données fondamentales justifieraient, et que les ventes de troupeau peuvent les pousser bien en dessous.

Reconnaître ces modèles chez soi, sur le moment, est vraiment difficile; c'est précisément pourquoi avoir un plan et une stratégie écrits d'avance (en écho à la discipline bâtie tout au long de ce niveau) compte davantage pendant les moments de marché chargés d'émotion que pendant les périodes calmes.

**3. Exemple pratique**
Pendant une baisse soudaine et marquée du marché, Reggie ressent une forte envie de vendre ses actions tout de suite, poussé par la peur et par des manchettes qui prédisent d'autres baisses. Avant d'agir, il relit le plan de placement écrit qu'il a établi des mois plus tôt, pendant une période calme, qui prévoyait précisément que des baisses arriveraient et indiquait son intention de rester investi malgré la volatilité à court terme, vu son long horizon de placement (leçon 27).

Revenir à ce plan établi d'avance aide Reggie à résister à l'impulsion de vendre motivée par la peur sur le moment. Ça montre pourquoi avoir un plan en place avant que les émotions s'emballent est plus efficace que d'essayer de raisonner calmement en plein milieu d'un événement de marché stressant.

**4. Quiz de pratique**
1. Qu'est-ce que la vente motivée par la peur peut transformer?
   a) Un gain garanti en perte garantie
   b) Une expérience de volatilité temporaire en perte permanente et concrétisée
   c) Une obligation en action
   d) Rien — elle n'a aucun effet
2. Qu'est-ce que l'« instinct grégaire »?
   a) Une analyse indépendante et attentive
   b) La tendance à suivre les achats ou les ventes de la foule plutôt que son propre plan
   c) Un type de cote d'obligation
   d) Un règlement gouvernemental
3. Vrai ou faux : Les biais comportementaux comme la peur et l'avidité n'ont aucun effet réel sur les décisions des investisseurs.
4. Pourquoi le plan écrit établi d'avance a-t-il aidé Reggie pendant la baisse du marché?
   a) Il n'a eu aucun effet sur sa décision
   b) Il lui a donné un point d'ancrage calme et décidé d'avance pour résister à une impulsion motivée par la peur sur le moment
   c) Il lui disait de vendre tout de suite
   d) Il avait été créé pendant la baisse elle-même

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Vendre par peur pendant une baisse peut concrétiser une perte qui aurait autrement pu être une expérience de volatilité temporaire et récupérable.
2. L'instinct grégaire consiste à suivre le comportement de la foule plutôt qu'une analyse indépendante ou un plan établi.
3. Les biais comportementaux comme la peur et l'avidité sont bien documentés et peuvent avoir un effet important sur les décisions réelles des investisseurs.
4. Le plan de Reggie, établi calmement d'avance, lui a donné un point d'ancrage stable pour résister à une impulsion émotionnelle sur le moment.

**7. Points clés à retenir**
- Vendre par peur peut transformer une volatilité temporaire en perte permanente et concrétisée.
- Acheter par avidité, souvent lié à la peur de manquer quelque chose, peut mener à des achats mal synchronisés près des sommets du marché.
- L'instinct grégaire consiste à suivre la foule plutôt qu'une analyse indépendante ou un plan établi.
- Un plan écrit établi pendant les périodes calmes est un meilleur point d'ancrage que de raisonner sur le moment sous le stress.
