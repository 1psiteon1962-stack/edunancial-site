---
id: WHITE-L2-030
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 30
title: "Imposable ou à avantage fiscal : quoi détenir où"
summary: "Comprends ce qu'est la localisation de l'actif, en quoi elle diffère de la répartition de l'actif et les éléments généraux pour décider quel placement mettre dans quel compte."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-030
### Imposable ou à avantage fiscal : quoi détenir où

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le concept général de la « localisation de l'actif », distinct de la répartition de l'actif.
- Décrire les éléments généraux à considérer pour décider quels placements détenir dans quels types de comptes.
- Reconnaître que c'est un domaine qui demande un encadrement professionnel coordonné.

**2. Contenu principal**
Dans la suite de la leçon précédente, la « localisation de l'actif » désigne la décision de savoir quels placements précis détenir dans quels types de comptes (imposables ou de différentes catégories à avantage fiscal), ce qui est distinct de la répartition de l'actif (leçon 16), qui porte sur l'ensemble du mélange d'actions, d'obligations et de liquidités, peu importe le type de compte. Un investisseur peut garder la même répartition globale de 70/30 entre actions et obligations dans plusieurs comptes, mais décider de façon réfléchie quels titres précis vont dans quel compte selon leurs caractéristiques fiscales.

Parmi les éléments généraux dont on discute dans ce domaine, il y a l'idée de placer les placements qui génèrent un revenu imposable continu important (comme certains intérêts d'obligations) dans des comptes à avantage fiscal où ce revenu pourrait ne pas être imposé dans l'immédiat, et de placer dans le compte imposable lui-même les placements qui bénéficient déjà d'un traitement fiscal plus avantageux, même dans un compte imposable (comme certaines actions détenues à long terme, vues plus en détail à la leçon 31). Ce sont des éléments généraux discutés dans la formation en finances personnelles, pas une formule universelle, puisque la localisation optimale réelle dépend de la situation fiscale complète de chaque personne et des comptes précis auxquels elle a accès.

**3. Exemple pratique**
En travaillant avec sa conseillère financière, Ingrid examine sa répartition globale de 70/30 entre actions et obligations, qu'elle détient à la fois dans un compte de courtage imposable et dans un compte de retraite à avantage fiscal. Au lieu de diviser chaque titre au hasard, à parts égales entre les deux comptes, elles placent de façon réfléchie ses obligations (qui génèrent des intérêts imposables réguliers) surtout dans son compte à avantage fiscal, et ses fonds indiciels d'actions (qui génèrent relativement moins d'activité imposable courante) surtout dans son compte imposable — tout en confirmant que sa répartition globale de 70/30 reste la même en combinant les deux comptes.

**4. Quiz de pratique**
1. À quoi la « localisation de l'actif » se rapporte-t-elle?
   a) À l'emplacement géographique du siège social d'une entreprise
   b) À la décision de savoir quels placements précis détenir dans quels types de comptes
   c) À la même notion que la répartition de l'actif
   d) À un type de cote d'obligation
2. En quoi la localisation de l'actif diffère-t-elle de la répartition de l'actif?
   a) Ce sont des notions identiques
   b) La répartition de l'actif porte sur le mélange global d'actions, d'obligations et de liquidités; la localisation porte sur quel compte détient quel placement
   c) La localisation de l'actif ne s'applique qu'à l'immobilier
   d) La répartition de l'actif ne s'applique qu'aux comptes imposables
3. Vrai ou faux : La localisation de l'actif optimale est la même pour chaque investisseur, peu importe sa situation fiscale ou les comptes auxquels il a accès.
4. Pourquoi Ingrid a-t-elle placé ses obligations surtout dans son compte à avantage fiscal?
   a) Les obligations ne génèrent aucun revenu
   b) Les obligations génèrent des intérêts imposables réguliers, qui peuvent profiter d'un traitement à avantage fiscal
   c) La loi l'exigeait
   d) Elle n'aimait pas les obligations

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La localisation de l'actif est la décision de savoir quels placements précis détenir dans quels types de comptes.
2. La répartition de l'actif porte sur le mélange global des placements; la localisation porte sur quel compte détient quel placement précis.
3. La localisation optimale dépend de la situation fiscale complète de chaque personne et des types de comptes auxquels elle a accès.
4. Les intérêts d'obligations sont souvent imposés comme un revenu ordinaire, ce qui fait des comptes à avantage fiscal un choix de placement souvent discuté.

**7. Points clés à retenir**
- La localisation de l'actif détermine quels placements précis sont détenus dans quels types de comptes, ce qui la distingue de la répartition de l'actif.
- Parmi les éléments généraux, on peut placer les placements qui génèrent plus de revenu imposable dans des comptes à avantage fiscal, quand c'est approprié.
- Ce sont des éléments généraux, pas une formule universelle, puisque le placement optimal dépend de la situation de chaque personne.
- Coordonner la localisation de l'actif avec un professionnel des finances ou de la fiscalité aide à aligner la stratégie globale sur la réalité fiscale de chacun.
