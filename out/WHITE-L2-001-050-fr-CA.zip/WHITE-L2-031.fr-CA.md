---
id: WHITE-L2-031
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 31
title: "Les gains en capital : à court terme ou à long terme"
summary: "Comprends ce qu'est un gain en capital, la distinction entre court et long terme là où elle existe, et pourquoi l'impôt doit éclairer ta décision sans la remplacer."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-031
### Les gains en capital : à court terme ou à long terme

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle un gain en capital.
- Distinguer de façon conceptuelle les gains en capital à court terme et à long terme.
- Expliquer pourquoi la période de détention peut compter dans la prise de décision d'un investisseur.

**2. Contenu principal**
Un gain en capital désigne généralement le profit réalisé quand un placement est vendu plus cher que son prix d'achat d'origine (une perte en capital se produit dans le cas contraire). Beaucoup de juridictions, y compris les États-Unis, font une distinction entre les gains en capital à court terme (généralement sur des actifs détenus moins longtemps, souvent imposés comme un revenu ordinaire) et les gains en capital à long terme (généralement sur des actifs détenus plus longtemps qu'un seuil précis, souvent imposés à des taux différents, parfois plus avantageux). Mais les seuils de période de détention et les taux précis dépendent de chaque juridiction, changent avec les lois et exigent une confirmation professionnelle à jour plutôt qu'une supposition générale.

À cause de cette distinction générale (dans les juridictions où elle s'applique), la période de détention peut devenir un facteur que l'investisseur considère, en plus de sa thèse de placement réelle. Cette leçon insiste toutefois sur le fait que les considérations fiscales devraient généralement éclairer, et non remplacer, une prise de décision de placement solide. Vendre un placement dont les données fondamentales s'affaiblissent uniquement pour éviter un taux à court terme, ou garder un placement solide plus longtemps qu'il ne le faudrait uniquement pour atteindre un seuil à long terme, sont deux façons de laisser une considération fiscale déformer une décision de placement par ailleurs solide.

**3. Exemple pratique**
En pensant à vendre une action qu'il détient, Julian remarque qu'il n'est qu'à quelques semaines de franchir le seuil de détention à long terme de sa juridiction. Au lieu de prendre sa décision uniquement en fonction de sa thèse de placement sous-jacente, il tient compte de ce moment comme d'un élément parmi d'autres et discute avec son fiscaliste pour savoir si attendre ces quelques semaines change de façon importante son résultat après impôt. Il confirme aussi que les données fondamentales du placement justifient quand même de le garder un peu plus longtemps, peu importe l'élément fiscal — ce qui évite un scénario où le seul moment fiscal aurait justifié de garder une position dont les données fondamentales se détériorent.

**4. Quiz de pratique**
1. Qu'est-ce qu'un gain en capital?
   a) Un type de dividende
   b) Le profit réalisé quand un placement est vendu plus cher que son prix d'achat
   c) Un rendement annuel garanti
   d) Le paiement de coupon d'une obligation
2. Là où cette distinction s'applique, qu'est-ce qui distingue généralement les gains en capital à court terme des gains à long terme?
   a) Le secteur d'activité de l'entreprise
   b) La période pendant laquelle l'actif a été détenu avant la vente
   c) L'âge de l'investisseur
   d) Le rendement en dividendes de l'action
3. Vrai ou faux : Les considérations fiscales devraient toujours l'emporter sur la thèse de placement sous-jacente quand on décide de vendre ou non.
4. Pourquoi Julian a-t-il tenu compte du seuil de détention à long terme qui approchait, tout en confirmant d'abord sa thèse de placement?
   a) Le moment fiscal était son seul élément à considérer
   b) Il voulait tenir compte du moment fiscal comme d'un élément parmi d'autres, en plus d'un raisonnement de placement solide, et non à sa place
   c) Il a complètement ignoré la période de détention
   d) Il n'avait aucune thèse de placement sous-jacente

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Un gain en capital est le profit réalisé en vendant un placement plus cher que son prix d'achat.
2. Là où cette distinction s'applique, c'est généralement la période de détention qui distingue le traitement des gains en capital à court terme et à long terme.
3. Les considérations fiscales devraient généralement éclairer, et non remplacer, une prise de décision de placement solide.
4. Julian a eu raison de traiter la période de détention comme un facteur en plus de sa thèse de placement, et non à sa place.

**7. Points clés à retenir**
- Un gain en capital est le profit tiré de la vente d'un placement à un prix supérieur à son prix d'achat.
- Beaucoup de juridictions distinguent les gains à court terme et à long terme selon la période de détention, souvent avec un traitement fiscal différent.
- Les taux et les seuils précis dépendent de chaque juridiction et exigent une confirmation professionnelle à jour.
- Les considérations fiscales devraient éclairer, et non remplacer, une prise de décision de placement solide.
