---
id: WHITE-L2-032
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 32
title: "Les bases des options : les options d'achat et de vente comme concepts"
summary: "Découvre ce que sont une option d'achat, une option de vente et la prime, et pourquoi une option peut expirer sans valeur, contrairement à une action."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-032
### Les bases des options : les options d'achat et de vente comme concepts

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle une option d'achat et une option de vente.
- Expliquer le concept général de la prime.
- Reconnaître que les options forment une catégorie de risque fondamentalement différente de la possession directe d'actions.

**2. Contenu principal**
Une option est un contrat qui donne à son acheteur le droit, mais pas l'obligation, d'acheter ou de vendre un actif sous-jacent (souvent une action) à un prix précis (le « prix d'exercice ») pendant une période précise, en échange d'un paiement initial appelé prime. Une option d'achat (*call*) donne à l'acheteur le droit d'acheter l'actif sous-jacent au prix d'exercice; une option de vente (*put*) donne à l'acheteur le droit de vendre l'actif sous-jacent au prix d'exercice.

Cette leçon présente les options uniquement comme un élément conceptuel de base, pas comme une stratégie recommandée. Les options diffèrent fondamentalement de la possession directe d'actions : le propriétaire d'une action participe proportionnellement à la propriété et aux résultats d'une entreprise, sans limite de temps, alors que la position de l'acheteur d'une option a une date d'expiration fixe et peut expirer complètement sans valeur si le prix de l'actif sous-jacent n'évolue pas favorablement par rapport au prix d'exercice pendant cette période précise. Toute la prime payée peut alors être perdue — un profil de risque vraiment différent de la simple possession d'actions.

**3. Exemple pratique**
En découvrant les options pour la première fois, Priscilla étudie un exemple hypothétique : une option d'achat qui donne à l'acheteur le droit d'acheter une action à un prix d'exercice précis avant une date d'expiration précise, en échange d'une prime payée au départ. Elle remarque que, si le prix de l'action reste sous le prix d'exercice jusqu'à l'expiration, l'option d'achat expirerait sans valeur et l'acheteur perdrait toute la prime payée — un contraste frappant avec la possession directe de l'action, où un prix qui ne bouge pas veut simplement dire aucun gain ni aucune perte, sans échéance fixe qui force un résultat.

**4. Quiz de pratique**
1. Que donne une option d'achat à son acheteur?
   a) L'obligation de vendre un actif
   b) Le droit, mais pas l'obligation, d'acheter un actif à un prix précis pendant une période précise
   c) La propriété garantie d'une entreprise
   d) Un dividende fixe
2. Dans le contexte d'une option, qu'est-ce qu'une « prime »?
   a) Un type de dividende
   b) Le paiement initial fait pour acquérir le contrat d'option
   c) La valeur nominale d'une obligation
   d) Un impôt sur la possession d'actions
3. Vrai ou faux : Une option, comme une action, n'a pas de date d'expiration et ne peut pas perdre toute sa valeur.
4. Selon cette leçon, quel risque clé distingue une option de la possession directe d'une action?
   a) Les options ne comportent aucun risque
   b) Une option peut expirer sans valeur, avec la perte de toute la prime, à cause de sa limite de temps fixe
   c) Les actions expirent toujours sans valeur
   d) Il n'y a aucune différence entre les deux

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une option d'achat donne à l'acheteur le droit, mais pas l'obligation, d'acheter un actif à un prix précis pendant une période précise.
2. La prime est le paiement initial que fait l'acheteur de l'option pour acquérir le contrat.
3. Contrairement à la possession d'actions, les options ont une date d'expiration fixe et peuvent expirer complètement sans valeur.
4. La date d'expiration fixe, qui rend possible la perte totale de la prime, est un risque clé qui distingue les options de la possession d'actions.

**7. Points clés à retenir**
- Une option donne à l'acheteur le droit, mais pas l'obligation, d'acheter (option d'achat) ou de vendre (option de vente) un actif à un prix précis pendant une période précise.
- La prime est le coût initial payé pour acquérir un contrat d'option.
- Les options ont une date d'expiration fixe et peuvent expirer complètement sans valeur, contrairement à la possession directe d'actions.
- Cette leçon présente les options seulement comme un concept, pas comme une stratégie recommandée pour un apprenant en particulier.
