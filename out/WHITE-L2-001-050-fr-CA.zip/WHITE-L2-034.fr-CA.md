---
id: WHITE-L2-034
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 34
title: "La marge et l'effet de levier dans les actifs papier"
summary: "Comprends ce qu'est l'achat sur marge, comment il agit comme un effet de levier semblable à celui de l'immobilier et quels risques et coûts il ajoute."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-034
### La marge et l'effet de levier dans les actifs papier

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle l'emprunt sur marge.
- Expliquer comment la marge agit comme un effet de levier dans les actifs papier, en écho à la discussion sur le levier du parcours RED.
- Nommer les risques généraux de l'emprunt sur marge.

**2. Contenu principal**
L'emprunt sur marge permet à un investisseur d'emprunter de l'argent à son courtier, en utilisant ses placements existants comme garantie, pour acheter des titres supplémentaires au-delà de ce que son argent seul permettrait — un parallèle direct, dans les actifs papier, de la notion d'effet de levier présentée dans le parcours RED (RED-L2-007), où de l'argent emprunté sert à contrôler une position plus grosse que ce que l'argent comptant seul permettrait.

Comme pour l'effet de levier en immobilier, la marge amplifie autant les gains que les pertes : si les titres achetés prennent de la valeur, le rendement en pourcentage de l'investisseur sur son propre argent investi est amplifié; si les titres perdent de la valeur, les pertes sont amplifiées de la même façon, et l'investisseur doit quand même rembourser le montant emprunté, peu importe la performance du placement. L'emprunt sur marge comporte aussi habituellement des frais d'intérêt continus sur le montant emprunté, ce qui ajoute un coût à surmonter pour que la stratégie soit rentable au total.

**3. Exemple pratique**
En comparant son approche à celle d'un ami, Xavier investit seulement avec son propre argent, alors que son ami utilise l'emprunt sur marge pour acheter deux fois plus de titres que ce qu'il pourrait se permettre avec son argent seul. Quand leur marché commun connaît une baisse, les pertes de Xavier se limitent à son propre argent investi, alors que celles de son ami sont amplifiées par sa position à effet de levier — et son ami doit quand même rembourser le montant emprunté au courtier, peu importe la baisse de valeur de son portefeuille, en plus des frais d'intérêt continus sur le prêt. Ça illustre le risque amplifié qui vient avec l'emprunt sur marge.

**4. Quiz de pratique**
1. Que permet généralement l'emprunt sur marge à un investisseur?
   a) Éviter tout risque de placement
   b) Emprunter de l'argent à son courtier, en utilisant ses placements existants comme garantie, pour acheter des titres supplémentaires
   c) Éliminer le besoin de tout placement en argent
   d) Garantir un rendement précis
2. En quoi l'emprunt sur marge est-il parallèle à la discussion sur l'effet de levier du parcours RED?
   a) Il n'a aucun lien avec les notions d'effet de levier en immobilier
   b) Les deux utilisent de l'argent emprunté pour contrôler une position plus grosse que l'argent comptant seul, ce qui amplifie les gains et les pertes
   c) L'emprunt sur marge élimine tous les effets de levier
   d) L'effet de levier immobilier et l'emprunt sur marge sont juridiquement identiques
3. Vrai ou faux : L'emprunt sur marge amplifie seulement les gains et n'amplifie jamais les pertes.
4. En plus du risque amplifié lui-même, quel coût supplémentaire l'emprunt sur marge comporte-t-il habituellement?
   a) Aucun coût supplémentaire
   b) Des frais d'intérêt continus sur le montant emprunté
   c) Un impôt gouvernemental unique
   d) Un dividende obligatoire

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. L'emprunt sur marge permet à un investisseur d'emprunter en donnant ses placements existants en garantie pour acheter des titres supplémentaires.
2. L'emprunt sur marge est un parallèle direct de l'effet de levier en immobilier : il utilise des fonds empruntés pour contrôler une position plus grosse, ce qui amplifie autant les gains que les pertes.
3. L'emprunt sur marge amplifie autant les gains que les pertes, pas seulement les gains.
4. L'emprunt sur marge comporte habituellement des frais d'intérêt continus sur le montant emprunté, un coût supplémentaire à surmonter.

**7. Points clés à retenir**
- L'emprunt sur marge permet d'acheter des titres supplémentaires avec des fonds empruntés garantis par des placements existants.
- C'est un parallèle direct de la notion d'effet de levier du parcours RED, qui amplifie autant les gains que les pertes.
- Le montant emprunté et ses intérêts doivent être remboursés peu importe la performance du placement.
- L'emprunt sur marge ajoute des frais d'intérêt continus qu'il faut surmonter pour que la stratégie soit rentable.
