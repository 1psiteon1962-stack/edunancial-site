---
id: WHITE-L2-035
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 35
title: "Le risque des appels de marge"
summary: "Comprends ce qu'est un appel de marge, pourquoi il peut forcer des ventes au pire moment et pourquoi ce risque s'aggrave pendant les baisses de marché."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-035
### Le risque des appels de marge

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle un appel de marge.
- Expliquer pourquoi les appels de marge peuvent forcer des ventes au mauvais moment.
- Décrire comment ce risque s'aggrave pendant les baisses de marché.

**2. Contenu principal**
Dans la suite de la leçon précédente, un appel de marge se produit quand la valeur du compte sur marge d'un investisseur baisse assez pour ne plus respecter le niveau minimal de garantie exigé par le courtier. Le courtier exige alors que l'investisseur dépose de l'argent ou des titres supplémentaires, sinon une partie de ses placements sera vendue automatiquement (souvent sans autre consultation) pour remettre le compte en conformité.

Ça crée un risque précis qui s'aggrave pendant les baisses de marché : à mesure que le prix des titres baisse, un investisseur qui utilise la marge peut être forcé de vendre ses placements exactement au pire moment possible — pendant une baisse — précisément pour répondre à un appel de marge. Ce qui aurait pu être une expérience de volatilité temporaire (leçon 26) devient alors une perte concrétisée, et il peut manquer complètement la reprise qui suit. Cette dynamique de vente forcée est une des principales raisons pour lesquelles on considère généralement que l'emprunt sur marge convient seulement aux investisseurs qui ont beaucoup d'expérience, une tolérance au risque élevée et la capacité financière de gérer ce risque précis.

**3. Exemple pratique**
Pendant une forte baisse du marché, le compte sur marge de Nadim tombe sous le niveau de maintien exigé par son courtier, ce qui déclenche un appel de marge. Comme il n'a pas d'argent supplémentaire facilement disponible pour y répondre, le courtier vend automatiquement une partie de ses placements aux prix actuels du marché, qui sont bas, pour remettre son compte en conformité. Des pertes sont ainsi concrétisées sur des positions qu'il aurait peut-être pu garder pendant la baisse et jusqu'à la reprise suivante, s'il n'avait pas utilisé la marge et n'avait donc pas été soumis à une vente forcée à ce moment précis, si mal choisi.

**4. Quiz de pratique**
1. Qu'est-ce qu'un appel de marge?
   a) Un appel téléphonique d'un courtier qui offre des conseils de placement
   b) Une demande du courtier pour une garantie supplémentaire quand la valeur d'un compte sur marge tombe sous un niveau exigé
   c) Un type de paiement de dividende
   d) Un avis fiscal gouvernemental
2. Pourquoi les appels de marge peuvent-ils forcer des ventes au mauvais moment?
   a) Ils ne surviennent que quand les prix montent
   b) Ils surviennent souvent pendant les baisses, ce qui force à vendre à bas prix pour respecter l'exigence de garantie
   c) Ils n'ont aucun lien avec le moment du marché
   d) Ils garantissent une vente rentable
3. Vrai ou faux : Un investisseur qui fait face à un appel de marge a toujours amplement le temps et les ressources pour éviter une vente forcée.
4. Qu'est-il arrivé à Nadim à la suite de son appel de marge?
   a) Ses placements ont été vendus à des prix élevés et avantageux
   b) Une partie de ses placements a été vendue automatiquement à bas prix, ce qui a concrétisé des pertes
   c) Il a plutôt reçu un dividende
   d) Son compte n'a pas été touché

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Un appel de marge est la demande d'un courtier pour une garantie supplémentaire quand un compte sur marge tombe sous un niveau de maintien exigé.
2. Les appels de marge surviennent souvent pendant les baisses du marché, ce qui force des ventes à bas prix pour rétablir la conformité.
3. Les investisseurs qui font face à un appel de marge peuvent manquer de temps ou de ressources pour éviter une vente forcée et mal synchronisée.
4. Les placements de Nadim ont été vendus de force à bas prix pendant la baisse, ce qui a concrétisé des pertes qu'il aurait peut-être pu éviter autrement.

**7. Points clés à retenir**
- Un appel de marge exige une garantie supplémentaire quand la valeur d'un compte sur marge tombe sous un niveau exigé.
- Les appels de marge surviennent souvent pendant les baisses, ce qui force des ventes exactement au pire moment possible.
- Ça peut transformer une volatilité temporaire en perte permanente et concrétisée.
- Ce risque de vente forcée est une des principales raisons pour lesquelles la marge convient généralement seulement aux investisseurs expérimentés et bien capitalisés.
