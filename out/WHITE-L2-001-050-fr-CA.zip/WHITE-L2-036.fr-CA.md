---
id: WHITE-L2-036
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 36
title: "Les marchés baissiers et les corrections : de quoi s'agit-il"
summary: "Apprends ce que veulent dire « correction » et « marché baissier », pourquoi ces termes décrivent une ampleur et non une durée, et ce que montre l'histoire des reprises."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-036
### Les marchés baissiers et les corrections : de quoi s'agit-il

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir les termes « correction » et « marché baissier » tels qu'on les emploie couramment.
- Expliquer pourquoi ces termes décrivent une ampleur, et pas nécessairement une cause ou une durée.
- Reconnaître la tendance historique à la reprise éventuelle, sans la considérer comme garantie pour un événement futur précis.

**2. Contenu principal**
Une « correction » est un terme couramment utilisé pour désigner une baisse d'environ 10 % ou plus par rapport à un sommet récent d'un large indice de marché; un « marché baissier » est un terme couramment utilisé pour une baisse d'environ 20 % ou plus par rapport à un sommet récent. Ce sont des étiquettes qui décrivent l'ampleur, pas des indicateurs de la cause, et elles ne disent rien en elles-mêmes sur la durée d'une baisse ni sur la rapidité (ou même la venue) d'une reprise : certaines corrections se règlent en quelques semaines, alors que certains marchés baissiers ont, historiquement, duré longtemps.

Historiquement, les larges indices de marché de bien des grandes économies ont fini par se remettre des corrections et des marchés baissiers, en atteignant souvent de nouveaux sommets dans les années suivantes — une tendance qui se rattache aux discussions précédentes sur l'horizon de placement à long terme (leçon 27) et la discipline comportementale (leçon 28). Cette leçon présente cette tendance historique comme un fait, sans garantir qu'elle se répétera de la même façon pour une baisse future précise, puisque chaque période a ses propres circonstances.

**3. Exemple pratique**
En vivant son premier vrai marché baissier comme investisseur, Cyrus étudie des exemples historiques de marchés baissiers passés. Il découvre que, même si chacun avait ses propres causes et ses propres délais de reprise, les larges indices de marché ont historiquement fini par se redresser et atteindre de nouveaux sommets dans les années qui ont suivi les baisses passées. Il ne considère pas cette tendance historique comme une garantie pour sa situation actuelle précise, mais elle lui donne un contexte utile — en plus de son long horizon de placement et de son plan établi d'avance (leçon 28) — pour garder son calme et s'en tenir à sa stratégie plutôt que de réagir uniquement aux manchettes du moment.

**4. Quiz de pratique**
1. À quoi le terme « correction » se rapporte-t-il couramment?
   a) À une baisse d'environ 10 % ou plus par rapport à un sommet récent
   b) À n'importe quelle baisse, peu importe sa taille
   c) À un événement futur garanti
   d) À un type de défaut d'obligation
2. À quoi le terme « marché baissier » se rapporte-t-il couramment?
   a) À une hausse de 20 % ou plus
   b) À une baisse d'environ 20 % ou plus par rapport à un sommet récent
   c) À la faillite d'une entreprise précise
   d) À une politique gouvernementale
3. Vrai ou faux : Ces termes garantissent combien de temps durera une baisse ou à quelle vitesse se fera la reprise.
4. Comment Cyrus a-t-il utilisé les tendances historiques des marchés baissiers pendant sa propre expérience?
   a) Comme une garantie que sa situation actuelle se réglerait de la même façon
   b) Comme un contexte utile, en plus de son propre plan, sans le considérer comme une garantie pour sa situation précise
   c) Il a complètement ignoré l'histoire
   d) Il a paniqué et vendu tout de suite

**5. Corrigé**
1. a  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une correction désigne couramment une baisse d'environ 10 % ou plus par rapport à un sommet récent.
2. Un marché baissier désigne couramment une baisse d'environ 20 % ou plus par rapport à un sommet récent.
3. Ces termes ne décrivent que l'ampleur; ils ne disent rien sur la durée ni sur la certitude d'un délai de reprise futur précis.
4. Cyrus a eu raison d'utiliser le contexte historique comme information utile, sans le considérer comme une garantie pour sa propre situation.

**7. Points clés à retenir**
- Une « correction » désigne couramment une baisse d'environ 10 % ou plus; un « marché baissier », une baisse d'environ 20 % ou plus par rapport à un sommet récent.
- Ces termes décrivent l'ampleur, pas la cause ni une durée garantie.
- Les larges indices de marché se sont historiquement remis des baisses passées, mais ce n'est pas une garantie pour un événement futur précis.
- Ce contexte historique, combiné à un long horizon de placement et à un plan établi, soutient la discipline comportementale pendant les baisses.
