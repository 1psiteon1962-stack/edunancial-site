---
id: WHITE-L2-037
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 37
title: "Les cycles historiques du marché : une vue à long terme"
summary: "Vois comment les marchés des actifs papier passent eux aussi par des cycles, comme l'immobilier, et pourquoi cette notion sert la patience plutôt que la prédiction."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-037
### Les cycles historiques du marché : une vue à long terme

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le concept général des cycles du marché à long terme.
- Relier ce concept à la discussion sur les cycles du marché du parcours RED.
- Reconnaître les limites de l'utilisation des tendances historiques pour prédire des résultats futurs précis.

**2. Contenu principal**
Tout comme le parcours RED a présenté les cycles du marché immobilier (RED-L2-034), causés par l'interaction des taux, de l'offre et de la demande, les marchés des actifs papier passent aussi par des cycles à long terme d'expansion et de contraction, influencés entre autres par la croissance économique, les taux d'intérêt, l'évolution des bénéfices des entreprises et le sentiment des investisseurs. C'est un autre vrai parallèle entre les couleurs : les cycles ne sont pas propres à l'immobilier, mais forment une tendance plus large qu'on observe dans différentes catégories d'actifs, même si leur fonctionnement précis et leur moment diffèrent.

Comme dans la discussion du parcours RED, cette leçon insiste sur le fait que reconnaître les cycles comme une tendance générale observée dans l'histoire est utile pour avoir des attentes réalistes, mais qu'utiliser les cycles historiques pour prédire avec précision le moment, la durée ou l'ampleur des cycles futurs reste vraiment difficile, même pour les investisseurs et les prévisionnistes professionnels. La valeur éducative est de comprendre que les marchés évoluent par phases, ce qui soutient la patience et la discipline (leçon 28), et non d'essayer de choisir le moment d'entrer et de sortir autour d'un cycle prédit.

**3. Exemple pratique**
En étudiant des données historiques du marché sur plusieurs décennies, une apprenante observe des tendances récurrentes : de longues périodes de croissance suivies de périodes de baisse, puis d'une reprise éventuelle, ce qui fait écho à ce qu'elle a appris sur les cycles immobiliers dans le parcours RED. Au lieu de conclure qu'elle peut maintenant prédire avec précision les points tournants du prochain cycle, elle conclut que cette tendance historique renforce l'importance d'un long horizon de placement et d'une stratégie disciplinée et constante (comme l'investissement périodique d'un montant fixe de la leçon 19), dont l'efficacité ne dépend pas de la capacité à prédire correctement le moment des cycles.

**4. Quiz de pratique**
1. Selon cette leçon, quels facteurs influencent les cycles à long terme des marchés des actifs papier?
   a) Seulement la météo
   b) La croissance économique, les taux d'intérêt, les bénéfices des entreprises et le sentiment des investisseurs, entre autres
   c) Rien — les cycles n'existent pas dans les actifs papier
   d) Seulement les directives gouvernementales
2. Comment cette leçon se rattache-t-elle à la discussion sur les cycles du marché du parcours RED?
   a) Elle n'a aucun lien
   b) Elle montre que les cycles sont une tendance plus large qu'on observe dans différentes catégories d'actifs
   c) L'immobilier et les actifs papier ne connaissent jamais de cycles
   d) Seul l'immobilier connaît des cycles
3. Vrai ou faux : Les cycles historiques du marché permettent de prédire avec précision le moment exact des cycles futurs.
4. Qu'est-ce que l'apprenante a conclu de son étude des données historiques sur les cycles du marché?
   a) Elle pouvait maintenant choisir parfaitement le moment d'entrer et de sortir du marché
   b) La tendance renforçait la valeur d'un long horizon de placement et d'une stratégie disciplinée et constante
   c) Les cycles du marché sont entièrement aléatoires et ne donnent aucune information utile
   d) Seul l'immobilier suit des tendances cycliques

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. La croissance économique, les taux d'intérêt, les bénéfices des entreprises et le sentiment des investisseurs font partie des facteurs qui influencent les cycles des marchés des actifs papier.
2. Cette leçon se rattache explicitement à la discussion sur les cycles du parcours RED, en montrant que les cycles sont une tendance commune à plusieurs catégories d'actifs.
3. Les tendances historiques ne permettent pas de prédire avec précision le moment, la durée ou l'ampleur des cycles futurs.
4. L'apprenante a eu raison d'utiliser les tendances historiques pour renforcer une stratégie disciplinée à long terme plutôt que d'essayer de choisir précisément le bon moment.

**7. Points clés à retenir**
- Les marchés des actifs papier passent par des cycles à long terme, influencés par l'économie, les taux, les bénéfices et le sentiment des investisseurs.
- C'est un parallèle direct de la discussion sur les cycles immobiliers du parcours RED, qui illustre un vrai modèle commun entre les couleurs.
- Les cycles historiques ne permettent pas de prédire avec précision le moment, la durée ou l'ampleur des cycles futurs.
- La valeur éducative est de soutenir la patience et une stratégie disciplinée et constante, pas de choisir le moment du marché.
