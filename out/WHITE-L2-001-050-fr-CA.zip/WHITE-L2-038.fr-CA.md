---
id: WHITE-L2-038
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 38
title: "Les FPI revisitées : WHITE rencontre RED"
summary: "Revois les fiducies de placement immobilier du point de vue des actifs papier, comment les évaluer avec les lentilles du niveau et quelle place leur donner dans un portefeuille."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-038
### Les FPI revisitées : WHITE rencontre RED

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Renforcer le concept de la FPI comme pont entre les couleurs WHITE et RED.
- Expliquer comment les FPI s'intègrent aux notions de répartition de l'actif et de diversification de ce niveau.
- Appliquer le cadre des lentilles (leçons 2 à 7) à l'évaluation d'une FPI.

**2. Contenu principal**
La leçon RED-L2-037 a présenté les FPI du point de vue de l'immobilier; cette leçon les revisite explicitement du point de vue WHITE (actifs papier), ce qui renforce la conception entre les couleurs de ce programme. Une FPI détenue comme actif papier (souvent sous forme d'action ou de fonds coté en Bourse) peut être évaluée avec les mêmes lentilles présentées plus tôt dans ce niveau : une FPI qui verse des distributions importantes et fiables peut surtout plaire à travers la lentille du revenu (leçon 5); une FPI dans un secteur immobilier en forte croissance peut plaire à travers la lentille de la croissance (leçon 4).

Du point de vue de la répartition de l'actif et de la diversification (leçons 16, 17 et 24), les FPI occupent une position intéressante : techniquement, ce sont des actifs papier (leurs parts s'achètent et se vendent comme des actions), mais leur performance sous-jacente est liée aux conditions du marché immobilier (RED-L2-034). Elles n'évoluent donc pas toujours parfaitement au même rythme que l'ensemble du marché boursier — un élément que certains investisseurs pèsent pour décider de l'avantage de diversification que les FPI peuvent leur apporter, même si cette relation n'est ni fixe ni garantie dans chaque période.

**3. Exemple pratique**
En décidant comment classer une FPI dans son analyse globale de diversification, Adaeze reconnaît qu'elle n'entre pas facilement dans une seule catégorie simple : elle se négocie comme un actif papier, avec ses actions et ses obligations, mais les facteurs qui déterminent sa performance sous-jacente sont étroitement liés aux conditions du marché immobilier. Elle la traite de façon réfléchie comme une pièce distincte dans sa répartition globale et applique la lentille du revenu pour évaluer son historique de distributions, plutôt que de simplement la mettre avec ses autres actions sans tenir compte de son exposition immobilière sous-jacente distincte.

**4. Quiz de pratique**
1. Qu'est-ce que cette leçon renforce explicitement au sujet des FPI?
   a) Qu'elles n'ont rien à voir avec l'immobilier
   b) Leur rôle de pont entre les couleurs WHITE (actifs papier) et RED (immobilier)
   c) Qu'on ne peut les évaluer avec aucune lentille de placement
   d) Qu'elles sont identiques aux obligations
2. Quelle lentille pourrait plaire à un investisseur attiré par les distributions importantes et fiables d'une FPI?
   a) Uniquement la lentille de la croissance
   b) La lentille du revenu
   c) Aucune lentille ne s'applique aux FPI
   d) La lentille de la marge
3. Vrai ou faux : Les FPI évoluent toujours exactement au même rythme que l'ensemble du marché boursier, dans chaque période.
4. Pourquoi Adaeze a-t-elle traité sa FPI comme une pièce distincte dans son analyse de répartition?
   a) Elle a ignoré ses caractéristiques uniques
   b) La FPI combine une négociation d'actif papier et une performance sous-jacente liée à l'immobilier, ce qui justifie une considération distincte
   c) Les FPI sont identiques à ses obligations
   d) Elle l'a complètement exclue de son portefeuille

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Cette leçon renforce le rôle des FPI comme vrai pont entre les notions des couleurs WHITE et RED.
2. La lentille du revenu convient à un investisseur attiré par l'historique de distributions importantes et fiables d'une FPI.
3. Les FPI n'évoluent pas toujours parfaitement au même rythme que l'ensemble du marché boursier, mais cette relation n'est ni fixe ni garantie.
4. Adaeze a eu raison de reconnaître le mélange distinct de sa FPI : une structure d'actif papier et une performance liée à l'immobilier.

**7. Points clés à retenir**
- Les FPI font le pont entre les parcours WHITE et RED : elles se négocient comme des actifs papier, mais sont liées à la performance du marché immobilier.
- Les lentilles de la valeur, de la croissance, du revenu et de la gestion passive de ce niveau peuvent toutes s'appliquer à l'évaluation des FPI.
- Les FPI peuvent offrir un certain avantage de diversification par rapport à l'ensemble des actions, mais cette relation n'est ni fixe ni garantie.
- Cette leçon renforce la conception volontaire entre les couleurs de ce programme.
