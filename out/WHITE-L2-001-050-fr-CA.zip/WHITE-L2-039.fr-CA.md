---
id: WHITE-L2-039
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 39
title: "Les fonds à date cible et les fonds de cycle de vie"
summary: "Comprends comment un fonds à date cible ajuste automatiquement sa répartition avec le temps et pourquoi deux fonds de même date peuvent avoir des trajectoires différentes."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-039
### Les fonds à date cible et les fonds de cycle de vie

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le concept général d'un fonds à date cible ou de cycle de vie.
- Décrire comment ces fonds ajustent automatiquement leur répartition avec le temps.
- Nommer les éléments généraux à considérer pour évaluer si un tel fonds convient à la situation d'un investisseur.

**2. Contenu principal**
Un fonds à date cible (ou fonds de cycle de vie) est un fonds unique conçu pour ajuster automatiquement sa répartition de l'actif (leçon 16) avec le temps. Il devient généralement plus prudent (en passant d'une plus grande part en actions à une plus grande part en obligations et en liquidités) à mesure qu'il approche d'une date cible précise, souvent associée à l'année de retraite prévue de l'investisseur. Cette structure vise à simplifier les décisions de répartition de l'actif et de rééquilibrage (leçon 18) qui exigeraient autrement une gestion active continue de la part de l'investisseur.

Les éléments généraux à considérer pour évaluer un fonds à date cible comprennent l'examen de sa « trajectoire » précise (la façon dont sa répartition change réellement avec le temps, puisque différents fonds ayant la même date cible peuvent avoir des trajectoires vraiment différentes), son ratio des frais (leçon 15) et la question de savoir si ses hypothèses de base sur la tolérance au risque et les besoins de dépenses à la retraite correspondent réellement à la situation précise de l'investisseur, puisqu'un seul fonds ne peut pas tenir compte de la situation unique de chaque personne, de ses autres sources de revenu ou des nuances de sa tolérance au risque.

**3. Exemple pratique**
En considérant un fonds à date cible aligné sur son année de retraite prévue, Simone étudie sa trajectoire précise et découvre qu'il devient nettement plus prudent plusieurs années plus tôt qu'un fonds concurrent ayant exactement la même année cible. Reconnaissant que sa tolérance personnelle au risque et les autres sources de revenu qu'elle prévoit à la retraite pourraient rendre une trajectoire un peu plus audacieuse plus appropriée pour sa situation précise, elle compare plusieurs fonds à date cible au lieu de supposer que tous les fonds qui partagent son année cible sont identiques en pratique.

**4. Quiz de pratique**
1. Que fait généralement un fonds à date cible avec le temps?
   a) Il garde une répartition fixe pour toujours
   b) Il ajuste automatiquement sa répartition et devient généralement plus prudent à l'approche de la date cible
   c) Il n'investit qu'en obligations dès le départ
   d) Il élimine le besoin de toute diversification
2. Qu'est-ce qu'une « trajectoire » (*glide path*)?
   a) Un type d'obligation
   b) La façon dont la répartition d'un fonds à date cible change réellement avec le temps
   c) Une date limite de déclaration de revenus
   d) Un type de compte de courtage
3. Vrai ou faux : Tous les fonds à date cible qui partagent la même année cible ont des trajectoires identiques et sont interchangeables en pratique.
4. Pourquoi Simone a-t-elle comparé plusieurs fonds à date cible plutôt que de supposer qu'ils étaient interchangeables?
   a) Elle n'avait aucun projet de retraite
   b) Différents fonds ayant la même année cible peuvent avoir des trajectoires vraiment différentes qui conviennent à des investisseurs différents
   c) Les fonds à date cible ne diffèrent pas vraiment les uns des autres
   d) Elle n'aimait pas le rééquilibrage automatique

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Un fonds à date cible ajuste automatiquement sa répartition et devient généralement plus prudent à l'approche de sa date cible.
2. Une trajectoire décrit la façon dont la répartition précise d'un fonds à date cible change avec le temps.
3. Différents fonds à date cible ayant la même année cible peuvent avoir des trajectoires et des ratios des frais vraiment différents.
4. Simone a eu raison de reconnaître que des trajectoires différentes pouvaient convenir plus ou moins bien à sa propre situation.

**7. Points clés à retenir**
- Les fonds à date cible (de cycle de vie) ajustent automatiquement leur répartition avec le temps et deviennent généralement plus prudents près de la date cible.
- Ça simplifie pour l'investisseur les décisions continues de répartition et de rééquilibrage.
- Les trajectoires et les ratios des frais peuvent être vraiment différents entre des fonds qui partagent la même date cible.
- Il reste important d'évaluer si les hypothèses de base d'un fonds correspondent à la situation réelle de chaque personne.
