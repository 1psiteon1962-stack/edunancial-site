---
id: WHITE-L2-041
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 41
title: "Lire le prospectus d'un fonds"
summary: "Découvre à quoi sert un prospectus, quelles sections examiner et comment sa lecture peut révéler des frais et des risques que le nom du fonds ne montre pas."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-041
### Lire le prospectus d'un fonds

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer le but général du prospectus d'un fonds.
- Nommer les principales sections qu'on trouve habituellement dans un prospectus.
- Appliquer cette compétence pour évaluer un fonds avant d'investir.

**2. Contenu principal**
Un prospectus est un document juridique officiel que les fonds sont généralement tenus de fournir; il divulgue les renseignements clés dont les investisseurs ont besoin pour prendre une décision éclairée. Les principales sections comprennent habituellement l'objectif et la stratégie de placement du fonds (est-ce qu'il suit une approche de valeur, de croissance, de revenu ou de gestion passive, en lien avec les leçons 2 à 7?), sa structure de frais, y compris le ratio des frais (leçon 15) et les autres frais, son rendement historique (présenté avec les mises en garde obligatoires selon lesquelles le rendement passé ne garantit pas les résultats futurs), ses facteurs de risque et ses titres en portefeuille ou sa composition générale.

Lire un prospectus, même sous forme résumée (beaucoup de fonds offrent un document plus court, comme un « prospectus simplifié » ou un aperçu du fonds), est une compétence pratique de niveau 2 qui transforme les notions abstraites de tout ce niveau en exercice d'évaluation concret : un investisseur peut vérifier directement la stratégie, les frais et les risques déclarés d'un fonds plutôt que de se fier seulement au matériel promotionnel ou au nom du fonds, qui ne reflète pas toujours entièrement sa vraie stratégie sous-jacente ou son profil de risque.

**3. Exemple pratique**
Avant d'investir dans un fonds qu'il ne connaît pas et qu'un ami lui a recommandé, Wendell lit son prospectus simplifié au lieu de se fier seulement à son nom et à la description informelle de son ami. Il découvre que le ratio des frais réel du fonds est plus élevé qu'il ne le pensait, et que sa stratégie de placement déclarée comporte des positions plus concentrées et plus risquées que ce que laissait entendre le matériel promotionnel général du fonds. Avec ce portrait plus complet, Wendell décide de chercher un autre fonds dont la stratégie et les frais réellement documentés correspondent mieux à ses propres objectifs et à sa tolérance au risque.

**4. Quiz de pratique**
1. Qu'est-ce qu'un prospectus?
   a) Une brochure promotionnelle informelle
   b) Un document juridique officiel qui divulgue les renseignements clés d'un fonds pour aider les investisseurs à décider
   c) Un type d'obligation
   d) Un formulaire fiscal
2. Que peut révéler la lecture d'un prospectus que le matériel promotionnel ou le nom du fonds seuls ne montrent pas toujours?
   a) Rien de nouveau
   b) Le vrai ratio des frais, ainsi que les détails de la stratégie et des risques
   c) Seulement le symbole boursier du fonds
   d) Les opinions personnelles du gestionnaire du fonds
3. Vrai ou faux : Le nom d'un fonds reflète toujours entièrement et exactement sa vraie stratégie sous-jacente et son profil de risque.
4. Qu'est-ce que Wendell a découvert en lisant le prospectus simplifié du fonds?
   a) Rien de différent de ce qu'il attendait
   b) Un ratio des frais plus élevé et une stratégie plus concentrée et plus risquée que ce que laissait entendre le matériel promotionnel
   c) Que le fonds n'avait aucuns frais
   d) Que le fonds était sans risque

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Un prospectus est un document juridique officiel qui divulgue les renseignements clés dont les investisseurs ont besoin pour prendre une décision éclairée.
2. Lire un prospectus peut révéler le vrai ratio des frais, les détails de la stratégie et des risques que le matériel promotionnel ou le nom du fonds ne montrent pas entièrement.
3. Le nom d'un fonds ne reflète pas toujours entièrement ni exactement sa vraie stratégie sous-jacente ou son profil de risque.
4. L'examen du prospectus par Wendell a révélé un ratio des frais plus élevé et une stratégie plus risquée qu'il ne l'avait supposé au départ.

**7. Points clés à retenir**
- Un prospectus est un document juridique officiel qui divulgue la stratégie, les frais, le rendement et les facteurs de risque d'un fonds.
- Les principales sections comprennent l'objectif de placement, la structure des frais, le rendement historique et les facteurs de risque.
- Lire un prospectus transforme les notions abstraites de ce niveau en compétence d'évaluation concrète et pratique.
- Le nom ou le matériel promotionnel d'un fonds ne reflète pas toujours entièrement sa stratégie et ses risques réellement documentés.
