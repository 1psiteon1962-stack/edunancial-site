---
id: WHITE-L2-042
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 42
title: "Comprendre les frais au-delà du ratio des frais"
summary: "Découvre les autres frais qui peuvent réduire tes rendements — commissions, frais de compte, frais de conseil et frais d'acquisition — et pourquoi il faut regarder le coût total."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-042
### Comprendre les frais au-delà du ratio des frais

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Nommer les types de frais, autres que le ratio des frais, qui peuvent toucher les rendements de placement.
- Expliquer le but général de chaque type de frais.
- Renforcer l'importance de la conscience du coût total présentée à la leçon 15.

**2. Contenu principal**
Dans la suite de la discussion sur les ratios des frais de la leçon 15, cette leçon présente d'autres types de frais qu'il vaut la peine de comprendre. Les commissions de négociation (des frais facturés à chaque transaction, même si bien des courtiers les ont réduites ou éliminées pour de nombreux types de transactions) peuvent compter pour les investisseurs qui font souvent des transactions. Les frais de tenue de compte (des frais périodiques pour détenir un compte, parfois annulés à certaines conditions) peuvent s'appliquer dans certaines institutions. Les frais de conseil (facturés par des conseillers financiers humains ou des robots-conseillers, leçon 40, habituellement en pourcentage de l'actif géré) rémunèrent l'accompagnement et la gestion professionnels.

Certains fonds facturent aussi des « frais d'acquisition » — des frais de vente appliqués à l'achat (frais d'entrée) ou à la vente (frais de sortie) de parts de fonds, distincts du ratio des frais continu. C'est une structure de frais que les investisseurs devraient surveiller précisément, puisque le portrait global des coûts d'un fonds est incomplet tant qu'on ne tient pas compte de tous les types de frais applicables ensemble, et non du seul ratio des frais.

**3. Exemple pratique**
En comparant deux fonds communs de placement semblables, Odalys suppose d'abord qu'ils coûtent la même chose parce que leurs ratios des frais sont presque identiques. En examinant de plus près la divulgation complète des frais de chaque fonds, elle découvre que l'un d'eux facture aussi des frais d'entrée — des frais de vente déduits dès l'achat —, alors que l'autre n'en facture pas, ce qui change de façon importante la vraie comparaison du coût total entre les deux fonds, malgré leurs ratios des frais semblables.

**4. Quiz de pratique**
1. Dans le contexte des frais d'un fonds, que sont des « frais d'acquisition »?
   a) La même chose qu'un ratio des frais
   b) Des frais de vente appliqués à l'achat ou à la vente de parts de fonds, distincts du ratio des frais continu
   c) Un impôt gouvernemental
   d) Un type de dividende
2. Pourquoi est-il important de regarder au-delà du seul ratio des frais quand on compare des fonds?
   a) Le ratio des frais est le seul type de frais qui existe
   b) D'autres frais, comme les frais d'acquisition ou de conseil, peuvent changer de façon importante le vrai coût total
   c) Tous les fonds ont des structures de frais identiques
   d) Les frais n'ont aucun effet sur les rendements
3. Vrai ou faux : Deux fonds aux ratios des frais presque identiques ont toujours une structure de coût total identique.
4. Qu'est-ce qu'Odalys a découvert qui a changé sa comparaison des coûts entre les deux fonds?
   a) Rien — les fonds avaient exactement le même coût
   b) Un des fonds facturait des frais d'entrée que l'autre ne facturait pas
   c) Les deux fonds n'avaient aucuns frais
   d) Les ratios des frais étaient très différents

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Les frais d'acquisition sont des frais de vente appliqués à l'achat ou à la vente de parts de fonds, distincts du ratio des frais continu.
2. D'autres frais, comme les frais d'acquisition et de conseil, peuvent changer de façon importante le vrai coût total d'un fonds ou d'un compte, au-delà du seul ratio des frais.
3. Des ratios des frais semblables ne garantissent pas une structure de coût total identique une fois les autres frais pris en compte.
4. L'examen plus approfondi des frais par Odalys a révélé, pour un des fonds, des frais d'entrée qui ont changé de façon importante la vraie comparaison des coûts.

**7. Points clés à retenir**
- Les frais au-delà du ratio des frais comprennent les commissions de négociation, les frais de tenue de compte, les frais de conseil et les frais d'acquisition.
- Le vrai coût total d'un fonds exige de considérer ensemble tous les types de frais applicables, pas seulement le ratio des frais.
- Les frais d'acquisition sont des frais de vente appliqués à l'achat ou à la vente, distincts des frais annuels continus.
- La conscience du coût total, présentée à la leçon 15, s'étend à toute cette gamme de frais possibles.
