---
id: WHITE-L2-043
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 43
title: "Rédiger un énoncé de politique de placement"
summary: "Apprends ce qu'est un énoncé de politique de placement personnel, ce qu'il contient et comment il t'aide à garder ta discipline pendant les périodes de stress du marché."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-043
### Rédiger un énoncé de politique de placement

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Définir de façon conceptuelle un énoncé de politique de placement (EPP).
- Nommer les éléments courants d'un EPP personnel.
- Expliquer comment un EPP soutient la discipline comportementale (leçon 28).

**2. Contenu principal**
Un énoncé de politique de placement (EPP, ou *Investment Policy Statement*) est un document écrit, couramment utilisé par les investisseurs institutionnels, mais de plus en plus recommandé aux investisseurs individuels. Il consigne les objectifs de l'investisseur, son horizon de placement, sa tolérance au risque, sa répartition de l'actif cible et ses règles générales de rééquilibrage ou de changement. Il rassemble essentiellement plusieurs notions de ce niveau (leçons 16, 18, 26 et 27) en un seul document de référence personnel, créé pendant une période calme et rationnelle, précisément pour qu'on puisse y revenir pendant les moments de marché chargés d'émotion (leçon 28).

Les éléments courants d'un EPP personnel comprennent un énoncé des objectifs financiers et de l'horizon de placement, des fourchettes de répartition de l'actif cible, des règles de rééquilibrage (selon un calendrier ou selon des seuils, leçon 18) et des lignes directrices explicites sur la façon dont l'investisseur compte réagir à une volatilité importante du marché, écrites d'avance plutôt que décidées en réaction sur le moment.

**3. Exemple pratique**
Après avoir terminé le contenu de ce niveau, Bianca rédige son propre énoncé de politique de placement personnel. Elle y consigne son objectif de retraite à long terme, son horizon de placement de 30 ans, sa répartition cible de 80/20 entre actions et obligations, son plan de rééquilibrage annuel et une note explicite qui rappelle à son futur moi que les baisses du marché sont une partie normale et prévisible de l'investissement à long terme, déjà prévue dans son plan. Des mois plus tard, pendant une importante baisse du marché, Bianca relit ce document et constate qu'il lui offre exactement le point d'ancrage calme et décidé d'avance dont elle a besoin pour résister à une envie émotionnelle de s'écarter de son plan établi.

**4. Quiz de pratique**
1. Qu'est-ce qu'un énoncé de politique de placement (EPP)?
   a) Un formulaire fiscal gouvernemental
   b) Un document écrit qui consigne les objectifs, l'horizon de placement, la tolérance au risque et les règles de répartition d'un investisseur
   c) Un type d'obligation
   d) Une demande d'ouverture de compte de courtage
2. Pourquoi crée-t-on un EPP pendant une période calme plutôt que pendant un stress du marché?
   a) Ça n'a aucun lien avec le stress du marché
   b) Pour fournir un point d'ancrage stable et décidé d'avance pour les moments plus chargés d'émotion à venir
   c) La loi exige qu'on le crée seulement pendant les baisses
   d) Les périodes calmes produisent des documents moins exacts
3. Vrai ou faux : Un EPP n'est utile que pour les investisseurs institutionnels et n'a aucune pertinence pour les particuliers.
4. Comment l'EPP de Bianca l'a-t-il aidée pendant la baisse du marché qui a suivi?
   a) Il n'a eu aucun effet sur son comportement
   b) Il lui a offert un point d'ancrage calme et décidé d'avance qui l'a aidée à résister à une envie émotionnelle de s'écarter de son plan
   c) Il lui disait de vendre tous ses placements tout de suite
   d) Elle n'en avait jamais vraiment écrit

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Un EPP est un document écrit qui consigne les objectifs, l'horizon de placement, la tolérance au risque et les règles de répartition et de rééquilibrage d'un investisseur.
2. Créer un EPP pendant une période calme fournit un point d'ancrage stable pour traverser plus tard des moments de marché plus chargés d'émotion.
3. On encourage de plus en plus les investisseurs individuels, et pas seulement les institutions, à créer leur propre EPP personnel.
4. L'EPP établi d'avance par Bianca lui a donné un point de référence stable qui l'a aidée à garder sa discipline pendant la baisse.

**7. Points clés à retenir**
- Un énoncé de politique de placement consigne dans un seul document les objectifs, l'horizon de placement, la tolérance au risque et les règles de répartition et de rééquilibrage.
- Il rassemble plusieurs notions de ce niveau en une seule référence personnelle.
- Le créer pendant une période calme soutient la discipline comportementale pendant les moments de marché plus chargés d'émotion qui suivront.
- Les investisseurs individuels, et pas seulement les institutions, profitent de plus en plus d'un EPP personnel.
