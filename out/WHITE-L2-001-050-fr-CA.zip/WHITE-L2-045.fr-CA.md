---
id: WHITE-L2-045
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 45
title: "La discipline comportementale pendant les baisses du marché"
summary: "Rassemble les notions comportementales du niveau en un cadre pratique pour traverser une baisse du marché, et vois pourquoi le vrai travail se fait avant la tempête."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-045
### La discipline comportementale pendant les baisses du marché

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Rassembler les notions comportementales de ce niveau (leçons 1, 19, 20, 26, 28, 36, 37 et 43) en un cadre pratique de réaction aux baisses.
- Expliquer le rôle d'un plan établi d'avance pendant un vrai stress du marché.
- Appliquer ce cadre à un scénario de baisse hypothétique.

**2. Contenu principal**
Cette leçon rassemble plusieurs fils comportementaux de WHITE-L2 en un seul cadre pratique pour traverser une vraie baisse du marché : se rappeler que la volatilité n'est pas une perte permanente (leçon 26); se rappeler la tendance historique à la reprise éventuelle après les corrections et les marchés baissiers, sans la considérer comme garantie pour l'événement actuel précis (leçon 36); se rappeler les biais comportementaux précis — la vente motivée par la peur, l'instinct grégaire — qui ont tendance à apparaître exactement dans ces moments-là (leçon 28); et revenir à un énoncé de politique de placement établi d'avance (leçon 43), créé pendant une période plus calme précisément pour ce but.

La compétence de niveau 2 renforcée ici, c'est de reconnaître que le travail comportemental le plus important se fait avant qu'une baisse arrive — dans la planification, l'EPP écrit et l'évaluation honnête de sa tolérance au risque (leçon 26) — plutôt que d'essayer de raisonner calmement pour la première fois en plein milieu d'une vraie baisse stressante.

**3. Exemple pratique**
Quand une importante baisse du marché finit par arriver, Malia ressent la même attirance émotionnelle vers la vente en panique contre laquelle ce niveau l'avait mise en garde. Au lieu de voir ce sentiment comme un signal d'agir, elle le reconnaît comme exactement le modèle comportemental prévisible décrit à la leçon 28. Elle relit l'énoncé de politique de placement qu'elle a écrit auparavant (leçon 43) et se rappelle la tendance historique à la reprise (leçon 36) ainsi que la différence entre la volatilité et la perte permanente (leçon 26). Elle utilise ainsi tout le cadre bâti dans ce niveau pour appuyer sa décision de rester investie selon son plan d'origine.

**4. Quiz de pratique**
1. Quel cadre combiné cette leçon bâtit-elle à partir des leçons précédentes de WHITE-L2?
   a) Un cadre pour maximiser les profits de négociation à court terme
   b) Un cadre pratique, tiré de plusieurs leçons, pour garder sa discipline comportementale pendant les baisses du marché
   c) Un cadre pour éviter complètement tout risque de placement
   d) Un cadre sans lien avec les leçons précédentes
2. Selon cette leçon, quand le travail comportemental le plus important se fait-il vraiment?
   a) Pendant la baisse elle-même, pour la première fois
   b) Avant la baisse, grâce à la planification et à un EPP écrit
   c) Le moment n'a aucune importance pour le travail comportemental
   d) Seulement une fois la baisse complètement terminée
3. Vrai ou faux : L'attirance émotionnelle de Malia vers la vente en panique veut dire que son plan était mauvais et qu'elle devrait l'abandonner.
4. Qu'est-ce qui a aidé Malia à résister à l'envie de vendre en panique pendant la vraie baisse?
   a) Rien ne l'a aidée; elle a agi uniquement par impulsion
   b) Revenir à son EPP établi d'avance et se rappeler les notions comportementales de ce niveau
   c) Elle n'avait jamais ressenti aucune réaction émotionnelle
   d) Elle a vendu tout de suite à cause des manchettes

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Cette leçon rassemble plusieurs leçons précédentes en un seul cadre pratique de discipline comportementale pendant les baisses.
2. Le travail comportemental le plus important se fait d'avance, grâce à la planification et à un EPP écrit pendant des périodes plus calmes.
3. Une attirance émotionnelle vers la vente en panique est un modèle prévisible et bien documenté, pas une preuve que le plan de départ est mauvais.
4. L'EPP établi d'avance par Malia et le rappel des notions comportementales de ce niveau l'ont aidée à résister à l'impulsion de vendre en panique.

**7. Points clés à retenir**
- Cette leçon rassemble la volatilité, les tendances historiques de reprise, les biais comportementaux et l'EPP en un seul cadre pour les baisses.
- Le travail le plus important de discipline comportementale se fait avant une baisse, grâce à une planification réalisée pendant des périodes plus calmes.
- Reconnaître une impulsion de panique comme un modèle prévisible, plutôt que comme un signal d'agir, aide à s'en tenir à un plan établi.
- Ce cadre s'appuie directement sur plusieurs leçons précédentes, ce qui renforce la structure cumulative de ce niveau.
