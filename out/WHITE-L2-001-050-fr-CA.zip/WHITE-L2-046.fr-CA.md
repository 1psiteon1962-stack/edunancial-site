---
id: WHITE-L2-046
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 46
title: "Les éléments successoraux et les bénéficiaires pour les actifs papier"
summary: "Comprends l'importance des désignations de bénéficiaire pour tes comptes de placement et pourquoi une désignation non mise à jour peut l'emporter sur ton testament."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-046
### Les éléments successoraux et les bénéficiaires pour les actifs papier

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Expliquer l'importance générale de la planification successorale pour les comptes d'actifs papier.
- Nommer la désignation de bénéficiaire comme un outil précis lié à ces comptes.
- Reconnaître que c'est un domaine qui exige un encadrement professionnel coordonné et personnalisé.

**2. Contenu principal**
En écho à la discussion sur la planification successorale du parcours RED (RED-L2-040), les comptes d'actifs papier (comptes de courtage, comptes de retraite) demandent eux aussi une attention réfléchie en matière de planification successorale. Un outil souvent discuté et propre à ces comptes est la désignation de bénéficiaire : nommer la personne qui devrait recevoir directement les actifs du compte au décès du titulaire. Dans bien des juridictions et pour bien des types de comptes, ça peut permettre aux actifs d'être transférés assez directement au bénéficiaire nommé, en évitant possiblement un processus d'homologation plus long, selon le type de compte et la juridiction.

Un élément important, parfois oublié : les désignations de bénéficiaire l'emportent généralement sur les instructions écrites dans un testament pour ce compte précis. Une désignation de bénéficiaire désuète (qui nomme un ex-conjoint, par exemple, après un divorce et un remariage) peut donc l'emporter sur les vraies volontés actuelles d'un investisseur exprimées ailleurs, si la désignation elle-même n'a jamais été mise à jour. C'est pourquoi revoir et mettre à jour périodiquement ses désignations de bénéficiaire, surtout après de grands événements de vie, est une pratique importante et parfois sous-estimée.

**3. Exemple pratique**
Des années après un divorce et un remariage, Owen découvre, lors d'une révision financière de routine avec son conseiller, qu'il n'avait jamais mis à jour la désignation de bénéficiaire d'un vieux compte de retraite, qui nommait encore son ex-conjointe. Même s'il avait rédigé un nouveau testament après son remariage pour refléter ses volontés actuelles, Owen apprend que la désignation de bénéficiaire désuète de ce compte précis l'emporterait probablement sur les instructions de son testament pour les actifs de ce compte. Il met immédiatement la désignation à jour, ce qui corrige un écart qui aurait autrement pu s'éloigner beaucoup de ses vraies intentions actuelles.

**4. Quiz de pratique**
1. Qu'est-ce qu'une désignation de bénéficiaire?
   a) Un type d'obligation
   b) Nommer la personne qui devrait recevoir directement les actifs d'un compte au décès du titulaire
   c) Un statut de déclaration fiscale
   d) Des frais de courtage
2. Qu'est-ce qui peut arriver si une désignation de bénéficiaire n'est pas mise à jour après un grand événement de vie?
   a) Rien — les désignations se mettent à jour automatiquement
   b) Elle peut l'emporter sur les instructions d'un testament et s'éloigner beaucoup des vraies volontés actuelles de l'investisseur
   c) Le compte devient gelé pour toujours
   d) Elle n'a aucune importance juridique
3. Vrai ou faux : Les instructions d'un testament l'emportent toujours automatiquement sur une désignation de bénéficiaire désuète pour un compte précis.
4. Quel écart Owen a-t-il découvert lors de sa révision financière?
   a) Son testament n'avait jamais été mis à jour
   b) La désignation de bénéficiaire de son compte de retraite nommait encore son ex-conjointe, malgré son remariage et son nouveau testament
   c) Il n'avait aucun compte de retraite
   d) Sa nouvelle conjointe était déjà correctement nommée

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Une désignation de bénéficiaire nomme la personne qui devrait recevoir directement les actifs d'un compte précis au décès du titulaire.
2. Une désignation désuète peut l'emporter sur les instructions d'un testament et s'éloigner beaucoup des vraies volontés actuelles d'un investisseur.
3. Les désignations de bénéficiaire l'emportent généralement sur les instructions du testament pour ce compte précis, et non l'inverse.
4. Le compte de retraite d'Owen nommait encore son ex-conjointe comme bénéficiaire, malgré son remariage et son testament mis à jour.

**7. Points clés à retenir**
- Les comptes d'actifs papier demandent une attention réfléchie en matière de planification successorale, en écho à la discussion du parcours RED.
- Les désignations de bénéficiaire nomment les personnes qui reçoivent directement les actifs d'un compte, souvent sans passer par un processus d'homologation plus long.
- Les désignations de bénéficiaire l'emportent généralement sur les instructions du testament pour ce compte précis.
- Revoir et mettre à jour périodiquement ses désignations, surtout après de grands événements de vie, est une pratique importante et parfois oubliée.
