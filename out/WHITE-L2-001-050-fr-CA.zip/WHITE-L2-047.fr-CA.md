---
id: WHITE-L2-047
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 47
title: "Les erreurs courantes des nouveaux investisseurs dans les actifs papier"
summary: "Passe en revue les erreurs les plus fréquentes des nouveaux investisseurs en actifs papier, les leçons qui les préviennent et la cause qu'elles ont en commun."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-047
### Les erreurs courantes des nouveaux investisseurs dans les actifs papier

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Nommer plusieurs erreurs courantes des nouveaux investisseurs dans les actifs papier.
- Relier chaque erreur à des leçons précises vues plus tôt dans ce niveau.
- Renforcer la structure cumulative de ce niveau, en écho à la leçon sur les erreurs du parcours RED.

**2. Contenu principal**
En reprenant le format de RED-L2-048, cette leçon passe en revue les erreurs courantes des nouveaux investisseurs propres aux actifs papier, chacune liée à des notions déjà vues. Courir après la performance récente (acheter tout ce qui vient de monter, plutôt que de suivre une stratégie cohérente) vient souvent du fait d'ignorer le cadre des philosophies et des lentilles (leçons 2 à 7) au profit de décisions réactives. Ignorer les frais (leçons 15 et 42) vient souvent du fait de se concentrer seulement sur les rendements annoncés sans tenir compte de l'effet de frein composé des coûts. Vendre en panique pendant les baisses (leçons 28 et 45) vient souvent d'une planification insuffisante à l'avance et du fait de n'avoir jamais évalué honnêtement sa tolérance au risque (leçon 26). Une diversification insuffisante malgré la détention de « beaucoup » d'actions individuelles (leçons 17 et 24) vient souvent du fait de ne pas vérifier la concentration réelle par secteur ou par catégorie d'actifs.

Comme dans le parcours RED, un modèle plus large se cache derrière la plupart de ces erreurs : réagir sur le moment plutôt que de suivre un cadre et un plan établis pendant une période plus calme et plus rationnelle — exactement la discipline que les leçons 43 et 45 visaient à bâtir.

**3. Exemple pratique**
En repensant à ses propres erreurs de débutante, Priyanka (présentée à la leçon 1) reconnaît, des années plus tard, qu'elle a déjà couru après une action en forte hausse uniquement à cause de sa performance récente, sans appliquer le cadre des lentilles des leçons 2 à 7, et qu'elle l'a vendue en panique pendant une baisse qui a suivi, sans avoir jamais évalué d'avance sa vraie tolérance au risque. En reliant ces erreurs précises aux notions vues tout au long de ce niveau, elle reconnaît qu'un cadre cohérent — bâti dès la discussion de la toute première leçon sur la façon de réduire le choix — aurait évité les deux erreurs.

**4. Quiz de pratique**
1. Selon cette leçon, qu'est-ce qui pousse souvent à « courir après la performance récente »?
   a) Une stratégie cohérente et établie
   b) Des décisions réactives prises sans cadre cohérent de lentilles ou de philosophie
   c) Une planification attentive à long terme
   d) Une diversification suffisante
2. Qu'est-ce qui cause souvent une diversification insuffisante, malgré la détention de « beaucoup » d'actions individuelles?
   a) Déjà trop de diversification
   b) Ne pas vérifier la concentration réelle par secteur ou par catégorie d'actifs
   c) Détenir trop peu d'actions au total
   d) Une diversification parfaite par défaut
3. Vrai ou faux : Cette leçon présente des notions entièrement nouvelles, sans lien avec le reste de WHITE-L2.
4. Quel modèle plus large se cache derrière la plupart des erreurs courantes vues dans cette leçon?
   a) Réagir plutôt que de suivre un cadre et un plan établis
   b) Être trop discipliné et prudent
   c) Suivre un énoncé de politique de placement de trop près
   d) Diversifier de façon trop agressive

**5. Corrigé**
1. b  2. b  3. Faux  4. a

**6. Réponses et explications**
1. Courir après la performance récente reflète souvent une prise de décision réactive, sans cadre cohérent de lentilles ou de philosophie.
2. Une diversification insuffisante vient souvent du fait de ne pas vérifier la concentration réelle par secteur ou par catégorie d'actifs, malgré un grand nombre de titres.
3. Cette leçon se rattache volontairement à des notions déjà vues tout au long de WHITE-L2, ce qui renforce la structure du niveau.
4. Réagir plutôt que de suivre un cadre et un plan établis est la cause de la plupart des erreurs vues.

**7. Points clés à retenir**
- Les erreurs courantes en actifs papier comprennent courir après la performance, ignorer les frais, vendre en panique et une diversification insuffisante.
- Chaque erreur se rattache à une notion précise déjà vue plus tôt dans ce niveau.
- Cette leçon fait écho à la leçon sur les erreurs du parcours RED, ce qui renforce une structure cohérente dans tout le programme.
- La plupart des erreurs ont une cause commune : réagir plutôt que de suivre un cadre et un plan établis.
