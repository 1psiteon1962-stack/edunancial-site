---
id: WHITE-L2-048
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 48
title: "Bâtir son cadre de placement personnel"
summary: "Rassemble les questions clés de tout le niveau — horizon, lentille, répartition, comptes, frais et plan écrit — en un cadre de placement personnel pratique."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-048
### Bâtir son cadre de placement personnel

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Rassembler un ensemble structuré de questions tirées de tout ce niveau pour en faire un cadre de placement personnel.
- Appliquer ce cadre à une décision de placement hypothétique.
- Expliquer comment ce cadre incarne la pensée de niveau 2 des « pièces d'échecs ».

**2. Contenu principal**
En écho au cadre de décision de RED-L2-049, cette leçon rassemble WHITE-L2 en un cadre de placement personnel pratique, structuré autour de questions tirées des leçons précédentes : quels sont mon horizon de placement et ma tolérance au risque pour ce montant précis (leçons 26 et 27)? Quelle lentille ou quel mélange de lentilles convient à mes objectifs (leçons 2 à 7)? Quelle répartition de l'actif et quelle approche de diversification conviennent à ce profil (leçons 16 et 17, 24 et 25)? Quels éléments de type de compte et de localisation de l'actif s'appliquent (leçons 29 et 30)? Quel est le portrait complet des frais, au-delà du seul ratio des frais (leçons 15 et 42)? Et est-ce que j'ai un plan écrit (un EPP, leçon 43) auquel revenir pendant les inévitables périodes de stress du marché (leçons 28, 36 et 45)?

Comme pour le cadre du parcours RED, c'est une habitude d'esprit plutôt qu'une liste rigide : le but est de suivre volontairement les effets d'une décision sur l'horizon de placement, la philosophie, la répartition, la fiscalité, les frais et la planification comportementale, tous ensemble, plutôt que d'agir à partir d'un seul chiffre attrayant ou du tuyau d'un ami pris isolément.

**3. Exemple pratique**
En considérant une nouvelle occasion de placement mentionnée par un collègue, Farid passe volontairement à travers ce cadre au lieu d'agir seulement selon l'enthousiasme de son collègue. Il clarifie son propre horizon de placement et sa tolérance au risque pour cet argent précis, se demande à quelle lentille (s'il y en a une) l'occasion correspond, vérifie son effet sur sa répartition globale et sa diversification, réfléchit au type de compte le plus approprié, examine le portrait complet des frais et confirme qu'elle respecte les lignes directrices de son énoncé de politique de placement écrit — avant de décider s'il va de l'avant et comment, plutôt que d'agir seulement par enthousiasme.

**4. Quiz de pratique**
1. Quel est le but du cadre de placement personnel présenté dans cette leçon?
   a) Remplacer tous les conseils professionnels
   b) Offrir une habitude structurée pour suivre les effets d'une décision sur plusieurs pièces de ce niveau
   c) Garantir un résultat rentable
   d) Éliminer le besoin de faire des recherches
2. Lequel des éléments suivants fait partie du cadre?
   a) L'horizon de placement, la correspondance avec une lentille, la répartition, le type de compte, les frais et un plan écrit
   b) Seulement le symbole boursier
   c) Seulement l'opinion d'un ami
   d) Seulement le prix actuel
3. Vrai ou faux : Ce cadre est fait pour être appliqué mécaniquement, sans vraie analyse de l'occasion précise.
4. Qu'a fait Farid avant d'aller de l'avant avec l'occasion suggérée par son collègue?
   a) Il a agi tout de suite, seulement par enthousiasme
   b) Il a passé l'occasion de façon systématique à travers tout son cadre de placement personnel
   c) Il a complètement ignoré sa propre tolérance au risque
   d) Il a sauté la vérification des frais

**5. Corrigé**
1. b  2. a  3. Faux  4. b

**6. Réponses et explications**
1. Ce cadre développe l'habitude de suivre au complet les effets d'une décision de placement sur plusieurs pièces; il ne garantit pas les résultats.
2. Le cadre couvre l'horizon de placement, la correspondance avec une lentille, la répartition, le type de compte, les frais et un plan écrit, tirés de tout ce niveau.
3. Le cadre sert à provoquer une vraie analyse propre à chaque situation, pas à cocher des cases mécaniquement.
4. L'application systématique du cadre par Farid a remplacé le fait d'agir seulement selon l'enthousiasme de son collègue.

**7. Points clés à retenir**
- Cette leçon rassemble WHITE-L2 en un cadre pratique qui couvre l'horizon de placement, la philosophie, la répartition, les comptes, les frais et la planification comportementale.
- Le cadre est une habitude d'esprit, en écho à la structure du cadre du parcours RED.
- L'appliquer de façon systématique aide à éviter d'agir à partir d'un seul détail attrayant ou seulement de l'enthousiasme des autres.
- Ce cadre incarne la pensée complète des « pièces d'échecs » que tout ce niveau a construite.
