---
id: WHITE-L2-049
track: WHITE
officialTrackName: "Paper Assets"
level: 2
lessonNumber: 49
title: "Les liens entre les couleurs : WHITE rencontre GREEN, GOLD et RED"
summary: "Fais le tour des liens entre WHITE et les autres couleurs — fiscalité, création de richesse et immobilier — et vois pourquoi aucune couleur n'existe vraiment seule."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
## WHITE-L2-049
### Les liens entre les couleurs : WHITE rencontre GREEN, GOLD et RED

**1. Objectifs d'apprentissage**
À la fin de cette leçon, tu pourras :
- Résumer les liens entre les couleurs repérés tout au long de WHITE-L2.
- Expliquer comment les actifs papier interagissent avec la fiscalité, la création de richesse plus large et l'immobilier.
- Renforcer la conception volontaire entre les couleurs de ce programme.

**2. Contenu principal**
Cette leçon rassemble les fils qui relient WHITE-L2 aux autres couleurs. WHITE + GREEN : presque chaque leçon qui porte sur les gains en capital (leçon 31), les comptes à avantage fiscal (leçon 29) et la localisation de l'actif (leçon 30) touche des éléments fiscaux, ce qui exige la même discipline d'encadrement professionnel que celle soulignée dans les leçons de RED-L2 proches de GREEN. WHITE + GOLD : les lentilles de philosophie de placement (leçons 2 à 7) et les notions de répartition de l'actif (leçon 16) s'appliquent directement aux décisions plus larges de création de richesse que GOLD-L2 explorera plus en profondeur, y compris la place des actifs papier à côté d'autres véhicules de création de richesse. WHITE + RED : les FPI (leçon 38) offrent un pont structurel direct, et les notions de cycles (leçon 37), d'effet de levier (leçon 34) et de diversification (leçon 17) ont chacune des parallèles directs dans le parcours RED.

Reconnaître ces liens renforce un principe fondamental du niveau 2, établi dans chaque couleur : aucune décision financière, et aucune notion d'une seule couleur, n'existe vraiment seule. Un investisseur complet finit par avoir besoin d'aisance avec ces liens, et pas seulement avec le vocabulaire d'une seule couleur.

**3. Exemple pratique**
En réfléchissant à tout ce qui a été vu dans WHITE-L2, un apprenant fait la carte des liens entre les couleurs qu'il a rencontrés : les éléments fiscaux qui traversent presque chaque leçon (GREEN), les lentilles de philosophie qui orienteront les décisions plus larges de création de richesse à venir (GOLD) et les parallèles structurels et conceptuels directs avec l'immobilier (RED) par les FPI, l'effet de levier, les cycles et la diversification. Cet exercice de cartographie aide l'apprenant à voir WHITE-L2 non pas comme un bloc isolé de 50 leçons, mais comme une partie d'un programme interrelié qu'il continuera de bâtir à travers chaque couleur restante.

**4. Quiz de pratique**
1. Quel lien entre les couleurs touche les gains en capital, les comptes à avantage fiscal et la localisation de l'actif?
   a) WHITE + BLACK
   b) WHITE + GREEN
   c) WHITE + ORANGE
   d) WHITE + PURPLE
2. Selon ce niveau, quel pont structurel relie le plus directement WHITE et RED?
   a) Les cotes des obligations
   b) Les FPI
   c) Les régimes de réinvestissement des dividendes
   d) Les appels de marge
3. Vrai ou faux : Cette leçon suggère que WHITE-L2 existe complètement isolé de toutes les autres couleurs.
4. Quel principe fondamental du niveau 2 cette leçon renforce-t-elle?
   a) Les couleurs devraient être étudiées complètement séparément les unes des autres
   b) Aucune décision financière ni aucune notion d'une seule couleur n'existe vraiment seule
   c) Seules les notions du parcours WHITE comptent pour investir
   d) Les liens entre les couleurs n'ont aucune importance au niveau 2

**5. Corrigé**
1. b  2. b  3. Faux  4. b

**6. Réponses et explications**
1. Les gains en capital, les comptes à avantage fiscal et la localisation de l'actif relient tous WHITE au parcours GREEN (fiscalité).
2. Les FPI offrent le pont structurel le plus direct entre WHITE et RED, en plus des parallèles conceptuels sur l'effet de levier et les cycles.
3. Cette leçon présente explicitement WHITE-L2 comme relié aux autres couleurs, et non isolé.
4. Le principe fondamental renforcé, c'est qu'aucune décision financière ni aucune couleur n'existe vraiment seule.

**7. Points clés à retenir**
- WHITE + GREEN se rejoignent par les gains en capital, les comptes à avantage fiscal et la localisation de l'actif.
- WHITE + GOLD se rejoignent par les notions de philosophie de placement et de répartition, qui alimentent la création de richesse plus large.
- WHITE + RED se rejoignent directement par les FPI, et sur le plan conceptuel par l'effet de levier, les cycles et la diversification.
- Ça renforce le principe du niveau 2 selon lequel les notions d'aucune couleur n'existent vraiment seules.
