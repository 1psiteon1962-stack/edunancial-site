---
id: WHITE-L3-001
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 1
title: "Pourquoi « acheter bas, vendre haut » est plus facile à dire qu'à faire"
summary: "Découvre pourquoi le conseil de placement le plus simple est aussi l'un des plus difficiles à suivre en pratique, et ce qui nous en empêche vraiment."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-001 : Pourquoi « acheter bas, vendre haut » est plus facile à dire qu'à faire

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi « acheter bas, vendre haut » est simple en théorie, mais difficile sur le plan du comportement
- Nommer les obstacles émotionnels et informationnels qui vont à l'encontre de ce conseil
- Expliquer pourquoi le « bas » et le « haut » ne sont clairs qu'après coup

## Contenu principal

Presque tout le monde a déjà entendu le conseil « acheter bas, vendre haut ». C'est vrai — et c'est presque inutile à lui seul, parce qu'il suppose que tu peux reconnaître le « bas » et le « haut » pendant que tu les vis, et pas seulement en regardant un graphique après coup.

Voici le « pourquoi » de cette difficulté : une baisse de prix qui ressemble à un « bas » après coup ne donne habituellement pas l'impression d'être une occasion pendant qu'elle se produit — elle ressemble plutôt à de l'incertitude, à de mauvaises nouvelles et à une vraie douleur financière. [VERIFIED FACT] Historiquement, les marchés baissent fortement pendant les périodes de stress ou d'incertitude économique importants, soit exactement au moment où acheter peut sembler le plus difficile, même si ces périodes ont souvent précédé une reprise. De la même façon, un prix qui ressemble à un « haut » après coup donne souvent, sur le moment, l'impression d'un élan impossible à arrêter — tout le monde semble faire de l'argent, et vendre donne l'impression de laisser des gains sur la table.

C'est pourquoi il vaut mieux voir « acheter bas, vendre haut » comme la description d'un résultat souhaité que comme un conseil applicable à lui seul. Les leçons suivantes de ce parcours examinent des outils, des notions et des comportements précis qui permettent plus facilement d'agir rationnellement quand tes instincts te poussent dans l'autre direction.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Pendant une forte baisse du marché, une investisseuse voit la valeur de son portefeuille diminuer considérablement. Après coup, cette période s'est révélée une excellente occasion d'achat à long terme. Mais pendant qu'elle la vivait, elle lisait des manchettes décourageantes, voyait le solde de son compte baisser chaque jour et ressentait une vraie anxiété face à d'autres pertes possibles — exactement le contraire d'une impression confortable du genre « c'est clairement le bas ». [ASSUMPTION] Les investisseurs qui ont acheté malgré ce malaise, au lieu d'attendre la confirmation que le creux était passé, ont historiquement profité d'une plus grande part de la reprise — mais il fallait pour ça agir à l'encontre de ce qu'on ressentait vraiment sur le moment.

## Quiz de pratique

1. Pourquoi « acheter bas, vendre haut » est-il plus facile à dire qu'à faire?
2. Pourquoi une vraie occasion d'achat peut-elle sembler inconfortable plutôt qu'évidente pendant qu'elle se produit?
3. Pourquoi une période de fort élan peut-elle sembler un mauvais moment pour vendre, même si elle se révèle plus tard avoir été un sommet?

## Corrigé

1. Parce que le « bas » et le « haut » ne se reconnaissent clairement qu'après coup — sur le moment, les prix bas s'accompagnent habituellement d'incertitude et de mauvaises nouvelles, et les prix élevés, d'un élan apparent.
2. Parce qu'elle coïncide habituellement avec des manchettes négatives, des comptes qui perdent de la valeur et une vraie incertitude quant à la possibilité que les prix baissent encore.
3. Parce qu'un fort élan peut donner l'impression que d'autres gains sont probables, ce qui rend émotionnellement difficile de vendre pendant une force apparente.

## Réponses et explications

1. C'est le paradoxe central que présente la leçon.
2. Ça explique l'expérience émotionnelle précise qui rend le « bas » difficile à reconnaître en temps réel.
3. Ça reflète la réponse précédente dans le sens inverse, du côté « haut » du conseil.

## Points clés à retenir
- « Acheter bas, vendre haut » décrit un résultat souhaité, et non une stratégie applicable à elle seule.
- Les vrais creux semblent souvent incertains et inconfortables pendant qu'ils se produisent, et non comme des occasions évidentes.
- Les vrais sommets ressemblent souvent à un fort élan, ce qui rend la vente difficile.
- La suite de ce parcours présente des outils et des notions précis qui rendent ce conseil plus facile à appliquer.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Le rendement passé ne garantit pas les résultats futurs. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
