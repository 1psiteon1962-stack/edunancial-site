---
id: WHITE-L3-002
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 2
title: "Pourquoi la diversification réduit le risque sans réduire le rendement attendu (autant qu'on le pense)"
summary: "Découvre pourquoi répartir tes placements sur de nombreux titres réduit le risque plus efficacement qu'il ne réduit le rendement attendu, et pourquoi cet avantage a une limite."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-002 : Pourquoi la diversification réduit le risque sans réduire le rendement attendu (autant qu'on le pense)

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi la diversification réduit le risque sans réduire proportionnellement le rendement attendu
- Distinguer le risque propre à une entreprise du risque qui touche l'ensemble du marché
- Expliquer pourquoi les avantages de la diversification diminuent au-delà d'un certain point

## Contenu principal

On pourrait croire que répartir ton argent sur de nombreux placements au lieu de le concentrer dans un seul répartirait — et réduirait — aussi ton rendement attendu. Ce n'est pas tout à fait comme ça que ça fonctionne, et comprendre pourquoi est au cœur de cette leçon.

Le risque d'une action individuelle vient de deux sources : le risque propre à cette entreprise (de mauvais résultats financiers, le rappel d'un produit, une poursuite) et le risque qui touche l'ensemble du marché (une récession, des variations générales des taux d'intérêt). La diversification — détenir de nombreuses actions différentes au lieu d'une seule — annule une grande partie du risque propre aux entreprises, parce qu'une mauvaise nouvelle dans une entreprise a peu de chances de toucher tous tes titres en même temps. Elle fait toutefois très peu pour annuler le risque de marché, puisque celui-ci touche presque tout en même temps.

Voici « pourquoi » ça ne réduit pas proportionnellement le rendement attendu : tu ne dilues pas tes meilleures idées avec des moins bonnes d'une façon qui réduirait forcément ton résultat moyen attendu — tu élimines le risque précis, non rémunéré, de la malchance d'une seule entreprise, tout en gardant ton exposition attendue au rendement global du marché. [VERIFIED FACT] Cet avantage a des rendements décroissants — l'effet de réduction du risque obtenu en ajoutant d'autres titres diminue nettement une fois qu'un portefeuille compte un nombre modéré d'entreprises différentes, puisque la plupart du risque restant à ce stade est le risque de marché, que la diversification ne peut pas éliminer.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse qui ne détient les actions que d'une seule entreprise est exposée au risque propre à cette entreprise — un scandale, un produit raté ou une poursuite pourrait nuire fortement à son portefeuille même si le marché dans son ensemble se porte bien. Une investisseuse qui détient des actions de 30 entreprises différentes dans des secteurs différents est beaucoup moins exposée aux mauvaises nouvelles d'une seule entreprise; un problème chez un des titres freine un peu le portefeuille total au lieu de causer une perte importante. [ASSUMPTION] Passer de 30 à 300 titres ajoute habituellement beaucoup moins de réduction du risque que de passer de 1 à 30 titres — la plus grande partie de la réduction possible du risque propre aux entreprises a déjà été obtenue.

## Quiz de pratique

1. Quelles sont les deux sources de risque d'une action individuelle décrites dans cette leçon?
2. Pourquoi la diversification ne réduit-elle pas le rendement attendu dans la même proportion qu'elle réduit le risque?
3. Pourquoi ajouter de plus en plus de titres finit-il par produire des avantages décroissants en matière de réduction du risque?

## Corrigé

1. Le risque propre à l'entreprise (particulier à une seule entreprise) et le risque de marché (qui touche presque tout en même temps).
2. Parce que la diversification élimine surtout le risque propre aux entreprises, qui n'est pas rémunéré, plutôt que de diluer l'exposition globale attendue au rendement du marché.
3. Parce que la plus grande partie du risque propre aux entreprises est déjà réduite après un nombre modéré de titres, et que le risque restant est surtout un risque de marché, que la diversification entre actions individuelles ne peut pas éliminer.

## Réponses et explications

1. Cette distinction est la base sur laquelle repose toute la leçon.
2. C'est le « pourquoi » central de la leçon, souvent mal compris.
3. Ça explique la tendance aux rendements décroissants et annonce pourquoi la diversification entre catégories d'actifs (une leçon plus loin) compte pour le risque de marché que la diversification entre actions individuelles ne peut pas toucher.

## Points clés à retenir
- La diversification réduit surtout le risque propre aux entreprises, et non le risque de marché.
- C'est pourquoi elle peut réduire le risque sans réduire proportionnellement le rendement attendu — elle élimine surtout un risque non rémunéré, et non le potentiel de hausse.
- L'avantage de réduction du risque obtenu en ajoutant d'autres titres diminue nettement après un nombre modéré d'entreprises différentes.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
