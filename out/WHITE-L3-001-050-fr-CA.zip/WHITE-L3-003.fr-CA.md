---
id: WHITE-L3-003
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 3
title: "Pourquoi c'est la corrélation qui détermine la vraie diversification, et pas seulement le nombre de titres"
summary: "Découvre pourquoi détenir de nombreux placements n'équivaut pas à être vraiment diversifié, et pourquoi la corrélation est la notion qui détermine réellement ta réduction du risque."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-003 : Pourquoi c'est la corrélation qui détermine la vraie diversification, et pas seulement le nombre de titres

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Définir la corrélation dans le contexte des rendements de placement
- Expliquer pourquoi détenir de nombreux titres qui évoluent ensemble n'est pas une vraie diversification
- Expliquer pourquoi une corrélation faible ou négative entre des actifs procure de plus grands avantages de diversification

## Contenu principal

La leçon 2 a établi que la diversification réduit le risque propre aux entreprises. Cette leçon ajoute une précision importante : il ne suffit pas de détenir de nombreux titres différents — ce qui compte, c'est la façon dont ces titres évoluent les uns par rapport aux autres, une notion appelée **corrélation**.

La corrélation mesure à quel point deux placements ont tendance à évoluer ensemble. Des actifs fortement corrélés ont tendance à monter et à baisser en même temps, pour des raisons semblables. Des actifs faiblement ou négativement corrélés ont tendance à réagir différemment aux mêmes événements — l'un peut rester stable ou même monter pendant que l'autre baisse.

Voici « pourquoi » ça compte plus que le simple nombre de titres : [ILLUSTRATIVE EXAMPLE] un investisseur qui détient 50 actions technologiques différentes est diversifié en nombre sur de nombreuses entreprises, mais si ces 50 titres sont fortement corrélés — et donc susceptibles de baisser ensemble pendant un repli général du secteur technologique —, l'avantage réel de la diversification est bien plus petit que ce que le chiffre « 50 » laisse croire. Une vraie réduction du risque vient du fait de combiner des actifs qui ne réagissent pas tous de la même façon aux mêmes événements.

[VERIFIED FACT] La corrélation entre des actifs n'est pas fixe pour toujours — elle peut changer avec le temps et, fait notable, elle a tendance à augmenter pendant les périodes de forte tension sur les marchés, quand des actifs qui évoluent normalement de façon assez indépendante peuvent commencer à baisser ensemble, ce qui réduit l'effet protecteur de la diversification exactement au moment où on en a le plus besoin.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un investisseur bâtit un portefeuille de 40 actions, toutes dans le même secteur et la même région géographique. Malgré le grand nombre de titres, elles ont tendance à réagir de façon semblable aux variations des taux d'intérêt, aux nouvelles réglementaires et aux changements économiques plus larges qui touchent ce secteur — ce qui veut dire que le portefeuille se comporte davantage comme un pari concentré que comme un portefeuille diversifié. Un deuxième investisseur détient seulement 15 actions, mais réparties entre des secteurs, des régions et des types d'actifs différents, historiquement moins corrélés entre eux. [ASSUMPTION] Même s'il détient moins de titres au total, le portefeuille du deuxième investisseur pourrait connaître un rendement plus régulier et plus vraiment diversifié pendant un repli propre à un secteur que le portefeuille plus gros, mais fortement corrélé, du premier investisseur.

## Quiz de pratique

1. Que mesure la corrélation entre deux placements?
2. Pourquoi un portefeuille qui compte de nombreux titres peut-il quand même manquer de vraie diversification?
3. Pourquoi les avantages de la diversification peuvent-ils s'affaiblir précisément pendant les périodes de forte tension sur les marchés?

## Corrigé

1. Le degré auquel les rendements de deux placements ont tendance à évoluer ensemble.
2. Si ces titres sont fortement corrélés — susceptibles de réagir de façon semblable aux mêmes événements —, le portefeuille se comporte davantage comme un pari concentré que comme un portefeuille vraiment diversifié, peu importe le nombre de titres.
3. Parce que la corrélation entre les actifs a tendance à augmenter pendant les périodes de forte tension sur les marchés, ce qui veut dire que des actifs auparavant moins corrélés peuvent commencer à évoluer ensemble, réduisant l'effet protecteur au moment précis où on en a le plus besoin.

## Réponses et explications

1. C'est la définition de base nécessaire pour le reste de la leçon.
2. Ça prolonge et précise directement la notion de diversification de la leçon 2.
3. C'est une mise en garde importante et honnête sur les limites de la diversification pendant une crise.

## Points clés à retenir
- Une vraie diversification dépend de la corrélation entre les titres, et pas seulement du nombre total de titres.
- De nombreux titres fortement corrélés réduisent beaucoup moins le risque que leur nombre seul le laisse croire.
- La corrélation peut changer avec le temps et augmente souvent pendant les périodes de forte tension sur les marchés, ce qui affaiblit l'effet protecteur de la diversification exactement quand il compte le plus.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
