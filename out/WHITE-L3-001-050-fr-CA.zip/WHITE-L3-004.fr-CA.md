---
id: WHITE-L3-004
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 4
title: "Pourquoi la volatilité et le risque ne sont pas tout à fait la même chose"
summary: "Découvre pourquoi un graphique de prix en dents de scie n'équivaut pas automatiquement à un vrai risque financier, et pourquoi cette différence compte dans ta façon d'évaluer un placement."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-004 : Pourquoi la volatilité et le risque ne sont pas tout à fait la même chose

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Distinguer la volatilité (les fluctuations de prix) du risque (la possibilité d'une perte permanente)
- Expliquer pourquoi un placement volatil n'est pas automatiquement un placement risqué
- Expliquer pourquoi un placement peu volatil peut quand même comporter un risque important

## Contenu principal

Dans le langage courant du placement, on emploie souvent « volatilité » et « risque » comme des synonymes. Ça vaut la peine de bien les distinguer. La **volatilité** décrit l'ampleur et la fréquence des hausses et des baisses d'un prix — c'est une caractéristique statistique et mesurable de l'historique des prix. Le **risque**, au sens qui compte le plus pour un investisseur, est la possibilité d'une vraie perte permanente de capital ou de ne pas atteindre tes objectifs financiers.

Voici « pourquoi » ce n'est pas la même chose : une action peut être très volatile — monter et descendre de façon importante — tout en étant en bonne voie de procurer de solides rendements à long terme, pourvu que l'entreprise sous-jacente reste saine et que tu n'aies pas besoin de vendre pendant une baisse. À l'inverse, un placement peut sembler calme et peu volatil en surface tout en comportant un vrai risque de perte permanente — par exemple, une obligation d'un émetteur en difficulté financière qui se négocie à un prix stable jusqu'au moment où il fait réellement défaut.

[VERIFIED FACT] Cette distinction compte surtout pour la façon dont un investisseur devrait réagir aux mouvements de prix : la volatilité seule, sans changement des données fondamentales sous-jacentes ou de ton propre horizon de placement, n'est pas forcément un signal de vente — mais un vrai changement du risque de perte permanente d'un placement est un signal beaucoup plus sérieux, qui justifie d'agir.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] L'action A monte et descend fortement d'un mois à l'autre, mais appartient à une entreprise financièrement solide et en croissance; un investisseur qui la garde à long terme, sans se laisser déranger par les fluctuations à court terme, pourrait obtenir de solides rendements avec le temps, malgré un parcours mouvementé. L'action B se négocie dans une fourchette de prix étroite et stable pendant des mois, ce qui donne une impression de sécurité — mais l'entreprise sous-jacente accumule discrètement une dette insoutenable. [ASSUMPTION] Quand ce problème d'endettement devient finalement public, le prix « stable » de l'action B pourrait chuter fortement et de façon permanente — la faible volatilité qui a précédé masquait un vrai risque grandissant plutôt que de refléter une vraie sécurité.

## Quiz de pratique

1. Quelle est la principale différence entre la volatilité et le risque, selon les définitions de cette leçon?
2. Pourquoi un placement très volatil n'est-il pas forcément « risqué » au sens qui compte le plus?
3. Pourquoi un placement peu volatil peut-il quand même comporter un risque caché important?

## Corrigé

1. La volatilité mesure l'ampleur des fluctuations d'un prix; le risque désigne la possibilité d'une vraie perte permanente de capital ou de ne pas atteindre ses objectifs financiers.
2. Parce que les fluctuations de prix à court terme ne reflètent pas forcément un changement de la solidité de l'entreprise sous-jacente ni de ta capacité à les traverser sans devoir vendre.
3. Parce qu'un prix stable ne garantit pas que les données fondamentales sous-jacentes sont saines — des problèmes peuvent s'accumuler discrètement avant de finir par causer une baisse de prix forte et permanente.

## Réponses et explications

1. C'est la distinction de base autour de laquelle la leçon est construite.
2. Ça corrige la supposition courante selon laquelle toute volatilité équivaut à un danger.
3. Ça corrige la supposition tout aussi courante selon laquelle la stabilité des prix équivaut à la sécurité.

## Points clés à retenir
- La volatilité mesure les fluctuations de prix; le risque désigne la possibilité d'une perte permanente ou de ne pas atteindre ses objectifs financiers.
- Un placement volatil n'est pas automatiquement risqué si les données fondamentales sous-jacentes restent saines et que tu peux traverser les fluctuations.
- Un placement qui semble stable peut quand même comporter un vrai risque caché si des problèmes sous-jacents ne se reflètent pas encore dans le prix.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
