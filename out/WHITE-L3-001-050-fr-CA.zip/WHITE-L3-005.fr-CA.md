---
id: WHITE-L3-005
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 5
title: "Pourquoi les options te donnent des droits, et non des obligations — et pourquoi ça a un coût"
summary: "Découvre la structure de base des contrats d'options, pourquoi acheter une option te donne seulement un droit, et pourquoi ce droit n'est pas gratuit."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-005 : Pourquoi les options te donnent des droits, et non des obligations — et pourquoi ça a un coût

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Définir une option d'achat et une option de vente
- Expliquer pourquoi acheter une option donne un droit, et non une obligation
- Expliquer pourquoi ce droit exige le paiement d'une prime

## Contenu principal

Une **option** est un contrat qui donne à l'acheteur le droit, mais non l'obligation, d'acheter ou de vendre un actif sous-jacent (comme une action) à un prix précis (le prix d'exercice) au plus tard à une date précise (la date d'échéance). Une **option d'achat** (*call*) donne le droit d'acheter au prix d'exercice; une **option de vente** (*put*) donne le droit de vendre au prix d'exercice.

Voici « pourquoi » c'est différent de simplement détenir l'action : comme tu n'es obligé d'agir que si c'est à ton avantage, la perte possible de l'acheteur d'une option se limite à ce qu'il a payé pour le contrat — appelé la **prime** —, alors que le gain possible peut être important si l'actif sous-jacent évolue favorablement. Cette asymétrie (une perte limitée, un gain possible plus grand) est exactement ce pour quoi l'acheteur paie.

[VERIFIED FACT] Le vendeur (ou « émetteur ») d'une option se trouve de l'autre côté de cette transaction : il prend l'obligation de respecter le contrat si l'acheteur choisit d'exercer son droit — c'est pourquoi la vente d'options comporte un profil de risque fondamentalement différent, abordé dans une leçon plus loin. La prime n'est pas arbitraire; elle reflète le prix actuel de l'actif sous-jacent, le prix d'exercice, le temps qui reste avant l'échéance et la volatilité attendue de l'actif.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse achète une option d'achat sur une action qui se négocie actuellement à 50 $, avec un prix d'exercice de 55 $, en payant une prime de 2 $ par action. Si l'action monte à 65 $ avant l'échéance, elle peut exercer son droit d'acheter à 55 $ — bien en dessous du prix du marché — pour un profit appréciable, moins la prime de 2 $ payée. Si l'action reste sous 55 $ ou baisse, elle laisse simplement l'option expirer, et sa perte totale se limite à la prime de 2 $ qu'elle a payée — elle n'a jamais été obligée d'acheter à 55 $ si ça n'avait pas de sens.

## Quiz de pratique

1. Quelle est la principale différence entre détenir une option et être obligé d'y donner suite?
2. Qu'est-ce qu'une option d'achat donne le droit de faire à l'acheteur?
3. Pourquoi la perte possible de l'acheteur d'une option reste-t-elle limitée à la prime payée, même si l'actif sous-jacent évolue fortement contre lui?

## Corrigé

1. Détenir (acheter) une option donne un droit, et non une obligation — l'acheteur peut choisir de l'exercer ou non, contrairement à la détention directe de l'action, qui ne comporte aucun choix quant à l'« activation » de la position.
2. Le droit d'acheter l'actif sous-jacent au prix d'exercice au plus tard à la date d'échéance.
3. Parce que l'acheteur n'est pas obligé d'exercer l'option — si elle est défavorable, il la laisse simplement expirer et ne perd que la prime déjà payée, sans plus.

## Réponses et explications

1. C'est la distinction de base qui sous-tend toutes les autres leçons sur les options de ce parcours.
2. C'est la définition précise d'une option d'achat, par opposition à une option de vente.
3. Ça explique la raison mécanique de l'asymétrie de perte limitée décrite dans le contenu principal.

## Points clés à retenir
- Une option donne à l'acheteur le droit, et non l'obligation, d'acheter (option d'achat) ou de vendre (option de vente) un actif à un prix fixé avant l'échéance.
- Comme l'exercice est facultatif, la perte possible de l'acheteur se limite à la prime payée, alors que le gain possible peut être plus grand.
- Le vendeur de l'option assume le côté obligation du contrat, ce qui comporte un profil de risque différent abordé dans une leçon plus loin.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. La négociation d'options comporte des risques importants et ne convient pas à tous les investisseurs. Consulte un professionnel de la finance autorisé avant de négocier des options.
