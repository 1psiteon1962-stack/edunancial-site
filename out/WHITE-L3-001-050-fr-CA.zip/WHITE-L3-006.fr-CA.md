---
id: WHITE-L3-006
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 6
title: "Pourquoi une option d'achat parie sur la direction et un straddle parie sur le mouvement"
summary: "Découvre la différence entre un pari directionnel avec des options et un straddle, qui profite d'un grand mouvement dans un sens ou dans l'autre."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-006 : Pourquoi une option d'achat parie sur la direction et un straddle parie sur le mouvement

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce qu'est une stratégie de straddle
- Distinguer un pari sur la direction d'un pari sur le mouvement ou la volatilité
- Reconnaître une situation où un straddle conviendrait mieux qu'une simple option d'achat ou de vente

## Contenu principal

La leçon 5 a présenté les options d'achat et de vente comme des paris directionnels : une option d'achat est profitable si l'actif sous-jacent monte, une option de vente est profitable s'il baisse. Mais que faire si tu es convaincu qu'un événement important va se produire — des résultats financiers, une annonce majeure — tout en étant vraiment incertain de la direction que prendra le prix?

Un **straddle** combine l'achat d'une option d'achat et d'une option de vente sur le même actif sous-jacent, au même prix d'exercice et à la même échéance. Voici « pourquoi » ça change la nature du pari : au lieu de parier sur la direction, un straddle parie sur **l'ampleur du mouvement** — il est profitable si l'actif sous-jacent évolue fortement dans un sens ou dans l'autre, assez pour couvrir le coût combiné des deux primes, et il perd de la valeur si le prix reste relativement stable, puisque les deux options expireraient alors avec peu de valeur.

[VERIFIED FACT] Comme un straddle consiste à acheter deux options au lieu d'une, il coûte plus cher au départ qu'une seule option d'achat ou de vente — ce qui veut dire que l'actif sous-jacent doit évoluer davantage, dans un sens ou dans l'autre, simplement pour atteindre le seuil de rentabilité de la position combinée.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse s'attend à ce que l'annonce prochaine des résultats d'une entreprise provoque une forte variation de prix, mais n'a aucune opinion ferme quant à savoir si la nouvelle sera bonne ou mauvaise. Au lieu d'acheter seulement une option d'achat (parier sur une hausse) ou seulement une option de vente (parier sur une baisse), elle achète un straddle — une option d'achat et une option de vente au même prix d'exercice. [ASSUMPTION] Si l'action bondit fortement après les résultats, l'option d'achat gagne assez de valeur pour plus que compenser la perte de l'option de vente et la prime totale payée, ce qui donne un profit. Si l'action chute plutôt fortement, l'option de vente joue le même rôle en sens inverse. Mais si l'action bouge à peine dans un sens ou dans l'autre, les deux options pourraient expirer en valant peu, et elle perdrait la plus grande partie, sinon la totalité, de la prime combinée payée.

## Quiz de pratique

1. Sur le plan de la structure, que combine un straddle?
2. En quoi parier sur le « mouvement » est-il différent de parier sur la « direction »?
3. Pourquoi un straddle a-t-il besoin d'un plus grand mouvement de prix pour devenir profitable qu'une seule option d'achat ou de vente?

## Corrigé

1. L'achat d'une option d'achat et d'une option de vente sur le même actif sous-jacent, au même prix d'exercice et à la même échéance.
2. Parier sur la direction veut dire être profitable seulement si le prix évolue dans un sens précis (à la hausse pour une option d'achat, à la baisse pour une option de vente); parier sur le mouvement veut dire profiter d'un grand mouvement dans un sens ou dans l'autre, peu importe lequel.
3. Parce que le coût combiné de l'achat de deux options (l'option d'achat et l'option de vente) est plus élevé que celui d'une seule, de sorte que le prix doit évoluer davantage pour couvrir cette prime totale plus importante avant que la position devienne profitable.

## Réponses et explications

1. C'est la définition structurelle nécessaire pour comprendre le reste de la leçon.
2. C'est la distinction conceptuelle centrale autour de laquelle la leçon est construite.
3. Ça renforce le compromis de coût lié au fait de combiner deux positions au lieu d'une.

## Points clés à retenir
- Un straddle combine une option d'achat et une option de vente au même prix d'exercice et à la même échéance, en pariant sur le mouvement plutôt que sur la direction.
- Il profite d'un grand mouvement de prix dans un sens ou dans l'autre et perd de la valeur si le prix reste relativement stable.
- Comme il coûte plus cher qu'une seule option, il exige un plus grand mouvement pour devenir profitable.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. La négociation d'options comporte des risques importants et ne convient pas à tous les investisseurs. Consulte un professionnel de la finance autorisé avant de négocier des options.
