---
id: WHITE-L3-007
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 7
title: "Pourquoi l'érosion du temps joue contre les acheteurs d'options"
summary: "Découvre pourquoi une option perd de la valeur simplement avec le passage du temps, même si le prix de l'actif sous-jacent ne change pas."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-007 : Pourquoi l'érosion du temps joue contre les acheteurs d'options

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce qu'est l'érosion du temps et pourquoi elle touche précisément les options
- Expliquer pourquoi l'érosion du temps s'accélère à l'approche de l'échéance
- Expliquer pourquoi l'érosion du temps joue contre les acheteurs d'options et en faveur des vendeurs d'options

## Contenu principal

La valeur d'une option a deux composantes : la valeur intrinsèque (à quel point le prix d'exercice est déjà avantageux par rapport au prix actuel du marché) et la valeur temps (la valeur supplémentaire qui reflète la possibilité que l'option devienne plus profitable avant l'échéance). À l'approche de l'échéance, cette composante de valeur temps diminue — un processus appelé **érosion du temps**.

Voici « pourquoi » ça se produit : moins il reste de temps, moins le prix de l'actif sous-jacent a d'occasions d'évoluer favorablement avant l'échéance de l'option. Une option qui a six mois avant l'échéance a beaucoup plus de temps pour devenir potentiellement profitable qu'une option identique à qui il reste une semaine — elle vaut donc plus, toutes choses égales par ailleurs, uniquement grâce à ce temps supplémentaire.

[VERIFIED FACT] L'érosion du temps n'est pas linéaire — elle s'accélère habituellement à l'approche de l'échéance, ce qui veut dire qu'une option peut perdre une grande partie de sa valeur temps restante dans ses dernières semaines ou ses derniers jours, même si le prix de l'actif sous-jacent n'a pas bougé du tout. C'est pourquoi les acheteurs d'options travaillent contre une horloge qui rétrécit constamment, alors que les vendeurs d'options (abordés dans la prochaine leçon) profitent généralement de ce même passage du temps.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un investisseur achète une option d'achat qui a trois mois avant l'échéance. Le prix de l'action sous-jacente reste parfaitement stable pendant les deux premiers mois. Même sans aucun mouvement de prix, la valeur de l'option a quand même diminué de façon appréciable pendant ces deux mois, uniquement à cause de l'érosion du temps — il reste simplement moins de temps pour que l'action fasse le mouvement qui rendrait l'option profitable. [ASSUMPTION] Pendant le dernier mois, à l'approche de l'échéance, cette érosion de la valeur temps s'accélère encore, de sorte que même un petit retard supplémentaire dans le mouvement de l'action peut nuire de façon appréciable à la valeur restante de l'option.

## Quiz de pratique

1. Quelles sont les deux composantes de la valeur d'une option?
2. Pourquoi la valeur temps d'une option diminue-t-elle à l'approche de l'échéance, même si le prix sous-jacent ne bouge pas?
3. Pourquoi l'érosion du temps s'accélère-t-elle au lieu de progresser à un rythme régulier et constant?

## Corrigé

1. La valeur intrinsèque (à quel point le prix d'exercice est avantageux par rapport au prix actuel du marché) et la valeur temps (qui reflète l'occasion restante d'un mouvement favorable avant l'échéance).
2. Parce que moins il reste de temps, moins le prix sous-jacent a d'occasions d'évoluer favorablement, ce qui réduit la valeur de l'option même sans aucun changement de prix.
3. Parce qu'à l'approche de l'échéance, il reste proportionnellement beaucoup moins de temps pour qu'un mouvement favorable se produise, ce qui fait s'éroder la valeur temps restante plus rapidement dans le dernier droit qu'au début de la vie de l'option.

## Réponses et explications

1. Ça établit la structure de valeur en deux parties sur laquelle repose le reste de la leçon.
2. C'est le mécanisme central de l'érosion du temps.
3. Ça ajoute la nuance importante de l'accélération, qui prépare la dynamique favorable aux vendeurs abordée dans la prochaine leçon.

## Points clés à retenir
- La valeur d'une option combine la valeur intrinsèque et la valeur temps; la valeur temps diminue à l'approche de l'échéance.
- Cette « érosion du temps » se produit même sans aucun mouvement du prix de l'actif sous-jacent.
- L'érosion du temps s'accélère à l'approche de l'échéance, ce qui joue contre les acheteurs d'options et en faveur des vendeurs d'options.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. La négociation d'options comporte des risques importants et ne convient pas à tous les investisseurs. Consulte un professionnel de la finance autorisé avant de négocier des options.
