---
id: WHITE-L3-008
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 8
title: "Pourquoi vendre des options inverse complètement le profil de risque"
summary: "Découvre pourquoi vendre (émettre) une option te place du côté de l'obligation du contrat, avec un profil de risque très différent de celui de l'achat."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-008 : Pourquoi vendre des options inverse complètement le profil de risque

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi vendre une option crée une obligation plutôt qu'un droit
- Expliquer pourquoi le gain maximal du vendeur d'une option est plafonné alors que son risque peut être beaucoup plus grand
- Distinguer une position d'option couverte d'une position non couverte (« à découvert »)

## Contenu principal

La leçon 5 a établi qu'acheter une option donne un droit, avec une perte limitée (la prime) et un gain possible plus grand. Vendre — ou « émettre » — une option inverse complètement cette structure : le vendeur encaisse la prime au départ, mais prend l'**obligation** de respecter le contrat si l'acheteur choisit de l'exercer.

Voici « pourquoi » ça inverse le profil de risque : le gain maximal du vendeur est plafonné à la prime encaissée — c'est le maximum qu'il peut gagner sur la position. Mais sa perte possible, surtout pour un vendeur qui ne détient pas déjà l'actif sous-jacent (une position « à découvert » ou non couverte), peut être beaucoup plus grande, puisque le prix sous-jacent peut évoluer fortement contre lui et qu'il reste obligé de respecter le contrat.

[VERIFIED FACT] Une **option d'achat couverte** — vendre une option d'achat sur une action que le vendeur détient déjà — limite le risque pratique de cette position précise, puisque si l'acheteur exerce l'option, le vendeur livre simplement des actions qu'il détient déjà, au lieu de devoir les acheter à un prix du marché potentiellement beaucoup plus élevé. Vendre des options sans détenir déjà l'actif sous-jacent (la vente « à découvert ») comporte un risque nettement plus grand et est généralement considéré comme une stratégie avancée.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse vend une option d'achat couverte sur une action qu'elle détient déjà, qui se négocie actuellement à 50 $, avec un prix d'exercice de 55 $, et encaisse une prime de 2 $. Si l'action reste sous 55 $, l'option expire sans valeur, et elle garde la prime de 2 $ comme profit net, tout en conservant ses actions. Si l'action monte à 70 $, l'acheteur exerce l'option, et elle est obligée de vendre ses actions à 55 $ — elle rate le gain supplémentaire au-delà de 55 $, mais son risque était limité puisqu'elle détenait déjà les actions vendues. Compare avec un vendeur d'option d'achat à découvert qui ne détient aucune action : à 70 $, il serait obligé d'acheter des actions au prix actuel du marché simplement pour les livrer à 55 $, une perte potentiellement importante, sans plafond en principe.

## Quiz de pratique

1. En quoi le profil de risque de la vente d'une option diffère-t-il de celui de l'achat?
2. Qu'est-ce qu'une option d'achat couverte, et pourquoi limite-t-elle le risque pratique par rapport à une option d'achat à découvert?
3. Quel est le gain maximal possible pour le vendeur d'une option?

## Corrigé

1. Vendre une option crée l'obligation de respecter le contrat s'il est exercé, avec un gain maximal plafonné (la prime), mais un risque potentiellement beaucoup plus grand — l'inverse de la perte limitée et du gain possible plus grand de l'acheteur.
2. Une option d'achat couverte consiste à vendre une option d'achat sur des actions que le vendeur détient déjà; elle limite le risque parce que, si l'option est exercée, le vendeur livre des actions qu'il détient déjà au lieu de devoir les acheter à un prix du marché potentiellement beaucoup plus élevé.
3. La prime encaissée au moment de la vente de l'option — c'est le profit maximal possible sur la position, peu importe à quel point l'actif sous-jacent évolue favorablement pour le vendeur.

## Réponses et explications

1. C'est la notion centrale d'inversion du profil de risque autour de laquelle la leçon est construite.
2. Ça distingue les deux façons de vendre et explique pourquoi le fait d'être « couvert » réduit précisément le risque pratique.
3. Ça renforce le côté gain plafonné du profil de risque asymétrique du vendeur.

## Points clés à retenir
- Vendre une option crée une obligation, et non un droit, avec un gain maximal plafonné (la prime) et un risque potentiellement beaucoup plus grand.
- Une option d'achat couverte, vendue sur des actions déjà détenues, limite le risque pratique par rapport à une option à découvert (non couverte).
- La vente d'options à découvert comporte un risque nettement plus grand et est généralement considérée comme une stratégie avancée.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. La négociation d'options comporte des risques importants et ne convient pas à tous les investisseurs. Consulte un professionnel de la finance autorisé avant de négocier des options.
