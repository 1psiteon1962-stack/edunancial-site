---
id: WHITE-L3-009
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 9
title: "Pourquoi l'achat sur marge amplifie les gains et les pertes comme l'effet de levier en immobilier"
summary: "Découvre comment fonctionne l'achat d'actions sur marge, et pourquoi il multiplie à la fois les gains et les pertes, à la manière de l'effet de levier en immobilier."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-009 : Pourquoi l'achat sur marge amplifie les gains et les pertes comme l'effet de levier en immobilier

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer comment fonctionne l'achat d'actions sur marge
- Expliquer pourquoi la marge amplifie proportionnellement les gains et les pertes
- Relier cette notion à l'effet de levier en immobilier abordé ailleurs dans ce programme

## Contenu principal

La **marge** permet à un investisseur d'emprunter de l'argent à une maison de courtage pour acheter plus de titres que son seul argent comptant ne le permettrait, en utilisant les titres du compte comme garantie du prêt. Cette notion reflète l'effet de levier en immobilier abordé ailleurs dans le parcours RED de ce programme : l'argent emprunté te permet de contrôler une position plus grande avec un montant plus petit de ton propre capital.

Voici « pourquoi » le même effet multiplicateur s'applique : ton rendement en pourcentage se calcule par rapport à ton propre argent investi, et non à la taille totale de la position — donc si la position prend de la valeur, ce gain est mesuré par rapport à une base plus petite, ce qui amplifie ton rendement en pourcentage. Si la position perd de la valeur, le même calcul amplifie ta perte en pourcentage exactement de la même façon, et tu dois quand même rembourser la totalité du montant emprunté, peu importe le rendement du placement.

[VERIFIED FACT] Les prêts sur marge comportent habituellement des intérêts, ce qui ajoute un coût continu à la position, et les maisons de courtage exigent le maintien d'un niveau minimal d'avoir dans le compte — si la valeur du compte baisse trop, ça peut déclencher un appel de marge, abordé dans la prochaine leçon.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un investisseur a 10 000 $ comptant et utilise la marge pour acheter pour 20 000 $ d'actions (en empruntant les 10 000 $ restants). Si l'action monte de 10 %, la position gagne 2 000 $ — un rendement de 20 % sur les 10 000 $ de départ de l'investisseur, et non de 10 %. Si l'action baisse plutôt de 10 %, la position perd 2 000 $ — une perte de 20 % sur les 10 000 $ de départ, et l'investisseur doit quand même rembourser la totalité des 10 000 $ empruntés, peu importe la nouvelle valeur, plus basse, de l'action.

## Quiz de pratique

1. Qu'est-ce que l'achat sur marge permet à un investisseur de faire?
2. Pourquoi la marge amplifie-t-elle les gains et les pertes en pourcentage par rapport à un achat entièrement au comptant?
3. Quel coût continu la marge ajoute-t-elle habituellement, en plus du risque amplifié?

## Corrigé

1. Emprunter de l'argent à une maison de courtage pour acheter plus de titres que son seul argent comptant ne le permettrait, en utilisant les avoirs du compte comme garantie.
2. Parce que les rendements sont mesurés par rapport au montant plus petit que l'investisseur a lui-même investi plutôt qu'à la taille totale de la position, le même gain ou la même perte en dollars devient une variation plus grande en pourcentage.
3. Les intérêts exigés sur le prêt sur marge, qui ajoutent un coût continu peu importe le rendement du placement.

## Réponses et explications

1. C'est la base de définition de la leçon.
2. C'est le même mécanisme multiplicateur que l'effet de levier en immobilier, appliqué ici au placement sur marge.
3. Ça ajoute une dimension de coût propre à la marge, qui n'a pas d'équivalent aussi direct dans la discussion sur l'effet de levier en immobilier.

## Points clés à retenir
- La marge permet d'emprunter pour acheter plus de titres que l'argent comptant seul ne le permettrait, en utilisant le compte comme garantie.
- Elle amplifie proportionnellement les gains et les pertes, à la manière de l'effet multiplicateur du levier en immobilier.
- Les prêts sur marge comportent des intérêts continus et exigent le maintien d'un avoir minimal dans le compte, avec le risque d'un appel de marge si la valeur du compte baisse trop.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. La négociation sur marge comporte des risques importants, y compris la possibilité de perdre plus que ton placement initial. Consulte un professionnel de la finance autorisé avant de négocier sur marge.
