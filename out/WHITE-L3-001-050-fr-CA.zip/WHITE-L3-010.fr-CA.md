---
id: WHITE-L3-010
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 10
title: "Pourquoi un appel de marge peut te forcer à vendre au pire moment possible"
summary: "Découvre ce qu'est un appel de marge, pourquoi il se déclenche automatiquement et pourquoi il peut forcer une vente précisément quand les prix ont déjà baissé."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-010 : Pourquoi un appel de marge peut te forcer à vendre au pire moment possible

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce qui déclenche un appel de marge
- Expliquer pourquoi un appel de marge peut forcer une vente à un moment particulièrement mauvais
- Expliquer pourquoi ce risque augmente avec le niveau de levier utilisé

## Contenu principal

La leçon 9 a présenté l'effet amplificateur de la marge sur les gains comme sur les pertes. Cette leçon aborde le mécanisme précis qui transforme une position sur marge perdante en vente forcée, souvent mal synchronisée : l'**appel de marge**.

Les maisons de courtage exigent qu'un niveau minimal d'avoir soit maintenu dans un compte sur marge (l'exigence de marge de maintien). Si la valeur d'une position baisse assez pour que l'avoir du compte passe sous ce minimum, la maison de courtage fait un appel de marge — une demande de déposer plus d'argent comptant ou de titres, ou de vendre une partie de la position, pour que le compte respecte de nouveau l'exigence.

Voici « pourquoi » c'est particulièrement dommageable : un appel de marge est déclenché par une baisse des prix, ce qui veut dire qu'il survient habituellement exactement au moment où l'investisseur subit déjà des pertes — et s'il ne peut pas ajouter de fonds rapidement, ou ne le fait pas, la maison de courtage peut vendre automatiquement ses avoirs, souvent sans le consulter davantage, pour rétablir le niveau d'avoir exigé. [VERIFIED FACT] Ça peut forcer une vente à un prix déprimé, en concrétisant les pertes au moment précis où, comme dans la discussion de la leçon 1, une occasion d'« acheter bas » pourrait autrement être en train de se former — le levier enlève le choix de simplement attendre que ça passe.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse utilise la marge pour acheter une position en actions plus grande que ce que son argent comptant seul lui permettrait. L'action chute fortement, et l'avoir de son compte passe sous l'exigence de maintien de la maison de courtage, ce qui déclenche un appel de marge. [ASSUMPTION] Incapable de déposer des fonds supplémentaires assez rapidement, elle voit la maison de courtage vendre automatiquement une partie de sa position pour que le compte respecte de nouveau l'exigence — ce qui concrétise ses pertes au prix déprimé, même si l'action se redresse plus tard. Une investisseuse qui détiendrait la même action sans marge aurait eu le choix de simplement garder ses titres pendant la baisse, puisqu'aucune exigence de vente forcée ne s'appliquait à sa position sans levier.

## Quiz de pratique

1. Qu'est-ce qui déclenche un appel de marge?
2. Pourquoi considère-t-on qu'un appel de marge survient à un moment particulièrement mauvais?
3. Quel choix un investisseur sur marge perd-il, alors qu'un investisseur sans levier le garde pendant une baisse?

## Corrigé

1. L'avoir du compte qui passe sous le niveau de marge de maintien exigé par la maison de courtage, habituellement à cause d'une baisse de la valeur de la position à effet de levier.
2. Parce qu'il est déclenché par une baisse des prix, ce qui force à agir exactement au moment où l'investisseur subit déjà des pertes, et peut concrétiser ces pertes à un prix déprimé.
3. Le choix de simplement garder ses titres pendant une baisse et d'attendre une reprise possible — la marge peut forcer une vente, peu importe la préférence de l'investisseur d'attendre.

## Réponses et explications

1. C'est le déclencheur mécanique sur lequel repose le reste de la leçon.
2. C'est le « pourquoi » central — le décalage entre le moment où survient un appel de marge et le moment où un investisseur voudrait idéalement vendre.
3. Ça se relie directement au thème de la leçon 1 sur la difficulté d'acheter bas et de tenir bon pendant les baisses.

## Points clés à retenir
- Un appel de marge se déclenche quand l'avoir d'un compte passe sous le niveau de maintien exigé par la maison de courtage.
- Comme il est déclenché par une baisse des prix, il peut forcer une vente à un prix déprimé, ce qui concrétise les pertes à un mauvais moment.
- La marge enlève à l'investisseur le choix de simplement tenir bon pendant une baisse, un choix que gardent les investisseurs sans levier.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. La négociation sur marge comporte des risques importants, y compris la liquidation forcée d'actifs. Consulte un professionnel de la finance autorisé avant de négocier sur marge.
