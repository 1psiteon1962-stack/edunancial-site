---
id: WHITE-L3-011
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 11
title: "Pourquoi la vente à découvert comporte un risque théoriquement illimité"
summary: "Découvre comment fonctionne la vente à découvert, pourquoi elle profite d'une baisse de prix et pourquoi sa perte possible est structurellement illimitée."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-011 : Pourquoi la vente à découvert comporte un risque théoriquement illimité

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer le fonctionnement mécanique de la vente à découvert
- Expliquer pourquoi le gain maximal d'un vendeur à découvert est plafonné alors que sa perte possible est théoriquement illimitée
- Expliquer ce qu'est un resserrement des positions à découvert (*short squeeze*) et pourquoi il peut accélérer les pertes

## Contenu principal

La **vente à découvert** consiste à emprunter des actions (habituellement par l'entremise d'une maison de courtage), à les vendre immédiatement au prix actuel, puis à les racheter plus tard (en espérant que ce soit à un prix plus bas) pour les rendre au prêteur — en profitant de la différence si le prix baisse.

Voici « pourquoi » la vente à découvert a une forme de risque fondamentalement différente de la simple détention d'une action : le prix d'une action peut seulement baisser jusqu'à zéro, donc le gain maximal possible d'un vendeur à découvert est plafonné (la valeur totale de l'action, si elle tombe à zéro). Mais le prix d'une action n'a aucune limite supérieure théorique — il peut continuer de monter indéfiniment, ce qui veut dire que la perte possible du vendeur à découvert, qui devra finir par racheter les actions empruntées au prix atteint, est théoriquement illimitée.

[VERIFIED FACT] Ce risque peut s'accélérer par un **resserrement des positions à découvert** — si le prix d'une action fortement vendue à découvert commence à monter, les vendeurs à découvert qui subissent des pertes croissantes peuvent être forcés (parfois par des mécanismes semblables à un appel de marge, leçon 10) de racheter des actions pour limiter leurs pertes, et cette pression acheteuse peut elle-même faire monter encore le prix, poussant d'autres vendeurs à découvert à faire de même dans un cycle qui s'auto-alimente.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un investisseur emprunte et vend à découvert 100 actions qui se négocient à 50 $, en s'attendant à ce que le prix baisse. Si le prix baisse effectivement à 30 $, il peut racheter les actions pour 3 000 $ et les rendre, en empochant la différence de 2 000 $ (avant les frais) — un gain solide, mais plafonné, puisque l'action pouvait au plus tomber à zéro. Si l'action monte plutôt de façon inattendue à 150 $, il devrait dépenser 15 000 $ pour racheter les actions qu'il a vendues 5 000 $ — une perte de 10 000 $, et si le prix continuait de grimper, cette perte continuerait d'augmenter sans limite supérieure.

## Quiz de pratique

1. Comment fonctionne la vente à découvert, sur le plan mécanique?
2. Pourquoi le gain maximal possible d'un vendeur à découvert est-il plafonné, alors que sa perte possible est théoriquement illimitée?
3. Qu'est-ce qu'un resserrement des positions à découvert, et comment peut-il accélérer les pertes d'un vendeur à découvert?

## Corrigé

1. Emprunter des actions, les vendre au prix actuel, puis les racheter plus tard pour les rendre au prêteur, en profitant de l'opération si le prix de rachat est plus bas que le prix de vente.
2. Le prix d'une action peut seulement baisser jusqu'à zéro (ce qui plafonne le gain), mais il n'a aucune limite supérieure théorique (ce qui laisse la perte possible illimitée).
3. Un cycle qui s'auto-alimente, où la hausse des prix force les vendeurs à découvert à racheter des actions pour limiter leurs pertes, et où cette pression acheteuse fait monter encore les prix, déclenchant d'autres rachats forcés.

## Réponses et explications

1. C'est la base mécanique de toute la leçon.
2. C'est la forme de risque asymétrique centrale qui distingue la vente à découvert de la détention ordinaire d'actions.
3. Ça explique un mécanisme d'accélération réel, observé historiquement, lié au risque de perte illimitée décrit plus haut.

## Points clés à retenir
- La vente à découvert profite d'une baisse du prix d'une action en empruntant, en vendant, puis en rachetant plus tard les actions à un prix (espérons-le) plus bas.
- Le gain maximal est plafonné puisqu'une action peut seulement tomber à zéro, mais la perte possible est théoriquement illimitée puisque le prix n'a pas de limite supérieure.
- Un resserrement des positions à découvert peut accélérer les pertes par un cycle de rachats forcés qui s'auto-alimente à mesure que les prix montent.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. La vente à découvert comporte des risques importants, potentiellement illimités, et ne convient pas à tous les investisseurs. Consulte un professionnel de la finance autorisé avant de vendre à découvert.
