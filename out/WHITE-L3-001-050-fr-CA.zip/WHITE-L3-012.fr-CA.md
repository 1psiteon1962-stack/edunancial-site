---
id: WHITE-L3-012
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 12
title: "Pourquoi l'achat périodique par sommes fixes réduit le risque lié au moment, et non le risque du placement"
summary: "Découvre pourquoi investir un montant fixe à intervalles réguliers réduit le risque de mal choisir son moment, sans réduire le risque propre au placement lui-même."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-012 : Pourquoi l'achat périodique par sommes fixes réduit le risque lié au moment, et non le risque du placement

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer comment fonctionne l'achat périodique par sommes fixes
- Expliquer le type précis de risque que réduit cette méthode
- Expliquer pourquoi cette méthode ne réduit pas le risque sous-jacent du placement lui-même

## Contenu principal

L'**achat périodique par sommes fixes** (en anglais, *dollar-cost averaging* ou DCA) consiste à investir un montant d'argent fixe à intervalles réguliers — chaque mois, par exemple —, peu importe le prix à chaque intervalle, plutôt que d'investir une somme plus importante en une seule fois.

Voici « pourquoi » cette méthode s'attaque précisément au risque lié au moment, en lien avec la leçon 1 : comme tu achètes à de nombreux prix différents au fil du temps, tu évites le risque d'investir tout ton montant juste avant une baisse importante et mal synchronisée. Certains achats se font à des prix plus élevés, d'autres à des prix plus bas, et le coût moyen par action se lisse sur la période de placement.

[VERIFIED FACT] L'achat périodique par sommes fixes ne réduit pas le risque ni la volatilité réels du placement sous-jacent — l'action, le fonds ou l'actif que tu achètes conserve les mêmes caractéristiques de risque fondamentales, peu importe comment tu étales tes achats. Ce que la méthode change, c'est ton exposition à un seul mauvais point d'entrée, et non le comportement propre du placement une fois que tu le détiens.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse a 12 000 $ à placer. Tout investir en une seule somme juste avant une forte baisse du marché voudrait dire que le montant entier serait immédiatement exposé à cette chute. Investir plutôt 1 000 $ par mois pendant 12 mois veut dire que seules les premières contributions sont exposées à toute la baisse si elle survient tôt dans la période — les contributions suivantes achètent aux prix maintenant plus bas, ce qui fait baisser le coût de base moyen de l'investisseuse. [ASSUMPTION] Si le marché monte plutôt de façon constante pendant les 12 mois, l'achat périodique aurait donné un coût moyen plus élevé que d'investir toute la somme immédiatement — la méthode protège contre un scénario précis de mauvais moment, mais ne garantit pas un meilleur résultat que l'investissement d'une somme forfaitaire dans tous les scénarios (une comparaison abordée directement dans la prochaine leçon).

## Quiz de pratique

1. Comment fonctionne l'achat périodique par sommes fixes?
2. Quel type précis de risque cette méthode cible-t-elle?
3. Cette méthode réduit-elle le risque sous-jacent du placement lui-même? Pourquoi?

## Corrigé

1. On investit un montant fixe à intervalles réguliers, peu importe le prix, plutôt que d'investir une somme forfaitaire en une seule fois.
2. Le risque lié au moment — le risque d'investir une somme importante juste avant une baisse mal synchronisée.
3. Non — les caractéristiques de risque et de volatilité du placement restent les mêmes; la méthode change seulement ton exposition à un seul point d'entrée potentiellement mal choisi.

## Réponses et explications

1. C'est la définition mécanique nécessaire pour le reste de la leçon.
2. C'est la distinction centrale et précise que fait la leçon — l'achat périodique est un outil de synchronisation, et non un outil de réduction du risque du placement lui-même.
3. Ça renforce la distinction et annonce le compromis examiné dans la prochaine leçon.

## Points clés à retenir
- L'achat périodique par sommes fixes consiste à investir un montant fixe à intervalles réguliers plutôt que tout en une seule fois.
- Il réduit précisément le risque lié au moment — le risque d'un seul placement important mal synchronisé.
- Il ne change pas le risque ni la volatilité sous-jacents du placement lui-même, seulement ton exposition à un mauvais point d'entrée.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
