---
id: WHITE-L3-013
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 13
title: "Pourquoi investir une somme forfaitaire donne souvent de meilleurs résultats que l'achat périodique (et pourquoi on choisit quand même l'achat périodique)"
summary: "Découvre pourquoi investir tout d'un coup tend statistiquement à faire mieux que l'achat périodique dans des marchés haussiers, et pourquoi de nombreux investisseurs préfèrent quand même l'achat périodique."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-013 : Pourquoi investir une somme forfaitaire donne souvent de meilleurs résultats que l'achat périodique (et pourquoi on choisit quand même l'achat périodique)

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi investir une somme forfaitaire tend à faire mieux que l'achat périodique dans un marché généralement haussier
- Expliquer pourquoi de nombreux investisseurs choisissent quand même l'achat périodique malgré cette tendance statistique
- Expliquer pourquoi il s'agit d'un compromis légitime, et non simplement d'une erreur de calcul des investisseurs qui choisissent l'achat périodique

## Contenu principal

La leçon 12 a montré que l'achat périodique par sommes fixes protège contre un scénario précis de mauvais moment. Voici « pourquoi » cette leçon va plus loin : comme les marchés ont historiquement monté plus souvent qu'ils n'ont baissé sur la plupart des longues périodes, investir une somme forfaitaire immédiatement, plutôt que de l'étaler, a plus souvent qu'autrement donné un meilleur résultat — puisqu'une plus grande partie de ton argent est investie et exposée aux gains possibles pendant plus longtemps, au lieu de rester en partie non investie pendant qu'on la déploie graduellement.

[VERIFIED FACT] Il s'agit d'une tendance statistique fondée sur des données historiques, et non d'une garantie pour une période future précise — il y a eu des périodes où l'achat périodique aurait fait mieux qu'une somme forfaitaire, en particulier celles qui commençaient peu avant une baisse importante.

Alors pourquoi de nombreux investisseurs choisissent-ils quand même l'achat périodique, même en comprenant cette tendance? La raison se relie au thème comportemental de la leçon 1 : l'achat périodique réduit le risque émotionnel d'investir une somme importante juste avant une baisse puis, sous l'effet du regret ou de la peur, d'abandonner complètement la stratégie. Un investisseur qui choisit l'achat périodique et s'en tient à son plan, même si ça donne un résultat attendu statistiquement plus faible, pourrait s'en tirer mieux qu'un investisseur qui choisit la somme forfaitaire, mais panique et vend pendant une baisse qui suit.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse reçoit un héritage important et doit choisir entre tout investir immédiatement ou l'étaler sur un an par achat périodique. [ASSUMPTION] Historiquement, pour une année choisie au hasard, investir la somme forfaitaire immédiatement aurait fait mieux que l'achat périodique plus souvent qu'autrement, puisque les marchés ont monté pendant la plupart des périodes historiques. Mais cette investisseuse sait par expérience qu'un placement important et soudain suivi d'une baisse du marché lui causerait probablement beaucoup d'anxiété et pourrait l'amener à vendre à perte. Choisir l'achat périodique, même avec un rendement attendu statistiquement plus faible, pourrait être la meilleure décision pour elle précisément, si ça augmente ses chances de s'en tenir à son plan de placement malgré les fluctuations du marché.

## Quiz de pratique

1. Pourquoi investir une somme forfaitaire tend-il statistiquement à faire mieux que l'achat périodique sur la plupart des périodes historiques?
2. Cette tendance est-elle une garantie pour une période future précise? Pourquoi?
3. Pourquoi un investisseur pourrait-il rationnellement choisir quand même l'achat périodique, malgré cette tendance statistique?

## Corrigé

1. Parce que les marchés ont historiquement monté plus souvent qu'ils n'ont baissé sur de longues périodes, de sorte qu'avoir plus d'argent investi plus longtemps permet habituellement de profiter davantage de cette tendance à la hausse que d'investir l'argent graduellement.
2. Non — elle repose sur des données historiques, et il y a eu des périodes précises, en particulier celles qui commençaient avant une baisse importante, où l'achat périodique aurait donné de meilleurs résultats.
3. Parce que l'achat périodique peut réduire le risque émotionnel d'un mauvais moment et d'une vente sous l'effet de la panique, ce qui peut mener à un meilleur résultat réel qu'une stratégie statistiquement supérieure que l'investisseur risquerait d'abandonner pendant une baisse.

## Réponses et explications

1. C'est le raisonnement statistique central derrière le titre de la leçon.
2. C'est une mise en garde importante et nuancée contre un excès de confiance dans les données historiques.
3. Ça relie la décision à la psychologie de l'investisseur, en renforçant l'idée que le « meilleur » choix sur papier n'est pas toujours le meilleur choix pour le comportement d'une personne en particulier.

## Points clés à retenir
- Investir une somme forfaitaire a historiquement fait mieux que l'achat périodique plus souvent qu'autrement, puisque les marchés ont eu tendance à monter sur la plupart des longues périodes.
- Il s'agit d'une tendance statistique, et non d'une garantie pour une période précise.
- De nombreux investisseurs choisissent rationnellement l'achat périodique malgré tout, parce qu'il peut réduire le risque émotionnel d'un mauvais moment et augmenter les chances de s'en tenir à un plan de placement à long terme.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Le rendement passé ne garantit pas les résultats futurs. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
