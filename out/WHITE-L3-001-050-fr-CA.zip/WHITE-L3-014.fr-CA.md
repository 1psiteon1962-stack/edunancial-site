---
id: WHITE-L3-014
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 14
title: "Pourquoi le rééquilibrage te force automatiquement à vendre haut et à acheter bas"
summary: "Découvre comment fonctionne le rééquilibrage d'un portefeuille, et pourquoi il intègre la discipline « acheter bas, vendre haut » dans un processus mécanique au lieu de compter sur la volonté."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-014 : Pourquoi le rééquilibrage te force automatiquement à vendre haut et à acheter bas

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce que veut dire rééquilibrer un portefeuille
- Expliquer pourquoi le rééquilibrage force mécaniquement à vendre les gagnants relatifs et à acheter les perdants relatifs
- Relier cette notion au défi central de la leçon 1

## Contenu principal

La leçon 1 a ouvert ce parcours avec la difficulté d'appliquer réellement « acheter bas, vendre haut ». Le **rééquilibrage** offre une solution partielle et mécanique : il consiste à ramener périodiquement un portefeuille à sa répartition cible initiale (par exemple, 60 % d'actions et 40 % d'obligations) après que les mouvements du marché ont éloigné ces proportions de la cible.

Voici « pourquoi » ça intègre automatiquement le comportement souhaité : si les actions ont eu un bon rendement et représentent maintenant 70 % du portefeuille au lieu de la cible de 60 %, rééquilibrer veut dire vendre une partie des actions (dont la valeur relative a augmenté) et acheter plus d'obligations (qui ont pris du retard) pour revenir à la cible initiale — en vendant mécaniquement une partie de ce qui a monté et en achetant une partie de ce qui n'a pas monté, sans avoir besoin de prédire le prochain mouvement du marché.

[VERIFIED FACT] Le rééquilibrage peut se faire selon un calendrier fixe (par exemple, chaque année) ou être déclenché quand la répartition s'écarte au-delà d'un certain seuil — dans les deux cas, on retire la prise de décision émotionnelle du processus pour la remplacer par une règle établie d'avance.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un investisseur commence avec un portefeuille composé à 60 % d'actions et à 40 % d'obligations. Après une bonne année pour les actions, le portefeuille a dérivé vers 72 % d'actions et 28 % d'obligations. Rééquilibrer veut dire vendre assez d'actions et acheter assez d'obligations pour revenir à la cible de 60/40 — en encaissant mécaniquement une partie des profits de la catégorie d'actifs gagnante et en ajoutant à celle qui a pris du retard, selon une règle établie d'avance plutôt qu'une prédiction de ce qui arrivera ensuite. [ASSUMPTION] Si les actions continuent de monter par la suite, ce rééquilibrage a « coûté » à l'investisseur une partie du gain supplémentaire; si les actions reculent plutôt, le rééquilibrage semble clairvoyant après coup — mais dans les deux cas, le processus a été suivi de façon constante plutôt qu'en réaction aux événements.

## Quiz de pratique

1. Que veut dire rééquilibrer un portefeuille?
2. Pourquoi le rééquilibrage mène-t-il mécaniquement à vendre des actifs au rendement relativement meilleur et à acheter des actifs au rendement relativement moins bon?
3. Pourquoi ça retire la prise de décision émotionnelle du processus?

## Corrigé

1. Ramener périodiquement un portefeuille à sa répartition d'actifs cible initiale après que les mouvements du marché ont éloigné les proportions réelles de cette cible.
2. Parce qu'une catégorie d'actifs qui a eu un bon rendement finit par représenter une plus grande part du portefeuille que prévu, de sorte que revenir à la répartition cible exige d'en vendre une partie; l'inverse s'applique à une catégorie d'actifs moins performante, à laquelle il faut ajouter.
3. Parce que la décision de vendre ou d'acheter repose sur une règle établie d'avance (la répartition cible et un calendrier ou un seuil de rééquilibrage) plutôt que sur un jugement en temps réel sur la direction que prendra le marché.

## Réponses et explications

1. C'est la base de définition pour le reste de la leçon.
2. Ça explique le mécanisme précis qui intègre la discipline « acheter bas, vendre haut » dans le processus.
3. Ça relie le processus mécanique au défi comportemental présenté à la leçon 1.

## Points clés à retenir
- Le rééquilibrage ramène périodiquement un portefeuille à sa répartition d'actifs cible initiale.
- Il mène mécaniquement à vendre des actifs qui ont eu un rendement relativement bon et à acheter ceux qui ont pris du retard, sans avoir besoin de prédire le rendement futur.
- Suivre un calendrier ou un seuil établi d'avance retire la prise de décision émotionnelle du processus.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
