---
id: WHITE-L3-015
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 15
title: "Pourquoi le risque de séquence des rendements compte plus à la retraite que pendant l'accumulation"
summary: "Découvre pourquoi l'ordre dans lequel les rendements surviennent peut compter plus que le rendement moyen lui-même, surtout une fois que tu commences à retirer de l'argent."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-015 : Pourquoi le risque de séquence des rendements compte plus à la retraite que pendant l'accumulation

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce que veut dire le risque de séquence des rendements
- Expliquer pourquoi un même rendement moyen peut donner des résultats très différents selon l'ordre des rendements
- Expliquer pourquoi ce risque est beaucoup plus petit pendant la phase d'accumulation que pendant les retraits à la retraite

## Contenu principal

La plupart des discussions sur le rendement des placements portent sur le rendement annuel moyen d'une période. Le **risque de séquence des rendements** met en lumière quelque chose que la moyenne seule cache : l'*ordre* dans lequel ces rendements surviennent peut changer de façon importante le résultat final, surtout quand des retraits réguliers sont en jeu.

Voici « pourquoi » l'ordre compte autant pendant les retraits : si un portefeuille connaît de mauvais rendements au début d'une période de retraits, l'investisseur est forcé de vendre plus d'unités (ou un plus grand pourcentage du portefeuille) à des prix déprimés pour financer chaque retrait, ce qui réduit de façon permanente la base d'actifs restante qui pourra profiter d'une éventuelle reprise du marché. Les mêmes mauvais rendements, s'ils surviennent plus tard, après quelques années de retraits, font moins de dégâts — il reste simplement moins de temps pour que des dommages précoces s'aggravent en s'accumulant.

[VERIFIED FACT] Pendant la phase d'accumulation (quand un investisseur ajoute de l'argent au lieu d'en retirer), la séquence des rendements compte beaucoup moins, puisqu'il n'y a pas de vente forcée pendant une baisse — l'investisseur peut simplement continuer de cotiser et attendre une reprise sans être forcé de concrétiser des pertes par des retraits.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Deux retraités commencent chacun avec la même valeur de portefeuille et font le même retrait annuel, et tous deux obtiennent exactement le même rendement annuel moyen sur 20 ans — mais dans un ordre différent. La retraitée A connaît de mauvais rendements dans les premières années de sa retraite, ce qui l'oblige à faire des retraits plus importants (en pourcentage d'un portefeuille qui rétrécit) pendant cette baisse. Le retraité B connaît les mêmes mauvaises années, mais plus tard dans la période de 20 ans, après que son portefeuille a déjà grossi grâce à de bonnes années au début. [ASSUMPTION] Malgré des rendements moyens identiques, le portefeuille de la retraitée A pourrait s'épuiser bien avant celui du retraité B, uniquement à cause du moment où les mauvais rendements sont survenus par rapport au calendrier de retraits.

## Quiz de pratique

1. Que décrit le risque de séquence des rendements?
2. Pourquoi de mauvais rendements au début d'une période de retraits peuvent-ils causer beaucoup plus de dégâts que les mêmes mauvais rendements plus tard?
3. Pourquoi le risque de séquence des rendements compte-t-il beaucoup moins pendant la phase d'accumulation?

## Corrigé

1. Le risque que l'ordre dans lequel les rendements surviennent — et pas seulement leur moyenne — influence de façon importante le résultat d'un portefeuille, surtout quand il y a des retraits réguliers.
2. Parce que de mauvais rendements précoces forcent des retraits plus importants en pourcentage d'un portefeuille qui rétrécit déjà, ce qui réduit de façon permanente la base d'actifs qui pourra profiter d'une reprise ultérieure.
3. Parce que, sans retraits forcés, un investisseur peut simplement continuer de cotiser et attendre la fin d'une baisse sans devoir vendre pendant celle-ci, de sorte que l'ordre des rendements n'a pas le même effet cumulatif.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. C'est le mécanisme central qui explique pourquoi le moment, et pas seulement le rendement moyen, compte autant à la retraite.
3. Ça compare directement les phases d'accumulation et de retraits, en précisant quand ce risque est le plus pertinent.

## Points clés à retenir
- Le risque de séquence des rendements veut dire que l'ordre des rendements peut compter autant que leur moyenne, surtout quand il y a des retraits.
- De mauvais rendements au début d'une période de retraits font des dégâts disproportionnés, puisqu'ils forcent à vendre une plus grande part d'un portefeuille qui rétrécit.
- Ce risque est beaucoup plus petit pendant l'accumulation, puisqu'il n'y a pas de vente forcée qui concrétise les pertes précoces.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel de la finance autorisé avant de prendre des décisions de planification de la retraite.
