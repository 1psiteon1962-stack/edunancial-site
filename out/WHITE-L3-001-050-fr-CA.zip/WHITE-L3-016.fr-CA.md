---
id: WHITE-L3-016
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 16
title: "Pourquoi un taux de retrait « sécuritaire » n'est pas une garantie"
summary: "Découvre ce qu'un taux de retrait sécuritaire est censé représenter, et pourquoi il s'agit d'une ligne directrice historique, et non d'une promesse sur ton avenir précis."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-016 : Pourquoi un taux de retrait « sécuritaire » n'est pas une garantie

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce qu'un « taux de retrait sécuritaire » est conçu pour estimer
- Expliquer pourquoi il repose sur des tests historiques, et non sur une formule garantie
- Relier cette notion au risque de séquence des rendements de la leçon 15

## Contenu principal

Un **taux de retrait sécuritaire** est une ligne directrice souvent citée qui propose un pourcentage d'un portefeuille de retraite qui aurait pu historiquement être retiré chaque année (rajusté selon l'inflation) avec une forte probabilité que le portefeuille dure pendant une retraite de durée typique, d'après l'étude des données historiques des marchés.

Voici « pourquoi » ce n'est pas une garantie : ces lignes directrices sont établies en testant des stratégies de retrait sur des séquences de rendements historiques (ce qui se relie directement à la leçon 15) — des périodes qui ont déjà eu lieu. [VERIFIED FACT] Un taux qui aurait fonctionné dans la plupart, voire dans la totalité, des périodes historiques étudiées ne garantit pas qu'il fonctionnera pour la retraite future réelle d'une personne précise, puisque les conditions futures du marché, l'inflation et les séquences de rendements n'ont aucune obligation de ressembler aux périodes historiques utilisées dans l'analyse.

C'est pourquoi traiter un pourcentage de retrait sécuritaire précis comme un chiffre fixe et garanti peut être trompeur — il vaut mieux le voir comme un point de départ éclairé par l'histoire, que de nombreux retraités et planificateurs financiers ajustent selon le rendement réel du marché pendant la retraite, la souplesse des dépenses et d'autres circonstances personnelles, au lieu de le suivre de façon rigide peu importe ce qui arrive.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un retraité planifie ses retraits selon une ligne directrice historique souvent citée, en s'attendant à ce que son portefeuille dure confortablement pendant toute sa retraite. [ASSUMPTION] S'il prend sa retraite au début d'une séquence de rendements nettement pire que la plupart des périodes historiques utilisées pour établir cette ligne directrice — en écho au risque de séquence des rendements de la leçon 15 —, un plan de retraits rigide et non ajusté fondé sur ce taux pourrait épuiser son portefeuille plus vite que l'analyse historique ne le laissait croire. Une approche plus souple, qui ajuste un peu les retraits selon le rendement réel du portefeuille en cours de route, pourrait mieux le protéger contre ce risque précis.

## Quiz de pratique

1. Qu'est-ce qu'un taux de retrait sécuritaire tente d'estimer?
2. Pourquoi un taux de retrait sécuritaire établi à partir de l'histoire n'est-il pas une garantie pour la retraite réelle d'une personne?
3. Comment cette leçon se relie-t-elle au risque de séquence des rendements de la leçon 15?

## Corrigé

1. Un pourcentage d'un portefeuille de retraite qui aurait pu historiquement être retiré chaque année (rajusté selon l'inflation) avec une forte probabilité de durer pendant une retraite typique, d'après les données historiques.
2. Parce qu'il est établi à partir de tests sur des séquences de rendements passées, et que les conditions futures du marché, l'inflation et les séquences de rendements n'ont aucune obligation de ressembler aux périodes historiques étudiées.
3. Un taux de retrait qui a fonctionné historiquement pourrait quand même échouer pour une personne qui connaît une séquence de rendements particulièrement défavorable au début de sa propre retraite — exactement le risque que décrit la leçon 15.

## Réponses et explications

1. Ça établit le but de base de la notion.
2. C'est la mise en garde centrale autour de laquelle la leçon est construite — un succès historique ne garantit pas le succès futur d'une personne.
3. Ça relie explicitement les deux leçons, ce qui renforce la structure intégrée du parcours.

## Points clés à retenir
- Un taux de retrait sécuritaire est une ligne directrice éclairée par l'histoire, et non une formule garantie pour l'avenir d'une personne.
- Il est établi à partir de tests sur des séquences de rendements passées, auxquelles les conditions futures n'ont aucune obligation de ressembler.
- La souplesse dans les retraits, ajustés selon le rendement réel du portefeuille, peut aider à gérer le risque qu'un taux historique fixe ne se concrétise pas comme prévu.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Le rendement passé ne garantit pas les résultats futurs. Consulte un professionnel de la finance autorisé avant de prendre des décisions de planification de la retraite.
