---
id: WHITE-L3-017
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 17
title: "Pourquoi les dividendes ne sont pas de « l'argent gratuit »"
summary: "Découvre pourquoi le versement d'un dividende réduit le prix d'une action d'environ le même montant, et pourquoi les dividendes redistribuent de la valeur au lieu d'être une prime."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-017 : Pourquoi les dividendes ne sont pas de « l'argent gratuit »

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi le prix d'une action baisse habituellement d'environ le montant du dividende à la date ex-dividende
- Expliquer pourquoi un dividende est une redistribution de valeur existante, et non une richesse nouvellement créée
- Expliquer pourquoi le « rendement total » est la façon la plus complète d'évaluer un placement qui verse des dividendes

## Contenu principal

Il est facile de voir le versement d'un dividende comme de l'argent en plus de la valeur existante d'une action — une prime pour avoir détenu l'action. Voici « pourquoi » cette façon de voir est trompeuse : une entreprise verse des dividendes à partir de sa propre trésorerie, ce qui réduit les actifs qui lui restent. [VERIFIED FACT] À la date ex-dividende, le prix d'une action baisse habituellement d'environ le montant du dividende versé, ce qui reflète le fait que l'entreprise vaut maintenant un peu moins, après avoir distribué une partie de sa trésorerie aux actionnaires.

Ça veut dire qu'un dividende n'est pas une richesse nouvellement créée qui apparaît de nulle part — c'est une redistribution de valeur qui existait déjà dans l'entreprise, déplacée maintenant dans la poche de l'actionnaire sous forme d'argent comptant au lieu de rester dans le prix de l'action. L'actionnaire n'est pas réellement plus riche au moment où le dividende est versé; il détient simplement la même valeur totale, répartie entre un prix d'action un peu plus bas et le dividende reçu en argent.

C'est pourquoi le **rendement total** — qui combine l'appréciation du prix et les dividendes — est la mesure la plus complète du rendement réel d'un placement, plutôt que de regarder isolément le revenu de dividendes ou l'appréciation du prix.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une action se négocie à 100 $ la veille du versement d'un dividende de 2 $ par action. À la date ex-dividende, toutes choses égales par ailleurs, le prix de l'action s'ajuste habituellement à environ 98 $, ce qui reflète les 2 $ par action qui viennent de quitter l'entreprise sous forme de versement en argent. Un investisseur qui détient une action a maintenant 98 $ en actions plus 2 $ en argent — toujours 100 $ de valeur totale, comme avant le versement du dividende. Le dividende n'a pas créé de nouvelle richesse; il a simplement converti 2 $ de valeur d'action existante en 2 $ d'argent comptant.

## Quiz de pratique

1. Qu'arrive-t-il habituellement au prix d'une action à la date ex-dividende, et pourquoi?
2. Pourquoi vaut-il mieux voir un dividende comme une redistribution de valeur plutôt que comme une richesse nouvellement créée?
3. Pourquoi considère-t-on le « rendement total » comme une mesure de rendement plus complète que les seuls dividendes?

## Corrigé

1. Le prix baisse habituellement d'environ le montant du dividende, parce que la trésorerie de l'entreprise — et donc sa valeur globale — a diminué de ce même montant.
2. Parce que la valeur totale de l'actionnaire (le prix de l'action plus le dividende reçu) reste à peu près la même immédiatement après le versement — le dividende convertit simplement une partie de la valeur existante de l'action en argent comptant, au lieu d'ajouter une nouvelle valeur.
3. Parce qu'il combine l'appréciation du prix et le revenu de dividendes, ce qui reflète le rendement complet du placement plutôt qu'une seule de ses composantes.

## Réponses et explications

1. C'est le fait mécanique sur lequel toute la leçon est construite.
2. C'est le changement de perspective central que la leçon vise à enseigner.
3. Ça présente le cadre d'évaluation plus complet vers lequel mène cette notion.

## Points clés à retenir
- Le prix d'une action baisse habituellement d'environ le montant du dividende à la date ex-dividende.
- Un dividende redistribue aux actionnaires, sous forme d'argent comptant, une valeur qui existait déjà dans l'entreprise — il ne crée pas à lui seul de nouvelle richesse.
- Le rendement total, qui combine l'appréciation du prix et les dividendes, est une façon plus complète d'évaluer le rendement réel d'un placement.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
