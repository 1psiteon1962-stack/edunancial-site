---
id: WHITE-L3-018
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 18
title: "Pourquoi la durée d'une obligation mesure sa sensibilité aux taux d'intérêt"
summary: "Découvre ce que mesure la durée d'une obligation, pourquoi les obligations à plus longue durée sont plus sensibles aux variations des taux d'intérêt, et pourquoi ça compte pour les investisseurs."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-018 : Pourquoi la durée d'une obligation mesure sa sensibilité aux taux d'intérêt

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Définir la durée d'une obligation
- Expliquer pourquoi les obligations à plus longue durée sont plus sensibles aux variations des taux d'intérêt
- Expliquer pourquoi deux obligations qui ont la même date d'échéance peuvent avoir des durées différentes

## Contenu principal

La **durée** est une mesure de la sensibilité d'une obligation aux variations des taux d'intérêt, exprimée d'une façon qui ressemble à un nombre d'années, mais qui représente quelque chose de plus précis : en gros, à quel point le prix d'une obligation devrait varier pour une variation donnée des taux d'intérêt.

Voici « pourquoi » une durée plus longue veut dire une plus grande sensibilité : une obligation dont les flux de trésorerie seront reçus plus tard est plus touchée par une variation des taux en vigueur, parce qu'une plus grande partie de sa valeur dépend de flux de trésorerie éloignés dans le temps, qui sont davantage touchés par un changement du taux utilisé pour les évaluer aujourd'hui (une notion liée à la relation entre les taux d'intérêt et le prix des obligations abordée dans la prochaine leçon).

[VERIFIED FACT] La durée n'est pas identique à l'échéance d'une obligation — le taux du coupon d'une obligation (les paiements d'intérêts versés en cours de route) influe aussi sur la durée; une obligation qui verse des paiements réguliers plus importants rend une plus grande partie de sa valeur plus tôt, ce qui lui donne généralement une durée un peu plus courte qu'une obligation qui a la même date d'échéance, mais des paiements réguliers plus petits ou nuls (une obligation à coupon zéro, par exemple, a une durée égale à son échéance complète, puisque toute sa valeur est remise à la toute fin).

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Deux obligations arrivent toutes deux à échéance dans 10 ans. L'obligation A verse des paiements d'intérêts réguliers et appréciables en cours de route, ce qui remet une partie de sa valeur à l'investisseur avant l'échéance — et lui donne une durée un peu plus courte que 10 ans. L'obligation B est une obligation à coupon zéro, qui ne verse rien avant son échéance et remet toute sa valeur seulement au bout de 10 ans — ce qui lui donne une durée égale à son échéance complète de 10 ans. [ASSUMPTION] Si les taux d'intérêt augmentent du même montant, le prix de l'obligation B devrait habituellement baisser davantage que celui de l'obligation A, uniquement à cause de sa durée plus longue, même si les deux obligations arrivent à échéance au même moment.

## Quiz de pratique

1. Que mesure la durée d'une obligation?
2. Pourquoi une durée plus longue veut-elle généralement dire une plus grande sensibilité aux variations des taux d'intérêt?
3. Pourquoi deux obligations qui ont la même date d'échéance peuvent-elles avoir des durées différentes?

## Corrigé

1. La sensibilité d'une obligation aux variations des taux d'intérêt — en gros, à quel point son prix devrait varier pour une variation donnée des taux.
2. Parce qu'une plus grande partie de la valeur de l'obligation dépend de flux de trésorerie éloignés dans le temps, qui sont davantage touchés par un changement du taux utilisé pour les évaluer aujourd'hui.
3. Parce que la durée dépend aussi de la taille et du moment des paiements d'intérêts réguliers d'une obligation — une obligation qui remet plus de valeur plus tôt (des paiements de coupon plus importants) a une durée plus courte qu'une obligation qui remet la plus grande partie, ou la totalité, de sa valeur seulement à l'échéance.

## Réponses et explications

1. C'est la définition de base nécessaire pour le reste de la leçon.
2. C'est le mécanisme central qui explique le lien entre la durée et la sensibilité aux taux d'intérêt.
3. Ça ajoute une nuance importante qui distingue la durée de la simple durée jusqu'à l'échéance.

## Points clés à retenir
- La durée mesure la sensibilité d'une obligation aux variations des taux d'intérêt, ce qui est distinct de sa date d'échéance.
- Les obligations à plus longue durée sont généralement plus sensibles aux variations des taux d'intérêt que les obligations à plus courte durée.
- Les paiements de coupon d'une obligation influent sur sa durée — des paiements plus importants et plus fréquents raccourcissent généralement la durée par rapport à l'échéance.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
