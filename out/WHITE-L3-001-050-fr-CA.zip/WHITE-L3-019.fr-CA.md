---
id: WHITE-L3-019
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 19
title: "Pourquoi le prix des obligations et les taux d'intérêt évoluent en sens inverse"
summary: "Découvre la raison mécanique pour laquelle une hausse des taux d'intérêt fait baisser le prix des obligations existantes, et pourquoi cette relation est prévisible, et non aléatoire."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-019 : Pourquoi le prix des obligations et les taux d'intérêt évoluent en sens inverse

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi le prix des obligations baisse quand les taux d'intérêt montent
- Expliquer pourquoi le prix des obligations monte quand les taux d'intérêt baissent
- Expliquer pourquoi cette relation est une question de comparaison, et non de risque propre à une entreprise

## Contenu principal

Les obligations versent un taux d'intérêt fixe (le coupon) établi au moment de leur émission. Les taux d'intérêt de l'ensemble du marché, eux, changent avec le temps. Voici « pourquoi » ça crée une relation inverse et prévisible entre le prix des obligations existantes et les taux d'intérêt actuels : les paiements fixes d'une obligation existante deviennent plus ou moins attrayants selon ce qu'offrent actuellement les nouvelles obligations.

Si les taux d'intérêt montent après l'émission d'une obligation, de nouvelles obligations sont émises avec des paiements fixes plus élevés que le taux fixe de l'ancienne obligation — ce qui rend l'ancienne obligation, qui paie moins, moins attrayante en comparaison. Pour que l'ancienne obligation reste concurrentielle aux yeux d'un acheteur potentiel, son prix doit baisser, ce qui fait monter son rendement (le rendement par rapport à son prix) pour qu'il corresponde aux conditions actuelles du marché. L'inverse se produit si les taux d'intérêt baissent : les paiements fixes relativement plus élevés de l'ancienne obligation semblent plus attrayants que ce qui est maintenant offert, donc son prix monte.

[VERIFIED FACT] Cette relation s'applique au prix d'une obligation vendue avant l'échéance — un investisseur qui garde une obligation jusqu'à son échéance reçoit quand même les paiements fixes d'origine et le remboursement du capital comme promis (en l'absence de défaut), peu importe ce qui arrive aux taux d'intérêt ou au prix de l'obligation entre-temps.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse détient une obligation qui verse un taux fixe de 3 %. Les taux d'intérêt de l'ensemble du marché montent ensuite, et de nouvelles obligations semblables offrent maintenant 5 %. Si elle voulait vendre son obligation à 3 % avant l'échéance, elle devrait l'offrir à un prix inférieur à celui qu'elle a payé, puisqu'un acheteur pourrait autrement simplement acheter une nouvelle obligation à 5 % — c'est l'ajustement du prix qui rend son ancienne obligation, qui paie moins, de nouveau concurrentielle. Si elle garde plutôt l'obligation jusqu'à l'échéance, elle continue de recevoir les paiements d'origine de 3 % et récupère son capital comme promis, sans être touchée par ce qui est arrivé aux taux en vigueur entre-temps.

## Quiz de pratique

1. Pourquoi le prix d'une obligation baisse-t-il quand les taux d'intérêt montent?
2. Pourquoi le prix d'une obligation monte-t-il quand les taux d'intérêt baissent?
3. Cette relation de prix touche-t-elle un investisseur qui garde une obligation jusqu'à l'échéance? Pourquoi?

## Corrigé

1. Parce que de nouvelles obligations commencent à offrir des paiements fixes plus élevés, ce qui rend l'ancienne obligation, qui paie moins, moins attrayante à moins que son prix baisse pour rendre son rendement effectif concurrentiel.
2. Parce que les paiements fixes relativement plus élevés de l'ancienne obligation deviennent plus attrayants que les taux plus bas maintenant offerts, ce qui augmente la demande et fait monter son prix.
3. Non, en ce qui concerne les paiements promis — un investisseur qui la garde jusqu'à l'échéance reçoit quand même les paiements fixes d'origine et son capital comme promis (en l'absence de défaut), peu importe les fluctuations de prix en cours de route.

## Réponses et explications

1. C'est le mécanisme central qui explique la relation inverse.
2. Ça confirme la compréhension de la relation dans le sens inverse.
3. C'est une précision importante qui distingue le risque de prix du marché des conditions de paiement prévues au contrat de l'obligation.

## Points clés à retenir
- Le prix des obligations et les taux d'intérêt évoluent en sens inverse : quand les taux montent, le prix des obligations existantes baisse, et inversement.
- Ça se produit parce que les paiements fixes des obligations existantes deviennent plus ou moins attrayants par rapport aux nouveaux taux offerts.
- Cette relation de prix touche la vente d'une obligation avant l'échéance; la garder jusqu'à l'échéance procure quand même les paiements promis à l'origine, peu importe les variations de taux en cours de route.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
