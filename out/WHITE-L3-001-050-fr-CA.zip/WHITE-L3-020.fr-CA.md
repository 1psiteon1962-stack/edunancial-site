---
id: WHITE-L3-020
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 20
title: "Pourquoi le risque de crédit et le risque de taux d'intérêt sont deux risques obligataires différents"
summary: "Découvre pourquoi une obligation peut perdre de la valeur pour deux raisons complètement différentes, et pourquoi savoir laquelle est en cause change ta façon d'y réfléchir."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-020 : Pourquoi le risque de crédit et le risque de taux d'intérêt sont deux risques obligataires différents

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Distinguer le risque de crédit du risque de taux d'intérêt dans les obligations
- Expliquer pourquoi ces deux risques peuvent influer sur le prix d'une obligation indépendamment l'un de l'autre
- Expliquer pourquoi la cote d'une obligation reflète surtout le risque de crédit, et non le risque de taux d'intérêt

## Contenu principal

La leçon 19 a expliqué comment le prix des obligations évolue à l'inverse des taux d'intérêt de l'ensemble du marché — c'est le **risque de taux d'intérêt**, qui s'applique à pratiquement toutes les obligations, même les plus sûres. Il existe un deuxième risque, distinct, qui influe aussi sur le prix des obligations : le **risque de crédit** — le risque que l'émetteur de l'obligation soit incapable de faire les paiements promis, à cause de difficultés financières ou d'un défaut.

Voici « pourquoi » il est important de les garder séparés : le prix d'une obligation peut baisser parce que les taux d'intérêt de l'ensemble du marché montent, sans aucun changement de la santé financière de l'émetteur — c'est le risque de taux d'intérêt, qui touche même les obligations des émetteurs les plus solides financièrement. Le prix d'une obligation peut aussi baisser parce que le marché s'inquiète de la capacité de cet émetteur précis à payer, même si les taux d'intérêt de l'ensemble du marché n'ont pas bougé — c'est le risque de crédit, et il est propre à cet émetteur.

[VERIFIED FACT] Les cotes de crédit des obligations, attribuées par des agences de notation indépendantes, sont conçues pour refléter le risque de crédit d'un émetteur — la probabilité de défaut —, et non la sensibilité de son obligation aux variations des taux d'intérêt; une cote de crédit très élevée (un signe de faible risque de crédit) peut quand même être attribuée à une obligation qui comporte un risque de taux d'intérêt important si elle a une longue durée (leçon 18).

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Deux obligations voient leur prix baisser pendant la même période. L'émetteur de l'obligation A reste financièrement solide et rien ne change de son côté, mais la baisse s'est produite parce que les taux d'intérêt de l'ensemble du marché ont monté — un pur événement de risque de taux d'intérêt. L'émetteur de l'obligation B, de son côté, a publié des nouvelles financières inquiétantes qui soulèvent de vrais doutes sur sa capacité à faire ses paiements futurs — un événement de risque de crédit, qui fait baisser son prix indépendamment de ce qu'ont fait les taux d'intérêt. [ASSUMPTION] Un investisseur qui confond ces deux causes pourrait croire à tort que la baisse de prix de l'obligation B est temporaire et liée aux taux, comme celle de l'obligation A, alors qu'elle reflète en réalité un problème plus grave, propre à l'émetteur.

## Quiz de pratique

1. Quelle est la différence entre le risque de crédit et le risque de taux d'intérêt dans les obligations?
2. Pourquoi le prix d'une obligation peut-il baisser à cause du risque de taux d'intérêt même si la santé financière de l'émetteur n'a pas changé?
3. Selon cette leçon, que reflète surtout la cote de crédit d'une obligation?

## Corrigé

1. Le risque de taux d'intérêt est le risque de variation de prix causée par les mouvements des taux d'intérêt de l'ensemble du marché, qui touche pratiquement toutes les obligations; le risque de crédit est le risque qu'un émetteur précis soit incapable de faire les paiements promis, indépendamment des taux de l'ensemble du marché.
2. Parce que le risque de taux d'intérêt reflète la comparaison entre les paiements fixes d'une obligation et les nouveaux taux offerts sur le marché, un facteur entièrement distinct de la situation financière de l'émetteur.
3. Le risque de crédit de l'émetteur — la probabilité de défaut —, et non la sensibilité de l'obligation aux variations des taux d'intérêt.

## Réponses et explications

1. C'est la distinction centrale autour de laquelle la leçon est construite.
2. Ça se relie directement au mécanisme expliqué à la leçon 19.
3. Ça clarifie une source de confusion courante — une obligation très bien cotée peut quand même comporter un risque de taux d'intérêt important.

## Points clés à retenir
- Le risque de taux d'intérêt touche presque toutes les obligations et découle des mouvements des taux de l'ensemble du marché, peu importe la santé financière de l'émetteur.
- Le risque de crédit est propre à un émetteur et reflète la possibilité qu'il ne fasse pas les paiements promis.
- Les cotes de crédit des obligations reflètent précisément le risque de crédit, et non la sensibilité d'une obligation aux variations des taux d'intérêt.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
