---
id: WHITE-L3-021
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 21
title: "Pourquoi les FNB et les fonds communs de placement diffèrent sur le plan de la négociation, de l'impôt et des coûts"
summary: "Découvre les différences pratiques entre les FNB et les fonds communs de placement, et pourquoi elles peuvent compter plus que leurs grandes ressemblances."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-021 : Pourquoi les FNB et les fonds communs de placement diffèrent sur le plan de la négociation, de l'impôt et des coûts

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer comment les FNB et les fonds communs de placement diffèrent dans leur façon d'être négociés
- Expliquer pourquoi les FNB sont souvent plus avantageux sur le plan fiscal que des fonds communs de placement comparables
- Expliquer pourquoi les structures de coûts peuvent différer entre les deux

## Contenu principal

Les **FNB (fonds négociés en bourse)** et les **fonds communs de placement** mettent tous deux en commun l'argent des investisseurs dans un panier diversifié de titres, et tous deux peuvent suivre des stratégies ou des indices semblables — mais ils diffèrent sur certains points pratiques qu'il vaut la peine de comprendre.

Voici « pourquoi » la négociation diffère : les FNB se négocient en bourse tout au long de la journée, comme des actions individuelles, à des prix qui fluctuent continuellement selon l'activité du marché. Les fonds communs de placement sont habituellement évalués et négociés une seule fois par jour, après la fermeture du marché, à la valeur liquidative calculée ce jour-là — tu ne connais pas le prix d'exécution exact quand tu passes un ordre de fonds commun pendant la journée de négociation.

[VERIFIED FACT] Les FNB sont aussi souvent plus avantageux sur le plan fiscal que des fonds communs de placement comparables, en grande partie à cause d'un mécanisme structurel dans la façon dont les parts de FNB sont créées et rachetées, qui tend à générer moins de distributions de gains en capital imposables pour les porteurs de parts que le processus utilisé par de nombreux fonds communs — même si ça varie selon le fonds et n'est pas automatique pour chaque FNB.

Les structures de coûts peuvent aussi différer : de nombreux FNB, surtout ceux qui suivent des indices larges, ont tendance à avoir des ratios de frais plus bas que les fonds communs de placement à gestion active, mais il existe aussi des fonds communs indiciels à faibles coûts — il faut comparer les coûts fonds par fonds plutôt que de les supposer selon le seul type de structure.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse veut acheter des parts d'un fonds indiciel qui suit le S&P 500. Si elle choisit la version FNB, elle peut passer un ordre pendant les heures de marché et voir immédiatement le prix d'exécution, comme pour l'achat d'une action. Si elle choisit plutôt la version fonds commun de placement, son ordre est exécuté à la valeur liquidative du fonds calculée après la fermeture du marché ce jour-là — elle ne connaîtra pas le prix exact avant la fin de la journée de négociation. [ASSUMPTION] Sur plusieurs années, si la version FNB génère moins de distributions de gains en capital imposables grâce à son mécanisme structurel, l'investisseuse dans le FNB pourrait obtenir un rendement après impôt un peu meilleur, même si les placements sous-jacents et le rendement avant impôt des fonds sont très semblables.

## Quiz de pratique

1. En quoi la négociation des FNB pendant la journée diffère-t-elle de celle des fonds communs de placement?
2. Pourquoi les FNB sont-ils souvent plus avantageux sur le plan fiscal que des fonds communs de placement comparables?
3. Est-il juste de supposer que tous les FNB coûtent moins cher que tous les fonds communs de placement? Pourquoi?

## Corrigé

1. Les FNB se négocient tout au long de la journée à des prix qui fluctuent continuellement, comme des actions; les fonds communs de placement sont habituellement évalués et négociés une fois par jour, après la fermeture du marché, à la valeur liquidative de la journée.
2. En grande partie à cause d'un mécanisme structurel dans la façon dont les parts de FNB sont créées et rachetées, qui tend à générer moins de distributions de gains en capital imposables que les processus de nombreux fonds communs de placement.
3. Non — même si les FNB et les fonds indiciels ont généralement tendance à coûter moins cher que les fonds à gestion active, il existe aussi des fonds communs indiciels à faibles coûts, de sorte qu'il faut comparer les coûts fonds par fonds plutôt que de les supposer selon le seul type de structure.

## Réponses et explications

1. C'est la principale distinction structurelle entre les deux types de fonds.
2. C'est le mécanisme central d'efficacité fiscale, accompagné de la nuance qu'il n'est pas automatique pour chaque FNB.
3. Ça corrige une généralisation trop simple sur les coûts, qui ne tient pas toujours.

## Points clés à retenir
- Les FNB se négocient tout au long de la journée comme des actions; les fonds communs de placement se négocient une fois par jour à une valeur liquidative calculée.
- Les FNB sont souvent, mais pas toujours, plus avantageux sur le plan fiscal grâce à leur structure de création et de rachat de parts.
- Il faut comparer les coûts fonds par fonds, puisqu'il existe des options à faibles coûts dans les deux structures, FNB et fonds communs de placement.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
