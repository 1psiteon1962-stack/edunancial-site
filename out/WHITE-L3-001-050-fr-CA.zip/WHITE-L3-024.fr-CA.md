---
id: WHITE-L3-024
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 24
title: "Pourquoi la gestion active doit surmonter ses propres frais pour ajouter de la valeur"
summary: "Découvre pourquoi un fonds à gestion active doit battre le marché par plus qu'une petite marge pour donner réellement un meilleur résultat qu'un fonds indiciel à faibles coûts."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-024 : Pourquoi la gestion active doit surmonter ses propres frais pour ajouter de la valeur

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi battre le marché avant frais n'équivaut pas à le battre après frais
- Expliquer pourquoi la gestion active comporte un obstacle de rendement intégré par rapport au placement indiciel
- Expliquer pourquoi cet obstacle s'accumule avec le temps, comme l'effet du ratio de frais de la leçon 22

## Contenu principal

La leçon 22 a montré comment les frais s'accumulent contre l'investisseur avec le temps. Voici « pourquoi » ça crée un défi précis pour les fonds à gestion active : comme les fonds actifs facturent généralement des frais plus élevés que les fonds indiciels (leçon 21), un gestionnaire n'a pas seulement besoin de choisir des placements qui font mieux que le marché — il doit faire assez mieux pour couvrir cet écart de frais, sinon l'investisseur s'en tire moins bien qu'en détenant simplement un fonds indiciel à faibles coûts, même si les choix du gestionnaire ont techniquement « battu le marché » avant frais.

[VERIFIED FACT] Battre le marché de façon constante, après frais, sur de longues périodes s'est historiquement révélé difficile pour le fonds à gestion active moyen, selon des études qui comparent le rendement des fonds actifs aux indices de référence pertinents sur des périodes de plusieurs années — même si certains fonds et gestionnaires peuvent faire mieux, et le font, pendant des périodes précises, et que les résultats varient selon le fonds, la stratégie et la période.

C'est pourquoi la question à se poser pour évaluer un fonds actif ne devrait pas être « le gestionnaire a-t-il choisi de bons placements? », mais plutôt « les choix du gestionnaire ont-ils fait assez mieux pour surmonter l'écart de frais par rapport à une solution indicielle comparable à faibles coûts? » — une barre nettement plus haute que simplement battre le marché.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un fonds à gestion active facture un ratio de frais de 1,2 %; un fonds indiciel comparable facture 0,05 % — un écart d'environ 1,15 point de pourcentage par année. Si les choix d'actions sous-jacents du fonds actif font 0,8 % de mieux que l'indice avant frais pendant une année donnée, le fonds a quand même eu un rendement inférieur à la solution indicielle à faibles coûts une fois les frais pris en compte, parce que la surperformance du gestionnaire n'était pas assez grande pour combler l'écart de frais. [ASSUMPTION] Sur de nombreuses années, un fonds actif devrait faire mieux que cet écart de frais de façon constante, et non seulement à l'occasion ou par une petite marge, pour vraiment ajouter une valeur nette par rapport à la solution indicielle.

## Quiz de pratique

1. Pourquoi battre le marché avant frais n'équivaut-il pas à le battre après frais?
2. Quelle barre de rendement précise un gestionnaire de fonds actif doit-il franchir pour ajouter de la valeur par rapport à un fonds indiciel comparable?
3. Qu'ont généralement constaté les recherches historiques sur la capacité du fonds à gestion active moyen à franchir cette barre de façon constante sur de longues périodes?

## Corrigé

1. Parce que les frais plus élevés du fonds sont soustraits des rendements, de sorte qu'une surperformance avant frais peut être entièrement ou partiellement annulée par l'écart de frais par rapport à une solution indicielle moins coûteuse.
2. Faire mieux que le marché par plus que l'écart de frais entre le fonds actif et un fonds indiciel comparable à faibles coûts, et pas seulement battre le marché.
3. Que le faire de façon constante, sur de longues périodes, s'est historiquement révélé difficile pour le fonds à gestion active moyen, même si les résultats varient selon le fonds, la stratégie et la période.

## Réponses et explications

1. C'est la distinction centrale autour de laquelle la leçon est construite.
2. Ça reformule la norme d'évaluation de la gestion active de façon plus précise et plus utile.
3. Ça fournit un contexte nuancé, tiré de la recherche historique, sans exagérer une règle universelle.

## Points clés à retenir
- Les frais plus élevés de la gestion active créent un obstacle de rendement intégré par rapport au placement indiciel moins coûteux.
- Un gestionnaire doit faire mieux que l'écart de frais, et pas seulement battre le marché, pour ajouter une valeur nette.
- Historiquement, le fonds à gestion active moyen a trouvé difficile d'y arriver de façon constante sur de longues périodes, même si les résultats individuels varient.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Le rendement passé ne garantit pas les résultats futurs. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
