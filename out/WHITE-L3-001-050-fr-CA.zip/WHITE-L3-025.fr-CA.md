---
id: WHITE-L3-025
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 25
title: "Pourquoi le rendement passé d'un fonds ne prédit pas son rendement futur"
summary: "Découvre pourquoi de solides résultats récents d'un fonds ne sont pas un signal fiable de son rendement à venir."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-025 : Pourquoi le rendement passé d'un fonds ne prédit pas son rendement futur

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi le rendement passé d'un fonds a une valeur prédictive limitée pour son rendement futur
- Expliquer ce que veut dire « courir après le rendement » et pourquoi ça peut nuire aux rendements
- Expliquer pourquoi cette notion se relie au biais de récence abordé plus loin dans ce parcours

## Contenu principal

Il est intuitif de supposer qu'un fonds qui a eu un bon rendement récemment continuera probablement d'en avoir un — après tout, il doit bien faire quelque chose de bien. Voici « pourquoi » cette intuition ne tient souvent pas la route : [VERIFIED FACT] de nombreuses recherches qui comparent le classement historique du rendement des fonds sur différentes périodes ont généralement constaté une faible persistance — c'est-à-dire que les fonds les plus performants d'une période ne sont pas, de façon fiable, les plus performants de la période suivante. Les autorités de réglementation ont relevé cette tendance, ce qui explique en partie pourquoi les documents d'information normalisés précisent que le rendement passé ne garantit pas les résultats futurs.

Plusieurs facteurs expliquent cette faible persistance : un bon rendement récent peut refléter un contexte temporairement favorable au style ou au secteur particulier du fonds, plutôt qu'un avantage de compétence reproductible; les stratégies ou les secteurs qui réussissent voient souvent les conditions changer ou deviennent plus encombrés, ce qui réduit l'avantage futur; et les changements de gestionnaire, la croissance de l'actif et d'autres facteurs peuvent tous influer sur les résultats futurs d'un fonds, indépendamment de son historique.

C'est pourquoi le fait de poursuivre les fonds les plus performants récemment — déplacer son argent vers le fonds qui a eu les meilleurs résultats dernièrement — est souvent décrit comme **courir après le rendement**, et peut amener les investisseurs à acheter constamment après de fortes hausses (potentiellement près d'un sommet) et à vendre après des périodes décevantes (potentiellement près d'un creux), ce qui correspond à une version, à l'échelle des fonds, de l'erreur « acheter haut, vendre bas » abordée au début de ce parcours.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un investisseur remarque qu'un fonds a affiché les meilleurs rendements de sa catégorie au cours des trois dernières années et décide d'y investir massivement en se fiant à cet historique. [ASSUMPTION] Si le bon rendement de ce fonds venait surtout d'un contexte temporairement favorable à son style de placement précis, et que ce contexte change dans les années suivantes, le fonds pourrait avoir un rendement inférieur par la suite — ce qui laisserait à l'investisseur une expérience décevante, même s'il l'avait choisi en se fiant à un historique impressionnant.

## Quiz de pratique

1. Qu'ont généralement constaté les recherches sur la persistance du rendement des meilleurs fonds d'une période à l'autre?
2. Qu'est-ce que « courir après le rendement », et pourquoi ça peut poser problème?
3. Pourquoi un bon rendement récent peut-il refléter un contexte temporaire plutôt qu'une compétence reproductible du gestionnaire?

## Corrigé

1. Une persistance généralement faible — les meilleurs fonds d'une période ne sont pas, de façon fiable, les meilleurs de la période suivante.
2. Déplacer son argent vers les fonds les plus performants récemment; ça peut mener à acheter après qu'une forte hausse a déjà eu lieu et à vendre après une période faible, potentiellement près d'un sommet et d'un creux respectivement.
3. Parce que le style de placement ou le secteur précis d'un fonds a peut-être simplement été favorisé par les conditions de cette période, plutôt que le gestionnaire ait démontré un avantage de compétence reproductible susceptible de durer.

## Réponses et explications

1. C'est le constat de recherche central autour duquel la leçon est construite.
2. Ça définit et explique le comportement risqué contre lequel la leçon met en garde.
3. Ça explique la raison de fond pour laquelle la persistance du rendement est souvent faible.

## Points clés à retenir
- Selon les recherches disponibles, le rendement passé d'un fonds a généralement montré une faible valeur prédictive de son rendement futur.
- Courir après le rendement — acheter les fonds les plus performants récemment — peut mener à une version, à l'échelle des fonds, du fait d'acheter haut et de vendre bas.
- Un bon rendement récent peut refléter des conditions temporairement favorables plutôt qu'un avantage de compétence reproductible du gestionnaire.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Le rendement passé ne garantit pas les résultats futurs. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
