---
id: WHITE-L3-027
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 27
title: "Pourquoi l'aversion aux pertes pousse les investisseurs à vendre leurs gagnants trop tôt et à garder leurs perdants trop longtemps"
summary: "Découvre pourquoi la douleur d'une perte a tendance à peser plus lourd que le plaisir d'un gain équivalent, et comment ce déséquilibre fausse les décisions de placement."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-027 : Pourquoi l'aversion aux pertes pousse les investisseurs à vendre leurs gagnants trop tôt et à garder leurs perdants trop longtemps

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Définir l'aversion aux pertes
- Expliquer l'« effet de disposition » et comment il découle de l'aversion aux pertes
- Expliquer pourquoi ce comportement peut nuire systématiquement aux rendements à long terme

## Contenu principal

L'**aversion aux pertes** décrit un comportement bien documenté : pour la plupart des gens, la douleur émotionnelle de perdre un certain montant d'argent a tendance à peser plus lourd que le plaisir émotionnel de gagner ce même montant. Cette asymétrie, bien qu'elle fasse partie normale de la psychologie humaine, peut fausser les décisions de placement d'une façon précise et prévisible.

Voici « pourquoi » ça mène à une erreur courante appelée l'**effet de disposition** : les investisseurs influencés par l'aversion aux pertes ont tendance à vendre leurs placements gagnants trop tôt, en concrétisant un gain modeste pour « se sentir bien » et éviter le risque de voir ce gain disparaître — tout en gardant leurs placements perdants bien plus longtemps que les données fondamentales ne le justifieraient, en espérant éviter de « matérialiser » la perte simplement en ne vendant pas, même quand les perspectives du placement se sont réellement détériorées.

[VERIFIED FACT] Ce comportement a été documenté dans de grands ensembles de données sur les opérations réelles d'investisseurs, qui montrent une tendance générale à vendre les gagnants plus souvent que les perdants, compte tenu du rendement réel de chaque position — un comportement qui, s'il est suivi de façon constante, peut nuire systématiquement aux rendements à long terme en coupant trop tôt les positions gagnantes et en laissant courir les positions perdantes.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse détient deux positions : l'une a gagné 15 %, l'autre a perdu 15 %. Influencée par l'aversion aux pertes, elle vend la position gagnante pour « encaisser » le gain et ressentir un sentiment d'accomplissement, et garde la position perdante en se disant qu'elle la vendra une fois qu'elle sera « revenue à l'équilibre », pour ne pas avoir à accepter la perte. [ASSUMPTION] Si la position gagnante continue de bien performer après sa vente, et que la position perdante continue de baisser pendant qu'elle la garde en attendant un rebond qui pourrait ne jamais venir, ce comportement — provoqué par l'asymétrie émotionnelle de l'aversion aux pertes plutôt que par les perspectives réelles de chaque placement — lui a coûté plus cher qu'une décision fondée uniquement sur les données fondamentales de chaque position.

## Quiz de pratique

1. Que décrit l'aversion aux pertes?
2. Qu'est-ce que l'« effet de disposition », et comment découle-t-il de l'aversion aux pertes?
3. Pourquoi suivre ce comportement de façon constante peut-il nuire aux rendements à long terme?

## Corrigé

1. La tendance de la douleur émotionnelle d'une perte à peser plus lourd que le plaisir émotionnel d'un gain équivalent.
2. La tendance à vendre ses placements gagnants trop tôt (pour concrétiser un sentiment agréable) et à garder ses placements perdants trop longtemps (pour éviter l'inconfort de matérialiser une perte) — une conséquence comportementale directe de l'aversion aux pertes.
3. Parce qu'il coupe systématiquement les positions gagnantes avant qu'elles aient fini leur course, tout en laissant les positions perdantes continuer de baisser, au lieu de fonder les décisions de vente sur les perspectives réelles de chaque placement.

## Réponses et explications

1. C'est la notion psychologique de base de la leçon.
2. C'est le comportement de placement précis, et nommé, qui découle de l'aversion aux pertes.
3. Ça explique la conséquence pratique de ce comportement, qui nuit aux rendements.

## Points clés à retenir
- L'aversion aux pertes décrit la tendance des pertes à être plus douloureuses que des gains équivalents sont agréables.
- Elle peut mener à l'effet de disposition : vendre ses gagnants trop tôt et garder ses perdants trop longtemps.
- Ce comportement, bien documenté dans les données d'opérations réelles, peut nuire systématiquement aux rendements à long terme s'il est suivi de façon constante.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
