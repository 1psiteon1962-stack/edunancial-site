---
id: WHITE-L3-028
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 28
title: "Pourquoi le biais de récence fausse la perception du risque après un mouvement de marché"
summary: "Découvre pourquoi les investisseurs ont tendance à accorder trop de poids aux événements récents quand ils évaluent le risque, et pourquoi ça peut mener à des décisions mal synchronisées."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-028 : Pourquoi le biais de récence fausse la perception du risque après un mouvement de marché

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Définir le biais de récence
- Expliquer pourquoi les événements récents du marché semblent plus prédictifs de l'avenir qu'ils ne le sont réellement
- Expliquer comment le biais de récence peut pousser les investisseurs vers des décisions mal synchronisées, autant dans les marchés en hausse que dans les marchés en baisse

## Contenu principal

Le **biais de récence** décrit la tendance à accorder plus de poids aux événements récents quand on forme ses attentes sur l'avenir, par rapport au poids que justifierait réellement un portrait historique plus complet.

Voici « pourquoi » ça fausse les décisions de placement : après une longue période de fortes hausses du marché, le biais de récence peut faire paraître la poursuite de rendements élevés comme la situation normale attendue — ce qui amène les investisseurs à prendre plus de risques ou à investir de façon plus agressive au moment même où les conditions pourraient être en train de changer. Après une longue baisse, le même biais peut faire paraître la poursuite des baisses comme inévitable, ce qui amène les investisseurs à vendre ou à éviter d'investir au moment même où les tendances historiques (et la discussion de la leçon 1 sur les « creux » évidents après coup) pourraient laisser croire qu'une reprise finira par suivre.

[VERIFIED FACT] Ce biais est un comportement bien documenté dans la recherche comportementale, distinct d'une mise à jour rationnelle des attentes fondée sur une information vraiment nouvelle — le biais de récence accorde précisément trop de poids à la tendance *la plus récente*, au lieu de tenir compte de l'ensemble plus large des résultats historiques et de leurs probabilités variables.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Après plusieurs années de hausses du marché fortes et régulières, un investisseur en vient à considérer ce rythme de croissance comme l'attente normale pour l'avenir, ce qui l'amène à prendre plus de risques de placement qu'il ne l'avait prévu au départ. Après une forte baisse qui suit, cette impression s'inverse — la baisse récente semble maintenant devoir simplement se poursuivre, ce qui l'amène à vendre près du creux et à éviter de réinvestir même quand les conditions commencent à se stabiliser. [ASSUMPTION] Dans les deux cas, ses attentes ont été façonnées de façon disproportionnée par la période la plus récente plutôt que par une perspective historique plus complète sur la façon dont les marchés ont traversé, avec le temps, des cycles de hausse et de baisse.

## Quiz de pratique

1. Que décrit le biais de récence?
2. Comment le biais de récence peut-il influencer le comportement des investisseurs après une longue période de fortes hausses du marché?
3. Comment le biais de récence peut-il influencer le comportement des investisseurs après une longue baisse?

## Corrigé

1. La tendance à accorder un poids disproportionné aux événements récents quand on forme ses attentes sur l'avenir, par rapport à un portrait historique plus complet.
2. Il peut faire paraître la poursuite de rendements élevés comme la situation normale attendue, ce qui amène les investisseurs à prendre plus de risques au moment même où les conditions pourraient être en train de changer.
3. Il peut faire paraître la poursuite des baisses comme inévitable, ce qui amène les investisseurs à vendre ou à éviter d'investir au moment même où les tendances historiques pourraient laisser croire qu'une reprise finira par suivre.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. Ça applique le biais au scénario de hausse, en le reliant à une prise de risque excessive.
3. Ça applique le biais au scénario de baisse, en le reliant au défi central de la leçon 1.

## Points clés à retenir
- Le biais de récence accorde un poids disproportionné aux événements récents quand on forme ses attentes sur l'avenir.
- Après de fortes hausses, il peut mener à une prise de risque excessive; après des baisses, il peut mener à vendre à des moments mal choisis.
- Ce biais accorde trop de poids à la tendance la plus récente au lieu de tenir compte de l'ensemble plus large des comportements historiques du marché.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Le rendement passé ne garantit pas les résultats futurs. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
