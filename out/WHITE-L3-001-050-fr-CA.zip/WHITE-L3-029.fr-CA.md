---
id: WHITE-L3-029
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 29
title: "Pourquoi l'inflation gruge le pouvoir d'achat même dans un portefeuille « sûr »"
summary: "Découvre pourquoi détenir uniquement des actifs très stables et peu rentables peut quand même te faire perdre du pouvoir d'achat avec le temps, même sans aucune perte de marché."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-029 : Pourquoi l'inflation gruge le pouvoir d'achat même dans un portefeuille « sûr »

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer la différence entre le rendement nominal et le rendement réel (rajusté selon l'inflation)
- Expliquer pourquoi un portefeuille « sûr » et peu rentable peut quand même perdre du pouvoir d'achat avec le temps
- Relier cette notion à la discussion sur la monnaie fiduciaire abordée ailleurs dans ce programme

## Contenu principal

Le **rendement nominal** d'un placement est son gain annoncé en pourcentage, sans rajustement pour l'inflation. Son **rendement réel** soustrait l'inflation de ce chiffre nominal et montre la variation réelle du pouvoir d'achat. Cette distinction se relie directement à la discussion sur la monnaie fiduciaire ailleurs dans ce programme : si le pouvoir d'achat de la monnaie fiduciaire a tendance à diminuer avec le temps, un placement qui ne dépasse pas cette diminution perd de la valeur réelle, même si son solde nominal augmente techniquement ou reste stable.

Voici « pourquoi » un portefeuille « sûr » peut quand même être risqué en termes réels : des actifs très stables et peu rentables — de l'argent comptant dans un compte à faible taux d'intérêt, par exemple — peuvent éviter complètement la volatilité du marché, mais si leur rendement ne suit pas l'inflation, le pouvoir d'achat de cet argent diminue chaque année, même si le montant nominal en dollars ne baisse pas du tout. [VERIFIED FACT] On appelle parfois ça le risque d'inflation, et il est facile de le négliger parce qu'il n'apparaît pas comme une perte visible sur un relevé de compte, comme le ferait une baisse du marché — le chiffre lui-même ne baisse pas, mais ce qu'il permet d'acheter, oui.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un investisseur garde 50 000 $ en argent comptant, à un taux d'intérêt très bas, précisément pour éviter tout risque de marché. [ASSUMPTION] Si l'inflation est nettement plus élevée que ce taux d'intérêt pendant plusieurs années, le solde de 50 000 $ lui-même ne diminue pas — il pourrait même augmenter un peu grâce aux intérêts —, mais les biens et les services que ces 50 000 $ permettent d'acheter ont discrètement diminué, puisque les prix ont augmenté plus vite que le compte. Le relevé de compte n'affiche jamais de « perte », ce qui rend cette érosion facile à manquer par rapport à une baisse visible du marché.

## Quiz de pratique

1. Quelle est la différence entre le rendement nominal et le rendement réel?
2. Pourquoi un portefeuille « sûr » et peu rentable peut-il quand même perdre de la valeur réelle avec le temps?
3. Pourquoi le risque d'inflation est-il facile à négliger par rapport au risque de marché?

## Corrigé

1. Le rendement nominal est le gain annoncé en pourcentage, sans rajustement pour l'inflation; le rendement réel soustrait l'inflation pour montrer la variation réelle du pouvoir d'achat.
2. Parce que, si le rendement ne suit pas l'inflation, le pouvoir d'achat de l'argent diminue même si sa valeur nominale en dollars est stable ou augmente.
3. Parce que le solde du compte lui-même ne diminue pas de façon visible comme lors d'une baisse du marché — l'érosion se produit dans ce que l'argent permet d'acheter, et non dans le chiffre affiché sur un relevé.

## Réponses et explications

1. C'est la distinction de base autour de laquelle la leçon est construite.
2. C'est le risque central, facile à négliger, que la leçon met en lumière.
3. Ça explique pourquoi ce risque précis est psychologiquement facile à manquer par rapport à une perte de marché.

## Points clés à retenir
- C'est le rendement réel, et non le rendement nominal, qui reflète la variation réelle du pouvoir d'achat d'un placement.
- Un portefeuille « sûr » et peu rentable peut quand même perdre de la valeur réelle avec le temps si son rendement ne suit pas l'inflation.
- Le risque d'inflation est facile à négliger parce qu'il n'apparaît pas comme une perte visible sur un relevé de compte.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
