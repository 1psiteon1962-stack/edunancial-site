---
id: WHITE-L3-030
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 30
title: "Pourquoi différents actifs réagissent différemment à l'inflation"
summary: "Découvre pourquoi certains placements ont tendance à mieux résister que d'autres pendant les périodes d'inflation, et pourquoi il n'existe aucune protection parfaite contre l'inflation."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-030 : Pourquoi différents actifs réagissent différemment à l'inflation

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi les actifs à revenu fixe sont généralement plus vulnérables à l'inflation que les actifs qui ont un potentiel de croissance
- Nommer des exemples de types d'actifs souvent présentés comme des protections possibles contre l'inflation
- Expliquer pourquoi aucun actif n'est une protection garantie et parfaite contre l'inflation

## Contenu principal

La leçon 29 a établi que l'inflation gruge le pouvoir d'achat. Voici « pourquoi » différents types d'actifs réagissent différemment à cette érosion : les actifs qui versent des paiements fixes et immuables — comme la plupart des obligations traditionnelles — n'ont aucun mécanisme intégré pour augmenter leurs versements si l'inflation monte, ce qui expose directement leur valeur réelle au risque d'inflation. Les actifs liés à des revenus, à des profits ou à une valeur physique qui croissent — des actions d'entreprises capables d'augmenter leurs prix, de l'immobilier dont les loyers peuvent être ajustés, ou certaines obligations gouvernementales conçues précisément pour s'ajuster à l'inflation — ont plus de chances de suivre la hausse des prix avec le temps.

[VERIFIED FACT] Les protections possibles contre l'inflation souvent citées comprennent les actions (en particulier celles d'entreprises qui ont un pouvoir de fixation des prix), l'immobilier, certaines marchandises et les obligations gouvernementales indexées à l'inflation — mais aucune n'est une protection garantie ou parfaite dans chaque période d'inflation; chacune peut aussi être touchée par d'autres facteurs (taux d'intérêt, conditions économiques, enjeux propres à un secteur) qui peuvent compenser, voire dépasser, tout avantage lié à l'inflation pendant une période donnée.

C'est pourquoi se demander « quel actif unique protège contre l'inflation » simplifie trop la notion — une approche plus réaliste traite la résistance à l'inflation comme un facteur parmi plusieurs à évaluer dans un portefeuille diversifié, plutôt que comme un problème réglé par un seul placement.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Pendant une période de hausse de l'inflation, une entreprise capable de refiler ses coûts plus élevés à ses clients en augmentant ses prix peut mieux maintenir ses marges de profit et la valeur de son action qu'une obligation qui verse un taux fixe établi avant le début de la période d'inflation. [ASSUMPTION] Toutefois, si cette même période d'inflation s'accompagne aussi d'une hausse des taux d'intérêt qui nuit à l'évaluation des actions en général (un facteur distinct), le rendement de l'action pourrait ne pas refléter uniquement l'avantage de protection contre l'inflation — ce qui montre pourquoi aucun actif ne réagit à l'inflation de façon complètement isolée de tout ce qui se passe sur le marché au même moment.

## Quiz de pratique

1. Pourquoi les actifs à revenu fixe, comme les obligations traditionnelles, sont-ils généralement plus vulnérables à l'inflation que les actifs qui ont un potentiel de croissance?
2. Nomme deux types d'actifs souvent présentés comme des protections possibles contre l'inflation.
3. Pourquoi aucun actif n'est-il considéré comme une protection garantie et parfaite contre l'inflation?

## Corrigé

1. Parce que leurs paiements sont fixes et ne s'ajustent pas à la hausse si l'inflation monte, ce qui expose directement leur valeur réelle à l'érosion causée par l'inflation.
2. Deux parmi les suivants : les actions (surtout celles d'entreprises qui ont un pouvoir de fixation des prix), l'immobilier, certaines marchandises, les obligations gouvernementales indexées à l'inflation.
3. Parce que chaque type d'actif peut aussi être touché par d'autres facteurs sans lien (comme les variations des taux d'intérêt ou des conditions propres à un secteur) qui peuvent compenser ou dépasser tout avantage lié à l'inflation pendant une période donnée.

## Réponses et explications

1. Ça se relie directement à la vulnérabilité des paiements fixes décrite de façon plus générale à la leçon 29.
2. Ça fournit des exemples concrets tirés de catégories souvent citées.
3. C'est une mise en garde importante et nuancée contre une vision trop simple des stratégies de protection contre l'inflation.

## Points clés à retenir
- Les actifs à revenu fixe sont généralement plus vulnérables à l'inflation, puisque leurs paiements ne s'ajustent pas à la hausse.
- Les actions, l'immobilier, les marchandises et les obligations indexées à l'inflation sont souvent présentés comme des protections possibles contre l'inflation.
- Aucun actif n'est une protection garantie et parfaite contre l'inflation, puisque d'autres facteurs peuvent compenser ou dépasser tout avantage lié à l'inflation.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
