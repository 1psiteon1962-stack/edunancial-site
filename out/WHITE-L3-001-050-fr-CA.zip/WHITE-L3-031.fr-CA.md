---
id: WHITE-L3-031
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 31
title: "Pourquoi le risque de change touche les placements internationaux"
summary: "Découvre pourquoi investir dans des actifs libellés en devise étrangère ajoute une couche de risque distincte du rendement du placement lui-même."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-031 : Pourquoi le risque de change touche les placements internationaux

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce qu'est le risque de change
- Expliquer pourquoi le rendement d'un placement international dépend de deux facteurs distincts
- Expliquer pourquoi les mouvements des devises peuvent aider ou nuire au rendement, indépendamment du rendement du placement sous-jacent

## Contenu principal

Quand un investisseur achète un placement international — une action ou une obligation étrangère, par exemple —, ce placement est habituellement évalué dans sa devise locale. Reconvertir les rendements dans la devise du pays de l'investisseur ajoute un facteur distinct : le **risque de change**, soit le risque que les mouvements du taux de change entre les deux devises influent sur le rendement réel de l'investisseur, indépendamment du rendement du placement sous-jacent lui-même.

Voici « pourquoi » ça crée deux facteurs distincts dans le rendement total : le placement pourrait avoir un bon rendement dans sa devise locale, mais si cette devise locale s'affaiblit fortement par rapport à la devise de l'investisseur avant la conversion, une partie ou la totalité de ce gain pourrait être annulée. À l'inverse, un rendement modeste en devise locale, combiné à une devise qui se raffermit par rapport à celle de l'investisseur, pourrait donner un meilleur rendement total que ce que le rendement local seul laisserait croire.

[VERIFIED FACT] Les mouvements des devises peuvent être difficiles à prévoir et dépendent de nombreux facteurs, dont les écarts de taux d'intérêt entre les pays, les conditions économiques et le climat général du marché — certains fonds internationaux offrent des versions couvertes contre le risque de change, conçues précisément pour réduire ce risque en rapprochant le rendement de l'investisseur du seul rendement local du placement sous-jacent, même si la couverture comporte elle-même des coûts et des compromis.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse achète des actions d'une entreprise étrangère qui montent de 10 % dans leur devise locale en un an. Si cette devise locale s'affaiblit de 8 % par rapport à la devise de l'investisseuse pendant la même période, son rendement réel, une fois reconverti, se rapproche plutôt de 2 % — la majeure partie du gain local a été annulée par le mouvement défavorable de la devise. [ASSUMPTION] Si cette devise locale s'était plutôt raffermie de 8 % par rapport à sa devise, son rendement converti aurait pu se rapprocher de 18 % — le mouvement de la devise jouant en sa faveur en plus du gain sous-jacent de 10 %.

## Quiz de pratique

1. Qu'est-ce que le risque de change?
2. Pourquoi le rendement total d'un placement international dépend-il de deux facteurs distincts?
3. À quoi sert un fonds couvert contre le risque de change?

## Corrigé

1. Le risque que les mouvements du taux de change entre la devise de l'investisseur et la devise locale du placement influent sur le rendement réel de l'investisseur, indépendamment du rendement du placement lui-même.
2. Parce que le rendement dépend à la fois du rendement du placement sous-jacent dans sa devise locale et de l'évolution de la valeur de cette devise locale par rapport à la devise de l'investisseur avant la conversion.
3. À réduire le risque de change en rapprochant le rendement de l'investisseur du rendement du placement sous-jacent en devise locale, même si ça comporte des coûts et des compromis.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. C'est la notion centrale des « deux facteurs » qu'explique la leçon.
3. Ça présente l'outil conçu pour gérer ce risque précis, avec une mise en garde honnête sur ses compromis.

## Points clés à retenir
- Le risque de change est le risque que les mouvements du taux de change influent sur le rendement d'un placement international, indépendamment du rendement du placement lui-même.
- Le rendement total d'un placement international dépend à la fois du rendement en devise locale et du mouvement de cette devise par rapport à celle de l'investisseur.
- Les fonds couverts contre le risque de change sont conçus pour réduire ce risque précis, même si la couverture comporte des coûts et des compromis.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Tous les chiffres sont des estimations à titre d'illustration, et non des garanties. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
