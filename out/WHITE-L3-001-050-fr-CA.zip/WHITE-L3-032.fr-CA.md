---
id: WHITE-L3-032
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 32
title: "Pourquoi les FPI te permettent d'investir en immobilier sans acheter de propriété"
summary: "Découvre comment fonctionnent les fiducies de placement immobilier, pourquoi elles se négocient comme des actions et comment elles relient les parcours RED et WHITE de ce programme."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-032 : Pourquoi les FPI te permettent d'investir en immobilier sans acheter de propriété

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce qu'est une FPI
- Expliquer pourquoi les FPI permettent aux investisseurs d'être exposés à l'immobilier sans détenir directement de propriété
- Relier cette notion aux concepts d'effet de levier et de flux de trésorerie abordés dans le parcours RED de ce programme

## Contenu principal

Une **FPI (fiducie de placement immobilier)** est une entité qui possède, exploite ou finance de l'immobilier productif de revenus, et dont les parts peuvent être achetées et vendues en bourse, comme n'importe quelle autre action cotée — ce qui fait le pont entre les parcours RED (Immobilier) et WHITE (Actifs papier) de ce programme.

Voici « pourquoi » les FPI offrent une expérience différente de l'achat direct d'une propriété, tel qu'abordé tout au long du parcours RED : un investisseur dans une FPI achète des parts qui représentent une participation dans un portefeuille diversifié de propriétés (souvent de nombreuses propriétés dans divers marchés), sans gérer directement les locataires, s'occuper de l'entretien ou organiser le financement de chaque propriété — ces responsabilités relèvent de l'équipe de gestion de la FPI. En échange, l'investisseur renonce habituellement au contrôle direct et aux traitements fiscaux précis (comme l'amortissement, abordé dans le parcours RED) dont peut profiter un propriétaire direct.

[VERIFIED FACT] Les FPI sont généralement tenues de distribuer une grande majorité de leur revenu imposable à leurs porteurs de parts, ce qui explique en partie pourquoi elles sont souvent reconnues pour des rendements de distribution relativement élevés par rapport à de nombreuses autres catégories d'actions — même si, comme on l'a vu à la leçon 17, une distribution représente toujours une redistribution de valeur, et non une prime qui s'y ajoute.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse veut être exposée à l'immobilier commercial, mais n'a ni le capital, ni le temps, ni l'envie de gérer directement un immeuble locatif financé par effet de levier, comme on le décrit tout au long du parcours RED de ce programme. Elle achète plutôt des parts d'une FPI qui possède un grand portefeuille d'immeubles de bureaux et de commerces. Elle obtient une exposition au revenu et à l'appréciation possible de l'immobilier, reçoit des distributions régulières tirées des revenus locatifs de la FPI, et peut acheter ou vendre ses parts en bourse en tout temps pendant les heures de marché — une expérience très différente de l'« investissement immobilier » qui consiste à financer et à gérer directement un immeuble locatif.

## Quiz de pratique

1. Qu'est-ce qu'une FPI?
2. Qu'est-ce qu'un investisseur dans une FPI gagne, et à quoi renonce-t-il, par rapport à la détention directe d'une propriété?
3. Pourquoi les FPI sont-elles souvent reconnues pour des rendements de distribution relativement élevés?

## Corrigé

1. Une entité qui possède, exploite ou finance de l'immobilier productif de revenus, dont les parts se négocient en bourse comme d'autres actions cotées.
2. Il obtient une exposition diversifiée à l'immobilier sans responsabilités de gestion directe ni décisions de financement propriété par propriété, mais renonce au contrôle direct et à certains traitements fiscaux (comme l'amortissement) dont peut profiter un propriétaire direct.
3. Parce que les FPI sont généralement tenues de distribuer une grande majorité de leur revenu imposable à leurs porteurs de parts.

## Réponses et explications

1. C'est la définition de base qui relie les notions des parcours RED et WHITE.
2. C'est le compromis central que met en lumière la leçon entre le placement dans une FPI et la détention directe d'une propriété.
3. Ça se relie à une exigence structurelle propre aux FPI, tout en rappelant la mise en garde de la leçon 17 sur les dividendes.

## Points clés à retenir
- Les FPI permettent aux investisseurs d'être exposés à l'immobilier au moyen de parts cotées en bourse, sans les responsabilités liées à la détention directe d'une propriété.
- Elles échangent le contrôle direct et certains avantages fiscaux contre la liquidité et la diversification.
- L'obligation des FPI de distribuer une grande partie de leur revenu explique pourquoi elles sont souvent reconnues pour des rendements de distribution relativement élevés.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
