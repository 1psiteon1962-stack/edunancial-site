---
id: WHITE-L3-033
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 33
title: "Pourquoi la concentration sectorielle augmente le risque même dans un portefeuille qui semble diversifié"
summary: "Découvre pourquoi détenir de nombreuses actions concentrées dans le même secteur peut laisser un portefeuille plus exposé au risque qu'il n'y paraît à première vue."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-033 : Pourquoi la concentration sectorielle augmente le risque même dans un portefeuille qui semble diversifié

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce que veut dire la concentration sectorielle
- Expliquer pourquoi un portefeuille peut sembler diversifié par le nombre de titres tout en étant concentré dans un secteur
- Relier cette notion à la discussion sur la corrélation de la leçon 3

## Contenu principal

La leçon 3 a établi que c'est la corrélation, et pas seulement le nombre de titres, qui détermine la vraie diversification. La **concentration sectorielle** est une façon précise et courante dont le risque de corrélation se manifeste : un portefeuille qui détient de nombreuses entreprises différentes, toutes actives dans la même industrie ou le même secteur.

Voici « pourquoi » ça compte : les entreprises d'un même secteur réagissent souvent à bon nombre des mêmes forces économiques et réglementaires — les entreprises technologiques touchées par les mêmes changements dans les dépenses technologiques, les entreprises énergétiques touchées par les mêmes mouvements des prix des marchandises, les entreprises de soins de santé touchées par les mêmes changements réglementaires. [VERIFIED FACT] Cette sensibilité commune veut dire qu'un portefeuille peut détenir un grand nombre d'actions individuelles et quand même se comporter, dans l'ensemble, un peu comme un pari concentré sur le sort de ce seul secteur — la corrélation entre les titres mine l'avantage de diversification que suggérerait leur simple nombre.

C'est pourquoi l'évaluation de la diversification d'un portefeuille devrait inclure un examen précis de l'exposition sectorielle, et pas seulement un simple décompte du nombre d'entreprises détenues.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse détient 25 actions différentes et se sent bien diversifiée en se fiant à ce seul nombre. En regardant de plus près, 20 de ces 25 actions sont des entreprises technologiques. Si une baisse générale touche précisément le secteur technologique — une variation des taux d'intérêt qui nuit particulièrement à l'évaluation des entreprises technologiques à forte croissance, par exemple —, la grande majorité de son portefeuille est exposée à cette même pression en même temps, malgré un nombre de titres qui semble diversifié. [ASSUMPTION] Un portefeuille qui compterait les mêmes 25 titres au total, mais répartis de façon plus équilibrée entre plusieurs secteurs différents, subirait probablement un effet global plus petit de cette même baisse propre à un secteur.

## Quiz de pratique

1. Qu'est-ce que la concentration sectorielle?
2. Pourquoi un portefeuille qui détient de nombreuses actions individuelles peut-il quand même se comporter comme un pari concentré?
3. Comment cette leçon se relie-t-elle à la notion de corrélation de la leçon 3?

## Corrigé

1. Un portefeuille qui détient de nombreuses entreprises concentrées dans la même industrie ou le même secteur, plutôt que réparties entre différents secteurs.
2. Parce que les entreprises d'un même secteur réagissent souvent à bon nombre des mêmes forces économiques et réglementaires, ce qui rend leurs rendements fortement corrélés même s'il s'agit techniquement d'entreprises différentes.
3. La concentration sectorielle est un exemple courant et précis du problème de corrélation présenté à la leçon 3 — de nombreux titres qui évoluent ensemble procurent beaucoup moins de vraie diversification que leur nombre seul le laisse croire.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. Ça applique directement la notion de corrélation de la leçon 3 à une situation concrète et courante.
3. Ça boucle explicitement la boucle entre les deux leçons, ce qui renforce la structure intégrée du parcours.

## Points clés à retenir
- La concentration sectorielle veut dire que les titres d'un portefeuille sont regroupés dans la même industrie, même si le nombre total de titres semble diversifié.
- Les entreprises d'un même secteur ont tendance à être fortement corrélées, ce qui mine l'avantage de diversification que suggérerait le seul nombre de titres.
- La diversification d'un portefeuille devrait être évaluée selon l'exposition sectorielle, et pas seulement selon le nombre d'entreprises détenues.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
