---
id: WHITE-L3-034
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 34
title: "Pourquoi la répartition de l'actif compte plus que le choix d'actions individuelles"
summary: "Découvre pourquoi la composition des catégories d'actifs d'un portefeuille a tendance à influencer davantage les résultats à long terme que les actions précises choisies dans chaque catégorie."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-034 : Pourquoi la répartition de l'actif compte plus que le choix d'actions individuelles

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Définir la répartition de l'actif
- Expliquer pourquoi la recherche a généralement constaté que la répartition de l'actif influence davantage les résultats d'un portefeuille à long terme que le choix des titres individuels
- Expliquer pourquoi ça ne veut pas dire que les choix de placement individuels n'ont aucune importance

## Contenu principal

La **répartition de l'actif** désigne la façon dont un portefeuille est divisé entre de grandes catégories de placements — actions, obligations, immobilier, encaisse et autres —, plutôt que les titres précis choisis dans chaque catégorie.

Voici « pourquoi » la répartition a tendance à compter plus que les choix individuels pour la plupart des investisseurs à long terme : [VERIFIED FACT] diverses recherches universitaires et de l'industrie sur le rendement des portefeuilles ont généralement constaté que les grandes décisions de répartition de l'actif expliquent une part importante de la variation du rendement à long terme des portefeuilles d'un investisseur à l'autre, davantage que les titres précis choisis dans chaque catégorie d'actifs — même si les constats et les méthodes varient d'une étude à l'autre, et que le choix des titres individuels peut quand même influer de façon importante sur les résultats à l'intérieur d'une répartition donnée.

Ça se relie aux notions abordées tout au long de ce parcours : puisque la diversification à l'intérieur d'une catégorie d'actifs (leçons 2 et 3) réduit déjà une grande partie du risque propre aux entreprises, le principal facteur restant du profil de risque et de rendement global d'un portefeuille devient la composition générale entre des catégories d'actifs aux caractéristiques de risque et de rendement vraiment différentes — les actions offrant généralement un plus grand potentiel de croissance à long terme avec plus de volatilité, les obligations offrant généralement plus de stabilité avec un potentiel de croissance à long terme plus faible, et ainsi de suite.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Deux investisseurs détiennent tous deux des portefeuilles bien diversifiés à l'intérieur des catégories d'actifs qu'ils ont choisies, mais l'investisseur A répartit 80 % en actions et 20 % en obligations, alors que l'investisseur B répartit 30 % en actions et 70 % en obligations. [ASSUMPTION] Sur une longue période, la différence de rendement et de volatilité globaux de leurs portefeuilles dépendra probablement en grande partie de cet écart de répartition générale, plutôt que des actions ou des obligations précises que chacun a choisies à l'intérieur de sa répartition — même si les deux ont fait des choix individuels raisonnablement judicieux.

## Quiz de pratique

1. Que désigne la répartition de l'actif?
2. Qu'a généralement constaté la recherche sur l'importance relative de la répartition de l'actif par rapport au choix des titres individuels pour les résultats d'un portefeuille à long terme?
3. Est-ce que ça veut dire que le choix des titres individuels n'a aucune importance? Pourquoi?

## Corrigé

1. La façon dont un portefeuille est divisé entre de grandes catégories de placements, comme les actions, les obligations, l'immobilier et l'encaisse.
2. Que les décisions de répartition de l'actif ont tendance à expliquer une part importante de la variation du rendement à long terme des portefeuilles, davantage que les titres précis choisis dans chaque catégorie d'actifs, même si les constats varient d'une étude à l'autre.
3. Non — le choix des titres individuels peut quand même influer de façon importante sur les résultats à l'intérieur d'une répartition donnée; la leçon insiste sur l'importance relative, et non sur le fait que les choix individuels seraient sans importance.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. C'est l'affirmation centrale, fondée sur la recherche et nuancée, autour de laquelle la leçon est construite.
3. Ça évite une conclusion trop simple selon laquelle les choix individuels n'ont pas d'importance à l'intérieur d'une répartition.

## Points clés à retenir
- La répartition de l'actif désigne la façon dont un portefeuille est divisé entre de grandes catégories de placements comme les actions, les obligations et l'encaisse.
- La recherche a généralement constaté que les décisions de répartition influencent davantage les résultats à long terme d'un portefeuille que le choix des titres individuels, même si les deux comptent.
- Ça se relie aux notions de diversification des leçons précédentes — une fois le risque propre aux entreprises réduit par la diversification, la composition générale des actifs devient un facteur plus important des résultats.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Le rendement passé ne garantit pas les résultats futurs. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
