---
id: WHITE-L3-035
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 35
title: "Pourquoi une trajectoire de répartition réduit le risque à mesure que tu vieillis"
summary: "Découvre pourquoi de nombreuses stratégies de placement à long terme font passer graduellement la répartition d'un portefeuille d'une composition plus dynamique à une composition plus prudente, et pourquoi ce moment compte."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-035 : Pourquoi une trajectoire de répartition réduit le risque à mesure que tu vieillis

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce que désigne une « trajectoire de répartition » (*glide path*) dans une stratégie de placement
- Expliquer pourquoi le passage graduel à une répartition plus prudente se relie au risque de séquence des rendements
- Expliquer la logique générale qui consiste à réduire le risque à l'approche d'une date cible (comme la retraite)

## Contenu principal

Une **trajectoire de répartition** décrit un plan établi d'avance pour faire passer graduellement la répartition de l'actif d'un portefeuille (leçon 34) d'une composition plus dynamique, axée sur la croissance, à une composition plus prudente, axée sur la stabilité, à mesure qu'un investisseur approche d'une date cible précise — le plus souvent la retraite. Les fonds à date cible sont un exemple courant de produit de placement fondé sur cette notion.

Voici « pourquoi » ce moment compte, en lien direct avec le risque de séquence des rendements de la leçon 15 : un portefeuille dont on n'aura pas besoin avant de nombreuses années a plus de temps pour se remettre d'une baisse, de sorte qu'il peut habituellement se permettre de détenir plus d'actions pour leur plus grand potentiel de croissance à long terme. À mesure que la date cible approche et que le temps pour se remettre d'une baisse possible diminue, passer graduellement à des actifs plus stables (comme les obligations) réduit le risque de subir une forte baisse mal synchronisée juste avant d'avoir besoin de l'argent — précisément le risque décrit à la leçon 15.

[VERIFIED FACT] Les différentes trajectoires de répartition varient selon la vitesse, plus ou moins prudente, à laquelle elles évoluent avec le temps, et selon que le changement se poursuit ou non après la date cible — il n'existe pas de trajectoire universelle unique, et le bon rythme d'ajustement dépend de la situation personnelle et de la tolérance au risque.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Un fonds à date cible conçu pour une personne qui prendra sa retraite dans environ 30 ans pourrait commencer avec un portefeuille fortement axé sur les actions, en profitant du long horizon pour se remettre éventuellement des baisses en cours de route. À mesure que la date de retraite cible approche au fil des décennies, le fonds augmente graduellement sa part d'obligations et réduit son exposition aux actions, dans le but de rendre le portefeuille moins vulnérable à une baisse mal synchronisée au moment où l'investisseur pourrait devoir commencer à retirer des fonds.

## Quiz de pratique

1. Que décrit une « trajectoire de répartition »?
2. Pourquoi un portefeuille passe-t-il habituellement d'une composition plus dynamique à une composition plus prudente à l'approche d'une date cible?
3. Comment cette notion se relie-t-elle directement au risque de séquence des rendements de la leçon 15?

## Corrigé

1. Un plan établi d'avance pour faire passer graduellement la répartition de l'actif d'un portefeuille d'une composition plus dynamique à une composition plus prudente à l'approche d'une date cible, comme la retraite.
2. Parce qu'il reste moins de temps pour se remettre d'une baisse possible à mesure que la date cible approche, de sorte que réduire l'exposition aux actifs plus volatils aide à protéger contre une baisse mal synchronisée juste avant d'avoir besoin de l'argent.
3. Le risque de séquence des rendements a montré que de mauvais rendements juste avant ou pendant les retraits peuvent causer des dégâts disproportionnés — une trajectoire de répartition est conçue précisément pour réduire la vulnérabilité à ce risque en diminuant l'exposition à la volatilité à l'approche de la date cible.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. Ça explique la logique de fond qui relie l'horizon de placement au niveau de risque approprié.
3. Ça relie explicitement la notion à la leçon 15, ce qui renforce la structure intégrée du parcours.

## Points clés à retenir
- Une trajectoire de répartition fait passer graduellement la répartition d'un portefeuille d'une composition plus dynamique à une composition plus prudente à l'approche d'une date cible.
- Ce moment répond directement au risque de séquence des rendements, en réduisant la vulnérabilité à une baisse mal synchronisée près de la date cible.
- Les trajectoires de répartition varient, et le bon rythme d'ajustement dépend de la situation personnelle et de la tolérance au risque.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
