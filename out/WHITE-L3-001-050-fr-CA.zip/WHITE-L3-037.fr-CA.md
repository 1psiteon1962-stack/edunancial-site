---
id: WHITE-L3-037
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 37
title: "Pourquoi la récolte de pertes fiscales transforme une perte en avantage futur"
summary: "Découvre comment fonctionne la récolte de pertes fiscales, pourquoi elle transforme une perte non réalisée en avantage fiscal utilisable, et pourquoi le processus exige de la prudence."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-037 : Pourquoi la récolte de pertes fiscales transforme une perte en avantage futur

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer la notion générale de la récolte de pertes fiscales
- Expliquer pourquoi il faut « réaliser » une perte en vendant pour pouvoir l'utiliser à des fins fiscales
- Expliquer pourquoi cette stratégie exige de comprendre une règle abordée dans la prochaine leçon

## Contenu principal

La **récolte de pertes fiscales** est une stratégie générale qui consiste à vendre volontairement un placement qui a perdu de la valeur afin de « réaliser » la perte — c'est-à-dire d'en faire une perte réelle et comptabilisée à des fins fiscales plutôt qu'une simple perte non réalisée sur papier —, perte qui pourra ensuite servir à compenser des gains imposables ailleurs dans le portefeuille, sous réserve des règles fiscales précises qui s'appliquent dans un pays donné.

Voici « pourquoi » ça exige une vente réelle : tant qu'un placement est simplement détenu à une valeur inférieure à son prix d'achat, on considère généralement qu'il s'agit d'une perte non réalisée — elle existe sur papier, mais n'a pas encore été « cristallisée » par une transaction, et dans de nombreux régimes fiscaux, seule une perte réalisée peut être utilisée à des fins fiscales. Vendre la position transforme cette perte sur papier en perte réalisée.

[VERIFIED FACT] Comme de nombreux investisseurs veulent conserver leur exposition globale au marché ou leur stratégie de placement tout en récoltant une perte, ils réinvestissent souvent le produit de la vente immédiatement dans un placement semblable (mais pas identique) — ce qui fait intervenir une règle importante, abordée dans la prochaine leçon, qui limite la rapidité avec laquelle on peut racheter un placement essentiellement identique tout en pouvant déduire la perte fiscale.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse détient un fonds qui a perdu beaucoup de valeur depuis son achat. Au lieu de simplement continuer à le détenir, elle vend la position, ce qui réalise la perte à des fins fiscales, et réinvestit le produit dans un fonds semblable, mais pas identique, pour conserver à peu près la même exposition au marché. [ASSUMPTION] La perte réalisée pourrait servir, sous réserve des règles fiscales applicables, à compenser d'autres gains imposables qu'elle a réalisés ailleurs dans son portefeuille cette année-là, ce qui transforme un résultat qui semblait purement négatif en un avantage fiscal pratique, au moins partiel.

## Quiz de pratique

1. De façon générale, qu'est-ce que la récolte de pertes fiscales?
2. Pourquoi le simple fait de détenir un placement qui a baissé ne crée-t-il pas une perte fiscale utilisable dans de nombreux régimes fiscaux?
3. Pourquoi un investisseur pourrait-il réinvestir dans un placement semblable, mais pas identique, après avoir récolté une perte?

## Corrigé

1. Vendre volontairement un placement qui a baissé pour réaliser la perte à des fins fiscales, ce qui peut compenser des gains imposables ailleurs, sous réserve des règles applicables.
2. Parce qu'une perte non réalisée (sur papier) n'a pas été « cristallisée » par une transaction réelle, et que de nombreux régimes fiscaux exigent qu'une perte soit réalisée par une vente avant de pouvoir être utilisée.
3. Pour conserver à peu près la même exposition globale au marché ou la même stratégie de placement tout en réalisant la perte fiscale, plutôt que de simplement garder l'argent comptant ou de sortir complètement de cette partie du marché.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. Ça explique la raison mécanique pour laquelle une vente est nécessaire, une notion clé pour comprendre la stratégie.
3. Ça présente la raison pratique pour laquelle les investisseurs réinvestissent habituellement rapidement, ce qui introduit la contrainte abordée dans la prochaine leçon.

## Points clés à retenir
- La récolte de pertes fiscales réalise volontairement une perte par une vente, ce qui peut compenser d'autres gains imposables, sous réserve des règles fiscales applicables.
- Dans de nombreux régimes fiscaux, seule une perte réalisée, et non une perte non réalisée sur papier, peut habituellement être utilisée à des fins fiscales.
- Les investisseurs réinvestissent souvent dans un placement semblable pour conserver leur exposition au marché, ce qui fait intervenir une règle de délai importante abordée ensuite.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Les règles fiscales varient beaucoup d'un pays à l'autre; consulte un fiscaliste autorisé avant de mettre en œuvre toute stratégie fiscale.
