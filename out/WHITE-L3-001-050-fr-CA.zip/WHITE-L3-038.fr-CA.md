---
id: WHITE-L3-038
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 38
title: "Pourquoi la règle sur les pertes apparentes limite la récolte de pertes fiscales"
summary: "Découvre ce qu'est une perte apparente (*wash sale*), pourquoi cette règle existe et pourquoi elle limite directement la façon de faire la récolte de pertes fiscales."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-038 : Pourquoi la règle sur les pertes apparentes limite la récolte de pertes fiscales

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer la notion générale derrière une règle de type « perte apparente »
- Expliquer pourquoi cette règle existe
- Expliquer comment cette règle limite directement la stratégie de récolte de pertes fiscales de la leçon 37

## Contenu principal

La leçon 37 a expliqué que les investisseurs veulent souvent réinvestir rapidement après avoir récolté une perte fiscale, pour conserver leur exposition au marché. De nombreux régimes fiscaux prévoient une règle — souvent appelée règle sur les pertes apparentes (en anglais, *wash sale*) — conçue précisément pour empêcher un certain type d'abus de la récolte de pertes fiscales.

Voici « pourquoi » cette règle existe : sans elle, un investisseur pourrait vendre un placement uniquement pour réaliser une perte fiscale, puis racheter immédiatement exactement le même placement (ou un placement essentiellement identique), en conservant en fait exactement la même position tout en déduisant un avantage fiscal — ce que de nombreuses autorités fiscales considèrent comme un abus de la notion de réalisation d'une perte, plutôt que comme un vrai changement de position de placement.

[VERIFIED FACT] Les modalités précises d'une règle de type « perte apparente » — y compris la période exacte pendant laquelle le rachat du même titre ou d'un titre essentiellement identique fait refuser la perte, et la définition de « essentiellement identique » — varient selon le pays et sont fixées par des lois fiscales précises; dans ce domaine, des conseils à jour et propres à chaque pays comptent donc plus que des suppositions générales.

C'est pourquoi la récolte de pertes fiscales, telle que présentée à la leçon 37, consiste habituellement à réinvestir dans un placement réellement différent (même s'il est semblable sur le plan de la stratégie ou de l'exposition), plutôt que dans exactement le même placement, afin de respecter ce type de règle tout en conservant une position comparable sur le marché.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse vend un fonds à perte pour profiter de l'avantage fiscal, puis rachète exactement le même fonds dès le lendemain, avec l'intention de déduire la perte dans sa déclaration de revenus. [ASSUMPTION] Si une règle de type « perte apparente » dans son pays refuse les pertes en cas de rachat du même titre ou d'un titre essentiellement identique pendant une certaine période, cette transaction pourrait ne pas procurer l'avantage fiscal voulu — la perte pourrait être refusée en vertu de cette règle, malgré son intention de la récolter. Acheter plutôt un fonds réellement différent, mais positionné de façon semblable, éviterait habituellement ce problème précis, sous réserve des règles applicables.

## Quiz de pratique

1. Qu'est-ce qu'une règle de type « perte apparente » vise généralement à empêcher?
2. Selon cette leçon, pourquoi cette règle existe-t-elle?
3. Comment cette règle façonne-t-elle la façon de faire habituellement la récolte de pertes fiscales en pratique?

## Corrigé

1. Qu'un investisseur vende un placement uniquement pour réaliser une perte fiscale, puis rachète immédiatement le même placement ou un placement essentiellement identique tout en déduisant l'avantage fiscal.
2. Parce que ça permettrait en fait de conserver exactement la même position de placement tout en déduisant une perte, ce que de nombreuses autorités fiscales considèrent comme un abus de la notion de réalisation d'une perte.
3. Elle fait en sorte que les investisseurs réinvestissent habituellement le produit dans un placement réellement différent, mais positionné de façon semblable, plutôt que dans exactement le même, pour respecter la règle tout en conservant une exposition comparable au marché.

## Réponses et explications

1. C'est la notion de base derrière ce type de règle.
2. Ça explique la raison d'être de la règle sur le plan des politiques.
3. Ça se relie directement à la stratégie pratique décrite à la leçon 37, en montrant comment les deux notions fonctionnent ensemble.

## Points clés à retenir
- Une règle de type « perte apparente » refuse généralement une perte fiscale si le même placement, ou un placement essentiellement identique, est racheté pendant une certaine période.
- Cette règle existe pour empêcher les investisseurs de déduire une perte fiscale tout en conservant en fait exactement la même position de placement.
- Les modalités précises varient beaucoup selon le pays, ce qui rend des conseils professionnels à jour particulièrement importants dans ce domaine.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Les règles fiscales varient beaucoup d'un pays à l'autre; consulte un fiscaliste autorisé avant de mettre en œuvre toute stratégie fiscale.
