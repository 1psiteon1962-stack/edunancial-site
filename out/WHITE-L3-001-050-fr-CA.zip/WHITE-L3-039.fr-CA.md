---
id: WHITE-L3-039
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 39
title: "Pourquoi les gains en capital sont imposés différemment selon la période de détention"
summary: "Découvre pourquoi la durée pendant laquelle tu détiens un placement avant de le vendre peut influer sur l'imposition d'un gain, et pourquoi ça crée un vrai incitatif lié au moment de la vente."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-039 : Pourquoi les gains en capital sont imposés différemment selon la période de détention

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer la notion générale d'un traitement des gains en capital fondé sur la période de détention
- Expliquer pourquoi de nombreux régimes fiscaux traitent différemment les périodes de détention plus courtes et plus longues
- Expliquer pourquoi ça crée un vrai incitatif, voulu, lié au moment des placements

## Contenu principal

De nombreux régimes fiscaux distinguent les gains sur des placements détenus pendant une période plus courte de ceux sur des placements détenus plus longtemps avant leur vente, en appliquant souvent des taux d'imposition différents à chaque catégorie. [VERIFIED FACT] Les seuils de période de détention et les taux d'imposition applicables varient beaucoup selon le pays et sont fixés par des lois fiscales précises — connaître la notion de façon générale est utile, mais les chiffres exacts doivent être vérifiés pour une situation et un pays précis. (À noter : certains régimes, comme celui du Canada, n'appliquent pas ce type de distinction selon la durée de détention.)

Voici « pourquoi » cette distinction existe couramment : de nombreux régimes fiscaux sont conçus, au moins en partie, pour encourager la détention de placements à plus long terme plutôt que les opérations fréquentes à court terme, souvent en imposant à un taux plus élevé les gains sur des placements détenus moins longtemps que les gains sur des placements détenus plus longtemps.

Ça crée un vrai incitatif, voulu, qu'il vaut la peine de comprendre : un investisseur qui se demande s'il doit vendre un placement qui approche d'un seuil de période de détention pertinent peut raisonnablement tenir compte de l'écart d'impôt possible dans sa décision sur le moment de vendre — non pas comme seul critère, mais comme un facteur pertinent parmi d'autres, avec les perspectives du placement lui-même et ses objectifs plus larges.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse envisage de vendre un placement qui a pris beaucoup de valeur, et elle est sur le point d'atteindre un seuil de détention plus long qui, dans son pays, appliquerait un taux d'imposition plus avantageux au gain. [ASSUMPTION] Si ses perspectives globales sur ce placement n'ont pas vraiment changé, attendre un peu plus longtemps pour franchir ce seuil pourrait réduire l'impôt total à payer lors de la vente — même s'il faut peser cette option par rapport à sa vision réelle des perspectives et du risque du placement à court terme, et ne pas la traiter comme une règle qui l'emporte automatiquement sur ces considérations.

## Quiz de pratique

1. Quelle distinction générale de nombreux régimes fiscaux font-ils au sujet des gains en capital?
2. Selon cette leçon, pourquoi de nombreux régimes fiscaux appliquent-ils ce type de distinction?
3. Comment cette distinction peut-elle raisonnablement influer sur la décision d'un investisseur quant au moment de vendre?

## Corrigé

1. Une distinction entre les gains sur des placements détenus pendant une période plus courte et ceux sur des placements détenus plus longtemps, souvent imposés à des taux différents.
2. Pour encourager la détention de placements à plus long terme plutôt que les opérations fréquentes à court terme, souvent en appliquant un taux d'imposition plus élevé aux gains sur des placements détenus moins longtemps.
3. Un investisseur sur le point d'atteindre un seuil de détention plus long peut raisonnablement tenir compte de l'avantage fiscal possible d'attendre, comme un facteur pertinent parmi d'autres, avec les perspectives du placement et ses objectifs plus larges — et non comme seul critère de décision.

## Réponses et explications

1. C'est la base conceptuelle générale de la leçon, nuancée compte tenu des différences d'un pays à l'autre.
2. Ça explique la raison d'être générale souvent invoquée pour ce type de distinction.
3. Ça applique la notion de façon pratique tout en mettant en garde contre le fait de laisser les considérations fiscales l'emporter entièrement sur un bon jugement de placement.

## Points clés à retenir
- De nombreux régimes fiscaux appliquent des taux différents aux gains selon la durée pendant laquelle un placement a été détenu avant sa vente.
- Cette distinction vise souvent à encourager la détention à plus long terme plutôt que les opérations fréquentes à court terme.
- Le moment lié à la période de détention peut raisonnablement influer sur une décision de vente, mais doit être pesé avec les perspectives du placement, et non l'emporter automatiquement sur elles.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Les règles fiscales varient beaucoup d'un pays à l'autre; consulte un fiscaliste autorisé pour obtenir des conseils adaptés à ta situation.
