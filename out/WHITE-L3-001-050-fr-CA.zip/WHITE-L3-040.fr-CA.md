---
id: WHITE-L3-040
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 40
title: "Pourquoi le prix de base détermine ton vrai gain imposable"
summary: "Découvre ce que veut dire le prix de base, pourquoi il n'est pas toujours aussi simple que le prix d'achat initial, et pourquoi il est important d'en faire un suivi exact."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-040 : Pourquoi le prix de base détermine ton vrai gain imposable

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Définir le prix de base
- Expliquer pourquoi le prix de base peut être plus complexe que le seul prix d'achat initial
- Expliquer pourquoi un suivi exact du prix de base influe directement sur le calcul du gain imposable

## Contenu principal

Le **prix de base** (ou coût de base) désigne généralement la valeur d'origine utilisée pour déterminer un gain ou une perte imposable au moment où un placement est finalement vendu — dans sa forme la plus simple, le prix d'achat. Voici « pourquoi » c'est souvent plus complexe que cette simple description : le prix de base peut être ajusté par plusieurs facteurs pendant la période de détention, dont les dividendes réinvestis (leçon 17) qui ont servi à acheter des parts supplémentaires, puisque chaque réinvestissement établit habituellement son propre prix de base au prix de cet achat.

[VERIFIED FACT] Faire un suivi exact du prix de base compte directement, parce qu'il détermine le gain imposable calculé (prix de vente moins prix de base) lors de la vente d'un placement — sous-estimer le prix de base surestime le gain imposable, ce qui peut faire payer plus d'impôt que nécessaire, alors que surestimer le prix de base sous-estime le gain, ce qui peut créer des problèmes de conformité.

Dans de nombreux pays, les maisons de courtage doivent suivre et déclarer l'information sur le prix de base pour de nombreux types de comptes, ce qui en a fait un fardeau moins manuel pour les investisseurs qu'autrefois — mais comprendre la notion de fond reste utile, surtout dans les situations qui comportent plusieurs achats au fil du temps, des dividendes réinvestis, ou des comptes et des situations où le suivi du prix de base est moins automatisé.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse achète des parts d'un fonds sur plusieurs années, en ajoutant à sa position à différents moments, et ses dividendes sont aussi réinvestis automatiquement en parts supplémentaires en cours de route. Chacun de ces achats — les achats d'origine et chaque réinvestissement de dividendes — établit son propre prix de base au prix de cette transaction précise. [ASSUMPTION] Quand elle finit par vendre une partie de sa position totale, le gain imposable calculé dépend des parts précises (et de leur prix de base) considérées comme vendues, selon la méthode comptable utilisée — ce qui montre pourquoi le simple fait d'utiliser le tout premier prix d'achat comme « le » prix de base de toute la position serait probablement inexact. (Au Canada, par exemple, on utilise plutôt un prix de base rajusté moyen pour des parts identiques.)

## Quiz de pratique

1. Que désigne généralement le prix de base?
2. Pourquoi le prix de base peut-il être plus complexe que le simple prix d'achat initial?
3. Qu'arrive-t-il si le prix de base est sous-estimé lors du calcul d'un gain imposable?

## Corrigé

1. La valeur d'origine utilisée pour déterminer un gain ou une perte imposable lors de la vente d'un placement.
2. Parce que les achats supplémentaires au fil du temps, y compris les dividendes réinvestis, établissent chacun leur propre prix de base, ce qui fait du prix de base de la position totale une combinaison de plusieurs transactions plutôt qu'un seul chiffre.
3. Le gain imposable calculé est surestimé, ce qui peut faire payer plus d'impôt que réellement nécessaire.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. C'est la complexité centrale que met en lumière la leçon, directement reliée à la notion de dividendes réinvestis de la leçon 17.
3. Ça renforce l'importance pratique d'un suivi exact du prix de base.

## Points clés à retenir
- Le prix de base est la valeur d'origine utilisée pour calculer le gain ou la perte imposable lors d'une vente, et il est souvent plus complexe qu'un seul prix d'achat.
- Les dividendes réinvestis et les achats multiples au fil du temps établissent chacun leur propre prix de base, ce qui exige un suivi attentif.
- Un suivi exact du prix de base influe directement sur le gain imposable calculé, avec de vraies conséquences s'il est surestimé ou sous-estimé.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Les règles fiscales varient beaucoup d'un pays à l'autre; consulte un fiscaliste autorisé pour obtenir des conseils adaptés à ta situation.
