---
id: WHITE-L3-041
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 41
title: "Pourquoi un ordre stop ne garantit pas ton prix de sortie"
summary: "Découvre comment fonctionne un ordre stop de protection, et pourquoi il déclenche un ordre au marché plutôt que de garantir le prix exact que tu obtiendras."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-041 : Pourquoi un ordre stop ne garantit pas ton prix de sortie

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer comment fonctionne un ordre stop de protection
- Expliquer pourquoi il ne garantit pas l'exécution au prix de déclenchement indiqué
- Expliquer ce qu'un ordre stop à cours limité change à ce compromis

## Contenu principal

Un **ordre stop de protection** (*stop-loss*) est une instruction de vendre automatiquement un titre si son prix baisse jusqu'à un niveau précis, conçue pour aider à limiter les pertes sur une position sans que l'investisseur ait à surveiller le prix constamment.

Voici « pourquoi » il ne garantit pas un prix de sortie exact : une fois le prix de déclenchement atteint, un ordre stop ordinaire se transforme habituellement en **ordre au marché** — un ordre de vendre immédiatement au meilleur prix offert à ce moment-là, et non précisément au prix de déclenchement. Si le prix évolue rapidement, ou si le titre ouvre en forte baisse (en sautant par-dessus le prix de déclenchement sans aucune négociation entre les deux, ce qui peut arriver autour d'annonces importantes), l'ordre peut être exécuté à un prix nettement moins bon que le prix de déclenchement.

[VERIFIED FACT] Un **ordre stop à cours limité** est une variante qui fixe à la fois un prix de déclenchement (qui active l'ordre) et un cours limite (le pire prix que l'investisseur est prêt à accepter) — ça protège contre un prix d'exécution étonnamment mauvais, mais crée un risque différent : si le prix dépasse trop rapidement le cours limite, l'ordre pourrait ne pas être exécuté du tout, ce qui laisse la position invendue pendant la baisse même contre laquelle l'investisseur voulait se protéger.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse place un ordre stop de protection à 45 $ sur une action qui se négocie actuellement à 50 $, afin de limiter sa perte si le prix baisse. [ASSUMPTION] Si une mauvaise nouvelle fait ouvrir l'action en forte baisse le lendemain, à 38 $, sans aucune négociation entre 45 $ et 38 $, son ordre stop serait déclenché et exécuté près du nouveau prix d'ouverture, plus bas — et non au prix de 45 $ qu'elle visait —, ce qui donnerait une perte plus grande que celle contre laquelle elle croyait peut-être être protégée.

## Quiz de pratique

1. Que fait un ordre stop de protection?
2. Pourquoi un ordre stop ordinaire ne garantit-il pas l'exécution exactement au prix de déclenchement indiqué?
3. Quel compromis un ordre stop à cours limité crée-t-il par rapport à un ordre stop ordinaire?

## Corrigé

1. Il déclenche automatiquement une vente si le prix d'un titre baisse jusqu'à un niveau précis, ce qui aide à limiter les pertes sans surveillance constante du prix.
2. Parce qu'une fois déclenché, il se transforme habituellement en ordre au marché, exécuté au meilleur prix offert à ce moment-là — qui peut être nettement moins bon que le prix de déclenchement en période de mouvements rapides ou d'ouverture en forte baisse.
3. Il fixe une limite au pire prix d'exécution acceptable, ce qui protège contre une mauvaise exécution, mais comporte le risque que l'ordre ne soit pas exécuté du tout si le prix dépasse trop rapidement cette limite.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. C'est le mécanisme central qui explique la mise en garde « aucune garantie » du titre de la leçon.
3. Ça présente l'autre type d'ordre et son propre compromis.

## Points clés à retenir
- Un ordre stop de protection déclenche automatiquement une vente quand un prix précis est atteint, mais il est habituellement exécuté comme un ordre au marché au meilleur prix offert, pas forcément au prix de déclenchement.
- Une ouverture en forte baisse peut donner un prix d'exécution nettement moins bon que le prix de déclenchement.
- Un ordre stop à cours limité fixe un pire prix acceptable, ce qui protège contre une mauvaise exécution, mais comporte le risque de ne pas être exécuté du tout si le prix évolue trop vite.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
