---
id: WHITE-L3-042
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 42
title: "Pourquoi la liquidité diffère entre une action de premier ordre et une action peu négociée"
summary: "Découvre ce que veut dire la liquidité d'un titre, et pourquoi une action peu négociée peut être plus difficile et plus coûteuse à acheter ou à vendre que son seul prix ne le laisse croire."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-042 : Pourquoi la liquidité diffère entre une action de premier ordre et une action peu négociée

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Définir la liquidité dans le contexte d'un titre négocié
- Expliquer pourquoi une faible liquidité peut élargir l'écart entre le cours acheteur et le cours vendeur
- Expliquer pourquoi le risque de liquidité compte même pour un investisseur qui ne prévoit pas faire d'opérations fréquentes

## Contenu principal

La **liquidité** décrit la facilité avec laquelle un actif peut être acheté ou vendu sans influer de façon importante sur son prix, ce qui reflète généralement le niveau d'activité de négociation régulière (le volume) sur ce titre. Une action bien connue et largement négociée est habituellement très liquide : un grand nombre d'actions changent de mains constamment, et les ordres d'achat et de vente peuvent habituellement être exécutés rapidement à des prix très proches du dernier cours.

Voici « pourquoi » un titre peu négocié se comporte différemment : avec moins d'acheteurs et de vendeurs actifs, l'**écart acheteur-vendeur** (la différence entre le prix le plus élevé qu'un acheteur est prêt à payer à ce moment-là et le prix le plus bas qu'un vendeur est prêt à accepter) a tendance à être plus large. [VERIFIED FACT] Un écart plus large veut dire qu'un investisseur qui achète puis revend immédiatement un titre peu négocié perdrait généralement plus à cause de cet écart qu'avec un titre très liquide, avant même de tenir compte de tout mouvement de prix — c'est un coût implicite de la négociation dans un marché moins liquide.

Le risque de liquidité compte même pour un investisseur à long terme qui fait peu d'opérations : si tu dois un jour vendre une position peu négociée, surtout en grande quantité ou pendant une période de tension sur les marchés, tu pourrais devoir accepter un prix moins avantageux, ou vendre plus graduellement, pour éviter de faire baisser encore le prix par tes propres ventes.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] L'action d'une grande entreprise bien connue se négocie à raison de millions d'actions par jour, avec un écart acheteur-vendeur de quelques cents seulement — un investisseur peut généralement acheter ou vendre une position typique rapidement, avec un coût d'écart minime. L'action d'une petite entreprise peu négociée pourrait ne s'échanger qu'à raison de quelques milliers d'actions par jour habituel, avec un écart beaucoup plus large. [ASSUMPTION] Une investisseuse qui doit vendre une position importante dans cette action peu négociée pourrait constater que ses propres ventes font baisser le prix davantage qu'une vente comparable de l'action très liquide, simplement parce qu'il y a moins d'acheteurs disponibles pour absorber les actions au prix actuel.

## Quiz de pratique

1. Que décrit la liquidité dans le contexte d'un titre négocié?
2. Pourquoi une faible liquidité a-t-elle tendance à élargir l'écart acheteur-vendeur?
3. Pourquoi le risque de liquidité compte-t-il même pour un investisseur qui ne prévoit pas faire d'opérations fréquentes?

## Corrigé

1. La facilité avec laquelle un actif peut être acheté ou vendu sans influer de façon importante sur son prix, ce qui reflète généralement le niveau d'activité de négociation régulière sur ce titre.
2. Parce qu'avec moins d'acheteurs et de vendeurs actifs, l'écart entre ce que les acheteurs sont prêts à payer et ce que les vendeurs sont prêts à accepter a tendance à s'élargir, ce qui reflète une activité de négociation réduite.
3. Parce que vendre un jour une position peu négociée, surtout en grande quantité ou pendant une période de tension sur les marchés, peut obliger à accepter un prix moins avantageux ou à vendre plus graduellement, puisqu'il y a moins d'acheteurs disponibles pour absorber les actions.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. Ça explique le mécanisme précis qui relie la liquidité au coût de négociation.
3. Ça élargit la notion à l'investisseur à long terme, et pas seulement au négociateur actif, ce qui en accroît la pertinence.

## Points clés à retenir
- La liquidité décrit la facilité avec laquelle un titre peut être acheté ou vendu sans influer de façon importante sur son prix.
- Les titres peu négociés ont tendance à avoir des écarts acheteur-vendeur plus larges, un coût implicite de la négociation dans un marché moins liquide.
- Le risque de liquidité compte même pour les investisseurs à long terme, puisque vendre un jour une position importante ou peu négociée peut obliger à accepter un prix moins avantageux.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
