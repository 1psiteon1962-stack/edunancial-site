---
id: WHITE-L3-043
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 43
title: "Pourquoi les ordres au marché et les ordres à cours limité servent des buts différents"
summary: "Découvre la différence entre un ordre au marché et un ordre à cours limité, et pourquoi le bon choix dépend de ce que tu cherches réellement à contrôler."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-043 : Pourquoi les ordres au marché et les ordres à cours limité servent des buts différents

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer la différence entre un ordre au marché et un ordre à cours limité
- Expliquer pourquoi chaque type d'ordre privilégie une variable différente — la rapidité ou le prix
- Relier cette notion à la discussion sur la liquidité de la leçon 42

## Contenu principal

Un **ordre au marché** demande à un courtier d'acheter ou de vendre un titre immédiatement, au meilleur prix offert à ce moment-là. Un **ordre à cours limité** demande à un courtier d'acheter ou de vendre seulement à un prix précis ou à un meilleur prix, quitte à attendre pour être exécuté (ou à ne pas l'être du tout) si ce prix n'est pas offert.

Voici « pourquoi » le choix entre les deux dépend de ce que tu privilégies : un ordre au marché privilégie la rapidité et la certitude d'exécution — il sera presque toujours exécuté rapidement, mais tu ne connais pas le prix exact d'avance, surtout pour un titre moins liquide (ce qui se relie directement à la discussion sur l'écart acheteur-vendeur de la leçon 42) ou en période de mouvements rapides. Un ordre à cours limité privilégie le contrôle du prix — tu connais le pire prix que tu accepteras —, mais tu renonces à la certitude d'exécution, puisque l'ordre pourrait ne jamais être exécuté si le marché n'atteint pas le prix que tu as fixé.

[VERIFIED FACT] Pour les titres très liquides à faible écart acheteur-vendeur, la différence pratique entre un ordre au marché et un ordre à cours limité raisonnablement placé est souvent petite; la distinction devient plus importante pour les titres moins liquides, les ordres plus gros ou pendant les périodes de forte volatilité, où l'incertitude sur le prix d'un ordre au marché peut être plus grande.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse veut acheter des actions d'une entreprise peu négociée (comme dans l'exemple de la leçon 42). Un ordre au marché garantit que l'achat se fera rapidement, mais l'écart acheteur-vendeur plus large veut dire qu'elle pourrait payer un prix nettement plus élevé que ce que laissait croire le dernier cours. Un ordre à cours limité, fixé à un prix maximal précis qu'elle est prête à payer, la protège plutôt contre un prix d'exécution étonnamment élevé — mais si le prix de l'action s'éloigne de sa limite avant qu'assez d'actions soient offertes à ce prix, son ordre pourrait ne pas être exécuté du tout, et elle pourrait rater l'occasion d'acheter.

## Quiz de pratique

1. Quelle est la principale différence entre un ordre au marché et un ordre à cours limité?
2. Qu'est-ce qu'un ordre au marché privilégie, et à quoi renonce-t-il en échange?
3. Selon cette leçon, dans quels types de situations le choix entre un ordre au marché et un ordre à cours limité devient-il plus important?

## Corrigé

1. Un ordre au marché est exécuté immédiatement au meilleur prix offert; un ordre à cours limité est exécuté seulement à un prix précis ou à un meilleur prix, et pourrait ne pas être exécuté du tout.
2. Il privilégie la rapidité et la certitude d'exécution, et renonce à la certitude quant au prix d'exécution exact.
3. Les titres moins liquides, les ordres plus gros ou les périodes de forte volatilité — des situations où l'incertitude sur le prix d'un ordre au marché devient plus grande, ce qui se relie à la discussion sur la liquidité de la leçon 42.

## Réponses et explications

1. C'est la distinction de base de la leçon.
2. Ça précise le compromis propre aux ordres au marché.
3. Ça relie directement la décision sur le type d'ordre à la notion de liquidité de la leçon précédente.

## Points clés à retenir
- Un ordre au marché privilégie la rapidité et la certitude d'exécution plutôt que la certitude sur le prix.
- Un ordre à cours limité privilégie le contrôle du prix, mais comporte le risque de ne pas être exécuté du tout.
- Ce compromis devient particulièrement important pour les titres moins liquides, les gros ordres ou les marchés volatils.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
