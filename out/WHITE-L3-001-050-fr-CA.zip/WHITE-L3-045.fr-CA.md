---
id: WHITE-L3-045
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 45
title: "Pourquoi les rachats d'actions touchent les actionnaires différemment des dividendes"
summary: "Découvre comment un rachat d'actions remet de la valeur aux actionnaires autrement qu'un dividende, et pourquoi les effets sur l'impôt et le nombre d'actions diffèrent."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-045 : Pourquoi les rachats d'actions touchent les actionnaires différemment des dividendes

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce qu'est un rachat d'actions
- Expliquer comment un rachat remet de la valeur aux actionnaires autrement qu'un dividende
- Expliquer une différence clé, sur le plan fiscal, entre les deux approches

## Contenu principal

Un **rachat d'actions** se produit quand une société utilise sa propre trésorerie pour racheter ses propres actions sur le marché, ce qui réduit le nombre total d'actions en circulation. C'est un mécanisme différent des versements de dividendes abordés à la leçon 17 pour remettre de la valeur aux actionnaires.

Voici « pourquoi » l'effet d'un rachat diffère de celui d'un dividende : au lieu de distribuer directement de l'argent aux actionnaires (ce qui, comme l'a expliqué la leçon 17, correspond à une baisse à peu près équivalente du prix de l'action), un rachat réduit le nombre d'actions en circulation — ce qui veut dire que chaque action restante représente une part de propriété un peu plus grande dans la société. [VERIFIED FACT] Si la valeur globale et les bénéfices de la société restent les mêmes pendant que le nombre d'actions diminue, les principaux indicateurs par action, comme le bénéfice par action, ont tendance à augmenter, ce qui peut soutenir un prix d'action plus élevé, toutes choses égales par ailleurs.

Une différence importante, sur le plan fiscal, entre les deux approches : un dividende crée généralement un événement imposable immédiat pour l'actionnaire qui le reçoit (sous réserve des règles fiscales applicables), alors qu'un rachat ne crée pas directement d'événement imposable pour les actionnaires qui ne vendent pas — tout avantage se traduit par une augmentation possible de la valeur des actions restantes, que les actionnaires réalisent (et sur laquelle ils pourraient devoir payer de l'impôt) seulement s'ils choisissent de vendre, et au moment où ils le font.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une société a un bénéfice de 1 million de dollars et 1 million d'actions en circulation, soit un bénéfice par action de 1 $. Si elle utilise la trésorerie disponible pour racheter 100 000 actions, ce qui ramène le nombre d'actions à 900 000, ce même bénéfice de 1 million de dollars correspond maintenant à environ 1,11 $ par action — un chiffre plus élevé uniquement grâce à la réduction du nombre d'actions, en supposant que le bénéfice reste le même. Une actionnaire qui ne vend aucune action ne reçoit pas de versement en argent immédiat (contrairement à un dividende) et ne fait face à aucun événement imposable immédiat, mais ses actions existantes pourraient valoir un peu plus si le marché tient compte de l'amélioration des indicateurs par action.

## Quiz de pratique

1. Qu'est-ce qu'un rachat d'actions?
2. En quoi le mécanisme par lequel un rachat remet de la valeur diffère-t-il de celui d'un dividende?
3. Quelle est une différence clé, sur le plan fiscal, entre un rachat et un dividende pour un actionnaire qui ne vend pas?

## Corrigé

1. Une société qui utilise sa propre trésorerie pour racheter ses propres actions, ce qui réduit le nombre total d'actions en circulation.
2. Un dividende distribue directement de l'argent aux actionnaires (avec une baisse de prix correspondante, selon la leçon 17); un rachat réduit le nombre d'actions, ce qui augmente la part de propriété proportionnelle de chaque action restante sans distribution directe d'argent.
3. Un dividende crée généralement un événement imposable immédiat pour l'actionnaire; un rachat ne crée pas directement d'événement imposable pour un actionnaire qui ne vend pas, puisque tout avantage se traduit seulement par une augmentation possible de la valeur des actions qu'il détient encore.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. C'est la distinction mécanique centrale entre les deux approches, comparée directement à la leçon 17.
3. Ça met en lumière une différence pratique importante quant à la façon et au moment où l'impôt touche les actionnaires.

## Points clés à retenir
- Un rachat d'actions réduit le nombre d'actions en circulation, ce qui augmente la part de propriété proportionnelle de chaque action restante.
- C'est mécaniquement différent d'un dividende, qui distribue directement de l'argent avec un ajustement de prix correspondant.
- Contrairement aux dividendes, les rachats ne créent généralement pas d'événement imposable immédiat pour les actionnaires qui ne vendent pas.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Les règles fiscales varient beaucoup d'un pays à l'autre; consulte un fiscaliste autorisé pour obtenir des conseils adaptés à ta situation.
