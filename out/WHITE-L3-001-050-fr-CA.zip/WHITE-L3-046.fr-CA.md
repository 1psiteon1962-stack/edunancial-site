---
id: WHITE-L3-046
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 46
title: "Pourquoi le bêta mesure la volatilité d'une action par rapport au marché"
summary: "Découvre ce que mesure le bêta, pourquoi un bêta supérieur ou inférieur à 1,0 t'apprend quelque chose de précis sur le comportement attendu d'une action, et ce que le bêta ne mesure pas."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-046 : Pourquoi le bêta mesure la volatilité d'une action par rapport au marché

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Définir le bêta comme une mesure de volatilité relative
- Interpréter ce qu'un bêta supérieur, inférieur ou égal à 1,0 laisse généralement entendre
- Expliquer une limite du bêta comme mesure du risque

## Contenu principal

Le **bêta** est une mesure statistique qui décrit la façon dont le prix d'une action a eu tendance à évoluer par rapport à l'ensemble du marché — habituellement un indice de référence. Un bêta de 1,0 laisse entendre qu'une action a historiquement évolué à peu près comme le marché. Un bêta supérieur à 1,0 laisse entendre une volatilité historiquement plus grande que celle du marché (des mouvements plus prononcés dans le même sens que le marché); un bêta inférieur à 1,0 laisse entendre une volatilité historiquement moins grande que celle du marché.

Voici « pourquoi » ça peut être un outil utile, quoique limité : le bêta donne une façon rapide et normalisée de comparer à quel point différentes actions ont été sensibles aux mouvements généraux du marché — ce qui est utile pour réfléchir à la façon dont une action pourrait contribuer à la volatilité globale d'un portefeuille (en lien avec les notions de diversification et de corrélation des leçons 2 et 3).

[VERIFIED FACT] Le bêta est calculé à partir de données de prix historiques et reflète la volatilité relative passée, sans garantir le comportement futur — et il mesure précisément la sensibilité aux mouvements généraux du marché, et non le risque total d'une action, ce qui veut dire que deux actions qui ont le même bêta pourraient quand même avoir des profils de risque propres à l'entreprise très différents (leçon 2), que le bêta seul ne mesure pas.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] L'action A a un bêta de 1,5, ce qui laisse entendre qu'elle a historiquement évolué environ 50 % plus que l'ensemble du marché, dans un sens comme dans l'autre — si le marché monte de 10 %, l'action A pourrait historiquement avoir monté d'environ 15 %, et l'inverse lors d'une baisse. L'action B a un bêta de 0,6, ce qui laisse entendre des mouvements historiquement plus modérés par rapport au marché. [ASSUMPTION] Une investisseuse qui bâtit un portefeuille pourrait utiliser ces bêtas historiques comme un élément parmi d'autres pour réfléchir à la façon dont chaque action pourrait contribuer à la volatilité globale du portefeuille — tout en se rappelant que le bêta reflète des tendances passées et ne mesure pas les risques précis et individuels de chaque entreprise, distincts des mouvements généraux du marché.

## Quiz de pratique

1. Que mesure le bêta?
2. Qu'est-ce qu'un bêta supérieur à 1,0 laisse généralement entendre sur la volatilité historique d'une action par rapport au marché?
3. Quelle limite cette leçon relève-t-elle quant à l'utilisation du bêta comme mesure complète du risque?

## Corrigé

1. La façon dont le prix d'une action a eu tendance à évoluer par rapport à l'ensemble du marché, habituellement un indice de référence.
2. Que l'action a historiquement évolué avec une volatilité plus grande que le marché — avec des mouvements plus prononcés dans le même sens que ceux du marché.
3. Le bêta reflète précisément la volatilité relative passée par rapport aux mouvements généraux du marché, sans garantir le comportement futur, et il ne mesure pas le risque propre à l'entreprise, distinct de l'ensemble du marché.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. Ça confirme l'interprétation du seuil numérique précis.
3. C'est une mise en garde importante contre le fait de traiter le bêta comme une mesure complète du risque total d'une action.

## Points clés à retenir
- Le bêta mesure la volatilité historique d'une action par rapport à l'ensemble du marché, 1,0 représentant une volatilité égale à celle du marché.
- Un bêta supérieur à 1,0 laisse entendre une volatilité relative historiquement plus grande; un bêta inférieur à 1,0, une volatilité historiquement moindre.
- Le bêta reflète des tendances passées et précisément la volatilité liée au marché — il ne mesure pas le risque propre à l'entreprise et ne garantit pas le comportement futur.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Le rendement passé ne garantit pas les résultats futurs. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
