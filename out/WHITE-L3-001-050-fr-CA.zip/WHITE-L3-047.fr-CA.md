---
id: WHITE-L3-047
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 47
title: "Pourquoi diversifier entre catégories d'actifs, et pas seulement entre actions, réduit le risque d'un portefeuille"
summary: "Découvre pourquoi combiner des actions avec d'autres catégories d'actifs, comme les obligations ou l'immobilier, peut réduire le risque global d'un portefeuille d'une façon impossible avec une diversification limitée aux actions."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-047 : Pourquoi diversifier entre catégories d'actifs, et pas seulement entre actions, réduit le risque d'un portefeuille

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi diversifier entre catégories d'actifs s'attaque à un type de risque que la seule diversification entre actions ne peut pas régler
- Relier cette notion à la discussion sur la corrélation de la leçon 3
- Expliquer pourquoi combiner des actifs aux comportements historiquement différents peut adoucir le rendement global d'un portefeuille

## Contenu principal

Les leçons 2 et 3 ont abordé la diversification et la corrélation à l'intérieur d'une catégorie de placements semblables — surtout les actions. Cette leçon étend la même logique à un niveau plus large : diversifier entre des **catégories d'actifs** complètement différentes — actions, obligations, immobilier (les FPI de la leçon 32, par exemple), encaisse et autres.

Voici « pourquoi » ça s'attaque à un type de risque que la diversification limitée aux actions ne peut pas régler : même un portefeuille d'actions bien diversifié, réparti entre de nombreuses entreprises et de nombreux secteurs, reste exposé au risque de marché qui touche les actions en général (comme l'a établi la leçon 2) — une baisse générale du marché boursier touche presque toutes les actions en même temps, peu importe à quel point le choix des actions est diversifié. [VERIFIED FACT] Les différentes catégories d'actifs ont historiquement montré des relations variées entre elles, parfois faiblement ou négativement corrélées, selon les conditions de marché — les obligations, par exemple, ont parfois eu un comportement différent de celui des actions pendant des baisses du marché boursier, même si cette relation n'est ni fixe ni garantie et peut changer selon le contexte économique précis (en lien avec la discussion sur les cycles de taux de la leçon 43 du parcours RED).

Combiner des catégories d'actifs aux comportements vraiment différents, plutôt que de diversifier seulement à l'intérieur d'une catégorie d'actifs, s'attaque au risque de marché que la diversification limitée aux actions ne peut précisément pas réduire.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse détient un portefeuille bien diversifié de 50 actions différentes dans de nombreux secteurs. Pendant une baisse générale du marché boursier, presque tous ses titres baissent ensemble, puisque la baisse reflète un risque de marché contre lequel sa diversification en actions, aussi poussée soit-elle, ne peut pas la protéger. [ASSUMPTION] Si elle avait aussi réparti une partie de son portefeuille en obligations, et que ces obligations avaient eu un comportement différent pendant cette même baisse — comme ça s'est produit pendant certaines périodes historiques —, la baisse globale de son portefeuille aurait pu être nettement plus petite que celle d'un portefeuille composé uniquement d'actions, même extrêmement bien diversifié à l'intérieur de la seule catégorie des actions.

## Quiz de pratique

1. À quel type de risque la diversification entre catégories d'actifs s'attaque-t-elle, alors que la diversification limitée aux actions ne le peut pas?
2. Pourquoi même un portefeuille d'actions très bien diversifié peut-il quand même subir des baisses importantes pendant une baisse générale du marché?
3. La relation entre le rendement des différentes catégories d'actifs pendant une baisse est-elle fixe et garantie? Pourquoi?

## Corrigé

1. Le risque de marché — le risque qui touche toute une catégorie d'actifs (comme les actions) de façon générale, peu importe à quel point les titres individuels de cette catégorie sont diversifiés.
2. Parce que le risque de marché touche presque toutes les actions en même temps, et que la diversification entre actions s'attaque surtout au risque propre aux entreprises (leçon 2), et non à ce risque plus large lié au marché.
3. Non — le rendement relatif des différentes catégories d'actifs dans diverses conditions de marché a varié historiquement et n'est ni fixe ni garanti, de sorte qu'il faut voir cet avantage comme une tendance historique, et non comme un résultat assuré.

## Réponses et explications

1. C'est la distinction centrale autour de laquelle la leçon est construite, qui étend le cadre des leçons 2 et 3 à une plus grande échelle.
2. Ça renforce directement la notion de risque de marché présentée pour la première fois à la leçon 2.
3. C'est une mise en garde importante et nuancée contre un excès de confiance dans les relations historiques entre catégories d'actifs.

## Points clés à retenir
- Diversifier entre catégories d'actifs s'attaque au risque de marché, ce que la diversification à l'intérieur d'une seule catégorie d'actifs (comme les actions) ne peut pas faire.
- Les différentes catégories d'actifs ont historiquement montré des corrélations variées entre elles, parfois faibles ou négatives, selon les conditions.
- Cette relation n'est ni fixe ni garantie, et peut changer selon le contexte économique général.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Le rendement passé ne garantit pas les résultats futurs. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
