---
id: WHITE-L3-048
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 48
title: "Pourquoi la taille des positions détermine à quel point un seul mauvais pari peut te nuire"
summary: "Découvre pourquoi le montant que tu investis dans une seule position compte autant que la qualité de l'idée, et pourquoi la taille des positions est une forme de contrôle du risque."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-048 : Pourquoi la taille des positions détermine à quel point un seul mauvais pari peut te nuire

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer ce que veut dire la taille des positions
- Expliquer pourquoi une bonne idée de placement peut quand même nuire à un portefeuille si la position est trop grande
- Relier cette notion à l'idée d'ajustement du risque par fractions d'actions utilisée ailleurs dans ce programme

## Contenu principal

La **taille des positions** désigne la part d'un portefeuille consacrée à un seul placement. C'est une décision distincte de la question de *quels* placements choisir — même une excellente idée de placement peut créer un risque démesuré pour un portefeuille si une trop grande part du capital total y est engagée.

Voici « pourquoi » la taille des positions est une forme de contrôle du risque à part entière, distincte de la qualité du choix des placements : aucune thèse de placement, aussi bien documentée soit-elle, n'est garantie de fonctionner — des événements inattendus, une nouvelle information ou simplement la malchance peuvent toucher même une position choisie avec soin. Si cette position représente une petite partie d'un portefeuille, un résultat décevant est un revers gérable. Si elle en représente une très grande partie, le même résultat décevant peut nuire sérieusement à tout le portefeuille, peu importe à quel point le raisonnement de départ était solide.

[VERIFIED FACT] Ça se relie à un principe plus large utilisé ailleurs dans ce programme, qui consiste à structurer le risque de façon à ce que les pertes soient réelles et ressenties, pour qu'elles enseignent de vraies leçons, sans jamais devenir catastrophiques pour la situation financière globale — la taille des positions est l'un des outils les plus directs et les plus contrôlables dont dispose un investisseur pour garder la perte possible d'une seule position dans une fourchette tolérable.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse repère ce qu'elle croit être une excellente occasion de placement après une recherche approfondie. Si elle y consacre 5 % de son portefeuille et que ça tourne mal — même s'il s'agissait d'une perte totale sur cette position —, les dommages à son portefeuille global sont limités et récupérables. [ASSUMPTION] Si elle consacre 50 % de son portefeuille à la même idée, sur la base de la même recherche et de la même conviction, ce même mauvais résultat pourrait faire reculer sérieusement toute sa situation financière — la qualité de l'idée de départ n'a pas changé, mais la taille de la position a changé de façon spectaculaire à quel point ce résultat précis pouvait lui nuire.

## Quiz de pratique

1. Que désigne la taille des positions?
2. Pourquoi même une idée de placement bien documentée peut-elle créer un risque démesuré pour un portefeuille?
3. Comment la taille des positions sert-elle d'outil de contrôle du risque, distinct du choix des placements?

## Corrigé

1. La part d'un portefeuille consacrée à un seul placement.
2. Parce qu'aucune thèse de placement n'est garantie de fonctionner, et que si une position qui performe mal représente une trop grande part du portefeuille, les dommages qui en résultent peuvent être importants, peu importe à quel point le raisonnement de départ était solide.
3. En limitant à quel point le résultat d'une seule position — bon ou mauvais — peut influer sur le portefeuille global, la taille des positions contrôle directement la perte possible, indépendamment de la qualité du choix de placement lui-même.

## Réponses et explications

1. C'est la définition de base de la leçon.
2. C'est l'idée centrale de gestion du risque autour de laquelle la leçon est construite.
3. Ça renforce le fait que la taille des positions et le choix des placements sont deux décisions distinctes, toutes deux importantes.

## Points clés à retenir
- La taille des positions détermine la part d'un portefeuille consacrée à un seul placement.
- Même une idée bien documentée peut causer des dommages démesurés au portefeuille si la position est trop grande, peu importe le raisonnement qui la sous-tend.
- La taille des positions est un outil de gestion du risque direct et contrôlable, distinct de la qualité du choix des placements lui-même.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
