---
id: WHITE-L3-049
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 49
title: "Pourquoi un plan de placement écrit te protège de tes propres émotions"
summary: "Découvre pourquoi mettre ton plan de placement par écrit à l'avance te protège contre les erreurs comportementales vues tout au long de ce parcours, commises sous le coup de l'émotion."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-049 : Pourquoi un plan de placement écrit te protège de tes propres émotions

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer le but général d'un plan de placement écrit
- Expliquer pourquoi décider des choses à l'avance protège contre des décisions émotionnelles prises sur le moment
- Résumer comment ce plan rassemble plusieurs notions comportementales vues plus tôt dans ce parcours

## Contenu principal

Ce parcours a abordé plusieurs façons précises dont les émotions et la psychologie peuvent fausser les décisions de placement : l'aversion aux pertes (leçon 27), le biais de récence (leçon 28), le fait de courir après le rendement (leçon 25) et l'écart comportemental plus large qu'ils créent ensemble (leçon 26). Un **plan de placement écrit** — parfois appelé énoncé de politique de placement — est un outil pratique conçu pour contrer tous ces biais à la fois.

Voici « pourquoi » il est important de mettre un plan par écrit à l'avance : les décisions prises calmement, d'avance, avant qu'un événement de marché précis ait déclenché une réaction émotionnelle, ont tendance à mieux correspondre aux vrais objectifs à long terme d'un investisseur que les décisions prises en réaction, au milieu d'une baisse stressante ou d'une hausse grisante. Un plan écrit — qui précise la répartition de l'actif cible (leçon 34), les règles de rééquilibrage (leçon 14) et des critères généraux pour acheter ou vendre — donne à l'investisseur un point de référence établi d'avance auquel revenir, plutôt que d'improviser une réaction pendant que les émotions sont à leur comble.

[VERIFIED FACT] Cette approche n'élimine pas l'expérience émotionnelle de la volatilité des marchés, mais elle peut réduire la probabilité d'agir sous le coup de cette émotion d'une façon qui contredit les objectifs et la stratégie que l'investisseur avait lui-même énoncés auparavant, après une réflexion calme.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse rédige un plan de placement pendant une période calme, en précisant sa répartition de l'actif cible, son intention de rééquilibrer chaque année et les critères qu'elle utilisera avant d'apporter tout changement important à sa stratégie. [ASSUMPTION] Des mois plus tard, pendant une forte baisse du marché, elle ressent une forte envie de tout vendre et de passer à l'encaisse. Le fait de revenir à son plan écrit — rédigé avant ce moment émotionnel précis — lui rappelle son raisonnement d'origine à long terme et ses règles de rééquilibrage, ce qui pourrait l'aider à éviter une décision réactive que sa version plus calme d'avant avait justement prévue et s'était engagée à refuser.

## Quiz de pratique

1. Quel est le but général d'un plan de placement écrit?
2. Pourquoi les décisions prises calmement à l'avance ont-elles tendance à mieux correspondre aux objectifs à long terme que les décisions prises en réaction, sur le moment?
3. Nomme deux notions comportementales précises, vues plus tôt dans ce parcours, qu'un plan écrit est conçu pour aider à contrer.

## Corrigé

1. Servir de point de référence établi d'avance qui précise la répartition cible, les règles de rééquilibrage et les critères de décision d'un investisseur, afin de guider son comportement de façon constante dans le temps.
2. Parce que les décisions prises en réaction, pendant un événement de marché stressant ou grisant, risquent davantage d'être influencées par l'émotion (aversion aux pertes, biais de récence) que par les vrais objectifs à long terme de l'investisseur, réfléchis calmement.
3. Deux parmi les suivantes : l'aversion aux pertes, le biais de récence, le fait de courir après le rendement, l'écart comportemental plus large.

## Réponses et explications

1. C'est le but de base autour duquel la leçon est construite.
2. C'est le raisonnement psychologique central qui explique la valeur de la planification à l'avance.
3. Ça vérifie si l'apprenant peut rassembler des notions de plusieurs leçons précédentes dans cet outil final et intégrateur.

## Points clés à retenir
- Un plan de placement écrit sert de point de référence établi d'avance pour la répartition, le rééquilibrage et les critères de décision.
- Les décisions prises calmement à l'avance ont tendance à mieux correspondre aux objectifs à long terme que les décisions réactives, dictées par l'émotion.
- Cet outil s'attaque directement à plusieurs notions comportementales vues tout au long de ce parcours, dont l'aversion aux pertes, le biais de récence et le fait de courir après le rendement.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
