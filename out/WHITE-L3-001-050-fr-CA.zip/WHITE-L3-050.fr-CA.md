---
id: WHITE-L3-050
track: WHITE
officialTrackName: "Paper Assets"
level: 3
lessonNumber: 50
title: "Pourquoi maîtriser les actifs papier, c'est savoir ce qu'on n'a pas besoin de prédire"
summary: "La leçon de clôture de ce parcours — pourquoi la vraie compétence en placement dans les actifs papier consiste à bâtir un plan qui tient compte de l'incertitude, et non à deviner le prochain mouvement du marché."
version: "1.0"
author: "Waldemar M. Caban, JD MA"
date: "2026-10-28"
locale: "fr-CA"
source_locale: "en-US"
---
# WHITE-L3-050 : Pourquoi maîtriser les actifs papier, c'est savoir ce qu'on n'a pas besoin de prédire

## Objectifs d'apprentissage
À la fin de cette leçon, tu pourras :
- Expliquer pourquoi ce parcours a insisté à plusieurs reprises sur la structure et la discipline plutôt que sur la prédiction
- Nommer plusieurs outils de ce parcours qui réduisent la dépendance à la prédiction du prochain mouvement du marché
- Résumer le fil conducteur central qui relie les 50 leçons de ce parcours

## Contenu principal

Ce parcours a commencé en reconnaissant à quel point « acheter bas, vendre haut » est difficile à appliquer (leçon 1), précisément parce qu'il faut pour ça prédire correctement quelque chose que personne ne peut prédire de façon fiable : le prochain mouvement du marché. Il se termine par un changement de perspective volontaire, en écho à la leçon de clôture du parcours RED : maîtriser les actifs papier, ce n'est pas d'abord apprendre à mieux prédire les marchés — c'est bâtir une structure qui réduit à quel point ton succès dépend réellement de la prédiction.

Regarde l'ensemble de ce parcours : la diversification et la corrélation (leçons 2 et 3) réduisent la dépendance au fait de bien choisir les gagnants individuels. L'achat périodique par sommes fixes et le rééquilibrage (leçons 12 et 14) réduisent la dépendance au fait de bien choisir le moment d'entrer et de sortir. La répartition de l'actif et les trajectoires de répartition (leçons 34 et 35) réduisent la dépendance au fait de bien prévoir quelle catégorie d'actifs fera mieux une année donnée. Le placement indiciel (leçon 23) élimine la dépendance au fait de bien choisir un gestionnaire actif. Un plan de placement écrit (leçon 49) réduit la dépendance au fait de rester rationnel en temps réel, exactement aux moments où la rationalité est la plus difficile à garder.

[VERIFIED FACT] Aucun de ces outils n'élimine l'incertitude sur l'avenir — les marchés restent réellement imprévisibles à court terme. Ce qu'ils font, c'est réduire à quel point le résultat d'un investisseur dépend du fait de deviner correctement ce parcours imprévisible à court terme.

## Exemple pratique

[ILLUSTRATIVE EXAMPLE] Une investisseuse qui a intégré tout ce parcours bâtit un portefeuille fondé sur une répartition générale de l'actif entre actions, obligations et autres catégories d'actifs (leçons 34 et 47), en grande partie au moyen de fonds indiciels à faibles coûts (leçon 23), investis par une combinaison d'achat périodique par sommes fixes et de rééquilibrage périodique (leçons 12 et 14), avec des positions de taille telle qu'aucune position ni aucun pari ne soit assez gros pour être catastrophique (leçon 48), le tout guidé par un plan écrit rédigé pendant une période calme (leçon 49). Elle ne sait pas ce que fera le marché l'an prochain — personne ne le sait de façon fiable —, mais son approche n'a pas besoin de cette connaissance pour fonctionner raisonnablement bien sur son véritable horizon de placement.

## Quiz de pratique

1. Quel changement de perspective central cette leçon de clôture propose-t-elle sur ce que veut dire « maîtriser » les actifs papier?
2. Nomme trois outils de ce parcours qui réduisent précisément la dépendance au fait de bien prédire les mouvements du marché.
3. Cette approche élimine-t-elle l'incertitude sur le rendement futur des marchés? Pourquoi?

## Corrigé

1. Que la maîtrise consiste à bâtir une structure qui réduit à quel point ton succès dépend de la prédiction, plutôt qu'à apprendre à prédire les marchés avec plus de précision.
2. Trois parmi les suivants : la gestion de la diversification et de la corrélation, l'achat périodique par sommes fixes, le rééquilibrage, la répartition de l'actif, les trajectoires de répartition, le placement indiciel, un plan de placement écrit.
3. Non — les marchés restent réellement imprévisibles à court terme; ces outils réduisent à quel point le résultat d'un investisseur dépend du fait de deviner correctement ce parcours imprévisible, plutôt que d'éliminer l'incertitude elle-même.

## Réponses et explications

1. C'est la thèse centrale de la leçon de clôture, qui recadre le but de tout le parcours.
2. Ça vérifie si l'apprenant peut rassembler des outils précis enseignés séparément dans de nombreuses leçons précédentes.
3. Ça termine le parcours par un énoncé honnête et nuancé — le but est la résilience face à l'incertitude, et non son élimination.

## Points clés à retenir
- La vraie maîtrise du placement dans les actifs papier consiste à bâtir une structure qui réduit la dépendance à la prédiction du prochain mouvement du marché, et non à améliorer la prédiction elle-même.
- La diversification, l'achat périodique par sommes fixes, le rééquilibrage, la répartition de l'actif, le placement indiciel et un plan écrit réduisent chacun la dépendance à un type différent de prédiction.
- Cette approche n'élimine pas l'incertitude des marchés — elle change à quel point le succès d'un investisseur dépend du fait de deviner correctement un parcours à court terme intrinsèquement imprévisible.

## Avis pédagogique
Cette leçon sert uniquement à l'éducation financière générale et ne constitue pas un conseil financier, de placement, fiscal ou juridique personnalisé. Consulte un professionnel de la finance autorisé avant de prendre des décisions de placement.
